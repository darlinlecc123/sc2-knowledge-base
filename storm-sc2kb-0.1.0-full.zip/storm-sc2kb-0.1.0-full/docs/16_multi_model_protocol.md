# 步骤 16：多模型标准化评测协议

## 1. 当前状态

- 状态：**DeepSeek 三条件评测已完成；其他模型尚未执行。**
- 日期：2026-09-05。
- 已完成：模型矩阵、三种实验条件、统一指标、失败分类、输出契约、DeepSeek 凭证 smoke、脱敏响应诊断、客户端元数据修复、2000-token 复杂题 smoke，以及正式参数的 challenge v0.3 RAG 复测。
- 尚未执行：GPT-5.6 Luna、其他兼容模型、SC2 运行和 LLM judge。
- 首次 41 题 DeepSeek RAG 运行使用了 `deepseek_v4_flash_smoke.yaml` 的 800-token 输出上限，与本协议统一参数 2000 不一致；该结果只保留为故障审计，不纳入正式横向比较。

凭证仅从环境变量读取，诊断文件只保存字段结构、长度、结束原因和 usage，不保存提示词、模型正文或密钥。修复后的正式 DeepSeek 配置为 `knowledge/evals/configs/deepseek_v4_flash_formal.yaml`。

## 2. 实验目标

在同一冻结问题集、同一知识库版本、同一生成参数和同一回答 Schema 下，对不同模型比较三种知识条件：

1. **no_knowledge_base**：不给知识库，只给问题和回答契约；
2. **full_context**：一次提供完整静态上下文，不执行检索；
3. **retrieval_augmented**：先进行本地混合检索，再把命中的变量记录交给模型。

目标不是比较模型的一般 StarCraft 常识，而是检查模型能否根据自然语言准确找到当前 STORM V0.1 中的变量，并给出物理含义、接口形式和源码证据。

## 3. 固定输入

| 项目 | 固定值 |
|---|---|
| 知识库版本 | `0.1.0` |
| 问题集 | `knowledge/evals/questions_challenge_v0.3.jsonl` |
| 题数 | 41 |
| benchmark 版本 | `0.3.0` |
| SHA-256 | `e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044` |
| temperature | 0 |
| max output tokens | 2000 |
| repeats | 1 |
| 题目顺序 | JSONL 原始顺序 |
| LLM judge | 关闭 |

challenge v0.3 已经完成唯一一次离线检索盲测。步骤 16 不修改该题集，也不能覆盖此前的首次盲测结果。

## 4. 模型槽位

`knowledge/evals/configs/model_matrix.yaml` 只保存环境变量名称，不保存密钥：

- `deepseek_v4_flash`：`deepseek-v4-flash`，`https://api.deepseek.com`；
- `gpt_5_6_luna`：`gpt-5.6-luna`，`https://api.openai.com/v1`；
- `compatible_optional`：未选择的可选兼容模型。

用户已授权前两个模型，配置仍保持 `enabled: false`，防止误触发批量调用。DeepSeek 已完成凭证 smoke、脱敏诊断和修复后复杂题 smoke；OpenAI 密钥环境变量当前仍缺失。

## 5. 三种条件的公平性

### 5.1 no_knowledge_base

模型只能看到：

- 原始自然语言问题；
- 标准 JSON 输出字段；
- 不得伪造源码证据的事实边界。

它不能看到变量表、别名表、完整上下文或本地检索结果。该条件衡量模型自身已有知识，但不能把其回答当作仓库事实。

### 5.2 full_context

模型看到：

- 与 no-KB 相同的问题和回答契约；
- `knowledge/context/sc2_raw_api_context_full.md` 的完整内容。

不先执行搜索。必须记录上下文是否超过模型限制；若超限，不得偷偷截断后仍标记为 full context，而应把该单元记为配置失败。

### 5.3 retrieval_augmented

使用当前 `QAAgent`：

- 本地检索策略：`hybrid_local`；
- `top_k=8`；
- `context_tier=standard`；
- 模型只能引用检索候选中的变量；
- grounding 来自知识库记录及源码证据。

## 6. 当前程序能力边界

现有 `knowledge/evals/run_evaluation.py` 已支持：

- 一个问题集上重复传入多个 OpenAI-compatible 模型配置；
- RAG 条件下的真实调用；
- dry-run、mock、断点续跑、确定性评分和运行清单。

但它目前把 live 模式固定连接到 `QAAgent`，因此只原生覆盖 **retrieval_augmented**。它不能把 no-KB 和完整上下文条件伪装成 RAG 的不同 `context_tier`：`full` 档位仍然是“检索后返回完整记录”，不等于“把整个知识库一次性给模型”。

因此，在真实三条件实验前还需要一个步骤 16 专用运行器，或对评测器增加显式的 `--knowledge-condition`。未经授权时，本轮不实现并试跑远程调用，也不制造空的真实结果文件。

## 7. 结果文件契约

只有真实调用发生后才创建：

### `raw_answers.jsonl`

每行至少包含：

- `run_id`、`model_id`、`actual_model`、`condition_id`；
- `question_id`、原始回答、解析后回答；
- HTTP/API 是否成功、重试次数；
- 延迟、token、费用（接口不返回时为 `null`）；
- 非敏感参数和代码/题集哈希。

### `scores.json`

按“模型 × 条件”汇总所有确定性指标，并保留题型和行为类型分组。

### `report.md`

报告必须区分：

- 真实运行结果；
- planned 或未执行单元；
- 接口没有返回的 token/费用；
- 需要人工复核的自由文本答案。

## 8. 失败分类

| 分类 | 判定说明 |
|---|---|
| `retrieval_error` | RAG 未找到目标变量、漏掉组合字段或返回无关候选 |
| `layer_error` | 命中了相同概念但选错 Raw/TBox/ABox/派生/动作/指标层 |
| `evidence_error` | 变量可能正确，但 evidence ID、源码路径或 symbol 缺失/错误 |
| `hallucination` | 输出知识库没有依据的变量、接口、运行事实或官方语义 |
| `format_error` | 非合法 JSON、缺少必需字段或字段类型错误 |
| `refusal_error` | 范围内问题错误拒答，或范围外问题没有拒答 |

同一道题允许多个失败标签，不能为了让统计相加等于题数而强制单选。

## 9. 授权后的执行顺序

1. 用户给出明确的总费用上限或最大 API 调用次数；
2. 更新矩阵中相应槽位为 `enabled: true`，填写 `actual_model` 与 `actual_interface`；
3. 只检查环境变量是否存在，不输出其值；
4. 验证 challenge v0.3 SHA-256；
5. 创建全新、不可覆盖的运行目录；
6. 先用 1 道非 challenge 的 smoke case 检查格式和接口；
7. 固定代码后执行 41 题 × 模型数 × 3 条件；
8. 保存原始回答后再评分，禁止边运行边调规则；
9. 生成结果报告，并再次核验题集和核心代码哈希。

## 10. 明确未执行项

截至本协议生成时：

- DeepSeek V4 Flash：已执行凭证 smoke、一次参数不合规的 41 题 RAG 故障审计、一次脱敏诊断、一次修复后非 challenge 复杂题 smoke，以及一次正式 2000-token 的 challenge v0.3 RAG 协议复测；
- GPT-5.6 Luna：已授权，但当前缺少 `OPENAI_API_KEY`，未调用；
- 其他 OpenAI-compatible 模型：未调用；
- 统一三条件多模型结果目录：未创建；
- API 成功率、延迟、token、费用：无真实数据；
- 三条件效果排序：未知，不能推测。

## 10. DeepSeek RAG 正式参数复测（2026-09-04）

- 运行 ID：`20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest`
- 条件：`retrieval_augmented`，`context_tier=standard`
- 参数：`temperature=0`、`max_output_tokens=2000`、`max_retries=0`
- 题集：challenge v0.3，41 题，SHA-256 与冻结清单一致
- 调用：26 次真实模型调用，15 题本地短路
- 结果：12 个可采纳回答，14 个 `model_error`，模型调用成功率 46.15%
- 主要错误：9 个输出截断且无最终正文、4 个非法 JSON、1 个候选变量越界
- 端到端：`behavior_accuracy=0.292683`，`status_accuracy=0.292683`
- Token：接口报告总计 117,021；费用仍为 `null`
- 报告：`knowledge/reports/deepseek_challenge_v0.3_rag_protocol_retest_20260904.md`
- 边界：这是协议修复后的复测，不是首次盲测；完整多模型三条件矩阵仍未完成。



## 11. DeepSeek 三条件正式评测（2026-09-05）

### 11.1 统一参数

- 模型：`deepseek-v4-flash`
- 题集：challenge v0.3，41 题，SHA-256 为 `e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044`
- 参数：`temperature=0`、`thinking=disabled`、`json_mode=false`、`max_output_tokens=2000`、`max_retries=0`
- 本轮不是首次离线盲测，也不与 2026-09-04 默认 thinking 的旧 RAG 结果视为同参数复现。

### 11.2 full-context 的实际实现

本轮 `full_context` 使用：

`knowledge/context/sc2_raw_api_context_full_compact_v2.jsonl`

它满足：

- 来源为 `knowledge/context/variables.jsonl`；
- 135/135 变量 ID 全覆盖且顺序保持；
- 不使用检索；
- 不按问题裁剪；
- 不截断；
- 只压缩重复结构和字段名；
- 不等于原始 Markdown 上下文的逐字副本，因此报告标签必须写作 `full_compact_context`。

对应 manifest：`knowledge/context/sc2_raw_api_context_full_compact_v2_manifest.json`。

### 11.3 输出兼容规则

DeepSeek 在 no-KB/full-context 下倾向返回完整 YAML，而 RAG 多为原生 JSON。运行器仅允许两类结果：

1. 严格 JSON 对象；
2. 单段、字段白名单内、无思维链标记的确定性 YAML 映射恢复。

观测到的 `_status` 仅在值属于 `answered|ambiguous|not_found` 且 `response_status` 缺失时，一对一恢复为 `response_status`。所有恢复均记录 `format_repaired=true`，不得静默处理。

### 11.4 结果摘要

| 条件 | 行为准确率 | 有效响应 | 模型错误 | 总 tokens |
|---|---:|---:|---:|---:|
| no_knowledge_base | 14.63% | 31/41 | 10 | 20,301 |
| full_compact_context | 90.24% | 40/41 | 1 | 1,214,822 |
| retrieval_augmented | 58.54% | 24/26 模型调用 | 2 | 82,502 |

完整分析：`knowledge/evals/analysis/20260905_deepseek_three_conditions/report.md`。
