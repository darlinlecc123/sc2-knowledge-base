# 步骤 07：自然语言别名与查询词典

- 报告日期：2026-09-03
- 范围：步骤五和步骤六的135条正式变量
- 状态：静态别名与查询规则已生成；未调用外部LLM、未挖掘外部语料

## 1. 一句话结论

步骤七把研究者可能使用的中文、英文、代码名、缩写、口语和论文表达映射到稳定变量ID；如果一个词可能指向多个层级，检索器必须返回候选和澄清问题，不能擅自选择。

## 2. 正式输出

- `knowledge/retrieval/aliases.yaml`：逐变量别名卡片、歧义组和反向alias_index
- `knowledge/retrieval/query_patterns.yaml`：五类查询意图、路由规则和每变量查询模板
- `knowledge/docs/07_alias_guide.md`：本说明文档

## 3. 数量统计

| 项目 | 数量 |
|---|---:|
| 正式变量 | 135 |
| 逐变量可检索表达总数 | 1180 |
| 规范化反向索引词 | 1096 |
| 自动识别的歧义索引词 | 57 |
| 人工高风险歧义组 | 12 |
| 有口语别名的变量 | 79 |
| 有缩写的变量 | 5 |
| 有错误叫法纠正规则的变量 | 92 |

## 4. 别名卡片结构

每个变量保留`chinese`、`english`、`code`、`abbreviations`、`colloquial`和`paper_terms`六类安全别名；`common_mistakes`单独保存，采用correction-only策略，不把错误叫法当成已确认的同义词，也不会因此创建新变量。

## 5. 歧义处理规则

1. 稳定变量ID精确匹配时直接检索。
2. 一个规范化别名只命中一个变量时返回该变量及证据。
3. 命中多个变量时返回全部候选、来源层和`clarification_question`。
4. 只命中错误叫法时先纠正，不静默重定向。
5. 没有候选时返回超出范围或未找到，不补造PySC2字段。

### 高风险歧义组

| 组 | 表面词 | 候选数 | 必须追问 |
|---|---|---:|---|
| `ambiguity.alliance` | alliance、敌我关系、阵营编码 | 2 | 你要查询PySC2原始阵营编码，还是写入ABox实例后的阵营字段？ |
| `ambiguity.armor` | armor、护甲 | 2 | 你指TBox静态类型护甲，还是当前代码中实际接收shield值的ABox armor字段？ |
| `ambiguity.enemy_count` | enemy_count、敌军数量 | 2 | 你指写入BattlefieldGraph的敌军节点计数，还是战术摘要中的敌军数量？ |
| `ambiguity.function_id` | function_id、函数编号 | 5 | 你要查询ATTACK、BUILD、MOVE、NO_OP还是TRAIN对应的FunctionCall编号？ |
| `ambiguity.health_absolute` | hp、生命值、血量 | 3 | 你要查询的是PySC2当前观测生命值、TBox兵种类型生命值，还是ABox单位实例生命值？ |
| `ambiguity.health_ratio` | hp ratio、生命比例、血量比例 | 4 | 你要查询单个RawUnit比例、ABox实例比例，还是友军/敌军聚合平均比例？ |
| `ambiguity.planned_actions` | planned_actions、计划动作 | 2 | 你指计划动作数量指标，还是传给SWM的候选动作列表？ |
| `ambiguity.score` | score、分数、得分 | 4 | 你指决策间增量、TimeStep累计得分、单episode最终得分，还是多episode平均得分？ |
| `ambiguity.step` | step、步数、步长 | 5 | 你指SC2环境步进倍率、ABox更新计数、动作延迟步，还是SWM预测相对步/预测长度？ |
| `ambiguity.tag` | tag、单位标签 | 3 | 你指RawUnit实例tag、ABox节点保存的tag，还是FunctionCall的unit_tags参数？ |
| `ambiguity.target` | target、目标 | 3 | 你指ABox关系目标节点、LLM动作目标，还是PySC2 FunctionCall目标参数？ |
| `ambiguity.unit_type` | unit type id、单位类型编号 | 3 | 你要查询RawUnit观测类型编号、TBox类型声明，还是ABox实例携带的类型编号？ |

## 6. health与health_ratio严格分离

`raw_unit.health`表示当前绝对生命值；`raw_unit.health_ratio`表示归一化比例。宽泛的“血量”“HP”会进入绝对生命值的多层候选，而“生命比例”“health ratio”进入比例候选。知识库不会因为名字相似把绝对值和比例合并成同一个物理量。

```text
“单位当前血量” → raw_unit.health
“单位血量百分比” → raw_unit.health_ratio
“图中单位血量” → abox.unit.hp
“友军平均血量” → derived.tactical.friendly_avg_hp
```

## 7. 五类查询模式

- `interface_query`：接口形式、数据类型、形状、单位和访问路径；
- `physical_meaning_query`：物理含义、数据层和真值边界；
- `source_location_query`：`.py`源码路径、函数、证据行和消费者；
- `formula_query`：上游变量、归一化、聚合、阈值或映射公式；
- `range_query`：范围、枚举、单位以及仍需验证的边界。

`query_patterns.yaml`为135个变量分别生成上述五类模板，合计675个意图槽位，每个槽位提供两种自然语言问法。

## 8. 检索响应建议

Agent回答时至少返回：命中的稳定变量ID、来源层、直接答案、证据ID、源码位置和可信边界。若歧义，则先列候选并提问，不能把TBox类型属性、RawUnit当前观测、ABox实例值和派生战术量混写。

## 9. 典型纠错

- “最大生命值”不能直接映射为`raw_unit.health`，因为当前字段是观测到的当前生命值；
- `tag`是单位实例标识，`unit_type`是单位类型编号；
- `action.delay_steps`不是`pysc2.function.queued`；
- ABox的`armor/armor_ratio`在当前代码中实际接收RawUnit的`shield/shield_ratio`；
- SWM预测状态不是下一时刻环境真值；
- 历史平均分不是当前单episode得分。

## 10. 验证边界

- 未启动StarCraft II；
- 未调用外部LLM测试自然语言命中率；
- 未挖掘搜索日志、论文语料或用户查询语料；
- 所有正式变量ID严格来自步骤五，未添加当前代码不存在的变量；
- 口语和论文表达是检索工程表达，实际召回率需要在后续自动化测试中验证。
