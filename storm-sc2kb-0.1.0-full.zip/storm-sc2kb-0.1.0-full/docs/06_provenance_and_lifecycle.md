# 步骤 06：变量来源、生命周期与可信度

- 报告日期：2026-09-03
- 范围：步骤五的135条正式变量卡片
- 状态：静态血缘分析完成；SC2运行时、外部模型和实验复现未执行

## 1. 一句话结论

本步骤没有新增PySC2字段，而是把步骤五的每个变量放回真实数据流：说明它从哪里产生、何时刷新、能保留多久、由谁消费，以及当前证据只能证明接口还是已经证明运行值。

## 2. 输入与输出

- `knowledge/variables/raw_api.yaml`：26条
- `knowledge/variables/tbox.yaml`：19条
- `knowledge/variables/abox.yaml`：28条
- `knowledge/variables/derived.yaml`：13条
- `knowledge/variables/actions.yaml`：21条
- `knowledge/variables/swm.yaml`：13条
- `knowledge/variables/metrics.yaml`：15条

输出：
- `knowledge/lineage/variable_lineage.yaml`：逐变量机器可读血缘表
- `knowledge/docs/06_provenance_and_lifecycle.md`：本说明文档

## 3. 来源层数量统计

| Schema source_layer | 步骤四规范层 | 数量 |
|---|---|---:|
| `abox_runtime` | `runtime_abox` | 29 |
| `derived_runtime` | `derived_runtime` | 15 |
| `environment_config` | `environment_config` | 9 |
| `executor_mapping` | `executor_mapped` | 9 |
| `experiment_aggregate` | `experiment_aggregated` | 15 |
| `llm_output` | `llm_output` | 3 |
| `pysc2_raw_observation` | `raw_observation` | 8 |
| `pysc2_timestep` | `raw_observation` | 6 |
| `raw_unit_transformed` | `raw_observation` | 2 |
| `swm_prediction` | `model_predicted` | 9 |
| `tbox_static` | `static_ontology` | 19 |
| `validated_action` | `parser_validated` | 11 |

## 4. 值类型统计

| value_class | 数量 |
|---|---:|
| `configuration` | 9 |
| `cross_frame_state` | 2 |
| `executor_mapped` | 9 |
| `experiment_aggregated` | 15 |
| `llm_generated` | 3 |
| `model_predicted` | 9 |
| `observation_value` | 16 |
| `parser_validated` | 11 |
| `runtime_abox_state` | 28 |
| `runtime_derived` | 14 |
| `static_knowledge` | 19 |

## 5. 生命周期时间轴

```text
初始化：environment_config确定；TBox构建或加载
episode开始：RawAgent.reset清空延迟动作、决策历史和episode统计
每次Agent观测：读取TimeStep/player/RawUnit，更新ABox与跨帧量
决策触发：计算战术派生量，调用LLM，Parser校验，可选SWM预测
动作执行：立即映射FunctionCall；延迟动作到期重验证后映射
下一状态/结束：计算SWM误差，聚合得分、Token、耗时和失败率
```

## 6. game loop、环境步和decision step不能混用

`step_mul`控制一次环境交互跨越多少SC2 game loops。RawUnit、player和ABox在Agent收到新observation时刷新，并不表示代码观察到了被跨越的每一个game loop。`decision_interval`控制常规LLM决策间隔，`delay_steps`表示动作延迟的Agent环境步数，三者必须分开解释。

## 7. 延迟动作生命周期

Parser通过的动作若`delay_steps > 0`，可进入`RawAgent.pending_actions`。计划step到达时，当前实现检查动作单位tag以及unit目标是否仍存在；失效动作被丢弃并计入延迟失败统计，剩余动作才交给ActionExecutor。`pysc2.function.queued`是PySC2 FunctionCall命令队列参数，不是`pending_actions`。

## 8. ABox跨episode边界

`RawAgent.reset`会重置Agent计数、延迟动作和决策历史，但没有显式重新创建`BattlefieldGraph`。新episode首个观测会通过tag集合删除、创建和更新节点，但`BattlefieldGraph.step_count`等图对象状态可能继续累积。该现象属于当前代码现实，实际多episode行为仍需运行验证。

## 9. 可信状态规则

| 对象 | 静态代码能够确认 | 本步骤不能确认 |
|---|---|---|
| Raw observation | 读取位置、转换公式、下游路径 | SC2运行值和官方字段语义 |
| TBox | 当前Python静态声明 | 与pickle缓存和游戏版本完全一致 |
| ABox/派生量 | 更新与计算代码 | 实际episode具体数值 |
| LLM/SWM | 输入输出接口、Parser结构 | 模型真实输出和预测准确性 |
| FunctionCall | 当前编号与参数映射 | 游戏引擎是否成功执行 |
| 实验指标 | 公式和落盘接口 | 当前checkout能否复现历史结果 |

## 10. 变量血缘示例

```text
raw_unit.health → abox.unit.hp → derived.tactical.friendly_avg_hp → derived.tactical.health_status
LLM actions → action.delay_steps → pending_actions → 到期重验证 → pysc2.function.*
swm.input.abox_state + swm.input.planned_actions → swm.predictions → state_t1 → metric.swm.*
```

## 11. 机器可读记录结构

每条记录包含`source_layer`、`taxonomy_source_layer`、`value_class`、上游变量、生产源码、转换公式、证据ID、`update_timing`、刷新粒度、持久性、重置边界、game loop关系、延迟重验证、训练阶段、下游消费者和`needs_runtime_verification`。

## 12. 已知问题与待验证项

1. 未启动StarCraft II，所有具体运行值仍未观测。
2. RawUnit位置索引只证明当前STORM代码现实，未访问PySC2官方资料。
3. TBox Python定义与`ontology_graph.pkl`缓存可能不同步。
4. ABox动态`armor/armor_ratio`实际来自RawUnit的`shield/shield_ratio`。
5. FunctionCall编号未对当前ActionSpec做运行时核验。
6. 未调用外部LLM/SWM，模型输出变量仍需验证。
7. 历史实验指标没有重新执行。

## 13. 验收结论

- [x] 135条变量全部进入血缘表；
- [x] 每条记录都有source_layer和非占位update_timing；
- [x] 静态知识、实时观测、跨帧状态、LLM值、预测值和聚合值分开；
- [x] 每条记录包含上游、下游消费者、生命周期与可信边界；
- [x] 未知运行时语义标记needs_runtime_verification；
- [x] 所有步骤六产物位于knowledge/；
- [ ] SC2运行时验证：未执行；
- [ ] 外部LLM/SWM验证：未执行；
- [ ] 实验复现：未执行。
