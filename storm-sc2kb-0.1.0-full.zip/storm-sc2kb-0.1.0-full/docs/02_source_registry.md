# STORM PySC2 Raw API 变量知识库：源码与证据登记表

- 登记表 ID：`storm-sc2kb-source-registry-v1`
- 上游范围：`storm-sc2kb-v1-raw`
- 文档版本：`0.1.0`
- 核对日期：2026-09-03
- 基准：当前 `storm111` checkout 的静态扫描
- 运行状态：**未运行 SC2、外部 LLM、测试、示例或历史实验复现**

## 1. 一句话说明

本登记表回答的不是“变量是什么意思”，而是“关于这个变量应该先查哪一个文件、哪个符号，以及这个证据能证明到什么程度”。完整机器可读记录见 `knowledge/manifests/source_registry.yaml`。

## 2. 证据使用优先级

| 顺序 | 等级 | 使用规则 |
|---:|---|---|
| 1 | E1 当前代码 | 证明当前 checkout 的真实读写、转换、校验、执行和统计逻辑。 |
| 2 | E2 测试/可复现示例 | 只有实际执行通过后才能标记 `runtime_verified`；本步骤均未执行。 |
| 3 | E3 配置/Schema/静态数据 | 证明声明值和静态结构；缓存需要额外检查陈旧性。 |
| 4 | E4 历史运行产物 | 证明某次文件中记录过这些列和值，不自动证明当前版本能复现。 |
| 5 | E5 README/说明 | 只用于设计意图、术语和候选字段，不能覆盖源码。 |
| 6 | E6 外部资料 | 本步骤未访问；后续用于核验 PySC2 官方语义和版本。 |

> 冲突原则：保留“代码现实”和“设计意图”两条记录，以高等级证据解释当前实现，不把冲突悄悄统一。

## 3. 核心源码登记

| ID | 路径 | 等级 | 关键符号 | 主要证明范围 | 陈旧风险 |
|---|---|---|---|---|---|
| `src-main-entry` | `main.py` | E1 | `main`@23 | `environment_config`, `timestep_player_score` | low |
| `src-raw-agent` | `agents/raw_agent.py` | E1 | `RawAgent.__init__`@47, `RawAgent.step`@249, `RawAgent.parse_raw_units`@334, `RawAgent._make_llm_decision`@552, `RawAgent._swm_guided_reevaluation`@683 | `timestep_player_score`, `raw_unit`, `abox_dynamic`, `derived_tactical_state`, `action_schema_and_scheduling`, `swm`, `experiment_metric` | low |
| `src-response-parser` | `agents/response_parser.py` | E1 | `VALID_ACTIONS`@26, `VALID_TARGET_TYPES`@34, `VALID_PRIORITIES`@37, `ResponseParser.parse`@63, `ResponseParser._validate_schema`@165 | `action_schema_and_scheduling` | low |
| `src-action-executor` | `agents/action_executor.py` | E1 | `ActionExecutor.get_supported_subtypes`@40, `ActionExecutor._check_resource_budget`@100, `ActionExecutor._record_skip`@124, `ActionExecutor.execute`@130 | `pysc2_function_call`, `action_schema_and_scheduling`, `experiment_metric` | low |
| `src-openai-client` | `agents/openai_client.py` | E1 | `OpenAIClient.__init__`@28, `OpenAIClient.request`@80, `OpenAIClient.request_with_retry`@178 | `experiment_metric`, `action_schema_and_scheduling` | low |
| `src-battlefield-graph` | `ontology/bridge.py` | E1 | `UNKNOWN_UNIT_DEFAULTS`@33, `UNKNOWN_UNITS_LOG_PATH`@50, `BattlefieldGraph.update_from_observation`@100, `BattlefieldGraph._create_instance`@137, `BattlefieldGraph._update_instance`@253 | `abox_dynamic`, `derived_tactical_state`, `tbox_static`, `unknown_ontology_extension` | low |
| `src-marine-ontology` | `ontology/data/marine_ontology.py` | E3 | `get_all_nodes`@712, `get_all_edges`@722, `get_node_by_type`@730, `get_edges_by_type`@744 | `tbox_static` | high |
| `src-prompt-template` | `ontology/prompt_template.py` | E3 | `SYSTEM_PROMPT`@1, `ACTION_SPACE`@17, `OUTPUT_FORMAT`@56, `PREDICTION_PROMPT`@132, `PREDICTION_REEVALUATION_PROMPT`@176 | `action_schema_and_scheduling`, `swm` | low |
| `src-swm-predictor` | `ontology/swm_predictor.py` | E1 | `SWMPredictor.predict`@93, `SWMPredictor.predict_for_actions`@164, `SWMPredictor.serialize_prediction_for_prompt`@193, `SWMPredictor.compute_prediction_error`@236, `SWMPredictor._parse_prediction_response`@387 | `swm`, `experiment_metric` | low |
| `src-swm-trainer` | `ontology/swm_trainer.py` | E1 | `TrajectoryCollector.record_state`@68, `TrajectoryCollector.record_actions`@72, `TrajectoryCollector.record_prediction`@76, `TrajectoryCollector.record_next_state`@80, `TrajectoryCollector.on_episode_start`@119 | `swm`, `experiment_metric` | low |
| `src-ontology-loader` | `ontology/loader.py` | E1 | `OntologyLoader.__init__`@40, `OntologyLoader.reload`@45, `OntologyLoader.get_unit_info`@71, `OntologyLoader.serialize_unit_for_llm`@318 | `tbox_static`, `abox_dynamic` | high |
| `src-ontology-builder` | `ontology/builder.py` | E1 | `build_ontology_graph`@24, `validate_ontology_graph`@58, `save_ontology_graph`@206, `load_ontology_graph_from_pickle`@240 | `tbox_static` | low |
| `src-auto-extender` | `ontology/auto_extender.py` | E1 | `load_unknown_units`@109, `build_extension_prompt`@131, `parse_and_validate`@241, `render_patch_module`@359, `run_pipeline`@412 | `unknown_ontology_extension`, `tbox_static` | low |
| `src-heuristic-agent` | `agents/heuristic_agent.py` | E1 | `HeuristicAgent.step`@101, `HeuristicAgent._parse_raw_units`@136, `HeuristicAgent._make_decision`@151, `HeuristicAgent.get_action_failure_rate`@259 | `heuristic_and_rl_baselines`, `raw_unit`, `pysc2_function_call`, `experiment_metric` | low |
| `src-rl-agent` | `agents/rl_agent.py` | E1 | `RLAgent.step`@381, `RLAgent._parse_raw_units`@533, `RLAgent.get_action_failure_rate`@731 | `heuristic_and_rl_baselines`, `raw_unit`, `pysc2_function_call`, `experiment_metric` | low |
| `src-llm-example` | `examples/llm_agent_example.py` | E1 | `main`@62 | `environment_config`, `timestep_player_score`, `experiment_metric` | medium |
| `src-ablation-experiment` | `examples/ablation_experiment.py` | E1 | `run_method`@69, `write_results_csv`@205, `main`@216 | `environment_config`, `experiment_metric` | medium |
| `src-swm-experiment` | `examples/swm_experiment.py` | E1 | `create_env`@174, `create_agent`@194, `build_episode_result`@215, `run_single_episode`@315, `aggregate_results`@436 | `environment_config`, `swm`, `experiment_metric` | medium |
| `src-ood-matrix-experiment` | `examples/ood_matrix_experiment.py` | E1 | `_compute_trajectory_stats`@115, `run_single_episode`@150, `run_scene`@297, `write_aggregate_csv`@463, `write_raw_csv`@474 | `environment_config`, `swm`, `experiment_metric` | medium |
| `src-adaptive-ontology-experiment` | `examples/adaptive_ontology_experiment.py` | E1 | `bake_tbox_caches`@133, `_activate_pickle`@152, `_count_unknown_log_lines`@164, `run_single_episode`@171, `_evaluate_tbox_similarity`@397 | `unknown_ontology_extension`, `tbox_static`, `experiment_metric` | high |
| `src-ood-heuristic-experiment` | `examples/ood_baseline_heuristic.py` | E1 | `run_single_episode`@114, `run_scene`@223, `write_aggregate_csv`@346, `write_raw_csv`@357, `main`@368 | `heuristic_and_rl_baselines`, `experiment_metric` | medium |
| `src-ood-rl-experiment` | `examples/ood_baseline_rl.py` | E1 | `run_single_episode`@121, `run_scene`@254, `write_aggregate_csv`@391, `write_raw_csv`@402, `main`@413 | `heuristic_and_rl_baselines`, `experiment_metric` | medium |
| `src-battlefield-example` | `examples/battlefield_graph_example.py` | E2 | 文件级 | `raw_unit`, `abox_dynamic`, `derived_tactical_state` | medium |
| `src-action-executor-example` | `examples/action_executor_example.py` | E2 | 文件级 | `action_schema_and_scheduling`, `pysc2_function_call` | medium |
| `src-unknown-fallback-tests` | `tests/test_unknown_unit_fallback.py` | E2 | `test_unknown_unit_creates_placeholder`@44, `test_serialize_for_llm_includes_warning`@86, `test_no_warning_when_all_known`@103, `test_agent_does_not_crash_with_unknown_units`@114 | `unknown_ontology_extension`, `abox_dynamic` | medium |
| `src-auto-extender-tests` | `tests/test_auto_extender.py` | E2 | `test_valid_response_produces_safe_patch`@139, `test_bad_effectiveness_is_rejected`@194, `test_end_to_end_pipeline_with_mock_llm`@223, `test_load_unknown_units_dedupes`@255 | `unknown_ontology_extension`, `tbox_static` | medium |
| `src-pyproject` | `pyproject.toml` | E3 | 文件级 | `environment_config` | medium |
| `src-python-version` | `.python-version` | E3 | 文件级 | `environment_config` | low |
| `src-readme-root` | `README.md` | E5 | 文件级 | `environment_config`, `experiment_metric` | high |
| `src-readme-agents` | `agents/README.md` | E5 | 文件级 | `action_schema_and_scheduling`, `pysc2_function_call` | high |
| `src-readme-ontology` | `ontology/README.md` | E5 | 文件级 | `tbox_static`, `abox_dynamic`, `derived_tactical_state`, `swm` | high |
| `src-readme-examples` | `examples/README.md` | E5 | 文件级 | `environment_config`, `experiment_metric` | high |

当前登记普通证据源 **32** 个：E1=20、E2=4、E3=4、E5=4。完整 SHA-256、字节数、文件系统修改时间、证明能力和限制均保存在 YAML。

## 4. 按变量层寻找首选证据

| 变量层 | 首选入口 | 辅助证据 |
|---|---|---|
| 环境配置 | `main.py::main`、各 `examples/*experiment.py` 的环境创建函数 | `pyproject.toml`、`.python-version` |
| TimeStep/player/score | `agents/raw_agent.py::RawAgent.step` | `main.py`、实验脚本的回合循环 |
| RawUnit | `agents/raw_agent.py::RawAgent.parse_raw_units` | `tests/test_unknown_unit_fallback.py`、固定观测示例 |
| TBox 静态属性 | `ontology/data/marine_ontology.py` | `ontology/builder.py`、`ontology/loader.py`、缓存文件 |
| ABox 与未知实体 | `ontology/bridge.py::BattlefieldGraph` | unknown fallback 测试、`ontology/auto_extender.py` |
| 战术派生量 | `ontology/bridge.py::BattlefieldGraph.generate_tactical_summary` | `serialize_for_llm`、battlefield graph 示例 |
| LLM 动作接口 | `agents/response_parser.py` | `ontology/prompt_template.py`、`agents/raw_agent.py` |
| PySC2 FunctionCall | `agents/action_executor.py::ActionExecutor.execute` | 动作执行示例、基线 Agent |
| SWM | `ontology/swm_predictor.py`、`ontology/swm_trainer.py` | `examples/swm_experiment.py`、OOD 实验 |
| 实验指标 | 对应 `examples/*experiment.py` 的聚合/写出函数 | `data/record` 历史 CSV/JSON |

## 5. 高风险证据与缓存

### 5.1 OntologyLoader 的 pickle 优先规则

`ontology/loader.py::OntologyLoader.__init__` 默认优先读取 `data/ontology/ontology_graph.pkl`。因此，修改 `ontology/data/marine_ontology.py` 并不保证运行时本体立刻变化；必须重建缓存并验证。

| ID | 路径 | 当前状态 | 风险 |
|---|---|---|---|
| `cache-ontology-pickle` | `data/ontology/ontology_graph.pkl` | 存在，本步骤未重建 | 可能遮蔽 marine_ontology.py 的最新修改。 |
| `cache-ontology-graphml` | `data/ontology/ontology_graph.graphml` | 存在，本步骤未重建 | 不保证与默认加载 pickle 或当前源定义同步。 |
| `cache-b3-pickle` | `data/ontology/ontology_graph_b3_extended.pkl` | 存在，本步骤未重建 | 历史实验缓存，不是默认基础真值。 |
| `cache-b3-graphml` | `data/ontology/ontology_graph_b3_extended.graphml` | 存在，本步骤未重建 | 可能与扩展 patch 或 pickle 不同步。 |
| `cache-b3-patch` | `data/ontology/b3_extension_patch.py` | 存在，本步骤未重建 | 生成物；需要回指生成实验和 unknown 日志。 |

### 5.2 未知单位运行时日志

- `data/unknown_units.jsonl`：**当前缺失**。
- 预期生成者：`ontology/bridge.py::BattlefieldGraph._log_unknown_unit`。
- 预期消费者：`ontology/auto_extender.py::load_unknown_units`。
- 它只应在真实运行或测试遇到未知单位后产生；不能因为文件缺失而编造内容。

## 6. 历史实验产物登记

在 `data/record` 下共识别 **31** 个 CSV/JSON/JSONL 结构化产物。每个文件的完整路径、SHA-256、修改时间和表头/顶层键已经写入 YAML。

| 产物组 | 数量 | 可以证明什么 | 不能证明什么 |
|---|---:|---|---|
| 早期消融与场景结果 | 7 | 文件中曾记录相应指标、回合或配置 | 当前代码仍可复现、指标语义从未改变 |
| OOD 与基线 | 9 | 文件中曾记录相应指标、回合或配置 | 当前代码仍可复现、指标语义从未改变 |
| 自适应本体 | 3 | 文件中曾记录相应指标、回合或配置 | 当前代码仍可复现、指标语义从未改变 |
| SWM 时间戳运行目录 | 12 | 文件中曾记录相应指标、回合或配置 | 当前代码仍可复现、指标语义从未改变 |

需要特别注意：`data/record/ood_matrix_no_swn.csv` 的文件名保留了 `swn` 拼写，登记表按真实路径记录，不擅自重命名或解释为新变量。

## 7. 文档与源码冲突的处理

- `agents/README.md` 中的主动作 `confidence` 描述只能作为设计意图；当前 Parser 中相关校验和返回代码已被注释。
- Prompt 中出现的字段只有在 Parser、RawAgent 或 Executor 实际解析/消费后，才能升级为当前有效接口。
- RawUnit 注释提到但返回字典没有生成的字段，应记录为 `declared_not_effective`，不能纳入正式当前字段集。
- ABox 的 `armor`/`armor_ratio` 必须回指 `ontology/bridge.py` 的实际赋值，不能只靠词名或 README 推断。

## 8. 当前未解决问题

- `issue-git-identity`：当前目录无法记录可靠 commit hash。
- `issue-installed-pysc2-version`：pyproject 只给出 pysc2>=4.0.0，未核验实际运行环境版本。
- `issue-cache-source-drift`：未比较 ontology_graph.pkl 与 marine_ontology.py 构建结果是否一致。
- `issue-tests-not-run`：测试和示例均未执行，E2 条目不能标记 runtime_verified。
- `issue-historical-artifact-lineage`：历史结果未逐个绑定 commit、命令和配置。
- `issue-external-official-semantics`：本步骤未访问 PySC2 官方资料，dtype/单位/枚举的外部语义留待后续版本核验。

## 9. 登记表维护规则

1. 修改源码后，重新计算对应文件 SHA-256、修改时间和 AST 行号。
2. 行号只用于快速定位，稳定引用必须是“仓库相对路径 + symbol”。
3. 新增变量前，必须先在本登记表中添加至少一个 E1 证据源。
4. 历史产物应逐步补充生成命令、配置、commit 和输出 Schema。
5. pickle/GraphML 更新时同时登记其源定义和生成脚本，避免缓存被误当作唯一真值。
6. 测试未运行时只能写 `defined_not_executed`，执行通过后再升级状态。

## 10. 步骤 02 结论

**状态：完成（源码与证据登记完成，运行时验证未执行）。**

下一步建议执行 `knowledge/prompts/03_design_schema.md`：先设计变量记录的 JSON Schema，并提供 RawUnit、TBox、派生量和动作字段示例；变量批量抽取将在后续步骤进行。
