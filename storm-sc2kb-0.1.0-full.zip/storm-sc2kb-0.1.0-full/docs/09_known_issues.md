# 步骤 09：实现差异、限制与已知问题

> 生成日期：2026-09-04
> 范围：仅限当前 STORM 主路径使用的 Raw API 变量及直接下游。
> 未启动 SC2、未调用外部 LLM/SWM、未重跑实验；结论以静态审计为主。

## 使用方法

回答变量问题时先查 knowledge/known_issues.yaml 的 variable_issue_index。命中后必须给出当前代码现实、限制和证据；needs_runtime_test 不得写成已验证事实。

## 总览

| ID | 类型 | 严重度 | 题目 |
|---|---|---|---|
| issue.abox_armor_stores_shield | 实现特性/陷阱 | high | ABox armor 字段实际保存 shield |
| issue.action_coordinate_clip_not_written_back | 确认缺陷 | high | 坐标裁剪结果未写回 action.target |
| issue.action_priority_not_validated_or_consumed | 文档不一致 | medium | priority 声明存在但未校验或调度 |
| issue.build_train_dual_representation | 文档不一致 | high | BUILD/TRAIN 动作表示形式不一致 |
| issue.function_ids_require_runtime_actionspec_check | 待运行验证 | high | 硬编码 FunctionCall ID 尚未核验 |
| issue.main_confidence_documented_but_disabled | 文档不一致 | medium | 主决策 confidence 文档声明但实现停用 |
| issue.ontology_pickle_may_be_stale | 待运行验证 | medium | TBox pickle 可能与 Python 定义不同步 |
| issue.swm_confidence_not_a_gate | 实现特性/陷阱 | medium | SWM confidence 被规范化但不是硬阈值门控 |
| issue.swm_error_uses_future_state_as_baseline | 确认缺陷 | critical | SWM health/position 误差基线错误 |
| issue.swm_relation_accuracy_is_prediction_precision | 实现特性/陷阱 | high | relation_accuracy 更接近预测关系命中率 |
| issue.unknown_unit_hp_default_is_static_only | 实现特性/陷阱 | low | 未知单位 hp=100 不覆盖实时 health |

## 确认缺陷

### 坐标裁剪结果未写回 action.target

- 稳定 ID：issue.action_coordinate_clip_not_written_back
- 严重度 / 可信状态：high / code_reality
- 涉及正式变量：action.target、pysc2.function.target
- 现象：np.clip 只修改局部 x/y，没有更新动作对象。
- 简明解释：越界坐标看似被裁剪，后续仍可能收到原始 target。
- 文档或预期行为：裁剪值应写回 action['target']，或明确拒绝越界动作。
- 当前实现：代码计算 x/y 后直接返回 True。
- 知识库回答约束：不得声称 Parser 已把越界坐标修正后传给执行器。
- 代码/实验风险：越界参数可能进入转换或执行阶段。
- 证据依据：
  - agents/response_parser.py:524-525，ResponseParser._validate_semantics：局部裁剪值未写回 action['target']。
- 建议验证（static_unit_test，当前 not_executed）：
  1. 提交 target=[-1,80]。
  2. 检查校验后动作对象中的 target。
- 通过标准：通过校验的动作实际携带 [0,63]，或被明确拒绝。
- 限制：测试未执行。

### SWM health/position 误差基线错误

- 稳定 ID：issue.swm_error_uses_future_state_as_baseline
- 严重度 / 可信状态：critical / code_reality
- 涉及正式变量：metric.swm.health_rmse、metric.swm.overall_error、metric.swm.position_rmse
- 现象：误差函数用 actual(t+1) 同时构造预测值和真实值。
- 简明解释：health 误差退化为 delta²，position 误差退化为预测位移模长。
- 文档或预期行为：预测绝对值应由 t 状态加 delta，再与 t+1 真值比较。
- 当前实现：函数没有接收 t 时刻单位基线。
- 知识库回答约束：不得称这些值为严格未来状态 RMSE；须提示基线缺陷及其传播到 overall_error。
- 代码/实验风险：实验指标可能无法反映真实预测误差。
- 证据依据：
  - ontology/swm_predictor.py:272-282，SWMPredictor.compute_prediction_error：health 与 position 都从 actual_state 构造预测值。
  - agents/raw_agent.py:285-292，RawAgent._record_swm_ground_truth：训练器记录下一帧快照。
- 建议验证（static_unit_test，当前 not_executed）：
  1. 构造 t、delta、t+1 的已知样例。
  2. 手算并回归三个指标。
- 通过标准：误差等于预测未来绝对状态与 t+1 真值之差。
- 限制：未重跑历史实验。


## 实现特性/陷阱

### ABox armor 字段实际保存 shield

- 稳定 ID：issue.abox_armor_stores_shield
- 严重度 / 可信状态：high / code_reality
- 涉及正式变量：abox.unit.armor、abox.unit.armor_ratio、raw_unit.shield、raw_unit.shield_ratio
- 现象：ABox 的 armor/armor_ratio 由 shield/shield_ratio 赋值。
- 简明解释：字段名称表达护甲，但当前数值语义是护盾。
- 文档或预期行为：armor 应保存护甲；若保存护盾应采用 shield 语义。
- 当前实现：创建和更新 ABox 时均使用 shield 映射。
- 知识库回答约束：必须说明当前 ABox armor 实际是 shield，不能解释为 SC2 护甲。
- 代码/实验风险：论文或代码可能错误解释物理量。
- 证据依据：
  - ontology/bridge.py:201-202，BattlefieldGraph._add_unit_instance：创建路径把 shield 写入 armor。
  - ontology/bridge.py:264-269，BattlefieldGraph._update_unit_instance：更新路径沿用同一映射。
- 建议验证（static_unit_test，当前 not_executed）：
  1. 构造 shield 非零的 raw_unit。
  2. 检查 ABox 创建和更新结果。
- 通过标准：字段命名、文档语义和数据源一致。
- 限制：未启动 SC2。

### SWM confidence 被规范化但不是硬阈值门控

- 稳定 ID：issue.swm_confidence_not_a_gate
- 严重度 / 可信状态：medium / code_reality
- 涉及正式变量：swm.confidence
- 现象：confidence 缺失时默认 0.5 并裁剪到 0..1；RawAgent 记录它，但未见阈值分支。
- 简明解释：该值当前是预测元数据，不是自动决定采用预测的开关。
- 文档或预期行为：若需要门控，应定义阈值、分支和日志。
- 当前实现：校验器规范化 confidence；非数值字符串还可能触发 float 异常。
- 知识库回答约束：只能说它被默认、裁剪、记录和传递；不得声称存在采用阈值。
- 代码/实验风险：可能被误当成安全门控；格式漂移也可能引发转换异常。
- 证据依据：
  - ontology/swm_predictor.py:413-427，SWMPredictor._validate_prediction：confidence 有默认和裁剪，但直接 float 转换。
  - agents/raw_agent.py:731-731，RawAgent._run_swm_prediction：RawAgent 在成功日志中读取该值。
- 建议验证（static_unit_test，当前 not_executed）：
  1. 测试 0、0.5、1 和非数值输入。
  2. 跟踪后续路径是否因阈值改变。
- 通过标准：门控可测试或文档明确仅为元数据；非法类型被结构化处理。
- 限制：未调用外部 SWM。

### relation_accuracy 更接近预测关系命中率

- 稳定 ID：issue.swm_relation_accuracy_is_prediction_precision
- 严重度 / 可信状态：high / code_reality
- 涉及正式变量：metric.swm.overall_error、metric.swm.relation_accuracy
- 现象：指标只以预测关系为分母；不惩罚漏报，空预测返回 1.0，当前真值快照 relations 为空。
- 简明解释：它不等同于覆盖假阴性的完整关系准确率。
- 文档或预期行为：应明确 precision/recall/F1 或定义空集合与漏报规则。
- 当前实现：实现遍历 predicted_relations；无预测时保留 1.0。
- 知识库回答约束：应称预测关系命中比例，并披露空预测=1.0与当前真值为空。
- 代码/实验风险：overall_error 可能偏乐观。
- 证据依据：
  - ontology/swm_predictor.py:291-309，SWMPredictor.compute_prediction_error：只用预测关系作分母且空预测为 1.0。
  - agents/raw_agent.py:290-290，RawAgent._record_swm_ground_truth：当前下一帧关系真值为空。
- 建议验证（static_unit_test，当前 not_executed）：
  1. 构造命中、误报、漏报和空预测案例。
  2. 比较 precision/recall/F1。
- 通过标准：指标名、公式和空集合规则一致。
- 限制：未重跑 SWM 实验。

### 未知单位 hp=100 不覆盖实时 health

- 稳定 ID：issue.unknown_unit_hp_default_is_static_only
- 严重度 / 可信状态：low / code_reality
- 涉及正式变量：abox.unit.hp、raw_unit.health、tbox.entity.hp
- 现象：UNKNOWN_UNIT_DEFAULTS 定义 hp=100，但 ABox hp 仍读取 raw_unit['health']。
- 简明解释：100 是未知类型静态占位，不是动态生命值覆盖。
- 文档或预期行为：静态默认与动态观测应明确分层。
- 当前实现：合并 static_info 后，instance_attrs.hp 单独使用实时 health。
- 知识库回答约束：不能说未知单位生命值总被设为100；要解释静态占位和动态 hp 的层次。
- 代码/实验风险：混淆两层会错误判断未知单位状态。
- 证据依据：
  - ontology/bridge.py:37-37，UNKNOWN_UNIT_DEFAULTS：未知类型静态默认 hp 为 100。
  - ontology/bridge.py:166-199，BattlefieldGraph._add_unit_instance：ABox 动态 hp 读取实时 health。
- 建议验证（static_unit_test，当前 not_executed）：
  1. 构造未知类型且 health=37。
  2. 断言 ABox hp=37。
- 通过标准：动态 hp 保持实时值，静态占位仍可保留。
- 限制：结论来自静态赋值路径。


## 文档不一致

### priority 声明存在但未校验或调度

- 稳定 ID：issue.action_priority_not_validated_or_consumed
- 严重度 / 可信状态：medium / code_reality
- 涉及正式变量：action.priority
- 现象：VALID_PRIORITIES 已定义，README 称会校验，但当前验证和执行链未读取 priority。
- 简明解释：priority 更接近设计字段，而不是已生效的调度量。
- 文档或预期行为：priority 应限制为 high/medium/low 并有明确消费点。
- 当前实现：常量和文档承诺存在，主路径未见强制校验或排序。
- 知识库回答约束：不得说 priority 当前会被强制校验或决定执行顺序。
- 代码/实验风险：错误值不会被拒绝，调度语义可能被误读。
- 证据依据：
  - agents/response_parser.py:37-37，VALID_PRIORITIES：允许值常量已声明。
  - agents/README.md:254-254，ResponseParser semantic validation：README 声称会校验。
- 建议验证（static_unit_test，当前 not_executed）：
  1. 输入 priority='urgent'。
  2. 跟踪解析结果和执行顺序。
- 通过标准：非法值被拒绝且有消费逻辑，或文档明确未使用。
- 限制：结论来自静态搜索。

### BUILD/TRAIN 动作表示形式不一致

- 稳定 ID：issue.build_train_dual_representation
- 严重度 / 可信状态：high / code_reality
- 涉及正式变量：action.subtype、action.type
- 现象：提示示例使用 BUILD-Barracks/TRAIN-Marine，Schema 又列 BUILD/TRAIN；执行器依赖 subtype。
- 简明解释：纯 BUILD/TRAIN 若不另给 subtype，不能满足当前执行链。
- 文档或预期行为：提示、Schema、Parser、Executor 应统一一种规范。
- 当前实现：Parser 拆分连字符形式；ActionExecutor 读取并要求 subtype。
- 知识库回答约束：推荐写 BUILD-Barracks/TRAIN-Marine，或显式提供 subtype；不能说纯动作名一定足够。
- 代码/实验风险：模型照 Schema 生成纯动作名时可能失败。
- 证据依据：
  - ontology/prompt_template.py:32-38，ACTION_TYPES：动作说明使用连字符形式。
  - agents/response_parser.py:269-277，ResponseParser._validate_schema：Parser 将连字符动作拆为 action 与 subtype。
  - agents/action_executor.py:176-177，ActionExecutor.execute_actions：执行器读取并要求 subtype。
- 建议验证（static_unit_test，当前 not_executed）：
  1. 比较 BUILD、BUILD-Barracks、BUILD+subtype。
  2. 对 TRAIN 重复测试。
- 通过标准：四处接口使用同一规范并有回归测试。
- 限制：未启动 SC2。

### 主决策 confidence 文档声明但实现停用

- 稳定 ID：issue.main_confidence_documented_but_disabled
- 严重度 / 可信状态：medium / code_reality
- 涉及正式变量：无正式变量 ID
- 涉及非正式字段：decision_response.confidence
- 现象：README 仍称 confidence 必填且校验范围，Parser 返回和校验代码已注释。
- 简明解释：主决策 confidence 不是步骤05正式动作变量，也不同于 swm.confidence。
- 文档或预期行为：文档与代码应统一决定是否保留和校验该字段。
- 当前实现：主解析与消融解析均不返回该字段。
- 知识库回答约束：不能虚构 action.confidence；必须区分 decision_response.confidence 与 swm.confidence。
- 代码/实验风险：下游按 README 取键时可能缺失。
- 证据依据：
  - agents/README.md:232-233，ResponseParser schema validation：README 声称必填并校验。
  - agents/response_parser.py:121-121，ResponseParser.parse_response：主解析返回已注释。
  - agents/raw_agent.py:1087-1087，RawAgent._parse_response_without_validation：消融解析返回也已注释。
- 建议验证（static_unit_test，当前 not_executed）：
  1. 解析带/不带 confidence 的响应。
  2. 根据设计决策同步实现、README 和变量表。
- 通过标准：代码、README、知识库对字段存在性一致。
- 限制：没有对应正式变量 ID。


## 待运行验证

### 硬编码 FunctionCall ID 尚未核验

- 稳定 ID：issue.function_ids_require_runtime_actionspec_check
- 严重度 / 可信状态：high / needs_verification
- 涉及正式变量：pysc2.attack.function_id、pysc2.build.function_id、pysc2.move.function_id、pysc2.no_op.function_id、pysc2.train.function_id
- 现象：ActionExecutor 硬编码 NO_OP/MOVE/ATTACK/BUILD/TRAIN 函数编号。
- 简明解释：静态代码只能确认这些值被使用，不能证明与当前 ActionSpec 一致。
- 文档或预期行为：应从当前 PySC2/SC2 ActionSpec 核对 ID、名称和参数签名。
- 当前实现：执行器直接用常量构造 FunctionCall。
- 知识库回答约束：回答 ID 时须标注为当前源码硬编码值、尚未运行核验。
- 代码/实验风险：版本或动作可用性差异可能导致无效调用。
- 证据依据：
  - agents/action_executor.py:7-15，BUILD_CALLS/TRAIN_CALLS：BUILD/TRAIN 函数编号以常量形式硬编码。
  - agents/action_executor.py:139-162，ActionExecutor.execute_actions：NO_OP、MOVE、ATTACK 调用使用数值 ID 0、13、3。
- 建议验证（runtime_sc2_test，当前 not_executed）：
  1. 启动 Raw API 环境。
  2. 读取 ActionSpec。
  3. 逐项比对并做最小冒烟测试。
- 通过标准：所有 ID 与参数签名匹配且调用可被环境接受。
- 限制：本步骤未启动 SC2。

### TBox pickle 可能与 Python 定义不同步

- 稳定 ID：issue.ontology_pickle_may_be_stale
- 严重度 / 可信状态：medium / needs_verification
- 涉及正式变量：tbox.entity.armor、tbox.entity.hp
- 现象：OntologyLoader 默认在 pickle 存在时优先加载，未自动比对源码定义。
- 简明解释：修改本体定义后若未重建缓存，运行时可能继续使用旧 TBox。
- 文档或预期行为：缓存应有一致性检查或版本标记。
- 当前实现：reload(use_pickle=True) 只在 pickle 不存在时重建。
- 知识库回答约束：回答 TBox 数值时应披露缓存来源；未比对前不能断言与 Python 定义同步。
- 代码/实验风险：静态属性和 BUILD/TRAIN 校验可能使用陈旧值。
- 证据依据：
  - ontology/loader.py:57-61，OntologyLoader.reload：存在 pickle 时优先加载。
- 建议验证（cache_consistency_check，当前 not_executed）：
  1. 分别加载 pickle 与源码重建图。
  2. 规范化后输出节点、边和属性差异。
- 通过标准：两图一致，或缓存可追溯且变更时自动重建。
- 限制：离线检查未执行。

## 未执行声明

本步骤没有启动 StarCraft II、访问外部账号、调用 LLM/SWM、重跑实验或修改 STORM 业务源码。所有建议验证项均为 not_executed。

## 维护规则

1. 修复代码后先更新机器文件，再重建本文。
2. 保留稳定 ID，用 status 管理生命周期。
3. 同步维护 affected_variable_ids 与 variable_issue_index。
4. 行号可能漂移，引用时同时保留路径、符号和结论。
