# STORM PySC2 Raw API 变量知识库：第一版范围与边界

- 范围 ID：`storm-sc2kb-v1-raw`
- 文档版本：`0.1.0`
- 基准仓库：当前 `storm111` checkout
- 核对日期：2026-09-03
- 核对方式：静态源码、配置、测试与已提交实验产物审查
- 运行时状态：**本步骤未运行 StarCraft II，也未调用 LLM/SWM API**

## 1. 一句话结论

第一版不是整理“PySC2 能提供的全部变量”，而是整理下列闭环中**当前 STORM 代码确实读取、转换、生成、校验、执行或统计的量**：

`SC2Env 配置 → TimeStep/Raw observation → RawUnit/player → TBox+ABox → 战术派生量 → LLM 动作 → Parser → Raw FunctionCall → 下一观测`

启用 SWM 时，还包括：

`候选动作 + 当前 ABox → SWM 预测 → LLM 再评估 → 最终动作 → 轨迹与预测误差`

## 2. 知识库要解决的问题

面向论文写作、代码开发和 LLM Agent 查询，第一版应支持以下问题：

1. 自然语言中的概念对应哪个规范变量？
2. 该变量是游戏原始观测、静态本体、运行时派生量，还是模型/实验生成量？
3. 它的物理或业务含义是什么？
4. 它在接口中以什么字段、类型、形状或参数形式出现？
5. STORM 在哪个文件、类和函数中读取或生成它？
6. 它经过了什么转换、归一化、聚合、裁剪或映射？
7. 哪些结论是当前代码事实，哪些只是设计意图或需要运行验证？

## 3. “变量”的判定标准

### 3.1 纳入条件

一个候选量满足以下任一条件，且能找到当前仓库证据时，可进入第一版：

- 被当前 STORM 执行路径从 PySC2 observation 或 `TimeStep` 中读取；
- 被转换后写入 RawUnit 字典、ABox 节点/边或图级状态；
- 来自当前 TBox，且确实被加载、查询、复制到 ABox 或写入 Prompt；
- 由当前状态直接计算并提供给决策、验证、执行或实验统计；
- 出现在当前 LLM/SWM 输入输出接口，并被代码解析、校验、归一化或消费；
- 被映射为 PySC2 Raw `FunctionCall` 的函数编号或参数；
- 被当前实验脚本实际计算、聚合或写入 CSV/JSON。

### 3.2 不充分条件

以下情况单独出现时，不能成为第一版正式变量：

- 只在 PySC2 官方接口中存在，但当前 STORM 未读取；
- 只在 README、注释或旧说明文档中出现，当前实现没有对应读写；
- 只属于一般 StarCraft II 背景知识；
- 只在历史结果表中出现，但无法定位其生成逻辑；
- 由分析者根据常识推测，缺少源码、配置、测试或运行证据。

### 3.3 记录粒度

- 原始字段和转换后的字段分别建记录，例如 `raw_unit.health` 与 `abox.hp` 是两个层级的记录，用关系连接。
- 同名但语义不同的量分别建记录，例如 TBox 静态 `armor` 与当前 ABox 动态 `armor` 不合并。
- 容器和实际消费的子字段分开处理，例如 `observation.player` 是容器，而代码实际使用的矿物、气体、已用人口、人口上限应有子记录。
- 只声明但未真正使用的字段仍可作为“接口/已知问题记录”收录，但必须标记 `declared_not_effective`，不能描述为有效控制量。

## 4. 当前代码确认的数据链

### 4.1 环境入口

`main.py::main` 创建 `SC2Env`，当前硬编码示例包括：

- `map_name="DefeatRoaches"`；
- 玩家种族 `Race.terran`；
- `use_raw_units=True`；
- `use_raw_actions=True`；
- `raw_resolution=64`；
- `step_mul=8`；
- `game_steps_per_episode=0`；
- `visualize=False`。

这些是环境控制变量，不等同于战场中的物理状态，但会影响坐标边界、时间推进和可用接口，因此纳入“环境配置层”。

### 4.2 TimeStep、player 与得分

`agents/raw_agent.py::RawAgent.step` 当前读取：

- `obs.observation["raw_units"]`；
- `obs.observation.player`；
- `obs.observation.get("score_cumulative", [0])[0]`；
- `TimeStep.last()` 由环境循环用于回合结束判断；
- `reward = new_score - previous_score` 是 STORM 自行计算的决策间得分增量。

`player` 被转成列表后传给战术摘要和动作执行器。当前代码明确消费索引 1–4 来得到矿物、气体、已用人口、人口上限及剩余人口。注释列出的其他 player 字段不能仅凭注释全部认定为当前有效决策变量。

### 4.3 RawUnit 解析

`agents/raw_agent.py::RawAgent.parse_raw_units` 当前实际生成以下 10 个字段：

| STORM 字段 | RawUnit 索引/转换 | 当前用途 |
|---|---:|---|
| `tag` | `unit[29]` | 单位实例标识、ABox 映射、动作单位参数 |
| `unit_type` | `unit[0]` | 查询 TBox 单位类型 |
| `alliance` | `unit[1]` | 区分友军、敌军和中立实体 |
| `x` | `unit[12]` | ABox 位置与空间派生量 |
| `y` | `unit[13]` | ABox 位置与空间派生量 |
| `health` | `unit[2]` | ABox 当前生命值 `hp` |
| `health_ratio` | `unit[7] / 255` | ABox 生命比例与战术摘要 |
| `shield` | `unit[3]` | 当前代码写入 ABox 的 `armor` 字段 |
| `shield_ratio` | `unit[8] / 255` | 当前代码写入 ABox 的 `armor_ratio` 字段 |
| `weapon_cooldown` | `unit[25]` | ABox 冷却状态和开火就绪比例 |

函数文档中提到的 `health_max` 并未被该函数实际生成，因此不能按已实现变量收录。

### 4.4 TBox 到 ABox

`ontology/data/marine_ontology.py` 定义当前项目本体中的单位、建筑、资源、科技和关系；`OntologyLoader` 负责加载和查询；`BattlefieldGraph` 将 RawUnit 实例化为 `networkx.DiGraph` 中的 ABox 节点。

ABox 当前包含三类信息：

1. 元信息：`node_type`、`tag`、`unit_type_id`、`unit_class`、`alliance`、`is_unknown`；
2. 从 TBox 复制的静态属性：`race`、`category`、`attack_damage`、`attack_range`、`attack_speed`、`movement_speed`、`description`；
3. 从 RawUnit 更新的动态状态：`hp`、`hp_ratio`、`armor`、`armor_ratio`、`position.x`、`position.y`、`weapon_cooldown`。

其中当前实现把 RawUnit 的 `shield` 和 `shield_ratio` 写入名为 `armor` 和 `armor_ratio` 的 ABox 字段。这是需要如实记录的代码现实，不能直接解释成单位静态护甲。

未知 `unit_type_id` 在启用 fallback 时会生成保守占位静态属性，并记录 `data/unknown_units.jsonl`；但 ABox 的动态 `hp` 仍由当前 RawUnit `health` 写入。

### 4.5 战术派生量

`ontology/bridge.py::BattlefieldGraph.generate_tactical_summary` 当前直接计算或输出：

- 资源摘要：Minerals、Gas、Supply remaining；
- `friendly_count`、`enemy_count` 和文本 `Force_Ratio`；
- 友军/敌军平均 `hp_ratio` 与文本 `Health_Status`；
- `hp_ratio < 0.3` 的 `Critical_Units`；
- 友军和敌军位置质心；
- 两方质心欧氏距离 `Formation_Distance`；
- 按距离阈值产生的 `Engagement_Type`：Close-Combat、Medium-Range、Long-Range；
- `weapon_cooldown == 0` 的数量和 `Fire_Readiness` 比例。

`serialize_for_llm` 还包含单位分组、紧凑/聚类表示和关系三元组等序列化派生信息。后续抽取步骤应逐项确认，而不能把输出文本标签自动当成 PySC2 原始字段。

### 4.6 动作 Schema、校验与调度

第一版收录以下动作接口族：

- 顶层：`reasoning`、`plan`、`actions`；
- 单动作：`action`、`units`、`target_type`、`target`、`delay_steps`、可选 `subtype`；
- 动作类型：`MOVE`、`ATTACK`、`BUILD`、`TRAIN`；
- 目标类型：`unit`、`pos`、`none`；
- `delay_steps` 缺失时设为 0，小于 0 时设为 0，大于 9 时设为 9；
- `BUILD-Barracks`、`TRAIN-Marine` 一类富动作字符串会被拆成基础动作和 `subtype`；
- 延迟动作进入 `pending_actions[current_step + delay_steps]`，执行前默认重新验证单位与目标是否仍存在。

`confidence` 的主动作 Schema 校验和返回目前被注释；`VALID_PRIORITIES` 虽然被声明，但当前需在后续已知问题步骤确认其是否真正进入 Schema 和消费路径。这些字段只能按“声明/设计信息”记录，不能描述为当前有效决策机制。

### 4.7 PySC2 Raw FunctionCall

`agents/action_executor.py::ActionExecutor.execute` 把已解析动作映射为 PySC2 Raw `FunctionCall`。当前应收录：

- no-op 函数与空参数；
- MOVE、ATTACK、BUILD、TRAIN 的函数编号映射；
- queued 标志、单位 tag 列表、位置目标或生产者 tag 等参数结构；
- BUILD/TRAIN 的 subtype 白名单；
- 资源预算检查和剩余人口计算；
- 建造位置边界、占用半径、邻近位置修复；
- submitted、skipped 与 skip_reasons 执行统计。

函数编号是当前实现和当前依赖版本下的接口映射，应保留版本/源码依据，不能描述成永久不变的游戏物理常量。

### 4.8 SWM

当前默认 RawAgent 配置允许启用 SWM，并在启用时延迟导入 `SWMPredictor` 和 `TrajectoryCollector`。第一版纳入：

- SWM 配置：模型、temperature、max_tokens、prediction_steps、cache_predictions；
- 输入：当前 ABox 序列化状态、候选动作、任务目标；
- 输出：`predictions`、各步 `predicted_unit_states`、`predicted_relations`、`confidence`、原始响应和 token usage；
- 单位预测字段中的 `health_delta`、`position_delta` 等；
- 再评估次数、预测次数、预测成功次数、动作是否被 SWM 修改；
- 轨迹中的当前状态、动作、下一状态、单位快照和预测误差；
- `health_rmse`、`position_rmse`、`relation_accuracy`、`overall_error`。

这些是模型预测量或模型评估量，不是 PySC2 原始真值。当前误差实现应在步骤 09 单独审计其基准和公式。

### 4.9 实验指标

纳入当前实验脚本实际计算、聚合或写入的指标，包括但不限于：

- episode score 及均值、标准差、最小值、最大值；
- 每回合环境步数、决策次数；
- prompt/completion/total token 及每决策均值；
- 单次/平均决策延迟；
- 决策动作失效率、延迟动作失效率、总体失效率；
- ActionExecutor skip 数与原因；
- SWM prediction、success、reevaluation、change 的次数或比例；
- SWM 的 relation accuracy、health RMSE、position RMSE、overall error；
- episode 请求数、完成数、失败数和并行度等实验运行元数据。

历史 CSV/JSON 可作为结果证据，但只有能连接到当前生成或分析代码的字段才能成为规范指标；同名历史文件不自动代表当前实现。

## 5. 第一版纳入范围

| 类别 | 是否纳入 | 边界说明 | 主要证据 |
|---|---|---|---|
| 环境配置 | 是 | 只收当前入口/实验脚本实际传给 `SC2Env` 或 RawAgent 的配置 | `main.py`、`examples/*.py` |
| TimeStep/player/score | 是 | 收当前代码读取的容器、索引、结束状态和得分增量 | `agents/raw_agent.py` |
| RawUnit | 是，核心 | 只收 `parse_raw_units` 实际读取的 10 个字段 | `agents/raw_agent.py::parse_raw_units` |
| TBox 静态知识 | 是 | 只收当前本体节点/边及真正加载、查询、提示的属性 | `ontology/data/marine_ontology.py`、loader/builder |
| ABox 动态状态 | 是，核心 | 收实例节点、映射、动态更新、未知实体降级 | `ontology/bridge.py` |
| 战术派生状态 | 是 | 收代码实际计算的计数、均值、质心、距离、阈值分类和序列化量 | `ontology/bridge.py` |
| 动作接口与校验 | 是，核心 | 收 Prompt、Parser、延迟调度中出现且可追踪的字段 | prompt_template、response_parser、raw_agent |
| Raw FunctionCall | 是，核心 | 收函数编号、参数结构、资源/位置检查和执行统计 | `agents/action_executor.py` |
| SWM | 是 | 收模型输入输出、轨迹、预测误差和再评估统计；标为预测层 | swm_predictor、swm_trainer、raw_agent |
| 实验指标 | 是 | 只收当前脚本实际生成/聚合的指标和必要运行元数据 | `examples/*experiment.py`、`data/record` |
| heuristic/RL 基线 | 部分 | 只收与比较实验直接相关的共享 Raw 输入、动作输出和最终指标；第一版不展开神经网络内部张量与训练超参数 | `agents/heuristic_agent.py`、`agents/rl_agent.py`、OOD scripts |
| 未知本体自动扩展 | 部分 | 未知实体观测日志和 fallback 属于核心；LLM 自动生成 TBox patch 的完整工作流作为扩展工具，不作为 Raw 变量主链 | auto_extender、tests |

## 6. 第一版明确排除范围

| 排除项 | 原因 | 未来何时可纳入 |
|---|---|---|
| 完整 PySC2 observation/RawUnit 字段表 | 当前 STORM 没有读取全部字段 | 项目代码开始读取，或建立独立“官方接口层”版本 |
| feature layer、RGB、screen/minimap 特征 | 当前主链要求 Raw units/actions | STORM 新增 feature/RGB agent 后 |
| 完整 SC2 单位、建筑、技能和科技百科 | 超出当前本体与代码消费范围 | 扩展 TBox 且有可验证来源后 |
| 游戏引擎内部不可观测真值 | PySC2 当前观测未直接提供 | 有明确接口或实验观测方案后 |
| 纯策略建议和兵种攻略 | 不是变量接口知识 | 可在独立战术知识库中维护 |
| OpenAI/PySC2 全部客户端参数 | 与“当前 STORM Raw 变量链”无直接关系 | 参数被当前代码配置或影响评测时逐项加入 |
| RL 网络权重、梯度、replay 中全部张量 | 属于独立基线内部学习状态，不是第一版核心 Raw→LLM 链 | 建立“基线智能体变量”扩展包时 |
| 绘图样式参数 | 不影响环境、Agent 接口或指标含义 | 建立实验可视化复现包时 |
| README 中未被实现的字段 | 文档不是高于代码的事实来源 | 找到实现或修复代码后 |
| 未运行验证的动态结论 | 本步骤仅完成静态审查 | 后续通过 SC2、单元测试或固定观测夹具验证后 |

## 7. 变量的五种性质标签

后续每条记录至少标注一种事实状态：

- `code_reality`：当前源码明确读、写、转换或判断；
- `runtime_observation`：通过实际 SC2/测试运行验证过的值或行为；
- `design_intent`：来自 Prompt、注释、README 或说明文档的预期；
- `derived_runtime`：由当前观测在运行时计算；
- `needs_verification`：静态代码不足以确认实际类型、量纲、版本稳定性或行为。

同一变量可同时有多种性质，但每条具体断言必须对应自己的证据状态。

## 8. 证据等级

| 等级 | 名称 | 可支持的结论 |
|---|---|---|
| E1 | 当前运行代码 | 字段确实被读取、转换、校验或消费；第一版最高优先级 |
| E2 | 当前测试/可复现运行 | 行为在固定条件下实际发生，或错误被测试覆盖 |
| E3 | 当前配置、Schema、静态数据 | 默认值、枚举、本体属性、输出格式 |
| E4 | 当前实验产物 | 某次运行结果和当时输出列；不自动证明当前代码仍能复现 |
| E5 | 当前 README、注释、项目说明文档 | 设计意图、术语和候选变量；与实现冲突时不能覆盖 E1 |
| E6 | 外部官方资料 | 接口语义和版本信息；后续步骤需要联网核验时使用 |

规则：核心变量至少需要 E1；只有 E5/E6 而无当前代码使用证据的内容不进入第一版正式变量集合。

## 9. 当前 checkout 已确认的边界风险

这些是后续步骤必须继续核查的线索，不在步骤 01 中直接判定为全部已修复或已运行验证：

1. `parse_raw_units` 文档与实际返回字段不完全一致；
2. ABox 动态 `armor` 当前来源是 RawUnit `shield`，与 TBox 静态护甲同名异义；
3. 未知单位占位静态 hp 与实时 ABox hp 必须分层解释；
4. Parser 对动作坐标、未知动作、priority、confidence 的实际约束强度需逐项审计；
5. BUILD/TRAIN 同时存在基础动作和带 subtype 的富动作表达；
6. Function ID 是实现映射，不应包装成不随版本变化的物理量；
7. SWM 的预测值与环境真值必须分开；误差实现的时间基准需专门审计；
8. 历史实验文件可能对应不同代码版本，指标定义必须回指生成脚本；
9. 当前目录无法通过常规 `git status` 确认为有效 Git 工作树，因此本步骤不能记录可靠 commit hash；
10. 用户提供的变量说明文档作为范围参考，但其中内容不高于当前 checkout 源码。

## 10. 第一版完成标准

第一版只有在以下条件全部满足时，才能称为“可交给 LLM Agent 使用”：

- 每个正式变量有稳定 ID、规范名、中文解释和所属层级；
- 每个核心变量至少有一个当前源码文件和符号证据；
- 明确接口路径、数据类型、形状、单位/尺度、范围或未知状态；
- 原始量、静态量、动态量、派生量、动作量、预测量和指标不混层；
- 转换、归一化、阈值和聚合公式可追踪；
- 设计意图与代码现实分开；
- 已知问题能链接回受影响变量；
- 支持按中英文名、代码名、别名、类别和源码路径检索；
- 标准问题集能检查变量命中、事实、证据、拒答和歧义处理；
- 离线测试通过后才记录“结构有效”；真实模型/SC2 未运行时不得记录“运行时已验证”。

## 11. 后续扩展原则

新增字段或新接口必须经过：

1. 提交当前代码使用证据或明确的官方接口层扩展提案；
2. 指定来源层级与稳定 ID；
3. 说明单位、类型、范围、生命周期和消费者；
4. 增加至少一个检索别名和一个标准测试问题；
5. 更新关系图和已知问题；
6. 通过 Schema、证据路径和回归测试；
7. 若改变旧语义，保留兼容别名并记录版本变更。

## 12. 本步骤读取的关键证据

### 当前代码与配置

- `main.py::main`
- `agents/raw_agent.py::RawAgent.__init__`
- `agents/raw_agent.py::RawAgent.step`
- `agents/raw_agent.py::RawAgent.parse_raw_units`
- `agents/raw_agent.py::RawAgent._make_llm_decision`
- `agents/raw_agent.py::RawAgent._convert_actions_to_pysc2`
- `agents/response_parser.py::ResponseParser`
- `agents/action_executor.py::ActionExecutor`
- `ontology/bridge.py::BattlefieldGraph`
- `ontology/data/marine_ontology.py`
- `ontology/loader.py::OntologyLoader`
- `ontology/builder.py`
- `ontology/prompt_template.py`
- `ontology/swm_predictor.py::SWMPredictor`
- `ontology/swm_trainer.py::TrajectoryCollector`
- `examples/ablation_experiment.py`
- `examples/swm_experiment.py`
- `examples/ood_matrix_experiment.py`
- `examples/adaptive_ontology_experiment.py`
- `agents/heuristic_agent.py`、`agents/rl_agent.py`
- `pyproject.toml`、`.python-version`

### 测试与结果材料

- `tests/test_unknown_unit_fallback.py`
- `tests/test_auto_extender.py`
- `data/record/*.csv`
- `data/record/**/summary.json`
- `data/record/**/summary.csv`

### 次级参考

- `README.md`、`agents/README.md`、`ontology/README.md`、`examples/README.md`
- 用户提供的 `StarCraft环境状态动作变量说明.docx`

次级参考只用于发现候选概念和术语；与当前代码不一致时，以代码现实为准并保留冲突记录。

## 13. 步骤 01 结论

**状态：完成（静态范围定义完成，运行时验证未执行）。**

下一步应执行步骤 02，建立结构化源码证据清单。步骤 02 应为本文件列出的每类变量进一步登记真实路径、关键符号、可证明的断言、证据等级和潜在陈旧性。
