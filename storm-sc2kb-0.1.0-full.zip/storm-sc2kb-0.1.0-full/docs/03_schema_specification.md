# STORM 变量知识库统一 Schema 规范

- Schema 版本：`1.0.0`
- 适用范围：`storm-sc2kb-v1-raw`
- Schema 文件：`knowledge/schemas/variable.schema.json`
- 示例文件：`knowledge/variables/examples.yaml`
- 核对日期：2026-09-03
- 核对方式：当前仓库静态源码审查
- 运行状态：**未启动 StarCraft II，未调用外部 LLM，未查阅外部 PySC2 官方资料**

## 1. 一句话说明

本 Schema 把每个变量写成一张可机器校验的“变量卡片”：既能让 LLM 用中文、英文或代码名找到变量，也能继续追到 PySC2 接口、STORM 源码、转换公式、消费者和证据，同时明确区分“本来想怎样”和“代码实际怎样”。

## 2. 设计目标

每条记录应能独立回答：

1. 变量叫什么，自然语言还可能怎么称呼？
2. 它属于原始观测、TBox、ABox、派生状态、动作、SWM 还是实验指标？
3. 它的物理或业务含义、类型、形状、单位、范围和枚举是什么？
4. PySC2 或 STORM 接口如何访问？
5. 哪段源码读取、转换或消费它？
6. 它何时更新，与哪些变量存在派生或易混淆关系？
7. 哪些结论由当前代码确认，哪些只是设计意图、运行时观测或待核验事项？

## 3. 顶层字段

| 字段 | 必填 | 用途 |
|---|---:|---|
| `schema_version` | 是 | 当前固定为 `1.0.0`，用于迁移和兼容性判断。 |
| `id` | 是 | 稳定机器 ID，如 `raw_unit.health_ratio`。 |
| `canonical_name` | 是 | 规范检索名。 |
| `names` | 是 | `zh`、`en`、`code` 三套名称。 |
| `category` | 是 | 第一版范围中的变量大类。 |
| `aliases` | 是 | 中文问法、英文术语、代码字段名和常见说法。 |
| `definition` | 是 | 严格定义，描述“这个量是什么”。 |
| `intuitive_explanation` | 是 | 面向研究者和 LLM 的大白话解释。 |
| `interface` | 是 | 类型、形状、单位、量纲、范围、枚举、接口路径。 |
| `provenance` | 是 | 来源层、派生方式和上游变量。 |
| `implementation` | 是 | 源码位置、提取代码、转换公式。 |
| `consumers` | 是 | 哪些模块使用它，以及使用目的。 |
| `lifecycle` | 是 | 更新时机、作用域和持久性。 |
| `examples` | 是 | 输入—输出示例和边界示例。 |
| `relationships` | 是 | 派生、转换、约束、区别和关联。 |
| `design_intent` | 是 | 文档、Prompt 或注释表达的设计意图断言。 |
| `code_reality` | 是 | 当前 checkout 的真实实现断言，至少一条。 |
| `limitations` | 是 | 使用边界和不能推出的结论。 |
| `known_issues` | 是 | 带稳定问题 ID 的冲突、陈旧或待核验问题。 |
| `evidence` | 是 | 可追踪证据对象，至少一条。 |
| `verification` | 是 | 本记录实际做过与没做过的验证。 |

## 4. 接口字段与未知值表达

`interface` 将容易混淆的接口属性拆开：

- `data_type`：跨语言逻辑类型；
- `python_type`：当前 Python 表现形式；
- `shape`：标量、向量、表、图等；
- `unit`：单位，例如 `STORM environment step`；
- `dimension`：量纲或类别性质；
- `range`：最小值、最大值和端点是否包含；
- `enum_values`：明确的字符串或离散值集合；
- `pysc2_path`：PySC2 入口；若不是 PySC2 原生量则明确为 `not_applicable`；
- `storm_paths`：变量在 STORM 数据流中的一个或多个路径。

禁止用空字符串伪装未知。单位、量纲、范围、枚举和 PySC2 路径使用以下状态：

| 状态 | 含义 |
|---|---|
| `known` | 已被当前高优先级证据明确确认。 |
| `not_applicable` | 对该变量不适用。 |
| `unknown` | 当前仓库没有给出答案。 |
| `needs_verification` | 有候选解释，但仍需官方资料、版本检查或运行验证。 |

## 5. 来源层与类别

`category` 用于稳定分类；`provenance.source_layer` 描述更具体的数据来源。二者不能替代彼此。例如：

- `raw_unit.health_ratio`：类别是 `raw_unit`，来源层是 `raw_unit_transformed`；
- `Marine.attack_range`：属于 TBox 静态知识；
- `Engagement_Type`：类别是 `derived_tactical_state`，来源层是 `derived_runtime`；
- `delay_steps`：类别是动作 Schema/调度，来源层是 `validated_action`。

第一版类别枚举与 `knowledge/manifests/scope.yaml` 对齐，避免各文件自行发明分类名。

## 6. design_intent 与 code_reality

二者必须使用不同数组，禁止写在同一句模糊描述里：

```yaml
design_intent:
  - claim: Prompt 要求 delay_steps 是 0 到 9 的整数。
    status: design_intent
    evidence_ids: [delay-prompt]
code_reality:
  - claim: Parser 使用 int(...) 转换并把结果裁剪到 0 到 9。
    status: code_reality
    evidence_ids: [delay-parser]
```

这样可以保留冲突。例如接口文档写“integer”，代码却可把字符串 `"3"` 转成整数；知识库不应静默合并。

允许的事实状态：

- `code_reality`：当前源码真实读写或控制流；
- `runtime_observation`：实际运行中观察到的值或行为；
- `design_intent`：Prompt、注释、README 或设计文档表达的意图；
- `derived_runtime`：由运行时输入按明确公式派生；
- `needs_verification`：当前证据不足。

## 7. 证据对象

每条证据包含：

```text
id, path, symbol, line_start, line_end,
evidence_type, claim, fact_status, verified_at
```

提示词要求的七个证据字段均已纳入；额外增加 `id` 供断言引用，增加 `fact_status` 防止“证据等级”和“事实状态”混淆。

行号允许为 `null`：配置、外部资料或易变化容器不一定有稳定行号。已有行号也必须与 `path + symbol` 一起使用，因为编辑代码会导致行号漂移。

| 等级 | 含义 |
|---|---|
| `E1` | 当前可执行源码。 |
| `E2` | 当前测试或可复现运行；只有实际执行后才能写 `runtime_verified`。 |
| `E3` | 配置、Schema、静态本体数据。 |
| `E4` | 已提交历史实验产物。 |
| `E5` | README、注释或说明，只支持设计意图/候选术语。 |
| `E6` | 外部官方资料，需要版本核验。 |

## 8. 实现、消费者与生命周期

- `implementation.source_locations` 支持一个变量对应多个实现位置。例如 `delay_steps` 同时有 Prompt、Parser 和调度器。
- `extraction_code` 记录关键访问形式，不复制整段源码。
- `transformation_formula` 记录归一化、阈值、裁剪或聚合。
- `consumers` 必须说明“谁用”和“为什么用”。
- `lifecycle` 明确静态、每观测、每决策、每动作、每回合或每实验更新。

## 9. 关系与 LLM 检索顺序

1. 对用户问题做中文/英文/代码名归一化；
2. 匹配 `id`、`canonical_name`、`names.*` 和 `aliases`；
3. 用 `category`、`source_layer` 缩小候选范围；
4. 用 `definition` 和 `intuitive_explanation` 回答含义；
5. 用 `interface` 回答类型、单位和接口；
6. 用 `implementation` 与 `evidence` 给出代码依据；
7. 用 `relationships` 区分同名或易混淆量；
8. 优先陈述 `code_reality`，再单列设计意图和待核验项。

推荐回答模板：

```text
规范变量：<id>（中文名 / code name）
简明含义：<intuitive_explanation>
接口形式：<pysc2_path + storm_paths + data_type/shape/unit>
转换或公式：<transformation_formula>
当前代码现实：<code_reality>
依据：<path>::<symbol>:<line_start>-<line_end>
限制/待核验：<limitations + known_issues>
```

## 10. 四类示例

| 类别 | 示例 ID | 展示重点 |
|---|---|---|
| RawUnit 字段 | `raw_unit.health_ratio` | 位置索引访问、除以 255、绝对值与比例区别。 |
| TBox 字段 | `tbox.unit.marine.attack_range` | 静态类型知识、单位未知、缓存陈旧风险。 |
| 派生量 | `derived.tactical.engagement_type` | 质心距离、枚举、阈值边界与缺失条件。 |
| 动作字段 | `action.delay_steps` | Prompt 意图、Parser 归一化、未来动作调度。 |

示例中的 `static_verified` 只表示当前源码/静态数据已人工核对，不表示 SC2 运行成功。

## 11. 验证方法

从仓库根目录执行：

```powershell
python -c "import json; json.load(open('knowledge/schemas/variable.schema.json', encoding='utf-8')); print('JSON PASS')"
python -c "import yaml; yaml.safe_load(open('knowledge/variables/examples.yaml', encoding='utf-8')); print('YAML PASS')"
python -c "import json,yaml,jsonschema; s=json.load(open('knowledge/schemas/variable.schema.json',encoding='utf-8')); jsonschema.Draft202012Validator.check_schema(s); d=yaml.safe_load(open('knowledge/variables/examples.yaml',encoding='utf-8')); [jsonschema.validate(r,s) for r in d['records']]; print('SCHEMA PASS')"
```

还应检查：示例 ID 唯一、四类齐全、证据路径存在、行号范围有效、所有输出位于 `knowledge/`、没有私人绝对路径、未夸大运行状态。

## 12. 当前限制和后续演进

1. 本步骤只设计单记录 Schema 和四类样例，不等于已完成全部变量卡片。
2. PySC2 RawUnit 位置索引的官方字段名、dtype 和版本语义尚未通过 E6 证据核验。
3. TBox 单位和本体 pickle 缓存一致性尚未运行验证。
4. SC2、LLM、SWM、示例脚本和业务测试均未执行。
5. 后续若增加字段，应提升 `schema_version`，提供迁移说明，并先更新自动化数据质量测试。
6. Schema 约束结构完整性，不自动判断自然语言定义是否正确；语义正确性仍依赖证据审查。
