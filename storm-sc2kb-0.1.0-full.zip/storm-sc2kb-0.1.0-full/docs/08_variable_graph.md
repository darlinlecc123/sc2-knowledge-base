# 步骤 08：变量关系图

- 报告日期：2026-09-04
- 范围：当前STORM主路径实际使用的135条变量
- 机器边表：`knowledge/relations/variable_relations.jsonl`
- 运行边界：SC2运行未执行；外部LLM/SWM未调用；实验复现未执行

## 1. 一句话结论

当前知识库已经把“变量卡片”连接为可追踪的有向图：既能沿
`PySC2 observation → RawUnit → ABox/BattlefieldGraph → Prompt → Parser → ActionExecutor → FunctionCall`
查动作链，也能沿
`ABox + 候选动作 → SWM预测 → 预测误差指标`
查预测链。源码能证明的是数据读取、转换和调用路径；真实SC2值、模型输出和游戏引擎执行结果仍需运行验证。

## 2. 关系类型

| 关系 | 含义 |
|---|---|
| `read_from` | 目标变量从源接口、配置或静态定义中读取。 |
| `transformed_to` | 源数据经过非纯存储的转换形成目标。 |
| `normalized_as` | 源编码按明确归一化公式形成目标比例量。 |
| `aggregated_into` | 一个或多个源值通过计数、均值、比率或统计公式汇总成目标。 |
| `stored_as` | 源值被复制、重命名、序列化或嵌入目标结构。 |
| `used_by` | 源变量或数据结构被目标组件消费。 |
| `validated_by` | 源响应或字段由目标校验器检查和修正。 |
| `mapped_to` | STORM动作语义被映射成PySC2 FunctionCall字段或编号。 |
| `predicts` | 源状态、动作或预测器产生未来状态预测。 |
| `evaluated_by` | 预测结果由目标误差或准确率指标评估。 |
| `aliases` | 自然语言规范化词可检索到目标变量；属于结构性索引关系。 |

## 3. Mermaid总览

```mermaid
flowchart LR
    OBS["PySC2 observation"] -->|read_from| RAW["RawUnit / player / score"]
    TBOX["TBox静态定义"] -->|stored_as| ABOX["ABox / BattlefieldGraph"]
    RAW -->|normalized_as / stored_as| ABOX
    ABOX -->|aggregated_into| TACT["战术派生状态"]
    TACT -->|used_by| PROMPT["STORM决策Prompt"]
    ABOX -->|used_by| PROMPT
    PROMPT -->|transformed_to| LLM["LLM响应"]
    LLM -->|validated_by| PARSER["ResponseParser"]
    PARSER -->|stored_as| ACT["校验后动作"]
    ACT -->|stored_as| DELAY["pending_actions"]
    ACT -->|mapped_to| FC["PySC2 Raw FunctionCall"]
    DELAY -->|used_by| FC
    ABOX -->|stored_as| SWMIN["SWM ABox输入"]
    ACT -->|stored_as| SWMIN
    SWMIN -->|predicts| SWMOUT["SWM预测"]
    SWMOUT -->|evaluated_by| METRIC["SWM误差指标"]
    SCORE["TimeStep累计得分"] -->|aggregated_into| METRIC2["实验指标"]
```

## 4. 边表结构

JSONL每行是一条完整关系，核心字段包括：

- `id`：由源ID、关系类型和目标ID计算的稳定关系ID；
- `source` / `target`：节点ID、节点类型、层级和变量类别；
- `relation_type`：本步骤定义的11类关系之一；
- `evidence_basis`：`source_evidence`或`structural_index`；
- `truth_status`：`code_reality`、`design_intent`、`runtime_observation`、`needs_verification`或不适用；
- `evidence`：仓库相对路径、符号和可稳定取得的行号；
- `formulas` / `limitations`：转换公式和事实边界。

## 5. 关系统计

| 关系 | 边数 |
|---|---:|
| `aggregated_into` | 26 |
| `aliases` | 1146 |
| `evaluated_by` | 3 |
| `mapped_to` | 12 |
| `normalized_as` | 1 |
| `predicts` | 3 |
| `read_from` | 42 |
| `stored_as` | 109 |
| `transformed_to` | 7 |
| `used_by` | 79 |
| `validated_by` | 2 |

总计：135条正式变量、1207个图节点、1430条边。

## 6. 关键查询示例

### “单位当前血量最后在哪里使用？”

```text
artifact.pysc2.observation
  → raw_unit.health
  → abox.unit.hp
  → derived.tactical.friendly_avg_hp / enemy_avg_hp
  → derived.tactical.health_status
  → STORM决策Prompt
```

### “动作怎样变成PySC2调用？”

```text
LLM response
  → ResponseParser
  → action.type / units / target / subtype
  → ActionExecutor
  → pysc2.*.function_id + unit_tags + target + queued + raw_flag
  → artifact.pysc2.function_call
```

### “SWM误差从哪里来？”

```text
ABox序列化状态 + 校验后动作列表 + prediction_steps
  → SWM raw_response
  → predictions / predicted_unit_states / predicted_relations
  → health_rmse / position_rmse / relation_accuracy
  → overall_error
```

## 7. 可信边界

- `code_reality`：当前源码明确存在读取、转换、校验或构造路径；
- `design_intent`：只代表设计或文档意图，不能冒充当前实现；
- `runtime_observation`：需要实际运行产生的观测证据；步骤08没有此类证据；
- `needs_verification`：LLM/SWM输出、SC2引擎执行、外部接口语义或运行值尚未验证；
- `aliases`边只是检索索引，不代表物理量之间存在因果关系。

## 8. 重要冲突：planned_actions不是同一种量

`action.planned_actions`是ResponseParser返回的**整数动作数量**；`swm.input.planned_actions`
是传给SWM的**动作字典列表**。当前代码实际传入`initial_parsed["actions"]`。因此关系图没有把整数计数
直接当成SWM动作列表，而是通过`artifact.storm.validated_actions`连接，并在审计报告中保留上游血缘冲突。

## 9. 使用建议

LLM Agent查询变量时，应先用`aliases`定位候选变量，再沿事实边回答上游、下游、公式和源码依据。
歧义别名不能静默选一个；`needs_verification`边不能描述成“已经在SC2中验证成功”。
