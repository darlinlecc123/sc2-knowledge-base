# 步骤 15：建立无 LLM 的基础测试

## 使用方式

1. 建议先把 `knowledge/prompts/00_master_prompt.md` 作为系统级或前置提示词提供给 Agent。
2. 再把本文件完整内容作为当前任务提示词。
3. Agent 必须从仓库根目录执行，并把所有新增产物写入 `knowledge/`。
4. 若上游产物不存在，先报告缺失项；能从源码安全补建时可以补建，否则不得编造。

## 统一范围

第一版仅整理当前 STORM 代码实际读取、转换、生成、校验或使用的 PySC2 Raw API 变量，以及这些变量直接产生的 TBox、ABox、派生战术状态、动作参数、SWM 变量和实验指标。不要扩展为完整 PySC2 或完整 StarCraft II 百科。

## Agent 角色

你是Python 测试与数据质量工程师。你的任务不是泛泛介绍 StarCraft II，而是依据当前 STORM 仓库生成可验证、可维护、可供 LLM Agent 检索的知识库产物。

## 必要输入与上游依赖

步骤 03、05、07、08、10、13、14 产物

## 本步骤任务

1. 为 Schema 合法性、唯一 ID、证据路径存在性、别名冲突、关系端点、JSONL/YAML 可解析性编写测试。
2. 为检索器编写固定查询测试和歧义处理测试。
3. 为上下文包编写范围泄漏、缺失证据和断链检查。
4. 为已知问题建立防误答测试，例如不能把 ABox armor 无条件解释成静态护甲。
5. 根据项目实际工具链选择最小可行测试运行方式；若引入 pytest，须在 knowledge 文档中说明，不修改陈旧 requirements.txt。

## 强制约束

- 所有事实必须能回指当前仓库源码、配置、测试或运行产物；外部常识只能作为补充并清楚标注。
- 不得把 PySC2 官方可能提供但 STORM 当前未读取的字段写成第一版正式变量。
- 必须区分 `design_intent`、`code_reality`、`runtime_observation` 和 `needs_verification`。
- 引用源码时记录相对仓库根目录的路径、类/函数/符号；能稳定获取行号时再记录行号，避免伪造精确行号。
- 未实际运行的测试、模型调用或实验必须标为“未执行”，不得声称成功。
- 不修改 `agents/`、`ontology/`、`examples/`、`main.py` 等 STORM 业务源码，除非用户另行授权。

## 输出文件

- `knowledge/tests/test_schema_and_data.py`
- `knowledge/tests/test_retrieval.py`
- `knowledge/tests/test_relations.py`
- `knowledge/tests/test_known_issues.py`
- `knowledge/docs/15_offline_tests.md`

若目录不存在可以创建，但所有路径必须位于 `knowledge/` 内。除指定文件外，如确需增加辅助文件，应在完成报告中解释原因。

## 输出要求

- Markdown 面向中文研究者，代码字段保留原始英文名。
- YAML/JSON/JSONL 必须可被程序解析；JSONL 每行一个完整对象。
- 机器可读文件使用 UTF-8，稳定 ID，确定性排序。
- 重要结论同时给“简明解释”和“证据依据”。

## 验收清单

- [ ] 测试无需 SC2 安装和外部 API
- [ ] 失败信息能定位具体变量记录
- [ ] 不得声称测试通过，除非实际运行并记录命令和结果
- [ ] 所有新增文件均位于 `knowledge/`。
- [ ] 完成报告列出读取文件、新建/修改文件、验证命令、验证结果和未解决问题。

## 禁止事项

- 禁止凭记忆补齐完整 PySC2 字段。
- 禁止把说明文档里的任务描述当成高优先级事实证据。
- 禁止覆盖既有人工内容而不先对比。
- 禁止在未经授权时访问外部模型账号、上传仓库或发布 GitHub。

## 完成报告模板

```markdown
### 步骤 15 完成报告
- 状态：完成 / 部分完成 / 阻塞
- 读取的关键证据：
- 新建或修改的文件：
- 执行的验证：
- 主要发现：
- 未解决问题：
- 建议下一步：
```
