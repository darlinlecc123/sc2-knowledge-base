# 步骤 02：建立源码与证据清单

## 使用方式

1. 建议先把 `knowledge/prompts/00_master_prompt.md` 作为系统级或前置提示词提供给 Agent。
2. 再把本文件完整内容作为当前任务提示词。
3. Agent 必须从仓库根目录执行，并把所有新增产物写入 `knowledge/`。
4. 若上游产物不存在，先报告缺失项；能从源码安全补建时可以补建，否则不得编造。

## 统一范围

第一版仅整理当前 STORM 代码实际读取、转换、生成、校验或使用的 PySC2 Raw API 变量，以及这些变量直接产生的 TBox、ABox、派生战术状态、动作参数、SWM 变量和实验指标。不要扩展为完整 PySC2 或完整 StarCraft II 百科。

## Agent 角色

你是代码考古与证据管理工程师。你的任务不是泛泛介绍 StarCraft II，而是依据当前 STORM 仓库生成可验证、可维护、可供 LLM Agent 检索的知识库产物。

## 必要输入与上游依赖

步骤 01 产物、当前仓库

## 本步骤任务

1. 扫描与 Raw API 变量有关的源码、配置、示例、测试、CSV/JSON 和已有文档。
2. 为每个证据源记录路径、用途、关键类/函数、可证明的变量类别、可信等级和更新时间。
3. 至少覆盖 main.py、agents/raw_agent.py、agents/response_parser.py、agents/action_executor.py、ontology/bridge.py、ontology/data/marine_ontology.py、ontology/prompt_template.py、ontology/swm_predictor.py、ontology/swm_trainer.py、ontology/loader.py、ontology/builder.py。
4. 记录同一概念存在多个来源时的优先级：运行时代码 > 校验代码/测试 > 配置/Schema > 文档/注释 > 外部常识。
5. 标记缓存、本体 pickle、历史实验文件等可能陈旧的证据。

## 强制约束

- 所有事实必须能回指当前仓库源码、配置、测试或运行产物；外部常识只能作为补充并清楚标注。
- 不得把 PySC2 官方可能提供但 STORM 当前未读取的字段写成第一版正式变量。
- 必须区分 `design_intent`、`code_reality`、`runtime_observation` 和 `needs_verification`。
- 引用源码时记录相对仓库根目录的路径、类/函数/符号；能稳定获取行号时再记录行号，避免伪造精确行号。
- 未实际运行的测试、模型调用或实验必须标为“未执行”，不得声称成功。
- 不修改 `agents/`、`ontology/`、`examples/`、`main.py` 等 STORM 业务源码，除非用户另行授权。

## 输出文件

- `knowledge/manifests/source_registry.yaml`
- `knowledge/docs/02_source_registry.md`

若目录不存在可以创建，但所有路径必须位于 `knowledge/` 内。除指定文件外，如确需增加辅助文件，应在完成报告中解释原因。

## 输出要求

- Markdown 面向中文研究者，代码字段保留原始英文名。
- YAML/JSON/JSONL 必须可被程序解析；JSONL 每行一个完整对象。
- 机器可读文件使用 UTF-8，稳定 ID，确定性排序。
- 重要结论同时给“简明解释”和“证据依据”。

## 验收清单

- [ ] 所有路径真实存在或明确标记缺失
- [ ] 关键结论能回指文件、符号或行号范围
- [ ] 不使用 README 替代源码证据
- [ ] 所有新增文件均位于 `knowledge/`。
- [ ] 完成报告列出读取文件、新建/修改文件、验证命令、验证结果和未解决问题。

## 禁止事项

- 禁止凭记忆补齐完整 PySC2 字段。
- 禁止把说明文档里的任务描述当成高优先级事实证据。
- 禁止覆盖既有人工内容而不先对比。
- 禁止在未经授权时访问外部模型账号、上传仓库或发布 GitHub。

## 完成报告模板

```markdown
### 步骤 02 完成报告
- 状态：完成 / 部分完成 / 阻塞
- 读取的关键证据：
- 新建或修改的文件：
- 执行的验证：
- 主要发现：
- 未解决问题：
- 建议下一步：
```
