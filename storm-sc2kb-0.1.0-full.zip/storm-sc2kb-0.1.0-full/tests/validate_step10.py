"""步骤10离线验收：不启动 SC2、不联网、不调用外部模型。"""
from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KNOWLEDGE = ROOT / "knowledge"
SRC = KNOWLEDGE / "src"
sys.path.insert(0, str(SRC))

from sc2kb import SearchEngine  # noqa: E402

ERRORS: list[str] = []
WARNINGS: list[str] = []


def check(condition: bool, message: str) -> None:
    if condition:
        print(f"PASS: {message}")
    else:
        ERRORS.append(message)
        print(f"FAIL: {message}")


def ids(result: dict) -> list[str]:
    return [item["variable_id"] for item in result["results"]]


def main() -> int:
    engine = SearchEngine()
    check(len(engine.kb.records) == 135, "加载且仅加载 135 个步骤05正式变量")

    required = [
        KNOWLEDGE / "src/sc2kb/__init__.py",
        KNOWLEDGE / "src/sc2kb/loader.py",
        KNOWLEDGE / "src/sc2kb/search.py",
        KNOWLEDGE / "src/sc2kb/cli.py",
        KNOWLEDGE / "docs/10_retrieval_usage.md",
    ]
    check(all(path.is_file() for path in required), "步骤10五个指定输出文件均存在")
    check(all(KNOWLEDGE in path.resolve().parents for path in required), "全部指定输出位于 knowledge 目录")

    health = engine.search("health")
    check(health["status"] == "found" and ids(health)[0] == "raw_unit.health", "health 命中当前别名索引指定的 raw_unit.health")

    hp = engine.search("hp")
    check(hp["status"] == "ambiguous", "hp 按步骤07歧义组返回 ambiguous")
    check({"raw_unit.health", "abox.unit.hp", "tbox.entity.hp"}.issubset(ids(hp)), "hp 返回 Raw/TBox/ABox 全部候选")
    check(bool(hp.get("clarification_question")), "歧义结果带澄清问题")

    weapon_id = engine.search("raw_unit.weapon_cooldown")
    check(weapon_id["status"] == "found" and ids(weapon_id) == ["raw_unit.weapon_cooldown"], "规范 ID 精确命中 weapon_cooldown")
    weapon_name = engine.search("weapon_cooldown")
    check(weapon_name["status"] == "ambiguous" and {"raw_unit.weapon_cooldown", "abox.unit.weapon_cooldown"}.issubset(ids(weapon_name)), "代码名 weapon_cooldown 返回跨层候选")

    alliance = engine.search("alliance")
    check(alliance["status"] == "ambiguous" and len(ids(alliance)) >= 2, "alliance 不武断选择单个层级")

    delay = engine.search("action.delay_steps")
    check(delay["status"] == "found" and ids(delay) == ["action.delay_steps"], "action.delay_steps 规范 ID 精确命中")

    chinese = engine.search("武器CD")
    check(chinese["status"] == "found" and ids(chinese)[0] == "raw_unit.weapon_cooldown", "中文别名可检索")

    natural = engine.search("weapon_cooldown 是什么意思")
    check(natural["match_stage"] in {"contained", "fuzzy"} and "raw_unit.weapon_cooldown" in ids(natural), "自然语言包含查询可检索")

    category = engine.search("health", category="raw_unit")
    check(ids(category) == ["raw_unit.health"], "category 过滤有效")

    source_path = engine.search("health", source_path="agents/raw_agent.py")
    check("raw_unit.health" in ids(source_path), "source_path 过滤有效")

    downstream = engine.search("", downstream_of="raw_unit.health")
    check("abox.unit.hp" in ids(downstream), "downstream_of 返回直接下游正式变量")
    upstream = engine.search("", upstream_of="abox.unit.hp")
    check("raw_unit.health" in ids(upstream), "upstream_of 返回直接上游正式变量")

    armor = engine.search("abox.unit.armor")
    armor_issues = [entry.get("id") for entry in armor["results"][0]["known_issues"]["step09"]]
    check("issue.abox_armor_stores_shield" in armor_issues, "结果合并步骤09已知问题")

    missing = engine.search("completely_nonexistent_sc2_variable_xyz")
    check(missing["status"] == "not_found" and missing["result_count"] == 0 and missing["results"] == [], "不存在查询明确返回 not_found")
    check("没有自动创建新变量" in missing.get("message", ""), "未找到消息明确说明不创建变量")

    required_result_fields = {
        "variable_id", "meaning", "interface", "source_evidence",
        "formula_or_transformation", "limitations", "known_issues",
    }
    check(required_result_fields.issubset(weapon_id["results"][0]), "结果包含七类强制字段")

    env = os.environ.copy()
    env["PYTHONPATH"] = str(SRC)
    env["PYTHONIOENCODING"] = "utf-8"
    cli = subprocess.run(
        [sys.executable, str(KNOWLEDGE / "src/sc2kb/cli.py"), "action.delay_steps", "--json"],
        cwd=ROOT,
        env=env,
        text=True,
        encoding="utf-8",
        capture_output=True,
        check=False,
    )
    check(cli.returncode == 0, "CLI 从仓库根目录直接运行成功")
    try:
        cli_json = json.loads(cli.stdout)
    except json.JSONDecodeError:
        cli_json = {}
    check(cli_json.get("results", [{}])[0].get("variable_id") == "action.delay_steps", "CLI --json 输出可解析")

    forbidden_import_roots = {"openai", "requests", "httpx", "chromadb", "faiss", "pinecone", "weaviate"}
    imported: set[str] = set()
    for path in (KNOWLEDGE / "src/sc2kb").glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imported.add(node.module.split(".")[0])
    check(not (imported & forbidden_import_roots), "检索包不导入外部网络、LLM 或向量库客户端")

    print(f"errors: {len(ERRORS)}")
    print(f"warnings: {len(WARNINGS)}")
    print("RESULT: " + ("PASS" if not ERRORS and not WARNINGS else "FAIL"))
    if ERRORS:
        print("ERROR_LIST:")
        for error in ERRORS:
            print("- " + error)
    return 0 if not ERRORS and not WARNINGS else 1


if __name__ == "__main__":
    raise SystemExit(main())


