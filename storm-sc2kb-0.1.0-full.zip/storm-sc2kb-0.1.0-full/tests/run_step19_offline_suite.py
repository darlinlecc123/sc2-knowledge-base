#!/usr/bin/env python3
"""顺序运行 knowledge/tests 下全部离线脚本，并保存机器可读结果。"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEST_DIR = ROOT / "knowledge" / "tests"
OUTPUT = ROOT / "knowledge" / "reports" / "19_offline_test_results.json"
SECRET_ENV_NAMES = {
    "OPENAI_API_KEY", "DEEPSEEK_API_KEY", "OPENAI_BASE_URL", "OPENAI_MODEL",
    "GPT_API_KEY", "API_KEY",
}


def main() -> int:
    env = os.environ.copy()
    for name in SECRET_ENV_NAMES:
        env.pop(name, None)
    scripts = sorted(p for p in TEST_DIR.glob("*.py") if p.name != Path(__file__).name)
    rows = []
    for script in scripts:
        started = time.perf_counter()
        try:
            proc = subprocess.run(
                [sys.executable, str(script)], cwd=ROOT, env=env,
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                timeout=180,
            )
            status = "passed" if proc.returncode == 0 else "failed"
            row = {
                "name": script.name,
                "status": status,
                "returncode": proc.returncode,
                "duration_seconds": round(time.perf_counter() - started, 3),
                "stdout": proc.stdout[-8000:],
                "stderr": proc.stderr[-8000:],
            }
        except subprocess.TimeoutExpired as exc:
            row = {
                "name": script.name, "status": "timeout", "returncode": None,
                "duration_seconds": round(time.perf_counter() - started, 3),
                "stdout": (exc.stdout or "")[-8000:] if isinstance(exc.stdout, str) else "",
                "stderr": (exc.stderr or "")[-8000:] if isinstance(exc.stderr, str) else "",
            }
        rows.append(row)
        print(f"{row['status'].upper():7} {script.name} ({row['duration_seconds']}s)")
    summary = {
        "schema_version": "1.0.0",
        "date": "2026-09-07",
        "python": sys.version.split()[0],
        "external_api_credentials_removed": sorted(SECRET_ENV_NAMES),
        "total": len(rows),
        "passed": sum(x["status"] == "passed" for x in rows),
        "failed": sum(x["status"] == "failed" for x in rows),
        "timeout": sum(x["status"] == "timeout" for x in rows),
        "results": rows,
    }
    OUTPUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({k: summary[k] for k in ("total", "passed", "failed", "timeout")}, ensure_ascii=False))
    # 有失败也返回0，让验收报告能够继续生成；失败状态由结果文件严格记录。
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
