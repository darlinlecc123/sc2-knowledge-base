"""步骤 12 离线验收：不启动 SC2，不访问外部模型。"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KB_ROOT = ROOT / "knowledge"
sys.path.insert(0, str(KB_ROOT / "src"))

from sc2kb.model_clients import CallableModelClient, DisabledModelClient, load_model_config
from sc2kb.qa_agent import QAAgent


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def fake_answer(messages, **kwargs):
    require(any("raw_unit.health" in message["content"] for message in messages), "假模型未收到 health 上下文")
    return json.dumps(
        {
            "corresponding_variables": ["raw_unit.health"],
            "plain_language_meaning": "单位当前生命值。",
            "physical_or_business_meaning": "当前绝对生命值。",
            "interface_form": {},
            "storm_code_locations": [],
            "transformations_or_formulas": [],
            "limitations_and_evidence": [],
        },
        ensure_ascii=False,
    )


def main() -> int:
    checks: list[str] = []

    agent = QAAgent(model_client=DisabledModelClient())
    health = agent.ask("health 是什么意思？", dry_run=True)
    require(health["status"] == "ready", "health dry-run 应处于 ready")
    require(health["candidate_variable_ids"] == ["raw_unit.health"], "health 应唯一命中 raw_unit.health")
    require(health["model_called"] is False, "dry-run 不得调用模型")
    require("raw-unit-health-code" in health["grounding"]["evidence_ids"], "应带 health 证据 ID")
    require(any(x.get("path") == "agents/raw_agent.py" for x in health["grounding"]["source_locations"]), "应带源码路径")
    checks.append("无密钥 health dry-run")

    for query in ("hp", "alliance", "weapon_cooldown"):
        result = agent.ask(query, dry_run=True)
        require(result["status"] == "ambiguous", f"{query} 应返回歧义")
        require(result["model_called"] is False, "歧义时不得调用模型")
    checks.append("跨层同名歧义")

    multi_cases = [
        (
            "我想看兵现在还剩多少血和盾，该找哪两个原始量？",
            {"raw_unit.health", "raw_unit.shield"},
        ),
        (
            "Compare pysc2.function.target and pysc2.function.unit_tags in the final FunctionCall.",
            {"pysc2.function.target", "pysc2.function.unit_tags"},
        ),
        (
            "ABox 单位节点的位置属性用哪个变量保存，它来自哪些 RawUnit 坐标？",
            {"abox.unit.position", "raw_unit.x", "raw_unit.y"},
        ),
    ]
    for question, expected_ids in multi_cases:
        result = agent.ask(question, dry_run=True, limit=8)
        require(result["status"] == "ready", f"多变量问题不应被误判为歧义：{question}")
        require(set(result["candidate_variable_ids"]) == expected_ids, f"多变量召回不准确：{question}")
    checks.append("自然语言多变量与跨层关系检索")

    alliance_sentence = agent.ask(
        "If I ask for alliance without naming a layer, which STORM variables are plausible candidates?",
        dry_run=True,
        limit=8,
    )
    require(alliance_sentence["status"] == "ambiguous", "明确未指定层级的完整问句仍应要求澄清")
    require(
        {"raw_unit.alliance", "abox.unit.alliance"}.issubset(alliance_sentence["candidate_variable_ids"]),
        "alliance 完整问句应保留 Raw/ABox 候选",
    )
    checks.append("完整问句歧义保留")

    missing = agent.ask("本知识库完全不存在的量子折跃概率", dry_run=False)
    require(missing["status"] == "not_found", "范围外问题应拒答")
    require(missing["model_called"] is False, "无依据时不得调用模型")
    require("拒绝编造" in missing["answer"]["refusal"], "拒答文本应明确禁止编造")
    require(
        "scope-v0.1-manifest" in missing["grounding"]["evidence_ids"],
        "范围外拒答应带 V0.1 范围清单证据",
    )
    require(
        any(
            item.get("path") == "knowledge/manifests/scope.yaml"
            and item.get("symbol") == "scope.in_scope_rule"
            for item in missing["grounding"]["source_locations"]
        ),
        "范围外拒答应带范围清单路径和符号",
    )
    checks.append("范围外拒答与范围证据")

    cache_issue = agent.ask("修改 marine_ontology.py 后 TBox 静态 hp 会立刻更新吗？", dry_run=True, limit=8)
    require(cache_issue["candidate_variable_ids"] == ["tbox.entity.hp"], "缓存问题应命中 tbox.entity.hp")
    required_issue_ids = {
        "tbox-entity-hp-code",
        "issue.ontology_pickle_may_be_stale",
        "issue.unknown_unit_hp_default_is_static_only",
    }
    require(
        required_issue_ids.issubset(cache_issue["grounding"]["evidence_ids"]),
        "TBox 缓存问题应聚合变量主证据和步骤09问题证据",
    )
    issue_paths = {item.get("path") for item in cache_issue["grounding"]["source_locations"]}
    require(
        {"ontology/loader.py", "ontology/bridge.py"}.issubset(issue_paths),
        "TBox 缓存问题应带 loader 与 bridge 的源码证据",
    )
    checks.append("步骤09已知问题多证据聚合")

    fake_agent = QAAgent(model_client=CallableModelClient(fake_answer))
    answered = fake_agent.ask("raw_unit.health", dry_run=False)
    require(answered["status"] == "answered", "本地假模型应完成结构化回答")
    require(answered["model_called"] is True, "非 dry-run 应调用注入客户端")
    require(answered["grounding"] == health["grounding"], "替换客户端不应改变检索 grounding")
    checks.append("可插拔本地假模型")

    config = load_model_config(KB_ROOT / "config" / "model.example.yaml")
    require(config["provider"] == "disabled", "示例配置必须默认禁用模型")
    config_text = (KB_ROOT / "config" / "model.example.yaml").read_text(encoding="utf-8")
    require("sk-" not in config_text.lower(), "示例配置疑似含真实密钥")
    checks.append("配置与密钥安全")

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    process = subprocess.run(
        [
            sys.executable,
            str(KB_ROOT / "src" / "sc2kb" / "qa_agent.py"),
            "action.delay_steps",
            "--dry-run",
            "--json",
        ],
        cwd=ROOT,
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=False,
    )
    require(process.returncode == 0, "CLI dry-run 执行失败：" + process.stderr)
    cli_result = json.loads(process.stdout)
    require(cli_result["model_called"] is False, "CLI dry-run 不得调用模型")
    require("action.delay_steps" in cli_result["candidate_variable_ids"], "CLI 应检索 delay_steps")
    checks.append("CLI JSON dry-run")

    print(json.dumps({"result": "PASS", "checks": checks, "external_model_test": "未执行", "sc2_runtime": "未执行"}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

