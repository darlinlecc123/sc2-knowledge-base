"""校验冻结挑战集；不得导入或调用检索器。"""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
QUESTIONS = KB / "evals" / "questions_challenge_v0.1.jsonl"
MANIFEST = KB / "evals" / "challenge_v0.1_manifest.json"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", text.casefold())


def main() -> int:
    payload = QUESTIONS.read_bytes()
    cases = [json.loads(line) for line in payload.decode("utf-8").splitlines() if line.strip()]
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    records = {
        r["variable_id"]: r
        for line in (KB / "context" / "variables.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
        for r in [json.loads(line)]
    }
    originals = {
        norm(q["question"])
        for name in ("questions_dev.jsonl", "questions_test.jsonl")
        for line in (KB / "evals" / name).read_text(encoding="utf-8").splitlines()
        if line.strip()
        for q in [json.loads(line)]
    }
    ids = [q["id"] for q in cases]
    questions = [norm(q["question"]) for q in cases]
    require(len(cases) == 32, "挑战集应固定为32题")
    require(len(ids) == len(set(ids)), "挑战题 ID 必须唯一")
    require(len(questions) == len(set(questions)), "挑战题文本必须唯一")
    require(not (set(questions) & originals), "挑战题不得与原 benchmark 规范化文本重复")
    require(all(q["split"] == "challenge" for q in cases), "split 必须为 challenge")
    require(all(q["notes"].startswith("冻结后首次运行") for q in cases), "必须声明冻结测试策略")
    require(all(set(q["expected_variable_ids"]) <= records.keys() for q in cases), "期望变量必须属于135条正式记录")
    require(all(q["required_evidence"] for q in cases), "每题至少需要一条证据")
    require(manifest["sha256"] == hashlib.sha256(payload).hexdigest(), "挑战集 SHA-256 与清单不一致")
    require(manifest["frozen_before_first_evaluation"] is True, "清单必须声明先冻结后评测")
    require(manifest["source_benchmark_normalized_overlap"] == 0, "清单必须记录零文本重叠")
    behavior = Counter(q["expected_behavior"] for q in cases)
    require(behavior["answer"] >= 25 and behavior["clarify"] >= 2 and behavior["refuse"] >= 2, "行为覆盖不足")
    types = Counter(q["question_type"] for q in cases)
    require(len(types) >= 9, "题型覆盖不足")
    print(json.dumps({
        "result": "PASS",
        "case_count": len(cases),
        "sha256": manifest["sha256"],
        "normalized_overlap_with_dev_test": 0,
        "difficulty": dict(Counter(q["difficulty"] for q in cases)),
        "question_type": dict(types),
        "expected_behavior": dict(behavior),
        "retrieval_imported_or_called": False,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
