"""RAG 多槽位检索优化的离线回归测试；禁止调用外部模型。"""
from __future__ import annotations

import hashlib
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
sys.path.insert(0, str(KB / "src"))

from sc2kb.qa_agent import QAAgent  # noqa: E402


EXPECTED_CHALLENGE_SHA256 = "E7FBFA05317D01BC93593DBFD354C34E7DC33F2AC34818CACF0E8171479E2044"


def load_rows(name: str) -> list[dict]:
    path = KB / "evals" / name
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


class RagCompositionalRetrievalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.agent = QAAgent(context_profile="standard")

    def evaluate(self, name: str, *, limit: int = 8) -> tuple[float, float, float, int]:
        rows = load_rows(name)
        status_hits = exact_hits = empty_answerable = 0
        recalls: list[float] = []
        status_map = {"found": "ready", "ambiguous": "ambiguous", "not_found": "not_found"}
        for row in rows:
            result = self.agent.ask(row["question"], dry_run=True, limit=limit)
            self.assertFalse(result["model_called"], f"{row['id']} 意外调用外部模型")
            actual = set(result["candidate_variable_ids"])
            expected = set(row.get("expected_variable_ids", []))
            status_hits += result["status"] == status_map[row["expected_status"]]
            exact_hits += actual == expected
            empty_answerable += row["expected_status"] == "found" and not actual
            recalls.append(len(actual & expected) / len(expected) if expected else float(not actual))
        n = len(rows)
        return status_hits / n, exact_hits / n, sum(recalls) / n, empty_answerable

    def test_rag_compact_context_is_smaller_and_buildable(self) -> None:
        question = "同一个 hp 概念在 Raw 观测、ABox 实例与 TBox 静态类型中分别对应什么？"
        compact = QAAgent(context_profile="rag_compact").ask(question, dry_run=True, limit=8)
        standard = QAAgent(context_profile="standard").ask(question, dry_run=True, limit=8)
        self.assertEqual(compact["candidate_variable_ids"], standard["candidate_variable_ids"])
        self.assertTrue(compact["messages"])
        compact_chars = sum(len(item["content"]) for item in compact["messages"])
        standard_chars = sum(len(item["content"]) for item in standard["messages"])
        self.assertLess(compact_chars, standard_chars)

    def test_new_optimization_development_set(self) -> None:
        rows = load_rows("questions_rag_optimization_dev_v0.1.jsonl")
        self.assertEqual(len(rows), 30)
        status, exact, recall, empty = self.evaluate("questions_rag_optimization_dev_v0.1.jsonl")
        self.assertGreaterEqual(status, 0.90)
        self.assertGreaterEqual(exact, 0.80)
        self.assertGreaterEqual(recall, 0.90)
        self.assertEqual(empty, 0)

    def test_atomic_slot_composition_development_set(self) -> None:
        status, exact, recall, empty = self.evaluate("questions_rag_composition_dev_v0.2.jsonl", limit=10)
        self.assertGreaterEqual(status, 0.95)
        self.assertGreaterEqual(exact, 0.85)
        self.assertGreaterEqual(recall, 0.90)
        self.assertEqual(empty, 0)

    def test_old_development_sets_remain_exact(self) -> None:
        for name in ("questions_generalization_dev_v0.1.jsonl", "questions_generalization_dev_v0.2.jsonl"):
            with self.subTest(name=name):
                status, exact, recall, empty = self.evaluate(name, limit=10)
                self.assertEqual((status, exact, recall, empty), (1.0, 1.0, 1.0, 0))

    def test_challenge_file_is_unchanged_and_regression_improves(self) -> None:
        challenge = KB / "evals" / "questions_challenge_v0.3.jsonl"
        self.assertEqual(hashlib.sha256(challenge.read_bytes()).hexdigest().upper(), EXPECTED_CHALLENGE_SHA256)
        status, exact, recall, empty = self.evaluate(challenge.name)
        self.assertGreaterEqual(status, 0.95)
        self.assertGreaterEqual(exact, 0.90)
        self.assertGreaterEqual(recall, 0.95)
        self.assertLessEqual(empty, 1)


    def test_formula_dependencies_are_explicit_and_valid(self) -> None:
        payload = json.loads((KB / "retrieval" / "formula_dependencies.json").read_text(encoding="utf-8"))
        formal_ids = {
            json.loads(line)["variable_id"]
            for line in (KB / "context" / "variables.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()
        }
        dependencies = payload.get("dependencies")
        self.assertIsInstance(dependencies, list)
        self.assertGreaterEqual(len(dependencies), 5)
        rule_ids = [rule["id"] for rule in dependencies]
        self.assertEqual(len(rule_ids), len(set(rule_ids)))
        for rule in dependencies:
            variables = set(rule.get("variable_ids", []))
            self.assertTrue(set(rule.get("inputs", [])) <= variables, rule["id"])
            self.assertTrue(set(rule.get("outputs", [])) <= variables, rule["id"])
            self.assertTrue(variables <= formal_ids, rule["id"])
            self.assertTrue(rule.get("all_groups"), rule["id"])

    def test_variable_groups_are_formal_and_valid(self) -> None:
        payload = json.loads((KB / "retrieval" / "variable_groups.json").read_text(encoding="utf-8"))
        formal_ids = {
            json.loads(line)["variable_id"]
            for line in (KB / "context" / "variables.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()
        }
        groups = payload.get("groups")
        self.assertIsInstance(groups, list)
        self.assertGreaterEqual(len(groups), 35)
        group_ids = [group["id"] for group in groups]
        self.assertEqual(len(group_ids), len(set(group_ids)))
        for group in groups:
            self.assertIn(group.get("kind"), {"family", "cross_layer", "ambiguity"})
            self.assertTrue(group.get("layers"), group["id"])
            variables = set(group.get("variable_ids", []))
            self.assertTrue(variables, group["id"])
            self.assertTrue(variables <= formal_ids, group["id"])
            self.assertTrue(group.get("all_groups"), group["id"])

    def test_generalization_development_v03(self) -> None:
        rows = load_rows("questions_rag_generalization_dev_v0.3.jsonl")
        self.assertEqual(len(rows), 45)
        status_map = {"found": "ready", "ambiguous": "ambiguous", "not_found": "not_found"}
        status_hits = exact_hits = 0
        recalls: list[float] = []
        precisions: list[float] = []
        for row in rows:
            result = self.agent.ask(row["question"], dry_run=True, limit=8)
            actual = set(result["candidate_variable_ids"])
            expected = set(row["expected_variable_ids"])
            status_hits += result["status"] == status_map[row["expected_status"]]
            exact_hits += actual == expected
            recalls.append(len(actual & expected) / len(expected) if expected else float(not actual))
            precisions.append(len(actual & expected) / len(actual) if actual else float(not expected))
        count = len(rows)
        self.assertGreaterEqual(status_hits / count, 0.95)
        self.assertGreaterEqual(exact_hits / count, 0.90)
        self.assertGreaterEqual(sum(recalls) / count, 0.95)
        self.assertGreaterEqual(sum(precisions) / count, 0.95)

    def test_scope_exclusions_precede_raw_positive_matches(self) -> None:
        questions = (
            "Raw 接口里的 feature_screen player_relative 是哪个变量？",
            "Raw observation 中 RGB screen shape 和 channel 怎么读？",
            "Raw 环境的 replay APM 在哪里？",
            "Raw 观测中的 UI control_groups 如何表示？",
        )
        for question in questions:
            with self.subTest(question=question):
                result = self.agent.ask(question, dry_run=True, limit=8)
                self.assertEqual(result["status"], "not_found")
                self.assertEqual(result["retrieval"]["match_stage"], "scope_exclusion")
                self.assertEqual(result["candidate_variable_ids"], [])

    def test_abox_dynamic_layer_recognition_and_group_metadata(self) -> None:
        result = self.agent.ask(
            "只看 ABox 动态实例的生命比例、武器冷却、攻击伤害与攻击距离。",
            dry_run=True,
            limit=8,
        )
        self.assertEqual(result["status"], "ready")
        self.assertEqual(
            result["candidate_variable_ids"],
            [
                "abox.unit.hp_ratio",
                "abox.unit.weapon_cooldown",
                "abox.unit.attack_damage",
                "abox.unit.attack_range",
            ],
        )
        self.assertIn("group.abox.dynamic_combat", result["retrieval"]["variable_group_ids"])

    def test_formula_metadata_and_complete_dependency_expansion(self) -> None:
        result = self.agent.ask(
            "解释每次决策平均 token：总 token 除以决策调用次数得到哪个输出？",
            dry_run=True,
            limit=8,
        )
        self.assertEqual(
            result["candidate_variable_ids"],
            [
                "metric.llm.total_tokens",
                "metric.llm.decision_calls",
                "metric.llm.avg_tokens_per_decision",
            ],
        )
        self.assertIn(
            "formula.metric.avg_tokens_per_decision",
            result["retrieval"]["formula_dependency_ids"],
        )


if __name__ == "__main__":
    unittest.main()
