"""校验 challenge v0.3 冻结完整性；不得导入或调用检索器。"""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
QUESTIONS = KB / "evals" / "questions_challenge_v0.3.jsonl"
MANIFEST = KB / "evals" / "challenge_v0.3_manifest.json"
FROZEN_SHA256 = "e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044"
PRIOR = (
    "questions_dev.jsonl",
    "questions_test.jsonl",
    "questions_generalization_dev_v0.1.jsonl",
    "questions_generalization_dev_v0.2.jsonl",
    "questions_challenge_v0.1.jsonl",
    "questions_challenge_v0.2.jsonl",
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", text.casefold())


def main() -> int:
    payload = QUESTIONS.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    cases = [json.loads(line) for line in payload.decode("utf-8").splitlines() if line.strip()]
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    records = {
        item["variable_id"]: item
        for line in (KB / "context" / "variables.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
        for item in [json.loads(line)]
    }
    prior_norms = {
        norm(item["question"])
        for name in PRIOR
        for line in (KB / "evals" / name).read_text(encoding="utf-8").splitlines()
        if line.strip()
        for item in [json.loads(line)]
    }
    ids = [item["id"] for item in cases]
    texts = [norm(item["question"]) for item in cases]
    require(len(cases) == 41, "challenge v0.3 应固定为 41 题")
    require(len(ids) == len(set(ids)), "v0.3 题目 ID 重复")
    require(len(texts) == len(set(texts)), "v0.3 题面重复")
    require(not (set(texts) & prior_norms), "v0.3 与既有题集存在规范化文本重合")
    require(all(item["split"] == "challenge_v0.3" for item in cases), "v0.3 split 非法")
    require(all(item["notes"].startswith("v0.3 已在首次评测前冻结") for item in cases), "v0.3 缺少冻结声明")
    require(all(set(item["expected_variable_ids"]) <= records.keys() for item in cases), "v0.3 引用非正式变量")
    require(all(item["required_evidence"] for item in cases), "v0.3 每题必须有证据")
    require(digest == FROZEN_SHA256, "v0.3 文件已偏离固定 SHA-256")
    require(manifest["sha256"] == FROZEN_SHA256, "v0.3 清单 SHA-256 不一致")
    require(manifest["frozen_before_first_evaluation"] is True, "v0.3 未声明先冻结")
    require(manifest["first_evaluation_status"] == "not_run_at_freeze_time", "v0.3 冻结时不应已有评测")
    require(manifest["normalized_overlap_with_all_prior_sets"] == 0, "v0.3 清单文本重合应为 0")
    require(manifest["retrieval_imported_or_called_during_generation"] is False, "v0.3 生成阶段不应调用检索器")
    behavior = Counter(item["expected_behavior"] for item in cases)
    require(behavior["answer"] >= 35 and behavior["clarify"] >= 3 and behavior["refuse"] >= 3, "v0.3 行为覆盖不足")
    require(len(Counter(item["question_type"] for item in cases)) >= 7, "v0.3 题型覆盖不足")
    print(json.dumps({
        "result": "PASS",
        "case_count": len(cases),
        "sha256": digest,
        "normalized_overlap_with_all_prior_sets": 0,
        "difficulty": dict(Counter(item["difficulty"] for item in cases)),
        "question_type": dict(Counter(item["question_type"] for item in cases)),
        "expected_behavior": dict(behavior),
        "retrieval_imported_or_called": False,
        "first_evaluation_status": manifest["first_evaluation_status"],
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
