"""步骤 13 benchmark 离线验收。"""
from __future__ import annotations

import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
K = ROOT / "knowledge"
DEV = K / "evals" / "questions_dev.jsonl"
TEST = K / "evals" / "questions_test.jsonl"
VARIABLES = K / "context" / "variables.jsonl"

REQUIRED_KEYS = {
    "id", "split", "question", "language", "question_type", "category", "difficulty",
    "expected_variable_ids", "required_facts", "required_evidence", "forbidden_claims",
    "expected_behavior", "expected_status", "clarification_required", "source_record_refs",
}
EXPECTED_VARIABLE_CATEGORIES = {
    "raw_unit", "timestep_player_score", "tbox_static", "abox_dynamic",
    "derived_tactical_state", "action_schema_and_scheduling", "pysc2_function_call",
    "swm", "experiment_metric", "environment_config",
}
RAW_CORE = {
    "raw_unit.unit_type", "raw_unit.alliance", "raw_unit.health", "raw_unit.shield",
    "raw_unit.health_ratio", "raw_unit.shield_ratio", "raw_unit.x", "raw_unit.y",
    "raw_unit.weapon_cooldown", "raw_unit.tag",
}
ACTION_CORE = {
    "action.type", "action.units", "action.target", "action.target_type", "action.delay_steps",
    "action.priority", "pysc2.function.unit_tags", "pysc2.function.target",
    "pysc2.function.queued", "pysc2.move.function_id", "pysc2.attack.function_id",
}
QUESTION_TYPES = {
    "direct", "oral", "english", "multi_variable_comparison", "ambiguous",
    "false_premise", "out_of_scope", "known_issue_trap",
}


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            raise AssertionError(f"{path.name}:{number} 不是合法 JSON: {exc}") from exc
        assert isinstance(value, dict), f"{path.name}:{number} 顶层不是对象"
        rows.append(value)
    return rows


def main() -> int:
    checks: list[str] = []
    assert DEV.is_file() and TEST.is_file(), "两份 benchmark JSONL 必须存在"
    dev, test = load_jsonl(DEV), load_jsonl(TEST)
    rows = dev + test
    assert len(dev) == 36 and len(test) == 18 and len(rows) == 54, "题量必须为 dev=36/test=18/total=54"
    checks.append("题量与拆分")

    ids = [row["id"] for row in rows]
    assert len(ids) == len(set(ids)), "题目 ID 必须唯一"
    assert [row["id"] for row in dev] == sorted(row["id"] for row in dev), "dev 未确定性排序"
    assert [row["id"] for row in test] == sorted(row["id"] for row in test), "test 未确定性排序"
    assert all(REQUIRED_KEYS <= row.keys() for row in rows), "存在缺少必需字段的题目"
    assert all(row["required_facts"] and row["required_evidence"] and row["forbidden_claims"] for row in rows), "必需约束字段不能为空"
    checks.append("JSONL schema 与稳定 ID")

    variable_rows = load_jsonl(VARIABLES)
    records = {row["variable_id"]: row for row in variable_rows}
    official_ids = set(records)
    cited_ids = {variable_id for row in rows for variable_id in row["expected_variable_ids"]}
    assert cited_ids <= official_ids, f"出现非正式变量：{sorted(cited_ids - official_ids)}"
    checks.append("期望变量均属于135条正式记录")

    for row in rows:
        for evidence in row["required_evidence"]:
            assert evidence.get("path") and evidence.get("evidence_id"), f"{row['id']} 存在空证据"
            if evidence["evidence_id"] == "scope-v0.1-manifest":
                assert (ROOT / evidence["path"]).is_file(), "范围证据文件不存在"
                continue
            matching_records = [records[vid] for vid in row["expected_variable_ids"]]
            direct_ids = {e.get("id") for r in matching_records for e in r.get("evidence", [])}
            issue_ids = {i.get("id") for r in matching_records for i in (r.get("known_issues") or {}).get("step09", [])}
            assert evidence["evidence_id"] in direct_ids | issue_ids, f"{row['id']} 引用了未绑定的证据 {evidence['evidence_id']}"
    checks.append("证据 ID 与变量记录一致")

    covered_categories = {category for row in rows for category in row["variable_categories"]}
    assert EXPECTED_VARIABLE_CATEGORIES <= covered_categories, f"变量类别覆盖不足：{EXPECTED_VARIABLE_CATEGORIES-covered_categories}"
    assert {row["difficulty"] for row in rows} == {"easy", "medium", "hard"}, "难度覆盖不足"
    assert QUESTION_TYPES <= {row["question_type"] for row in rows}, "题型覆盖不足"
    checks.append("类别、难度、题型覆盖")

    assert RAW_CORE <= cited_ids, f"RawUnit 核心字段覆盖不足：{RAW_CORE-cited_ids}"
    assert ACTION_CORE <= cited_ids, f"关键动作字段覆盖不足：{ACTION_CORE-cited_ids}"
    checks.append("RawUnit 与动作核心字段覆盖")

    assert sum(row["expected_behavior"] == "clarify" for row in rows) >= 4, "歧义题不足"
    assert sum(row["question_type"] == "false_premise" for row in rows) >= 4, "错误前提题不足"
    assert sum(row["expected_behavior"] == "refuse" for row in rows) >= 3, "拒答题不足"
    assert any("issue.abox_armor_stores_shield" in json.dumps(row, ensure_ascii=False) for row in rows), "缺少 ABox armor 陷阱"
    checks.append("歧义、错误前提、拒答与已知问题")

    assert not ({row["question"] for row in dev} & {row["question"] for row in test}), "dev/test 问题文本重复"
    assert all(row["split"] == "dev" for row in dev) and all(row["split"] == "test" for row in test), "split 字段错误"
    checks.append("保留测试集隔离")

    process = subprocess.run(
        [sys.executable, str(K / "scripts" / "generate_step13_benchmark.py"), "--check"],
        cwd=ROOT, capture_output=True, text=True, encoding="utf-8", check=False,
    )
    assert process.returncode == 0, "确定性重建失败：" + process.stdout + process.stderr
    checks.append("生成器确定性重建")

    stats = {
        "dev": len(dev), "test": len(test), "total": len(rows),
        "difficulty": dict(sorted(Counter(row["difficulty"] for row in rows).items())),
        "question_type": dict(sorted(Counter(row["question_type"] for row in rows).items())),
        "evaluation_category": dict(sorted(Counter(row["category"] for row in rows).items())),
        "variable_categories": sorted(covered_categories),
    }
    print(json.dumps({
        "result": "PASS", "checks": checks, "statistics": stats,
        "external_model_test": "未执行", "sc2_runtime": "未执行",
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
