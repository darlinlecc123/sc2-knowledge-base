"""校验 challenge v0.2 冻结完整性；不得导入或调用检索器。"""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
QUESTIONS = KB / "evals" / "questions_challenge_v0.2.jsonl"
MANIFEST = KB / "evals" / "challenge_v0.2_manifest.json"
PRIOR = ("questions_dev.jsonl", "questions_test.jsonl", "questions_challenge_v0.1.jsonl", "questions_generalization_dev_v0.1.jsonl")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", text.casefold())


def main() -> int:
    payload = QUESTIONS.read_bytes()
    cases = [json.loads(line) for line in payload.decode("utf-8").splitlines() if line.strip()]
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    records = {r["variable_id"]: r for line in (KB / "context" / "variables.jsonl").read_text(encoding="utf-8").splitlines() if line.strip() for r in [json.loads(line)]}
    prior_norms = {norm(q["question"]) for name in PRIOR for line in (KB / "evals" / name).read_text(encoding="utf-8").splitlines() if line.strip() for q in [json.loads(line)]}
    ids = [q["id"] for q in cases]
    texts = [norm(q["question"]) for q in cases]
    require(len(cases) == 35, "challenge v0.2 应固定为35题")
    require(len(ids) == len(set(ids)), "v0.2 题目 ID 重复")
    require(len(texts) == len(set(texts)), "v0.2 题目文本重复")
    require(not (set(texts) & prior_norms), "v0.2 与既有题集存在规范化文本重合")
    require(all(q["split"] == "challenge_v0.2" for q in cases), "v0.2 split 非法")
    require(all(q["notes"].startswith("v0.2 冻结后首次运行") for q in cases), "v0.2 未声明冻结策略")
    require(all(set(q["expected_variable_ids"]) <= records.keys() for q in cases), "v0.2 引用非正式变量")
    require(all(q["required_evidence"] for q in cases), "v0.2 每题必须有证据")
    require(manifest["sha256"] == hashlib.sha256(payload).hexdigest(), "v0.2 SHA-256 不一致")
    require(manifest["frozen_before_first_evaluation"] is True, "v0.2 未声明先冻结")
    require(manifest["normalized_overlap_with_all_prior_sets"] == 0, "v0.2 清单文本重合应为0")
    behavior = Counter(q["expected_behavior"] for q in cases)
    require(behavior["answer"] >= 30 and behavior["clarify"] >= 2 and behavior["refuse"] >= 2, "v0.2 行为覆盖不足")
    require(len(Counter(q["question_type"] for q in cases)) >= 7, "v0.2 题型覆盖不足")
    print(json.dumps({"result": "PASS", "case_count": len(cases), "sha256": manifest["sha256"], "normalized_overlap_with_all_prior_sets": 0, "difficulty": dict(Counter(q["difficulty"] for q in cases)), "question_type": dict(Counter(q["question_type"] for q in cases)), "expected_behavior": dict(behavior), "retrieval_imported_or_called": False}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
