"""challenge v0.4 冻结完整性测试；不得调用 QAAgent 或外部模型。"""
from __future__ import annotations

import hashlib
import json
import re
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
EVALS = KB / "evals"
EXPECTED_QUESTION_SHA256 = "12041D3A9D52439D13233D0AD6FEAA06BCB06BA2504BE2765C13BB5FC02F69C1"
EXPECTED_LOCK_SHA256 = "89AF0FD012E18B4C2C33FE2493D0D05499C34A726CB85D31AF13ACEBE2060A48"
FORMAL_FILES = ("abox.yaml","actions.yaml","derived.yaml","metrics.yaml","raw_api.yaml","swm.yaml","tbox.yaml")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def normalize(text: str) -> str:
    return re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+", "", text).casefold()


class ChallengeV04FreezeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.question_file = EVALS / "questions_challenge_v0.4.jsonl"
        cls.manifest_file = EVALS / "challenge_v0.4_manifest.json"
        cls.lock_file = EVALS / "rag_v0.4_preblind_lock.json"
        cls.rows = [json.loads(line) for line in cls.question_file.read_text(encoding="utf-8").splitlines() if line.strip()]
        cls.manifest = json.loads(cls.manifest_file.read_text(encoding="utf-8"))
        cls.lock = json.loads(cls.lock_file.read_text(encoding="utf-8"))
        cls.formal_ids = set()
        for name in FORMAL_FILES:
            payload = yaml.safe_load((KB / "variables" / name).read_text(encoding="utf-8"))
            cls.formal_ids.update(record["id"] for record in payload["records"])

    def test_frozen_hashes(self) -> None:
        self.assertEqual(sha256(self.question_file), EXPECTED_QUESTION_SHA256)
        self.assertEqual(sha256(self.lock_file), EXPECTED_LOCK_SHA256)
        self.assertEqual(self.manifest["sha256"].upper(), EXPECTED_QUESTION_SHA256)
        self.assertEqual(self.manifest["rag_lock_sha256"].upper(), EXPECTED_LOCK_SHA256)

    def test_preblind_lock_records_immutable_baseline_and_current_rag_is_postblind(self) -> None:
        self.assertEqual(self.lock["file_count"], len(self.lock["files"]))
        changed = {
            entry["path"]
            for entry in self.lock["files"]
            if sha256(ROOT / entry["path"]) != entry["sha256"]
        }
        self.assertIn("knowledge/src/sc2kb/qa_agent.py", changed)
        self.assertIn("knowledge/retrieval/semantic_concepts.json", changed)
        self.assertIn("knowledge/retrieval/facet_registry.json", changed)

    def test_question_schema_ids_and_evidence(self) -> None:
        self.assertEqual(len(self.rows), 51)
        self.assertEqual(len({row["id"] for row in self.rows}), len(self.rows))
        self.assertEqual(len({normalize(row["question"]) for row in self.rows}), len(self.rows))
        for row in self.rows:
            with self.subTest(question_id=row["id"]):
                self.assertEqual(row["benchmark_version"], "0.4.0")
                self.assertEqual(row["split"], "challenge_v0.4")
                self.assertFalse(set(row["expected_variable_ids"]) - self.formal_ids)
                self.assertTrue(row["required_evidence"])
                for evidence in row["required_evidence"]:
                    self.assertTrue((ROOT / evidence["path"]).exists())

    def test_no_exact_question_overlap_with_prior_sets(self) -> None:
        current = {normalize(row["question"]) for row in self.rows}
        for prior in EVALS.glob("questions*.jsonl"):
            if prior == self.question_file:
                continue
            prior_norms = {normalize(json.loads(line)["question"]) for line in prior.read_text(encoding="utf-8").splitlines() if line.strip()}
            self.assertFalse(current & prior_norms, f"与 {prior.name} 存在规范化完全重复")

    def test_generator_did_not_import_retrieval(self) -> None:
        source = (EVALS / "create_challenge_v0_4.py").read_text(encoding="utf-8")
        self.assertNotIn("QAAgent", source.replace("禁止导入或调用 QAAgent", ""))
        self.assertNotIn("from sc2kb", source)
        self.assertNotIn("import sc2kb", source)


if __name__ == "__main__":
    unittest.main()
