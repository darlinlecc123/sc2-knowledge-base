"""challenge v0.6 冻结完整性测试；不得调用问答代理、检索器或外部模型。"""
from __future__ import annotations

import hashlib
import json
import re
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
EVALS = KB / "evals"
EXPECTED_QUESTION_SHA256 = "17154021026EBCBBA90896B51FDE12D26F4419D019ADACE072A63C803589AD14"
EXPECTED_MANIFEST_SHA256 = "C596CC845BDF7AA1CD03A2C1F59308374EB0748D3A8B7FB12F6F341E3A14204F"
EXPECTED_LOCK_SHA256 = "EE9FA81B36B8CC9362F467E3EC5EE94C870F09A56B587442C02D3459236F0D05"
EXPECTED_GENERATOR_SHA256 = "6B2D6A7D0F9C69D65E24217E5F2FFE900397A8C8C13CD72BD1037B4B83BA6675"
EXPECTED_RECEIPT_SHA256 = "1DB961353F349CB7BDD117F011BE1901CB2927021C9A24F1101AF6FBE9EB7C95"
FORMAL_FILES = ("abox.yaml", "actions.yaml", "derived.yaml", "metrics.yaml", "raw_api.yaml", "swm.yaml", "tbox.yaml")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def normalize(text: str) -> str:
    return re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+", "", text).casefold()


class ChallengeV06FreezeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.question_file = EVALS / "questions_challenge_v0.6.jsonl"
        cls.manifest_file = EVALS / "challenge_v0.6_manifest.json"
        cls.lock_file = EVALS / "rag_v0.6_preblind_lock.json"
        cls.generator_file = EVALS / "create_challenge_v0_6.py"
        cls.receipt_file = EVALS / "challenge_v0.6_freeze_receipt.json"
        cls.rows = [json.loads(line) for line in cls.question_file.read_text(encoding="utf-8").splitlines() if line.strip()]
        cls.manifest = json.loads(cls.manifest_file.read_text(encoding="utf-8"))
        cls.lock = json.loads(cls.lock_file.read_text(encoding="utf-8"))
        cls.receipt = json.loads(cls.receipt_file.read_text(encoding="utf-8"))
        cls.formal_ids = set()
        for name in FORMAL_FILES:
            payload = yaml.safe_load((KB / "variables" / name).read_text(encoding="utf-8"))
            cls.formal_ids.update(record["id"] for record in payload["records"])

    def test_frozen_artifact_hashes(self) -> None:
        self.assertEqual(sha256(self.question_file), EXPECTED_QUESTION_SHA256)
        self.assertEqual(sha256(self.manifest_file), EXPECTED_MANIFEST_SHA256)
        self.assertEqual(sha256(self.lock_file), EXPECTED_LOCK_SHA256)
        self.assertEqual(sha256(self.generator_file), EXPECTED_GENERATOR_SHA256)
        self.assertEqual(sha256(self.receipt_file), EXPECTED_RECEIPT_SHA256)
        self.assertEqual(self.manifest["sha256"].upper(), EXPECTED_QUESTION_SHA256)
        self.assertEqual(self.manifest["rag_lock_sha256"].upper(), EXPECTED_LOCK_SHA256)

    def test_question_schema_ids_and_evidence(self) -> None:
        self.assertEqual(len(self.rows), 60)
        self.assertEqual(len({row["id"] for row in self.rows}), 60)
        self.assertEqual(len({normalize(row["question"]) for row in self.rows}), 60)
        for row in self.rows:
            with self.subTest(question_id=row["id"]):
                self.assertEqual(row["benchmark_version"], "0.6.0")
                self.assertEqual(row["split"], "challenge_v0.6")
                self.assertFalse(set(row["expected_variable_ids"]) - self.formal_ids)
                self.assertTrue(row["required_evidence"])
                for evidence in row["required_evidence"]:
                    self.assertTrue((ROOT / evidence["path"]).exists())

    def test_no_exact_question_overlap_with_prior_sets(self) -> None:
        current = {normalize(row["question"]) for row in self.rows}
        for prior in EVALS.glob("questions*.jsonl"):
            if prior == self.question_file:
                continue
            prior_norms = {
                normalize(json.loads(line)["question"])
                for line in prior.read_text(encoding="utf-8").splitlines()
                if line.strip()
            }
            self.assertFalse(current & prior_norms, f"与 {prior.name} 存在规范化完全重复")

    def test_generator_is_independent_of_retrieval_implementation(self) -> None:
        source = self.generator_file.read_text(encoding="utf-8")
        self.assertNotIn("from sc2kb", source)
        self.assertNotIn("import sc2kb", source)
        self.assertNotRegex(source, r"\bQAAgent\b")
        self.assertNotRegex(source, r"\bSearchEngine\b")

    def test_preblind_lock_all_files_remain_identical(self) -> None:
        self.assertEqual(self.lock["file_count"], 102)
        self.assertEqual(len(self.lock["files"]), 102)
        for entry in self.lock["files"]:
            with self.subTest(path=entry["path"]):
                locked_path = ROOT / entry["path"]
                self.assertTrue(locked_path.exists())
                self.assertEqual(sha256(locked_path), entry["sha256"].upper())
                self.assertEqual(locked_path.stat().st_size, entry["bytes"])

    def test_freeze_receipt_matches_artifacts_and_protocol(self) -> None:
        expected = {
            "question_file": EXPECTED_QUESTION_SHA256,
            "manifest": EXPECTED_MANIFEST_SHA256,
            "rag_lock": EXPECTED_LOCK_SHA256,
            "generator": EXPECTED_GENERATOR_SHA256,
        }
        for key, digest in expected.items():
            self.assertEqual(self.receipt["files"][key]["sha256"], digest)
            self.assertEqual(self.receipt["files"][key]["bytes"], (ROOT / self.receipt["files"][key]["path"]).stat().st_size)
        state = self.receipt["state_at_freeze"]
        self.assertFalse(state["retrieval_pre_run"])
        self.assertFalse(state["model_pre_run"])
        self.assertEqual(state["external_model_test"], "not_run")
        policy = self.receipt["immutable_policy"]
        self.assertTrue(policy["no_retrieval_preview"])
        self.assertTrue(policy["no_partial_or_limit_run"])
        self.assertTrue(policy["first_result_must_not_be_overwritten"])


if __name__ == "__main__":
    unittest.main()
