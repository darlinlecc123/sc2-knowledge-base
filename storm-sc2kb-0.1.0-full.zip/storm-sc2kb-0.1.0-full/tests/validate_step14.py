"""步骤 14 离线验收：固定模拟回答 + QAAgent dry-run。"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
K = ROOT / "knowledge"
RESULTS_ROOT = K / "evals" / "results"
RUNNER = K / "evals" / "run_evaluation.py"


def run(args: list[str]) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    process = subprocess.run([sys.executable, str(RUNNER), *args], cwd=ROOT, env=env,
                             capture_output=True, text=True, encoding="utf-8", check=False)
    if process.returncode != 0:
        raise AssertionError("命令失败：\n" + process.stdout + "\n" + process.stderr)
    return process


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path):
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def new_dir(label: str) -> Path:
    RESULTS_ROOT.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix=f"step14_{label}_", dir=RESULTS_ROOT))


def main() -> int:
    checks: list[str] = []

    perfect_dir = new_dir("perfect")
    args = ["--questions", "knowledge/evals/questions_test.jsonl", "--mode", "mock-perfect",
            "--limit", "6", "--model-label", "mock-a", "--model-label", "mock-b",
            "--output-dir", str(perfect_dir)]
    run(args)
    for name in ("results.jsonl", "summary.json", "run_manifest.json", "report.md"):
        assert (perfect_dir / name).is_file(), f"缺少 {name}"
    perfect_results = read_jsonl(perfect_dir / "results.jsonl")
    perfect_summary = read_json(perfect_dir / "summary.json")["models"]
    assert len(perfect_results) == 12, "两个标签 × 6 题应产生12条结果"
    assert set(perfect_summary) == {"mock-a", "mock-b"}, "多模型/标签结果未隔离"
    for summary in perfect_summary.values():
        assert summary["variable_hit_rate"] == 1
        assert summary["required_fact_coverage"] == 1
        assert summary["evidence_hit_rate"] == 1
        assert summary["forbidden_assertion_rate"] == 0
        assert summary["behavior_accuracy"] == 1
    manifest = read_json(perfect_dir / "run_manifest.json")
    assert manifest["external_model_test"] == "未执行"
    assert manifest["sc2_runtime"] == "未执行"
    assert manifest["code_version"] and manifest["models"] and manifest["randomness"]
    assert "总体指标" in (perfect_dir / "report.md").read_text(encoding="utf-8")
    checks.append("固定正确模拟回答与双标签汇总")

    before = len(perfect_results)
    run([*args, "--resume"])
    after = len(read_jsonl(perfect_dir / "results.jsonl"))
    assert before == after, "resume 应跳过已完成的模型-题目组合"
    checks.append("断点续跑不重复追加")

    imperfect_dir = new_dir("imperfect")
    run(["--questions", "knowledge/evals/questions_dev.jsonl", "--mode", "mock-imperfect",
         "--limit", "20", "--output-dir", str(imperfect_dir)])
    imperfect = read_json(imperfect_dir / "summary.json")["models"]["mock-imperfect"]
    assert imperfect["variable_hit_rate"] < 1, "错误模拟应降低变量命中率"
    assert imperfect["required_fact_coverage"] < 1, "错误模拟应降低事实覆盖率"
    assert imperfect["evidence_hit_rate"] < 1, "错误模拟应降低证据命中率"
    assert imperfect["forbidden_assertion_rate"] > 0, "错误模拟应触发禁止断言"
    assert "失败或需复核样本" in (imperfect_dir / "report.md").read_text(encoding="utf-8")
    checks.append("固定错误模拟可被评分器识别")

    dry_dir = new_dir("dry")
    run(["--questions", "knowledge/evals/questions_dev.jsonl", "--mode", "dry-run",
         "--limit", "3", "--output-dir", str(dry_dir)])
    dry_results = read_jsonl(dry_dir / "results.jsonl")
    assert len(dry_results) == 3
    assert all(item["agent_result"]["model_called"] is False for item in dry_results)
    assert read_json(dry_dir / "run_manifest.json")["external_model_test"] == "未执行"
    checks.append("QAAgent dry-run 无 API 批量运行")

    reproduce_dir = new_dir("reproduce")
    question_id = imperfect_dir.joinpath("results.jsonl")
    failed_id = read_jsonl(question_id)[0]["question_id"]
    run(["--questions", "knowledge/evals/questions_dev.jsonl", "--mode", "mock-imperfect",
         "--question-id", failed_id, "--output-dir", str(reproduce_dir)])
    reproduced = read_jsonl(reproduce_dir / "results.jsonl")
    assert len(reproduced) == 1 and reproduced[0]["question_id"] == failed_id
    assert "--question-id" in reproduced[0]["reproduce_command"]
    checks.append("失败样本可按 question-id 单独复现")

    config_text = (K / "config" / "evaluation.example.yaml").read_text(encoding="utf-8")
    assert "sk-" not in config_text.lower() and "provider: disabled" in config_text
    checks.append("示例配置默认禁用模型且不含密钥")

    print(json.dumps({
        "result": "PASS", "checks": checks,
        "validation_result_dirs": [str(perfect_dir), str(imperfect_dir), str(dry_dir), str(reproduce_dir)],
        "external_model_test": "未执行", "sc2_runtime": "未执行", "llm_judge": "未执行",
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
