"""三知识条件运行器的离线测试；不访问模型 API。"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "knowledge/src"))

from sc2kb.evaluation_conditions import DirectKnowledgeConditionAgent
from sc2kb.model_clients import CallableModelClient


VALID = json.dumps({
    "response_status": "answered",
    "corresponding_variables": ["raw_unit.tag"],
    "plain_language_meaning": "单位唯一标识",
    "physical_or_business_meaning": "区分单位实例",
    "interface_form": {"type": "int"},
    "storm_code_locations": [],
    "transformations_or_formulas": [],
    "limitations_and_evidence": [],
}, ensure_ascii=False)


def main() -> int:
    seen: list[list[dict[str, str]]] = []
    client = CallableModelClient(lambda messages, **kwargs: seen.append(messages) or VALID)
    no_kb = DirectKnowledgeConditionAgent(client, "no_knowledge_base")
    result = no_kb.ask("哪个变量唯一标识单位？", dry_run=False)
    assert result["status"] == "answered"
    assert result["candidate_variable_ids"] == ["raw_unit.tag"]
    assert "FULL_KNOWLEDGE_CONTEXT_BEGIN" not in seen[-1][1]["content"]

    with tempfile.TemporaryDirectory() as td:
        context = Path(td) / "full.md"
        context.write_text("FULL_MARKER raw_unit.tag", encoding="utf-8")
        full = DirectKnowledgeConditionAgent(client, "full_context", context)
        result = full.ask("哪个变量唯一标识单位？", dry_run=False)
        assert result["status"] == "answered"
        assert "FULL_MARKER raw_unit.tag" in seen[-1][1]["content"]
        assert full.context_metadata["truncated"] is False
        assert full.context_metadata["bytes"] > 0

    ambiguous_payload = json.loads(VALID)
    ambiguous_payload.update({
        "response_status": "ambiguous",
        "corresponding_variables": [],
        "clarification_question": "请指定层级。",
    })
    ambiguous = DirectKnowledgeConditionAgent(
        CallableModelClient(lambda **kwargs: json.dumps(ambiguous_payload, ensure_ascii=False)),
        "no_knowledge_base",
    ).ask("HP 是哪一个变量？", dry_run=False)
    assert ambiguous["status"] == "ambiguous"

    invalid = DirectKnowledgeConditionAgent(
        CallableModelClient(lambda **kwargs: "not-json"),
        "no_knowledge_base",
    ).ask("测试", dry_run=False)
    assert invalid["status"] == "model_error"
    assert invalid["model_called"] is True

    print("THREE_CONDITIONS_RUNNER_TEST_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
