"""步骤11上下文包离线验收。"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KNOWLEDGE = ROOT / "knowledge"
CONTEXT = KNOWLEDGE / "context"
ERRORS: list[str] = []
WARNINGS: list[str] = []


def check(condition: bool, message: str) -> None:
    print(("PASS: " if condition else "FAIL: ") + message)
    if not condition:
        ERRORS.append(message)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    required = [
        CONTEXT / "sc2_raw_api_context_short.md",
        CONTEXT / "sc2_raw_api_context_standard.md",
        CONTEXT / "sc2_raw_api_context_full.md",
        CONTEXT / "variables.jsonl",
        CONTEXT / "index.yaml",
    ]
    check(all(path.is_file() for path in required), "步骤11五个指定输出存在")
    check(all(CONTEXT in path.resolve().parents for path in required), "全部指定输出位于 knowledge/context")

    rows = []
    with (CONTEXT / "variables.jsonl").open(encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                ERRORS.append(f"variables.jsonl 第{number}行无效: {exc}")
    ids = [row.get("variable_id") for row in rows]
    check(len(rows) == 135 and len(set(ids)) == 135, "JSONL 含135条唯一正式变量")
    check(ids == sorted(ids), "JSONL 按 variable_id 确定性排序")
    check(all(row.get("record_ref") and row.get("evidence") for row in rows), "每条 JSONL 均保留记录引用和源码证据")
    check(all(row.get("category") and row.get("source_layer") for row in rows), "每条记录明确类别和来源层")
    check(all(row.get("retrieval", {}).get("topics") and row.get("retrieval", {}).get("data_chains") for row in rows), "每条记录至少属于一个主题和数据链分片")

    index = yaml.safe_load((CONTEXT / "index.yaml").read_text(encoding="utf-8"))
    check(index["scope"]["formal_variable_count"] == 135, "索引声明135个正式变量")
    check(index["scope"]["complete_pysc2_api"] is False, "索引明确不是完整 PySC2 API")
    check(index["scope"]["external_llm_tested"] is False and index["scope"]["sc2_executed"] is False, "索引如实标记未调用外部模型且未启动 SC2")
    line_map = index["jsonl"]["variable_id_to_line"]
    check(all(rows[line_map[vid] - 1]["variable_id"] == vid for vid in ids), "索引 JSONL 行号全部准确")
    check(index["jsonl"]["sha256"].casefold() == digest(CONTEXT / "variables.jsonl").casefold(), "索引中的 JSONL SHA-256 正确")

    all_id_set = set(ids)
    for dimension in ("by_category", "by_query_topic", "by_data_chain"):
        for name, item in index["slices"][dimension].items():
            check(item["count"] == len(item["variable_ids"]) == len(item["jsonl_lines"]), f"分片 {dimension}/{name} 计数一致")
            check(set(item["variable_ids"]) <= all_id_set, f"分片 {dimension}/{name} 不含范围外变量")

    markdown = {name: (CONTEXT / f"sc2_raw_api_context_{name}.md").read_text(encoding="utf-8") for name in ("short", "standard", "full")}
    check(len(markdown["short"]) < len(markdown["standard"]) < len(markdown["full"]), "short < standard < full 内容规模递增")
    for name, text in markdown.items():
        check("先识别层级" in text and "证据不足就说不知道" in text and "歧义不强选" in text, f"{name} 包含强制回答规则")
        check("不是完整 PySC2" in text, f"{name} 明确 V0.1 范围边界")
    check("category=`raw_unit`" in markdown["short"] and "source_layer=`pysc2_raw_observation`" in markdown["short"], "短版变量卡不混淆层级")
    check(all(f"`{vid}`" in markdown["standard"] for vid in ids), "standard 覆盖全部135个变量 ID")
    check(all(f"### `{vid}`" in markdown["full"] for vid in ids), "full 覆盖全部135个完整变量卡")

    all_output_text = "".join(path.read_text(encoding="utf-8") for path in required)
    check("�" not in all_output_text, "上下文包未注入 Unicode replacement character 乱码")
    omitted_records = sum(bool(row.get("corrupt_fields_omitted")) for row in rows)
    omitted_fields = sum(len(row.get("corrupt_fields_omitted", [])) for row in rows)
    check(index["encoding_safety"]["records_with_omissions"] == omitted_records, "索引的 U+FFFD 剔除记录数与 JSONL 一致")
    check(index["encoding_safety"]["omitted_field_occurrences"] == omitted_fields, "索引的 U+FFFD 剔除字段数与 JSONL 一致")

    for name in ("short", "standard", "full"):
        profile = index["token_budget_profiles"][name]
        path = ROOT / profile["path"]
        check(profile["sha256"].casefold() == digest(path).casefold(), f"{name} SHA-256 与索引一致")
        check(profile["characters"] == len(path.read_text(encoding="utf-8")), f"{name} 字符预算统计准确")
        check(profile["estimated_tokens"] > 0, f"{name} 含非零估算 token 预算")

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    generated = subprocess.run(
        [sys.executable, str(KNOWLEDGE / "scripts/generate_step11_context.py"), "--check"],
        cwd=ROOT, env=env, text=True, encoding="utf-8", capture_output=True, check=False,
    )
    check(generated.returncode == 0 and "RESULT: PASS" in generated.stdout, "生成器 --check 证明五个产物可确定性重建")

    print(f"errors: {len(ERRORS)}")
    print(f"warnings: {len(WARNINGS)}")
    print("RESULT: " + ("PASS" if not ERRORS and not WARNINGS else "FAIL"))
    if ERRORS:
        print("ERROR_LIST:")
        for error in ERRORS:
            print("- " + error)
    return 0 if not ERRORS and not WARNINGS else 1


if __name__ == "__main__":
    raise SystemExit(main())

