"""步骤15：变量关系图与血缘关键链路测试。"""
from __future__ import annotations

import json
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
FORMAL_FILES = ("abox.yaml", "actions.yaml", "derived.yaml", "metrics.yaml", "raw_api.yaml", "swm.yaml", "tbox.yaml")
ALLOWED_RELATION_TYPES = {
    "aliases", "read_from", "stored_as", "normalized_as", "transformed_to",
    "aggregated_into", "mapped_to", "predicts", "evaluated_by", "used_by", "validated_by",
}
ALLOWED_NONVARIABLE_KINDS = {"alias", "artifact", "component", "interface_field"}


def formal_ids() -> set[str]:
    result: set[str] = set()
    for name in FORMAL_FILES:
        payload = yaml.safe_load((KB / "variables" / name).read_text(encoding="utf-8"))
        result.update(item["id"] for item in payload["records"])
    return result


class RelationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.variable_ids = formal_ids()
        cls.relations = []
        path = KB / "relations" / "variable_relations.jsonl"
        for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if line.strip():
                try:
                    cls.relations.append(json.loads(line))
                except json.JSONDecodeError as exc:
                    raise AssertionError(f"关系 JSONL 解析失败 {path}:{line_no}: {exc}") from exc
        cls.edges = {(r["source"]["id"], r["target"]["id"], r["relation_type"]) for r in cls.relations}

    def test_relation_ids_types_and_endpoints(self) -> None:
        ids = [relation["id"] for relation in self.relations]
        self.assertEqual(len(ids), len(set(ids)), "关系 ID 重复")
        for relation in self.relations:
            with self.subTest(relation_id=relation["id"]):
                self.assertIn(relation["relation_type"], ALLOWED_RELATION_TYPES, f"非法关系类型: {relation['relation_type']}")
                for side in ("source", "target"):
                    endpoint = relation[side]
                    if endpoint["kind"] == "variable":
                        self.assertIn(endpoint["id"], self.variable_ids, f"关系 {relation['id']} 的 {side} 变量端点不存在: {endpoint['id']}")
                    else:
                        self.assertIn(endpoint["kind"], ALLOWED_NONVARIABLE_KINDS, f"关系 {relation['id']} 的 {side} 端点 kind 非法: {endpoint}")
                        expected_prefix = "pysc2." if endpoint["kind"] == "interface_field" else endpoint["kind"] + "."
                        self.assertTrue(endpoint["id"].startswith(expected_prefix), f"关系 {relation['id']} 的非变量端点未显式标记: {endpoint}")

    def assert_edge(self, source: str, target: str, relation_type: str) -> None:
        self.assertIn((source, target, relation_type), self.edges, f"关键链路缺失: {source} -[{relation_type}]-> {target}")

    def test_key_lineage_chains(self) -> None:
        self.assert_edge("raw_unit.x", "abox.unit.position", "stored_as")
        self.assert_edge("raw_unit.y", "abox.unit.position", "stored_as")
        self.assert_edge("raw_unit.shield", "abox.unit.armor", "stored_as")
        self.assert_edge("player.food_cap", "player.supply_remaining", "transformed_to")
        self.assert_edge("player.food_used", "player.supply_remaining", "transformed_to")
        self.assert_edge("action.units", "pysc2.function.unit_tags", "mapped_to")
        self.assert_edge("action.target", "pysc2.function.target", "mapped_to")
        self.assert_edge("action.target_type", "pysc2.function.target", "mapped_to")
        self.assert_edge("action.type", "pysc2.build.function_id", "mapped_to")
        self.assert_edge("action.subtype", "pysc2.train.function_id", "mapped_to")

    def test_lineage_file_is_complete_and_has_no_dangling_variable_ids(self) -> None:
        payload = yaml.safe_load((KB / "lineage" / "variable_lineage.yaml").read_text(encoding="utf-8"))
        records = payload["records"]
        lineage_ids = {record["variable_id"] for record in records}
        self.assertEqual(lineage_ids, self.variable_ids, f"血缘文件变量集合不完整: missing={sorted(self.variable_ids-lineage_ids)}, extra={sorted(lineage_ids-self.variable_ids)}")
        for record in records:
            for upstream in record["provenance"].get("upstream_variable_ids", []):
                self.assertIn(upstream, self.variable_ids, f"血缘断链: {record['variable_id']} 引用不存在的上游 {upstream}")
            for downstream in record["downstream"].get("variable_ids", []):
                self.assertIn(downstream, self.variable_ids, f"血缘断链: {record['variable_id']} 引用不存在的下游 {downstream}")


if __name__ == "__main__":
    unittest.main()
