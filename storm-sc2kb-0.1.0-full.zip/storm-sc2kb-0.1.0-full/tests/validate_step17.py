"""步骤17文档离线验收。"""
from __future__ import annotations
import hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];KB=ROOT/'knowledge';sys.path.insert(0,str(KB/'src'))
from sc2kb.loader import load_knowledge_base
DOCS=('index.md','variable_catalog.md','dataflow.md','query_cookbook.md','glossary.md')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def anchor(i):return 'var-'+''.join(x if x.isalnum() else '-' for x in i.lower())
def main():
 errors=[];kb=load_knowledge_base(KB);d=KB/'docs'
 for n in DOCS:
  if not (d/n).exists() or not (d/n).stat().st_size:errors.append('缺失或为空: '+n)
 if errors:raise SystemExit('\n'.join(errors))
 cat=(d/'variable_catalog.md').read_text(encoding='utf-8')
 for i,r in kb.records.items():
  if f'<a id="{anchor(i)}"></a>' not in cat:errors.append('缺少变量锚点: '+i)
  if r.get('intuitive_explanation') not in cat:errors.append('大白话与 YAML 不一致: '+i)
  for x in r.get('implementation',{}).get('source_locations',[]):
   if not (ROOT/x['path']).exists():errors.append(f"源码不可定位: {i} -> {x['path']}")
   if x.get('symbol') and x['symbol'] not in cat:errors.append(f"目录缺源码符号: {i} -> {x['symbol']}")
 if cat.count('<a id="var-')!=len(kb.records):errors.append('变量详情锚点数不等于正式变量数')
 alltext='\n'.join((d/n).read_text(encoding='utf-8') for n in DOCS)
 for x in ('design_intent','code_reality','runtime_observation','needs_verification','TBox','ABox','RawUnit','RAG','ActionExecutor','ResponseParser'):
  if x not in alltext:errors.append('缺少关键说明: '+x)
 pat=re.compile(r'\[[^\]]+\]\(([^)#]+\.md)(?:#[^)]+)?\)')
 for n in DOCS:
  for x in pat.findall((d/n).read_text(encoding='utf-8')):
   if not (d/x).resolve().exists():errors.append(f'内部链接不存在: {n} -> {x}')
 mp=KB/'manifests'/'step17_docs_manifest.json'
 try:m=json.loads(mp.read_text(encoding='utf-8'))
 except Exception as e:errors.append('manifest 不可解析: '+str(e));m={}
 for x in m.get('outputs',[]):
  p=ROOT/x['path']
  if not p.exists() or sha(p)!=x['sha256']:errors.append('输出哈希不一致: '+x['path'])
 if m.get('scope',{}).get('formal_variable_count')!=len(kb.records):errors.append('manifest 变量数不一致')
 if errors:
  print('STEP17 VALIDATION FAILED');[print('FAIL',x) for x in errors];raise SystemExit(1)
 print('STEP17 VALIDATION OK');print('documents=5');print('formal_variables=',len(kb.records));print('relations=',len(kb.relations));print('known_issues=',len(kb.issues));print('source_references=',sum(len(r.get('implementation',{}).get('source_locations',[])) for r in kb.records.values()));print('external_model_called=false');print('sc2_executed=false')
if __name__=='__main__':main()
