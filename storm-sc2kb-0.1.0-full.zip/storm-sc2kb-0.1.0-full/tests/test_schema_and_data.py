"""步骤15：Schema、变量数据和上下文包的离线完整性测试。"""
from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
FORMAL_VARIABLE_FILES = (
    "abox.yaml", "actions.yaml", "derived.yaml", "metrics.yaml",
    "raw_api.yaml", "swm.yaml", "tbox.yaml",
)
EXPECTED_FORMAL_COUNT = 135
CHALLENGE_V01_SHA256 = "68f04650fca4183d213bdfa149a9f9526c2d457fc065dc0a57f52be3016f1c04"
CHALLENGE_V02_SHA256 = "10dd404a28eebf146a150b3191f25591f4b5d901dd027899e5a3ba6f1b6accc4"
CHALLENGE_V03_SHA256 = "e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044"


def load_formal_records() -> list[dict]:
    records: list[dict] = []
    for name in FORMAL_VARIABLE_FILES:
        path = KB / "variables" / name
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
        records.extend(payload["records"])
    return records


class SchemaAndDataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.schema = json.loads((KB / "schemas" / "variable.schema.json").read_text(encoding="utf-8"))
        cls.records = load_formal_records()
        cls.ids = {record["id"] for record in cls.records}

    def test_schema_and_core_fields(self) -> None:
        required = set(self.schema["required"])
        self.assertEqual(self.schema["properties"]["schema_version"]["const"], "1.0.0")
        for record in self.records:
            with self.subTest(variable_id=record.get("id")):
                missing = required - set(record)
                self.assertFalse(missing, f"变量 {record.get('id')} 缺少 Schema 核心字段: {sorted(missing)}")
                self.assertEqual(record["schema_version"], "1.0.0", f"变量 {record['id']} schema_version 异常")

    def test_formal_count_and_unique_ids(self) -> None:
        ids = [record["id"] for record in self.records]
        duplicates = sorted({item for item in ids if ids.count(item) > 1})
        self.assertEqual(len(ids), EXPECTED_FORMAL_COUNT, f"正式变量应为 {EXPECTED_FORMAL_COUNT} 条，实际 {len(ids)} 条")
        self.assertFalse(duplicates, f"变量 ID 重复: {duplicates}")

    def test_each_record_has_existing_source_evidence(self) -> None:
        for record in self.records:
            evidence = record.get("evidence") or []
            with self.subTest(variable_id=record["id"]):
                self.assertTrue(evidence, f"变量 {record['id']} 没有 evidence")
                for item in evidence:
                    source = item.get("path")
                    self.assertTrue(source, f"变量 {record['id']} 的 evidence 缺少 path: {item}")
                    self.assertTrue((ROOT / source).exists(), f"变量 {record['id']} 的证据路径不存在: {source}")

    def test_governed_machine_files_are_parseable(self) -> None:
        yaml_files = list((KB / "variables").glob("*.yaml")) + [
            KB / "known_issues.yaml", KB / "lineage" / "variable_lineage.yaml",
            KB / "retrieval" / "aliases.yaml", KB / "retrieval" / "query_patterns.yaml",
            KB / "context" / "index.yaml",
        ]
        json_files = [
            KB / "schemas" / "variable.schema.json",
            KB / "retrieval" / "semantic_concepts.json",
            KB / "evals" / "challenge_v0.1_manifest.json",
            KB / "evals" / "generalization_dev_v0.1_manifest.json",
            KB / "evals" / "challenge_v0.2_manifest.json",
            KB / "evals" / "generalization_dev_v0.2_manifest.json",
            KB / "evals" / "challenge_v0.3_manifest.json",
        ]
        jsonl_files = [
            KB / "relations" / "variable_relations.jsonl",
            KB / "context" / "variables.jsonl",
            KB / "evals" / "questions_dev.jsonl",
            KB / "evals" / "questions_test.jsonl",
            KB / "evals" / "questions_challenge_v0.1.jsonl",
            KB / "evals" / "questions_generalization_dev_v0.1.jsonl",
            KB / "evals" / "questions_challenge_v0.2.jsonl",
            KB / "evals" / "questions_generalization_dev_v0.2.jsonl",
            KB / "evals" / "questions_challenge_v0.3.jsonl",
        ]
        for file in yaml_files:
            with self.subTest(file=str(file.relative_to(ROOT))):
                self.assertIsNotNone(yaml.safe_load(file.read_text(encoding="utf-8")), f"YAML 无法解析: {file}")
        for file in json_files:
            with self.subTest(file=str(file.relative_to(ROOT))):
                json.loads(file.read_text(encoding="utf-8"))
        for file in jsonl_files:
            with self.subTest(file=str(file.relative_to(ROOT))):
                for line_no, line in enumerate(file.read_text(encoding="utf-8").splitlines(), 1):
                    if line.strip():
                        try:
                            json.loads(line)
                        except json.JSONDecodeError as exc:
                            self.fail(f"JSONL 无法解析: {file.relative_to(ROOT)}:{line_no}: {exc}")

    def test_alias_and_semantic_rule_ids_are_formal(self) -> None:
        aliases = yaml.safe_load((KB / "retrieval" / "aliases.yaml").read_text(encoding="utf-8"))
        referenced: set[str] = set()
        referenced.update(record["variable_id"] for record in aliases["records"])
        for entry in aliases["alias_index"]:
            referenced.update(item["variable_id"] for item in entry["candidate_matches"])
        invalid = sorted(referenced - self.ids)
        self.assertFalse(invalid, f"别名索引引用非正式变量: {invalid}")

        semantic = json.loads((KB / "retrieval" / "semantic_concepts.json").read_text(encoding="utf-8"))
        semantic_ids = {vid for rule in semantic["rules"] for vid in rule.get("variable_ids", [])}
        self.assertFalse(semantic_ids - self.ids, f"语义规则引用非法变量: {sorted(semantic_ids - self.ids)}")
        rule_ids = [rule["id"] for rule in semantic["rules"]]
        self.assertEqual(len(rule_ids), len(set(rule_ids)), "semantic_concepts.json 中 rule id 重复")
        exclusion_ids = [rule["id"] for rule in semantic.get("scope_exclusions", [])]
        self.assertEqual(len(exclusion_ids), len(set(exclusion_ids)), "scope_exclusions 中 rule id 重复")

    def test_context_contains_only_formal_variables_with_evidence(self) -> None:
        rows = [json.loads(line) for line in (KB / "context" / "variables.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
        context_ids = {row["variable_id"] for row in rows}
        self.assertEqual(context_ids, self.ids, f"上下文变量集合与正式变量不一致: missing={sorted(self.ids-context_ids)}, extra={sorted(context_ids-self.ids)}")
        for row in rows:
            self.assertTrue(row.get("evidence"), f"上下文变量 {row['variable_id']} 缺少 evidence")

    def test_challenge_v01_is_still_frozen(self) -> None:
        data = (KB / "evals" / "questions_challenge_v0.1.jsonl").read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        self.assertEqual(actual, CHALLENGE_V01_SHA256, "challenge v0.1 已变化，禁止覆盖冻结盲测集")

    def test_challenge_v02_is_still_frozen(self) -> None:
        data = (KB / "evals" / "questions_challenge_v0.2.jsonl").read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        self.assertEqual(actual, CHALLENGE_V02_SHA256, "challenge v0.2 已变化，禁止覆盖首次盲测集")

    def test_challenge_v03_is_still_frozen(self) -> None:
        data = (KB / "evals" / "questions_challenge_v0.3.jsonl").read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        self.assertEqual(actual, CHALLENGE_V03_SHA256, "challenge v0.3 已变化，禁止覆盖冻结盲测集")


if __name__ == "__main__":
    unittest.main()
