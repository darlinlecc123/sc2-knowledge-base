"""步骤15：不调用外部模型的检索与歧义处理测试。"""
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
sys.path.insert(0, str(KB / "src"))

from sc2kb.qa_agent import QAAgent  # noqa: E402


class RetrievalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.agent = QAAgent(context_profile="standard")

    def assert_ids(self, question: str, expected: set[str], *, status: str = "ready") -> dict:
        result = self.agent.ask(question, dry_run=True, limit=10)
        self.assertEqual(result["status"], status, f"问题状态错误: {question}")
        self.assertEqual(set(result["candidate_variable_ids"]), expected, f"问题变量映射错误: {question}")
        self.assertFalse(result["model_called"], f"离线测试不得调用模型: {question}")
        return result

    def test_canonical_id_chinese_and_english_queries(self) -> None:
        self.assert_ids("raw_unit.health", {"raw_unit.health"})
        self.assert_ids("单位当前绝对血量对应哪个 RawUnit 字段？", {"raw_unit.health"})
        self.assert_ids("Which RawUnit scalar tells whether its weapon is ready to fire?", {"raw_unit.weapon_cooldown"})

    def test_multi_variable_decomposition(self) -> None:
        self.assert_ids(
            "当前绝对血量和当前护盾分别对应哪些 RawUnit 字段？",
            {"raw_unit.health", "raw_unit.shield"},
        )
        self.assert_ids(
            "ABox 单位节点的位置属性来自哪些 RawUnit 横纵坐标？",
            {"abox.unit.position", "raw_unit.x", "raw_unit.y"},
        )

    def test_ambiguity_is_preserved(self) -> None:
        cases = {
            "hp 没有指定层级时可能对应哪些量？": {"raw_unit.health", "tbox.entity.hp", "abox.unit.hp"},
            "alliance without naming a layer": {"raw_unit.alliance", "abox.unit.alliance"},
            "tag 没有指定层级时可能对应哪些字段？": {"raw_unit.tag", "abox.unit.tag"},
        }
        for question, minimum_ids in cases.items():
            with self.subTest(question=question):
                result = self.agent.ask(question, dry_run=True, limit=10)
                self.assertEqual(result["status"], "ambiguous", f"应保留歧义: {question}")
                self.assertTrue(minimum_ids.issubset(result["candidate_variable_ids"]), f"歧义候选不全: {question}")
                self.assertFalse(result["model_called"])

    def test_out_of_scope_not_found_has_scope_evidence(self) -> None:
        result = self.agent.ask("查询当前知识库未收录的量子折跃概率", dry_run=True)
        self.assertEqual(result["status"], "not_found")
        self.assertFalse(result["model_called"])
        self.assertIn("scope-v0.1-manifest", result["grounding"]["evidence_ids"])
        self.assertTrue(any(item.get("path") == "knowledge/manifests/scope.yaml" for item in result["grounding"]["source_locations"]))

    def test_generalization_development_set_runs_offline(self) -> None:
        questions = [json.loads(line) for line in (KB / "evals" / "questions_generalization_dev_v0.1.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
        self.assertEqual(len(questions), 26)
        for item in questions:
            with self.subTest(question_id=item["id"]):
                result = self.agent.ask(item["question"], dry_run=True, limit=10)
                self.assertFalse(result["model_called"], f"{item['id']} 意外调用模型")
                self.assertIn(result["status"], {"ready", "ambiguous", "not_found"}, f"{item['id']} 返回非法状态")

    def test_v02_failure_development_set_exact_regression(self) -> None:
        questions = [json.loads(line) for line in (KB / "evals" / "questions_generalization_dev_v0.2.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
        self.assertEqual(len(questions), 33)
        for item in questions:
            with self.subTest(question_id=item["id"]):
                result = self.agent.ask(item["question"], dry_run=True, limit=10)
                expected_status = {"found": "ready", "ambiguous": "ambiguous", "not_found": "not_found"}[item["expected_status"]]
                self.assertEqual(result["status"], expected_status, f"{item['id']} 状态回归")
                self.assertEqual(set(result["candidate_variable_ids"]), set(item["expected_variable_ids"]), f"{item['id']} 变量回归")
                self.assertFalse(result["model_called"], f"{item['id']} 意外调用模型")


if __name__ == "__main__":
    unittest.main()
