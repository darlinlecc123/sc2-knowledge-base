"""步骤15：高风险已知问题的防误答与证据绑定测试。"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
sys.path.insert(0, str(KB / "src"))

from sc2kb.qa_agent import QAAgent  # noqa: E402

REQUIRED_ISSUES = {
    "issue.abox_armor_stores_shield",
    "issue.unknown_unit_hp_default_is_static_only",
    "issue.ontology_pickle_may_be_stale",
    "issue.action_coordinate_clip_not_written_back",
    "issue.action_priority_not_validated_or_consumed",
}


class KnownIssueTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.payload = yaml.safe_load((KB / "known_issues.yaml").read_text(encoding="utf-8"))
        cls.issues = {item["id"]: item for item in cls.payload["issues"]}
        cls.agent = QAAgent(context_profile="standard")

    def test_issue_ids_unique_and_affected_variables_traceable(self) -> None:
        issue_list = self.payload["issues"]
        ids = [item["id"] for item in issue_list]
        self.assertEqual(len(ids), len(set(ids)), "known_issues.yaml 中 issue ID 重复")
        self.assertTrue(REQUIRED_ISSUES.issubset(ids), f"缺少关键已知问题: {sorted(REQUIRED_ISSUES-set(ids))}")
        indexed = {item["variable_id"]: set(item["issue_ids"]) for item in self.payload["variable_issue_index"]}
        for issue in issue_list:
            for variable_id in issue["affected_variable_ids"]:
                self.assertIn(variable_id, indexed, f"已知问题 {issue['id']} 的变量 {variable_id} 未进入 variable_issue_index")
                self.assertIn(issue["id"], indexed[variable_id], f"变量 {variable_id} 未反向指向已知问题 {issue['id']}")

    def test_abox_armor_is_bound_to_shield_evidence(self) -> None:
        issue = self.issues["issue.abox_armor_stores_shield"]
        self.assertIn("shield", issue["phenomenon"])
        self.assertIn("不能解释为 SC2 护甲", issue["impact"]["knowledge_answer_constraint"])
        result = self.agent.ask("ABox 的 armor 字段现在存的是单位护甲值吗？", dry_run=True, limit=8)
        self.assertEqual(set(result["candidate_variable_ids"]), {"abox.unit.armor", "raw_unit.shield"})
        self.assertIn(issue["id"], result["grounding"]["evidence_ids"])
        self.assertTrue(any(item.get("path") == "ontology/bridge.py" for item in result["grounding"]["source_locations"]))

    def test_unknown_hp_default_does_not_replace_live_health(self) -> None:
        issue = self.issues["issue.unknown_unit_hp_default_is_static_only"]
        self.assertIn("ABox hp 仍读取 raw_unit['health']", issue["phenomenon"])
        self.assertEqual(issue["truth_status"], "code_reality")
        self.assertEqual({item["symbol"] for item in issue["evidence"]}, {"UNKNOWN_UNIT_DEFAULTS", "BattlefieldGraph._add_unit_instance"})

    def test_cache_clip_and_priority_boundaries_are_explicit(self) -> None:
        cache = self.issues["issue.ontology_pickle_may_be_stale"]
        self.assertEqual(cache["truth_status"], "needs_verification")
        self.assertEqual(cache["recommended_verification"]["execution_status"], "not_executed")
        self.assertIn("pickle", cache["phenomenon"])

        clip = self.issues["issue.action_coordinate_clip_not_written_back"]
        self.assertEqual(clip["issue_type"], "confirmed_bug")
        self.assertIn("未写回", clip["title_zh"])
        self.assertIn("不得声称", clip["impact"]["knowledge_answer_constraint"])

        priority = self.issues["issue.action_priority_not_validated_or_consumed"]
        self.assertIn("未读取 priority", priority["phenomenon"])
        self.assertIn("不得说 priority", priority["impact"]["knowledge_answer_constraint"])

    def test_not_found_and_dev036_grounding(self) -> None:
        missing = self.agent.ask("知识库范围外的量子折跃概率", dry_run=True)
        self.assertEqual(missing["status"], "not_found")
        self.assertIn("scope-v0.1-manifest", missing["grounding"]["evidence_ids"])

        result = self.agent.ask("修改 marine_ontology.py 后 TBox 静态 hp 会立刻更新吗？", dry_run=True, limit=8)
        expected = {
            "tbox-entity-hp-code",
            "issue.ontology_pickle_may_be_stale",
            "issue.unknown_unit_hp_default_is_static_only",
        }
        self.assertTrue(expected.issubset(result["grounding"]["evidence_ids"]), "dev.036 未绑定全部主证据和已知问题")
        paths = {item.get("path") for item in result["grounding"]["source_locations"]}
        self.assertTrue({"ontology/loader.py", "ontology/bridge.py"}.issubset(paths), "dev.036 缺少 loader/bridge 源码路径")


if __name__ == "__main__":
    unittest.main()
