"""challenge v0.5 冻结完整性测试；不得调用问答代理、检索器或外部模型。"""
from __future__ import annotations

import hashlib
import json
import re
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
EVALS = KB / "evals"
EXPECTED_QUESTION_SHA256 = "E7878DB6EF34ED95966455342614672AF62575FAEB56ED017C5D6BC2849F4EDA"
EXPECTED_MANIFEST_SHA256 = "760A3EDFDC3435A2893045029F934717A77F65D409ABEF1D1EDD9E43CAE5AB44"
EXPECTED_LOCK_SHA256 = "565444625BF1697207EFBFC863D530380F633505FD386B29BE9C9CD7E9784760"
EXPECTED_GENERATOR_SHA256 = "08C79720940E994482C10C06F402685D797E47F790FCCDC04A60ABD4868C95DB"
FORMAL_FILES = ("abox.yaml", "actions.yaml", "derived.yaml", "metrics.yaml", "raw_api.yaml", "swm.yaml", "tbox.yaml")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def normalize(text: str) -> str:
    return re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+", "", text).casefold()


class ChallengeV05FreezeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.question_file = EVALS / "questions_challenge_v0.5.jsonl"
        cls.manifest_file = EVALS / "challenge_v0.5_manifest.json"
        cls.lock_file = EVALS / "rag_v0.5_preblind_lock.json"
        cls.generator_file = EVALS / "create_challenge_v0_5.py"
        cls.receipt_file = EVALS / "challenge_v0.5_freeze_receipt.json"
        cls.rows = [json.loads(line) for line in cls.question_file.read_text(encoding="utf-8").splitlines() if line.strip()]
        cls.manifest = json.loads(cls.manifest_file.read_text(encoding="utf-8"))
        cls.lock = json.loads(cls.lock_file.read_text(encoding="utf-8"))
        cls.receipt = json.loads(cls.receipt_file.read_text(encoding="utf-8"))
        cls.formal_ids = set()
        for name in FORMAL_FILES:
            payload = yaml.safe_load((KB / "variables" / name).read_text(encoding="utf-8"))
            cls.formal_ids.update(record["id"] for record in payload["records"])

    def test_frozen_artifact_hashes(self) -> None:
        self.assertEqual(sha256(self.question_file), EXPECTED_QUESTION_SHA256)
        self.assertEqual(sha256(self.manifest_file), EXPECTED_MANIFEST_SHA256)
        self.assertEqual(sha256(self.lock_file), EXPECTED_LOCK_SHA256)
        self.assertEqual(sha256(self.generator_file), EXPECTED_GENERATOR_SHA256)
        self.assertEqual(self.manifest["sha256"].upper(), EXPECTED_QUESTION_SHA256)
        self.assertEqual(self.manifest["rag_lock_sha256"].upper(), EXPECTED_LOCK_SHA256)

    def test_preblind_lock_is_preserved_and_postblind_drift_is_explicit(self) -> None:
        # v0.5 已完成唯一一次首次盲测；当前阶段允许 post-v0.5 regression 修改检索层，
        # 但不得改写当时的锁文件、题集、manifest、生成器和首次结果封存。
        self.assertEqual(self.lock["file_count"], len(self.lock["files"]))
        drifted = {
            entry["path"]
            for entry in self.lock["files"]
            if sha256(ROOT / entry["path"]) != entry["sha256"]
        }
        self.assertTrue({
            "knowledge/retrieval/semantic_concepts.json",
            "knowledge/src/sc2kb/qa_agent.py",
            "knowledge/tests/test_rag_compositional_retrieval.py",
        } <= drifted)
        protocol = self.lock["blind_protocol"]
        self.assertFalse(protocol["retrieval_pre_run_before_challenge_freeze"])
        self.assertFalse(protocol["model_pre_run_before_challenge_freeze"])
        self.assertFalse(protocol["modify_locked_files_after_freeze"])
        self.assertFalse(protocol["tune_on_challenge_v0_5"])
        self.assertFalse(protocol["overwrite_first_result"])
        self.assertTrue(protocol["full_dataset_single_first_run"])

    def test_question_schema_ids_and_evidence(self) -> None:
        self.assertEqual(len(self.rows), 57)
        self.assertEqual(len({row["id"] for row in self.rows}), len(self.rows))
        self.assertEqual(len({normalize(row["question"]) for row in self.rows}), len(self.rows))
        for row in self.rows:
            with self.subTest(question_id=row["id"]):
                self.assertEqual(row["benchmark_version"], "0.5.0")
                self.assertEqual(row["split"], "challenge_v0.5")
                self.assertFalse(set(row["expected_variable_ids"]) - self.formal_ids)
                self.assertTrue(row["required_evidence"])
                for evidence in row["required_evidence"]:
                    self.assertTrue((ROOT / evidence["path"]).exists())

    def test_no_exact_question_overlap_with_prior_sets(self) -> None:
        current = {normalize(row["question"]) for row in self.rows}
        for prior in EVALS.glob("questions*.jsonl"):
            if prior == self.question_file:
                continue
            prior_norms = {normalize(json.loads(line)["question"]) for line in prior.read_text(encoding="utf-8").splitlines() if line.strip()}
            self.assertFalse(current & prior_norms, f"与 {prior.name} 存在规范化完全重复")

    def test_generator_is_independent_of_retrieval_implementation(self) -> None:
        source = self.generator_file.read_text(encoding="utf-8")
        self.assertNotIn("from sc2kb", source)
        self.assertNotIn("import sc2kb", source)
        self.assertNotIn("knowledge/retrieval", source)
        self.assertNotRegex(source, r"\bQAAgent\b")

    def test_freeze_receipt_matches_artifacts(self) -> None:
        expected = {
            "question_file": EXPECTED_QUESTION_SHA256,
            "manifest": EXPECTED_MANIFEST_SHA256,
            "rag_lock": EXPECTED_LOCK_SHA256,
            "generator": EXPECTED_GENERATOR_SHA256,
        }
        for key, digest in expected.items():
            self.assertEqual(self.receipt["files"][key]["sha256"], digest)
        state = self.receipt["state_at_freeze"]
        self.assertFalse(state["retrieval_pre_run"])
        self.assertFalse(state["model_pre_run"])
        self.assertEqual(state["external_model_test"], "not_run")


if __name__ == "__main__":
    unittest.main()
