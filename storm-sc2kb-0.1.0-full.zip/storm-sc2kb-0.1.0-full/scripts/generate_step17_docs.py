"""步骤17：从机器可读记录确定性生成面向人和 LLM 的 Markdown 文档。"""
from __future__ import annotations
import hashlib, json, sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[2]
KBROOT=ROOT/'knowledge'
sys.path.insert(0,str(KBROOT/'src'))
from sc2kb.loader import load_knowledge_base

DATE='2026-09-07'
DOCS=KBROOT/'docs'
CATEGORY={
'environment_config':('环境与 Agent 配置','运行前设置，会影响接口、时间推进或 Agent 行为。'),
'timestep_player_score':('TimeStep、玩家与得分','从 PySC2 TimeStep/observation 边界读取的信息。'),
'raw_unit':('RawUnit 原始单位字段','STORM 实际从 raw_units 读取或紧邻读取后转换的单位状态。'),
'tbox_static':('TBox 静态本体','仓库预定义并由本体构建/加载流程提供的静态知识。'),
'abox_dynamic':('ABox 运行时实例','BattlefieldGraph 根据观测、TBox 与 fallback 构造或更新的事实。'),
'derived_tactical_state':('派生战术状态','由观测或 ABox 按公式、聚合或阈值计算的战术量。'),
'action_schema_and_scheduling':('动作 Schema 与调度','LLM 动作输出、解析、校验和延迟执行字段。'),
'pysc2_function_call':('PySC2 FunctionCall','ActionExecutor 映射到 PySC2 Raw FunctionCall 的函数与参数。'),
'swm':('SWM 变量','状态世界模型的输入、预测、候选和误差字段。'),
'experiment_metric':('实验指标','实验代码实际计算、聚合或写出的指标。')}
LAYERS={'environment_config':'运行前配置输入','pysc2_timestep':'PySC2 TimeStep/observation 直接读取','pysc2_raw_observation':'PySC2 Raw observation/RawUnit 直接读取','raw_unit_transformed':'紧邻 RawUnit 读取后的归一化或转换','tbox_static':'静态本体声明','abox_runtime':'运行时 ABox 实例','derived_runtime':'运行时公式、聚合或阈值派生','llm_output':'LLM 原始动作输出','validated_action':'解析与校验后的动作','executor_mapping':'PySC2 FunctionCall 执行映射','swm_prediction':'SWM 输入、输出或预测','experiment_aggregate':'实验级统计与落盘'}
STATUS={'design_intent':'设计目标、注释或文档承诺，不能自动视为已经实现。','code_reality':'由当前仓库源码、配置或静态数据直接确认。','runtime_observation':'来自实际运行观测；静态审查不能使用此标签。','derived_runtime':'由运行时输入按当前公式得到，不是 PySC2 原始字段。','needs_verification':'证据不足，仍需 SC2、接口或专门测试核验。'}
INPUTS=[*sorted((KBROOT/'variables').glob('*.yaml')),KBROOT/'retrieval'/'aliases.yaml',KBROOT/'relations'/'variable_relations.jsonl',KBROOT/'known_issues.yaml',KBROOT/'taxonomy'/'categories.yaml',KBROOT/'taxonomy'/'source_layers.yaml']

def t(v,default='未记录'):
 if v is None or v=='': return default
 return str(v).replace('\n',' ').strip()
def c(v): return '`'+t(v).replace('`','')+'`'
def cell(v): return t(v).replace('|','\\|')
def anch(i): return 'var-'+''.join(x if x.isalnum() else '-' for x in i.lower())
def rel(p): return p.relative_to(ROOT).as_posix()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def state(r):
 ss=[x.get('status') for x in r.get('code_reality',[])]
 if 'needs_verification' in ss or r.get('verification',{}).get('status')=='needs_verification': return 'needs_verification'
 if 'derived_runtime' in ss:return 'derived_runtime'
 if 'runtime_observation' in ss:return 'runtime_observation'
 return 'code_reality'
def write(p,s): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s.rstrip()+'\n',encoding='utf-8')
def source_lines(r):
 out=[]
 for x in r.get('implementation',{}).get('source_locations',[]):
  q=f"{x.get('path')}::{x.get('symbol')}"
  if x.get('line_start') is not None:q+=f"（记录行 {x['line_start']}–{x.get('line_end',x['line_start'])}；行号可能漂移）"
  out.append('- '+c(q))
 return out or ['- 未记录源码位置。']
def interface_lines(r):
 i=r.get('interface',{});s=i.get('shape',{});u=i.get('unit',{});g=i.get('range',{});e=i.get('enum_values',{});p=i.get('pysc2_path',{})
 lo,hi=g.get('minimum'),g.get('maximum')
 rg=(t(lo,'-∞')+' ～ '+t(hi,'+∞')) if lo is not None or hi is not None else t(g.get('description'),'未证明')
 return [f"- 数据类型：{c(i.get('data_type'))}；Python 类型：{c(i.get('python_type'))}",f"- 形状：{c(s.get('kind'))}；{t(s.get('description'))}",f"- 单位：{c(u.get('value')) if u.get('value') is not None else '未知'}（{c(u.get('status'))}）",f"- 范围：{rg}（{c(g.get('status'))}）",'- 枚举：'+(', '.join(c(x) for x in e.get('values',[])) or '不适用或未声明'),f"- PySC2 路径：{c(p.get('value')) if p.get('value') else '不适用或未确认'}（{c(p.get('status'))}）",'- STORM 接口：'+(', '.join(c(x) for x in i.get('storm_paths',[])) or '未记录')]

def build_index(kb):
 cats=Counter(r['category'] for r in kb.records.values());sts=Counter(state(r) for r in kb.records.values())
 L=['# STORM PySC2 Raw API 变量知识库','', '> 一句话导航：把自然语言里的“血量、位置、冷却、动作目标、预测误差”等概念对应到 STORM 变量，请从本页进入变量目录或查询手册。','', '<!-- 由 knowledge/scripts/generate_step17_docs.py 自动生成。 -->','','## 1. 范围和事实边界','', '第一版只覆盖当前 STORM 实际读取、转换、生成、校验、执行或统计的 Raw API 相关变量及其 TBox、ABox、派生状态、动作、SWM 和指标；不是完整 PySC2/SC2 百科。','',f'- 正式变量：**{len(kb.records)}** 个',f'- 关系边：**{len(kb.relations)}** 条',f'- 已知问题：**{len(kb.issues)}** 个','- 本步骤未启动 StarCraft II，未调用外部模型，也未伪造论文参考文献。','','## 2. 我应该去哪查？','', '| 我想知道 | 首选文档 |','|---|---|','| 变量含义、接口、源码、公式 | [变量总目录](variable_catalog.md) |','| Raw 到 ABox、动作或指标的数据流 | [数据流与关系](dataflow.md) |','| 自然语言怎样定位变量 | [查询手册](query_cookbook.md) |','| ABox、TBox、RawUnit、RAG 等术语 | [术语表](glossary.md) |','| 范围、来源和已知坑 | [范围说明](01_scope.md)、[来源登记](02_source_registry.md)、[已知问题](09_known_issues.md) |','','## 3. 分类总览','', '| 分类 | 数量 | 大白话解释 |','|---|---:|---|']
 for k in CATEGORY:
  if cats[k]:L.append(f"| [{CATEGORY[k][0]}](variable_catalog.md#category-{k.replace('_','-')}) | {cats[k]} | {CATEGORY[k][1]} |")
 L+=['','## 4. 可信状态','', '| 状态 | 数量 | 含义 |','|---|---:|---|']
 for k in ('code_reality','derived_runtime','runtime_observation','needs_verification'):L.append(f'| {c(k)} | {sts[k]} | {STATUS[k]} |')
 L+=['','> `code_reality` 只证明当前代码这样做，不保证字段名称的物理语义正确；回答前仍须检查已知问题。','','## 5. 高频入口','', '- 当前生命值：[`raw_unit.health`](variable_catalog.md#var-raw-unit-health)','- 生命比例：[`raw_unit.health_ratio`](variable_catalog.md#var-raw-unit-health-ratio)','- ABox 当前生命：[`abox.unit.hp`](variable_catalog.md#var-abox-unit-hp)','- 位置：[`raw_unit.x`](variable_catalog.md#var-raw-unit-x)、[`raw_unit.y`](variable_catalog.md#var-raw-unit-y)','- 武器冷却：[`raw_unit.weapon_cooldown`](variable_catalog.md#var-raw-unit-weapon-cooldown)','- 阵营：[`raw_unit.alliance`](variable_catalog.md#var-raw-unit-alliance)','- 动作目标：[`action.target`](variable_catalog.md#var-action-target)','- 延迟：[`action.delay_steps`](variable_catalog.md#var-action-delay-steps)','','## 6. LLM Agent 最短规则','', '1. 先定位稳定 ID，再回答，不能只凭一般 SC2 常识。','2. 明确 Raw/TBox/ABox/派生/动作/SWM/指标层。','3. 同时返回接口、源码和公式依赖。','4. `needs_verification` 与已知问题必须保留。','5. 范围外字段应说明未收录，不能补成完整 PySC2 API。','6. 程序化问答优先 RAG，不要每题重复塞入全部变量。','','## 7. 维护','',f'- 生成日期：{DATE}','- 生成器：`knowledge/scripts/generate_step17_docs.py`','- 验收：`knowledge/tests/validate_step17.py`','- 清单：`knowledge/manifests/step17_docs_manifest.json`']
 return '\n'.join(L)

def build_catalog(kb):
 groups=defaultdict(list)
 for r in kb.records.values():groups[r['category']].append(r)
 L=['# 变量总目录','',f'> 这里是 {len(kb.records)} 个正式变量的人工可读视图。每个条目先用大白话解释，再给定义、接口、源码、公式、例子、关系、限制和可信状态。','', '<!-- 由 knowledge/scripts/generate_step17_docs.py 自动生成。 -->','','## 阅读规则','', '- 稳定 ID 是检索和跨文档引用的主键；代码字段保留英文。','- 行号可能漂移，定位时以“路径 + 类/函数/符号”为主。','- Raw、TBox、ABox、派生量和预测不能混为一谈。','- 已知问题优先于字段字面名称。','','## 分类索引','', '| 分类 | 数量 |','|---|---:|']
 for cat in CATEGORY:
  if groups[cat]:L.append(f"| [{CATEGORY[cat][0]}](#category-{cat.replace('_','-')}) | {len(groups[cat])} |")
 for cat in CATEGORY:
  if not groups[cat]:continue
  L+=['',f'<a id="category-{cat.replace("_","-")}"></a>',f'## {CATEGORY[cat][0]}','',CATEGORY[cat][1],'','| 稳定 ID | 中文名 | 来源层 | 状态 |','|---|---|---|---|']
  records=sorted(groups[cat],key=lambda x:x['id'])
  for r in records:L.append(f"| [{c(r['id'])}](#{anch(r['id'])}) | {cell(r.get('names',{}).get('zh'))} | {c(r.get('provenance',{}).get('source_layer'))} | {c(state(r))} |")
  for r in records:
   i=r.get('implementation',{});p=r.get('provenance',{});v=r.get('verification',{});issues=kb.known_issues_for(r['id'])
   ups=set(x for x in p.get('upstream_variable_ids',[]) if x in kb.records)
   ups.update(x.get('source',{}).get('id') for x in kb.upstream(r['id']) if x.get('source',{}).get('id') in kb.records)
   downs=set(x.get('target',{}).get('id') for x in kb.downstream(r['id']) if x.get('target',{}).get('id') in kb.records)
   L+=['',f'<a id="{anch(r["id"])}"></a>',f"### {c(r['id'])} — {t(r.get('names',{}).get('zh'))}",'',f"**一句大白话：** {t(r.get('intuitive_explanation'))}",'',f"**正式定义：** {t(r.get('definition'))}",'','**身份与来源**','',f"- 分类：{c(r.get('category'))}",f"- 来源层：{c(p.get('source_layer'))}（{LAYERS.get(p.get('source_layer'),'未登记')}）",f"- 派生方式：{c(p.get('derivation_kind'))}",f"- 可信状态：{c(state(r))}",'- 别名：'+(', '.join(c(x) for x in r.get('aliases',[])) or '未记录'),'','**接口形式**','',*interface_lines(r),'','**STORM 实现与依据**','',*source_lines(r)]
   if i.get('extraction_code'):L+=['','代码摘记：','']+['- '+c(x) for x in i['extraction_code']]
   L+=['','公式或转换：','']+(['- '+c(x) for x in i.get('transformation_formula',[])] or ['- 无显式公式或尚未记录。'])
   L+=['','**示例**','']
   if r.get('examples'):
    for x in r['examples'][:2]:L.append(f"- {t(x.get('scenario'))}：{t(x.get('explanation'))} 输入={c(json.dumps(x.get('input'),ensure_ascii=False,sort_keys=True))}；输出={c(json.dumps(x.get('output'),ensure_ascii=False,sort_keys=True))}")
   else:L.append('- 未记录示例。')
   L+=['','**上下游关系**','', '- 上游：'+('、'.join(f'[{c(x)}](#{anch(x)})' for x in sorted(ups)[:15]) if ups else '未记录正式变量上游。'),'- 下游：'+('、'.join(f'[{c(x)}](#{anch(x)})' for x in sorted(downs)[:15]) if downs else '未记录正式变量下游。')]
   if len(ups)>15 or len(downs)>15:L.append('- 这里只展示前 15 个关系；全量见 `knowledge/relations/variable_relations.jsonl`。')
   L+=['','**限制与已知问题**','']
   L+=['- '+t(x) for x in r.get('limitations',[])] or ['- 当前记录未声明额外限制。']
   if issues:
    for x in issues:L.append(f"- **{c(x['id'])} / {t(x.get('severity'))}：** {t(x.get('concise_explanation'))}")
   else:L.append('- 当前没有关联到登记中的已知问题。')
   L+=['','**核验状态**','',f"- verification.status：{c(v.get('status'))}",f"- 方法：{t(v.get('method'))}",'','---']
 return '\n'.join(L)

def build_dataflow(kb):
 lc=Counter(r.get('provenance',{}).get('source_layer') for r in kb.records.values());rc=Counter(r.get('relation_type','unknown') for r in kb.relations);fr=[r for r in kb.relations if r.get('formulas')]
 L=['# 数据流与变量关系','', '> 大白话：这里回答“一个量从哪里来、经过什么转换、最后被谁使用”。Raw 值、TBox 静态知识、ABox 动态实例和派生指标不能混为一谈。','', '<!-- 由 knowledge/scripts/generate_step17_docs.py 自动生成。 -->','','## 1. 总体数据流','', '```text','SC2Env 配置','  ↓','PySC2 TimeStep / observation / raw_units','  ↓ RawAgent 读取与紧邻归一化','RawUnit / player / score','  ↓ BattlefieldGraph + 静态 TBox','运行时 ABox 节点、边和图级缓存','  ↓ 聚合、阈值和公式','派生战术状态 → Prompt → LLM 动作','  ↓ ResponseParser 校验和延迟调度','验证后动作 → ActionExecutor → PySC2 Raw FunctionCall','  ↓','下一次 TimeStep / observation','','可选：ABox + 候选动作 → SWM 预测 → 再评估 → 最终动作 → 轨迹/预测误差','实验：episode 与动作日志 → 聚合指标 → CSV/JSON','```','','## 2. 来源层','', '| 来源层 | 数量 | 定义 |','|---|---:|---|']
 for k,n in sorted(lc.items()):L.append(f'| {c(k)} | {n} | {LAYERS.get(k,"未登记")} |')
 L+=['','## 3. TBox、ABox 与 Raw 的边界','', '- **Raw observation**：当前 PySC2 观测直接提供或紧邻读取后计算的值。','- **TBox**：单位类型的静态声明，不是当前战场实时值。','- **ABox**：当前单位实例事实，可能混合 Raw 值、TBox 副本和 fallback。','- **派生状态**：从运行时单位集合进一步聚合或计算。','- **模型预测**：SWM 预测不是已经发生的游戏事实。','','## 4. 典型链路','','### 当前生命值','', '```text','observation.raw_units[*].health',' → raw_unit.health',' → raw_unit.health_ratio',' → abox.unit.hp / abox.unit.hp_ratio',' → derived.tactical.*_avg_hp / critical_units','```','','### 位置与动作目标','', '```text','raw_unit.x + raw_unit.y → ABox position → 空间/距离关系','自然语言目标 → action.target → ResponseParser → pysc2.function.target → FunctionCall','```','', '> 已知问题：Parser 计算了坐标裁剪值但没有写回 `action.target`，不能声称越界值已经修正后传入执行器。','','### shield 与 ABox armor 名称错配','', '```text','raw_unit.shield / shield_ratio → abox.unit.armor / armor_ratio  # 当前代码现实','```','', '这是实现事实，不是推荐命名；回答必须附带 `issue.abox_armor_stores_shield`。','','### 延迟动作','', '```text','LLM action.delay_steps → Parser → 延迟队列/到期重验证 → ActionExecutor','```','', '`delay_steps` 是环境/Agent 步语义，没有证据时不能换算成现实秒数。','','### SWM','', '```text','当前 ABox + candidate_action/index → SWM.predict → predicted_state/confidence',' → LLM 再评估 → 实际下一状态 → prediction_error','```','', 'SWM 输出属于预测，在下一状态实际到来前不能标成 `runtime_observation`。','','## 5. 关系图统计','',f'当前共有 **{len(kb.relations)}** 条关系，其中 **{len(fr)}** 条带公式或转换摘记。','', '| 关系类型 | 数量 |','|---|---:|']
 for k,n in sorted(rc.items()):L.append(f'| {c(k)} | {n} |')
 L+=['','## 6. 公式依赖示例','', '以下从关系图确定性展示前 30 条“上下游均为正式变量”的公式边；完整内容见 JSONL。','', '| 上游 | 关系 | 下游 | 公式/转换 | 状态 |','|---|---|---|---|---|']
 n=0
 for r in sorted(fr,key=lambda x:(x.get('source',{}).get('id',''),x.get('target',{}).get('id',''),x.get('id',''))):
  a=r.get('source',{}).get('id');b=r.get('target',{}).get('id')
  if a not in kb.records or b not in kb.records:continue
  L.append(f"| [{c(a)}](variable_catalog.md#{anch(a)}) | {c(r.get('relation_type'))} | [{c(b)}](variable_catalog.md#{anch(b)}) | {cell('; '.join(t(x) for x in r.get('formulas',[])))} | {c(r.get('truth_status'))} |")
  n+=1
  if n==30:break
 L+=['','## 7. 追溯步骤','', '1. 在变量总目录找到稳定 ID。','2. 查看 `source_layer`、`derivation_kind` 和源码符号。','3. 查看上下游链接；全量关系读取 `knowledge/relations/variable_relations.jsonl`。','4. 查看关联已知问题。','5. `needs_verification` 必须运行相应测试后才能升级结论。']
 return '\n'.join(L)

def build_cookbook(kb):
 examples=[('单位当前还剩多少血？','raw_unit.health','当前原始观测；若明确问图节点则查 abox.unit.hp。'),('血量百分比是什么？','raw_unit.health_ratio','比例不能和原始 health 混用。'),('敌我阵营怎么看？','raw_unit.alliance','若明确问 ABox，再查 abox.unit.alliance。'),('ABox armor 真是护甲吗？','abox.unit.armor','必须说明当前实际映射到 shield。'),('延迟几步在哪里控制？','action.delay_steps','继续追踪 Parser 和延迟队列。'),('坐标最后传给 PySC2 哪个参数？','pysc2.function.target','沿 executor mapping 追踪。'),('友军平均生命比例怎么算？','derived.tactical.friendly_avg_hp','公式题必须展开依赖。'),('SWM 预测是真实观测吗？','swm.predicted_unit_states','预测不是实际观测。')]
 L=['# 查询手册：从自然语言找到变量','', '> 大白话：先判断用户问的是哪一层、哪种量，再找稳定 ID；不要看到“血量”“护甲”“目标”就只按字面猜。','', '<!-- 由 knowledge/scripts/generate_step17_docs.py 自动生成。 -->','','## 1. 标准流程','', '1. 识别对象：环境、单位、图节点、动作、SWM 或实验。','2. 识别时间语义：静态知识、当前观测、派生值、预测或实验聚合。','3. 识别形式：原始值、比例、计数、坐标、枚举、公式、代码位置或接口参数。','4. 用中文别名、英文名、代码名召回候选并归一到稳定 ID。','5. Raw/TBox/ABox 同名时根据上下文消歧，必要时要求澄清。','6. 公式、多变量和跨层 lineage 问题要展开上下游。','7. 绑定路径 + 类/函数/符号证据。','8. 范围外问题拒答；已知问题与待核验状态必须说明。','','## 2. 常见映射','', '| 问题 | 首选变量 | 说明 |','|---|---|---|']
 for q,i,w in examples:
  L.append(f"| {q} | [{c(i)}](variable_catalog.md#{anch(i)}) | {w} |" if i in kb.records else f'| {q} | 需检索确认 | {w} |')
 L+=['','## 3. 按意图导航','', '| 意图 | 优先分类 | 同时检查 |','|---|---|---|','| 当前单位状态 | `raw_unit` | ABox 映射和派生比例 |','| 单位类型静态知识 | `tbox_static` | 不能写成当前实时值 |','| 图实例节点或边 | `abox_dynamic` | Raw 来源、TBox 副本、fallback、已知问题 |','| 战术统计/公式 | `derived_tactical_state` | 全部上游、聚合范围、除零/空集合 |','| LLM 动作字段 | `action_schema_and_scheduling` | 是否真正校验和消费 |','| 最终 PySC2 调用 | `pysc2_function_call` | 函数 ID、参数形状、executor 映射 |','| 世界模型预测 | `swm` | 输入、预测、实际下一状态与误差 |','| 论文实验指标 | `experiment_metric` | 聚合公式、写出位置与运行批次 |','','## 4. 歧义处理','',f'别名登记共有 **{len(kb.ambiguity_groups)}** 个显式歧义组。完整内容见 `knowledge/retrieval/aliases.yaml`。','', '| 歧义组 | 候选变量 | 处理建议 |','|---|---|---|']
 for g in sorted(kb.ambiguity_groups.values(),key=lambda x:x.get('id',''))[:20]:
  ids=g.get('variable_ids') or g.get('candidate_variable_ids') or g.get('members') or []
  hint=g.get('resolution_hint') or g.get('disambiguation') or g.get('description') or '根据层级、时间语义和对象澄清。'
  L.append(f"| {c(g.get('id'))} | {', '.join(c(x) for x in ids)} | {cell(hint)} |")
 L+=['','## 5. 负向范围识别','', '以下情况应先判为范围外，而不是因为出现 Raw 关键词就强行命中：','', '- STORM 当前未读取的完整 PySC2 字段；','- feature layer、RGB、完整单位或科技百科；','- 没有仓库证据的游戏机制常识；','- 要求实时战局数值但没有传入 observation/ABox；','- 要求官方单位或版本语义，而记录标记为未知或待核验。','','## 6. 本地检索','', '目的：先缩小到相关记录，再让 LLM 组织回答，避免每次提供全部 135 个变量。','','```powershell','$env:PYTHONIOENCODING = "utf-8"','python knowledge/src/sc2kb/cli.py "单位当前血量对应哪个字段" --limit 8','```','', '以 [检索用法](10_retrieval_usage.md) 中当前验证过的入口为准，不要自行猜参数。','','## 7. 回答契约','', '```text','对应变量：稳定 ID、规范名、层级','一句话解释与正式含义','接口：路径、类型、形状、范围/枚举、单位','实现：路径、类/函数、提取/转换','关系和公式：上下游与聚合','限制、已知问题、证据、可信状态','```','','## 8. 论文和代码','', '- 论文可引用“当前 STORM 实现做了什么”并给仓库路径/符号，但源码位置不是学术文献。','- 代码修改前先确认接口、范围和消费者；修改本体后注意 ontology pickle 缓存。','- 历史 CSV 只代表特定运行，不自动证明当前 checkout 的效果。']
 return '\n'.join(L)

def build_glossary(kb):
 terms=[('Raw API','当前项目使用的 PySC2 原始单位/动作接口边界；第一版不含 feature layer/RGB。'),('TimeStep','环境一次 step 返回的对象；只收录 STORM 当前实际读取部分。'),('RawUnit','observation.raw_units 中的单位对象；只收录当前代码读取字段。'),('TBox','类型层静态本体知识，不等于当前战局实例值。'),('ABox','BattlefieldGraph 根据观测建立的实例事实，可能混合 Raw、TBox 和 fallback。'),('BattlefieldGraph','使用 networkx.DiGraph 组织 TBox/ABox 并生成战术摘要的图结构。'),('派生变量','经公式、归一化、聚合、阈值或映射得到，不是原始字段。'),('lineage / 数据血缘','变量的上游来源、转换以及下游消费者链。'),('稳定 ID','跨文件和评测使用的主键，例如 raw_unit.health。'),('alias / 别名','用户可能使用的中文、英文或代码表达，可能需要跨层消歧。'),('source layer','值或断言来自数据流的哪一层，与 category 是不同维度。'),('design intent','设计或文档希望实现的行为，可能与代码现实不同。'),('code reality','当前源码、配置或静态数据直接确认的行为。'),('runtime observation','实际运行记录；静态审查不能冒充运行结果。'),('needs verification','证据不足，需要运行或接口核验。'),('ResponseParser','解析 LLM 动作并进行当前实现中的语义校验。'),('ActionExecutor','把验证后动作映射为 PySC2 Raw FunctionCall。'),('FunctionCall','PySC2 动作调用对象，具体函数和参数以 executor 映射为准。'),('delay_steps','动作延迟的环境/Agent 步数，不能无依据换算成现实秒。'),('SWM','状态世界模型分支；预测不是实际观测。'),('RAG','先检索相关知识，再把有限证据交给 LLM 生成回答。'),('full-context','每题提供全部静态知识，不做查询专属检索。'),('no-KB','不向模型提供本知识库的对照条件。'),('grounding / 证据绑定','回答能回指变量记录、关系与源码证据。')]
 L=['# 术语表','', '> 本页解释术语在当前 STORM Raw API 知识库中的严格含义，不是完整 SC2 百科。','', '<!-- 由 knowledge/scripts/generate_step17_docs.py 自动生成。 -->','','## 1. 核心术语','', '| 术语 | 当前项目中的含义 |','|---|---|']
 for a,b in terms:L.append(f'| **{a}** | {b} |')
 counts=Counter(r['category'] for r in kb.records.values())
 L+=['','## 2. 变量分类','', '| 分类 ID | 中文名 | 定义 |','|---|---|---|']
 for k,(a,b) in CATEGORY.items():L.append(f'| {c(k)} | {a} | {b} 当前 {counts[k]} 个。 |')
 L+=['','## 3. 来源层','', '| 来源层 | 含义 |','|---|---|']
 for k,b in LAYERS.items():L.append(f'| {c(k)} | {b} |')
 L+=['','## 4. 事实状态','', '| 状态 | 含义 |','|---|---|']
 for k,b in STATUS.items():L.append(f'| {c(k)} | {b} |')
 expl={'source_of':'直接数据来源。','normalized_to':'比例化、归一化或紧邻转换。','mapped_to':'字段或参数映射。','derived_into':'参与公式或规则得到派生值。','aggregated_into':'计数、求和、平均或列表化。','validated_by':'由解析或验证规则检查。','executed_as':'动作被映射为执行接口。'}
 L+=['','## 5. 关系类型','', '这些关系表示当前代码和知识记录中的血缘或映射，不自动证明外部游戏机制。','', '| 关系 | 阅读方式 |','|---|---|']
 for k in sorted({r.get('relation_type') for r in kb.relations if r.get('relation_type')}):L.append(f"| {c(k)} | {expl.get(k,'具体含义以关系边的 summary 与 evidence 为准。')} |")
 L+=['','## 6. 易混淆术语','', '- **health vs hp**：Raw 常用 health，ABox 映射常用 hp，必须看完整 ID。','- **armor vs shield**：当前 ABox armor 实际来自 Raw shield，是已登记错配。','- **静态最大值 vs 当前值**：TBox 属性、Raw 当前值、比例不能互换。','- **动作 confidence vs SWM confidence**：生产者和消费者不同。','- **prediction vs observation**：预测不是事实；实际下一状态到来后才能计算误差。']
 return '\n'.join(L)

def main():
 missing=[rel(x) for x in INPUTS if not x.exists()]
 if missing:raise FileNotFoundError('缺少上游：'+', '.join(missing))
 kb=load_knowledge_base(KBROOT)
 outputs={DOCS/'index.md':build_index(kb),DOCS/'variable_catalog.md':build_catalog(kb),DOCS/'dataflow.md':build_dataflow(kb),DOCS/'query_cookbook.md':build_cookbook(kb),DOCS/'glossary.md':build_glossary(kb)}
 for p,s in outputs.items():write(p,s)
 m={'schema_version':'1.0.0','step':17,'generated_at':DATE,'generator':'knowledge/scripts/generate_step17_docs.py','scope':{'knowledge_base':'storm-sc2kb-v1-raw','formal_variable_count':len(kb.records),'relation_count':len(kb.relations),'known_issue_count':len(kb.issues),'sc2_executed':False,'external_model_called':False},'inputs':[{'path':rel(p),'sha256':sha(p)} for p in sorted(INPUTS,key=rel)],'outputs':[{'path':rel(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(outputs,key=rel)]}
 write(KBROOT/'manifests'/'step17_docs_manifest.json',json.dumps(m,ensure_ascii=False,indent=2,sort_keys=True))
 print(json.dumps(m['scope'],ensure_ascii=False,indent=2))
 for x in m['outputs']:print('WROTE',x['path'],x['bytes'],'bytes')
if __name__=='__main__':main()

