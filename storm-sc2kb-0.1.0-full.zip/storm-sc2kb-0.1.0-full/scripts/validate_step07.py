"""严格校验步骤 07 别名词典和查询模式；不运行 SC2 或外部模型。"""
from __future__ import annotations

import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Any

import yaml

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[2]
K = ROOT / "knowledge"
V = K / "variables"
LINEAGE_PATH = K / "lineage" / "variable_lineage.yaml"
ALIASES_PATH = K / "retrieval" / "aliases.yaml"
PATTERNS_PATH = K / "retrieval" / "query_patterns.yaml"
DOC_PATH = K / "docs" / "07_alias_guide.md"
FILES = ["raw_api", "tbox", "abox", "derived", "actions", "swm", "metrics"]
EXPECTED_ALIAS_GROUPS = {
    "chinese",
    "english",
    "code",
    "abbreviations",
    "colloquial",
    "paper_terms",
}
EXPECTED_INTENTS = {
    "interface_query",
    "physical_meaning_query",
    "source_location_query",
    "formula_query",
    "range_query",
}
ABSOLUTE_WINDOWS_RE = re.compile(
    r"[A-Za-z]:[\\/](?:Users|Documents and Settings)[\\/]", re.I
)
BAD_UNICODE = {"\ufffd", "\x00"}


def load_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def normalize(term: str) -> str:
    text = unicodedata.normalize("NFKC", str(term)).strip().lower()
    text = re.sub(r"\s+", " ", text)
    text = text.replace("－", "-").replace("_", " ").replace("-", " ")
    return re.sub(r"\s+", " ", text).strip()


def iter_strings(value: Any):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from iter_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from iter_strings(item)


def candidates(index: dict[str, dict[str, Any]], term: str) -> set[str]:
    item = index.get(normalize(term))
    if not item:
        return set()
    return {x["variable_id"] for x in item.get("candidate_matches", [])}


def main() -> int:
    errors: list[str] = []
    warnings: list[str] = []

    step05: dict[str, dict[str, Any]] = {}
    for name in FILES:
        path = V / f"{name}.yaml"
        if not path.is_file():
            errors.append(f"缺少步骤五文件: {path.relative_to(ROOT)}")
            continue
        data = load_yaml(path)
        for row in data.get("records", []):
            vid = row.get("id")
            if vid in step05:
                errors.append(f"步骤五变量ID重复: {vid}")
            step05[vid] = row
    if len(step05) != 135:
        errors.append(f"步骤五变量数量错误: {len(step05)} != 135")

    if not LINEAGE_PATH.is_file():
        errors.append("缺少步骤六血缘文件")
        lineage_by_id = {}
    else:
        lineage = load_yaml(LINEAGE_PATH)
        lineage_by_id = {
            row["variable_id"]: row for row in lineage.get("records", [])
        }
    if set(lineage_by_id) != set(step05):
        errors.append("步骤六血缘ID集合与步骤五不一致")

    if not ALIASES_PATH.is_file():
        errors.append("缺少 knowledge/retrieval/aliases.yaml")
        aliases = {}
    else:
        aliases = load_yaml(ALIASES_PATH)

    records = aliases.get("records") if isinstance(aliases, dict) else None
    if not isinstance(records, list):
        errors.append("aliases.yaml缺少records数组")
        records = []
    record_ids = [
        row.get("variable_id") for row in records if isinstance(row, dict)
    ]
    if len(records) != 135:
        errors.append(f"别名卡片数量错误: {len(records)} != 135")
    if record_ids != sorted(record_ids):
        errors.append("别名卡片未按variable_id确定性排序")
    if len(record_ids) != len(set(record_ids)):
        duplicates = sorted(k for k, v in Counter(record_ids).items() if v > 1)
        errors.append(f"别名卡片ID重复: {duplicates}")
    if set(record_ids) != set(step05):
        errors.append(
            f"别名卡片ID集合错误: missing={sorted(set(step05)-set(record_ids))}, "
            f"extra={sorted(set(record_ids)-set(step05))}"
        )

    record_by_id = {
        row["variable_id"]: row
        for row in records
        if isinstance(row, dict) and isinstance(row.get("variable_id"), str)
    }
    safe_terms_by_id: dict[str, set[str]] = {}
    for vid in sorted(set(record_by_id) & set(step05)):
        row = record_by_id[vid]
        source = step05[vid]
        lineage_row = lineage_by_id[vid]

        if row.get("category") != source.get("category"):
            errors.append(f"category与步骤五不一致: {vid}")
        if row.get("source_layer") != lineage_row.get("source_layer"):
            errors.append(f"source_layer与步骤六不一致: {vid}")
        if row.get("taxonomy_source_layer") != lineage_row.get(
            "taxonomy_source_layer"
        ):
            errors.append(f"taxonomy_source_layer与步骤六不一致: {vid}")
        if row.get("names") != source.get("names"):
            errors.append(f"names与步骤五不一致: {vid}")

        names = row.get("names", {})
        for field in ("zh", "en", "code"):
            if not isinstance(names.get(field), str) or not names[field].strip():
                errors.append(f"缺少核心{field}名称: {vid}")

        groups = row.get("alias_groups")
        if not isinstance(groups, dict):
            errors.append(f"缺少alias_groups: {vid}")
            groups = {}
        if set(groups) != EXPECTED_ALIAS_GROUPS:
            errors.append(
                f"alias_groups类型错误: {vid} -> {sorted(set(groups))}"
            )
        for group_name in EXPECTED_ALIAS_GROUPS:
            values = groups.get(group_name)
            if not isinstance(values, list):
                errors.append(f"别名组不是数组: {vid}.{group_name}")
                continue
            if len(values) != len(
                {unicodedata.normalize('NFKC', str(x)).casefold() for x in values}
            ):
                errors.append(f"别名组内部重复: {vid}.{group_name}")

        if names.get("zh") not in groups.get("chinese", []):
            errors.append(f"中文主名称未进入chinese组: {vid}")
        if names.get("en") not in groups.get("english", []):
            errors.append(f"英文主名称未进入english组: {vid}")
        for required_code in (vid, source.get("canonical_name"), names.get("code")):
            if required_code not in groups.get("code", []):
                errors.append(f"代码别名缺失: {vid} -> {required_code}")

        searchable = row.get("searchable_terms")
        if not isinstance(searchable, list) or not searchable:
            errors.append(f"searchable_terms为空: {vid}")
            searchable = []
        expected_safe = set()
        for group_name in EXPECTED_ALIAS_GROUPS:
            expected_safe.update(groups.get(group_name, []))
        # searchable_terms按NFKC+大小写折叠去重；例如英文名Description与
        # 代码字段description会保留在各自分组，但检索词表只需保留一个规范化词。
        if {normalize(x) for x in searchable} != {
            normalize(x) for x in expected_safe
        }:
            errors.append(f"searchable_terms与安全别名组不一致: {vid}")
        safe_terms_by_id[vid] = {normalize(x) for x in searchable}

        mistakes = row.get("common_mistakes")
        if not isinstance(mistakes, list):
            errors.append(f"common_mistakes不是数组: {vid}")
            mistakes = []
        for mistake in mistakes:
            if (
                not isinstance(mistake, dict)
                or not str(mistake.get("term", "")).strip()
                or not str(mistake.get("correction", "")).strip()
            ):
                errors.append(f"错误叫法记录不完整: {vid}")
        if row.get("mistake_match_policy") != (
            "correction_only; do_not_treat_as_confirmed_semantic_alias"
        ):
            errors.append(f"错误叫法策略不正确: {vid}")

        evidence = row.get("evidence", {})
        if evidence.get("step05_variable_id") != vid:
            errors.append(f"step05_variable_id错误: {vid}")
        if evidence.get("evidence_ids") != lineage_row["provenance"]["evidence_ids"]:
            errors.append(f"证据ID与步骤六不一致: {vid}")
        if evidence.get("producer_locations") != lineage_row["provenance"][
            "producer_locations"
        ]:
            errors.append(f"生产位置与步骤六不一致: {vid}")
        if row.get("truth_boundary") != lineage_row.get("truth_boundary"):
            errors.append(f"可信边界与步骤六不一致: {vid}")

    alias_index = aliases.get("alias_index")
    if not isinstance(alias_index, list):
        errors.append("aliases.yaml缺少alias_index数组")
        alias_index = []
    normalized_terms = [
        row.get("normalized_term") for row in alias_index if isinstance(row, dict)
    ]
    if normalized_terms != sorted(normalized_terms):
        errors.append("alias_index未按normalized_term排序")
    if len(normalized_terms) != len(set(normalized_terms)):
        errors.append("alias_index存在重复normalized_term")
    index_by_term = {
        row["normalized_term"]: row
        for row in alias_index
        if isinstance(row, dict) and isinstance(row.get("normalized_term"), str)
    }

    for term, item in index_by_term.items():
        if normalize(term) != term:
            errors.append(f"索引键未规范化: {term}")
        matches = item.get("candidate_matches")
        if not isinstance(matches, list) or not matches:
            errors.append(f"索引没有候选: {term}")
            continue
        match_ids = [x.get("variable_id") for x in matches]
        if match_ids != sorted(match_ids):
            errors.append(f"索引候选未排序: {term}")
        if len(match_ids) != len(set(match_ids)):
            errors.append(f"索引候选重复: {term}")
        for match in matches:
            vid = match.get("variable_id")
            if vid not in step05:
                errors.append(f"索引引用不存在变量: {term} -> {vid}")
                continue
            if match.get("taxonomy_source_layer") != lineage_by_id[vid].get(
                "taxonomy_source_layer"
            ):
                errors.append(f"索引来源层错误: {term} -> {vid}")
            if not isinstance(match.get("matched_alias_groups"), list):
                errors.append(f"索引缺少matched_alias_groups: {term} -> {vid}")
        expected_ambiguous = len(match_ids) > 1
        if item.get("ambiguous") is not expected_ambiguous:
            errors.append(f"ambiguous标志错误: {term}")
        resolution = item.get("resolution", {})
        if expected_ambiguous:
            if resolution.get("policy") != "return_candidates_and_ask":
                errors.append(f"歧义词未要求返回候选: {term}")
            if not str(resolution.get("clarification_question", "")).strip():
                errors.append(f"歧义词缺少澄清问题: {term}")
        else:
            if resolution.get("policy") != "direct_candidate":
                errors.append(f"唯一候选词路由错误: {term}")
            if resolution.get("clarification_question") is not None:
                errors.append(f"唯一候选词不应追问: {term}")

    # 每个安全别名必须能在反向索引中找到原变量。
    for vid, terms in safe_terms_by_id.items():
        for term in terms:
            if vid not in candidates(index_by_term, term):
                errors.append(f"安全别名未反向索引: {vid} -> {term}")

    groups = aliases.get("ambiguity_groups")
    if not isinstance(groups, list) or len(groups) < 1:
        errors.append("缺少人工歧义组")
        groups = []
    group_ids = [x.get("id") for x in groups if isinstance(x, dict)]
    if group_ids != sorted(group_ids):
        errors.append("人工歧义组未按ID排序")
    if len(group_ids) != len(set(group_ids)):
        errors.append("人工歧义组ID重复")
    for group in groups:
        candidate_ids = group.get("candidate_variable_ids")
        if not isinstance(candidate_ids, list) or len(candidate_ids) < 2:
            errors.append(f"歧义组候选不足: {group.get('id')}")
            continue
        if not set(candidate_ids) <= set(step05):
            errors.append(f"歧义组引用不存在变量: {group.get('id')}")
        if not str(group.get("clarification_question", "")).strip():
            errors.append(f"歧义组缺少澄清问题: {group.get('id')}")
        for surface in group.get("surface_forms", []):
            if not set(candidate_ids) <= candidates(index_by_term, surface):
                errors.append(
                    f"歧义表面词未包含全部候选: {group.get('id')} -> {surface}"
                )

    # 关键物理量边界：绝对值和比例不能静默混为一条记录。
    absolute_ids = {"raw_unit.health", "tbox.entity.hp", "abox.unit.hp"}
    ratio_ids = {
        "raw_unit.health_ratio",
        "abox.unit.hp_ratio",
        "derived.tactical.friendly_avg_hp",
        "derived.tactical.enemy_avg_hp",
    }
    if candidates(index_by_term, "HP") != absolute_ids:
        errors.append(f"HP候选错误: {sorted(candidates(index_by_term, 'HP'))}")
    if candidates(index_by_term, "health") != {"raw_unit.health"}:
        errors.append("health不应匹配health_ratio或其他派生量")
    if candidates(index_by_term, "health ratio") != {"raw_unit.health_ratio"}:
        errors.append("health ratio必须精确指向raw_unit.health_ratio")
    if candidates(index_by_term, "血量") != absolute_ids:
        errors.append("宽泛血量词的绝对值层级候选错误")
    if candidates(index_by_term, "血量比例") != ratio_ids:
        errors.append("宽泛血量比例词的比例候选错误")
    if candidates(index_by_term, "单位当前血量") != {"raw_unit.health"}:
        errors.append("单位当前血量应精确命中raw_unit.health")
    if candidates(index_by_term, "单位血量百分比") != {
        "raw_unit.health_ratio"
    }:
        errors.append("单位血量百分比应精确命中raw_unit.health_ratio")

    stats = aliases.get("statistics", {})
    expected_stats = {
        "variables": len(records),
        "searchable_terms": sum(
            len(row.get("searchable_terms", [])) for row in records
        ),
        "normalized_index_terms": len(alias_index),
        "ambiguous_index_terms": sum(
            row.get("ambiguous") is True for row in alias_index
        ),
        "manual_ambiguity_groups": len(groups),
        "variables_with_colloquial_aliases": sum(
            bool(row.get("alias_groups", {}).get("colloquial")) for row in records
        ),
        "variables_with_abbreviations": sum(
            bool(row.get("alias_groups", {}).get("abbreviations")) for row in records
        ),
        "variables_with_common_mistakes": sum(
            bool(row.get("common_mistakes")) for row in records
        ),
    }
    if stats != expected_stats:
        errors.append(f"aliases统计不一致: actual={stats}, expected={expected_stats}")

    boundary = aliases.get("runtime_boundary", {})
    for flag in ("sc2_executed", "external_llm_called", "external_corpus_mined"):
        if boundary.get(flag) is not False:
            errors.append(f"不得虚称已执行: {flag}")

    if not PATTERNS_PATH.is_file():
        errors.append("缺少 knowledge/retrieval/query_patterns.yaml")
        patterns = {}
    else:
        patterns = load_yaml(PATTERNS_PATH)
    intents = {
        row.get("id")
        for row in patterns.get("intent_registry", [])
        if isinstance(row, dict)
    }
    if intents != EXPECTED_INTENTS:
        errors.append(f"查询意图不完整: {sorted(intents)}")
    global_templates = patterns.get("global_templates", {})
    if set(global_templates) != EXPECTED_INTENTS:
        errors.append("全局查询模板未覆盖五类意图")
    for intent in EXPECTED_INTENTS:
        if not isinstance(global_templates.get(intent), list) or not global_templates[
            intent
        ]:
            errors.append(f"全局查询模板为空: {intent}")

    per_variable = patterns.get("per_variable_patterns")
    if not isinstance(per_variable, list):
        errors.append("query_patterns.yaml缺少per_variable_patterns数组")
        per_variable = []
    pattern_ids = [
        row.get("variable_id") for row in per_variable if isinstance(row, dict)
    ]
    if pattern_ids != sorted(pattern_ids):
        errors.append("逐变量查询模板未按ID排序")
    if set(pattern_ids) != set(step05) or len(pattern_ids) != 135:
        errors.append("逐变量查询模板没有精确覆盖135条变量")
    for row in per_variable:
        vid = row.get("variable_id")
        item_patterns = row.get("patterns")
        if not isinstance(item_patterns, dict) or set(item_patterns) != EXPECTED_INTENTS:
            errors.append(f"逐变量五类模板不完整: {vid}")
            continue
        for intent, examples in item_patterns.items():
            if (
                not isinstance(examples, list)
                or len(examples) < 2
                or not all(isinstance(x, str) and x.strip() for x in examples)
            ):
                errors.append(f"逐变量模板示例不足: {vid}.{intent}")

    pattern_boundary = patterns.get("runtime_boundary", {})
    for flag in ("external_llm_tested", "sc2_executed"):
        if pattern_boundary.get(flag) is not False:
            errors.append(f"query_patterns不得虚称已执行: {flag}")

    if not DOC_PATH.is_file():
        errors.append("缺少 knowledge/docs/07_alias_guide.md")
    else:
        doc = DOC_PATH.read_text(encoding="utf-8")
        required = [
            "135条",
            "aliases.yaml",
            "query_patterns.yaml",
            "health与health_ratio严格分离",
            "不能擅自选择",
            "interface_query",
            "physical_meaning_query",
            "source_location_query",
            "formula_query",
            "range_query",
            "未启动StarCraft II",
            "未调用外部LLM",
            "未添加当前代码不存在的变量",
        ]
        for phrase in required:
            if phrase not in doc:
                errors.append(f"步骤七文档缺少关键声明: {phrase}")

    for label, payload in (
        ("aliases.yaml", aliases),
        ("query_patterns.yaml", patterns),
        ("07_alias_guide.md", DOC_PATH.read_text(encoding="utf-8") if DOC_PATH.is_file() else ""),
    ):
        for text in iter_strings(payload):
            if any(ch in text for ch in BAD_UNICODE):
                errors.append(f"{label}包含损坏Unicode字符")
                break
            if ABSOLUTE_WINDOWS_RE.search(text):
                errors.append(f"{label}包含私人绝对路径")
                break

    print("步骤07严格静态校验")
    print(f"variables: {len(records)}")
    print(f"searchable_terms: {stats.get('searchable_terms', 0)}")
    print(f"normalized_index_terms: {len(alias_index)}")
    print(f"ambiguous_index_terms: {sum(x.get('ambiguous') is True for x in alias_index)}")
    print(f"manual_ambiguity_groups: {len(groups)}")
    print(f"query_intents: {len(intents)}")
    print(f"per_variable_patterns: {len(per_variable)}")
    print(f"errors: {len(errors)}")
    for item in errors:
        print(f"  ERROR: {item}")
    print(f"warnings: {len(warnings)}")
    for item in warnings:
        print(f"  WARNING: {item}")
    print("RESULT:", "PASS" if not errors else "FAIL")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
