from pathlib import Path
p=Path('knowledge/docs/16_multi_model_protocol.md')
s=p.read_text(encoding='utf-8-sig')
s=s.replace('- 状态：**部分完成（DeepSeek RAG 已完成故障审计、客户端修复、复杂题 smoke 和正式 2000-token 的 41 题复测；统一三条件矩阵尚未执行）**。','- 状态：**DeepSeek 三条件评测已完成；其他模型尚未执行。**')
s=s.replace('- 日期：2026-09-04。','- 日期：2026-09-05。',1)
s=s.replace('- 尚未执行：`no_knowledge_base`、真正的 `full_context`、GPT-5.6 Luna、SC2 运行和 LLM judge。','- 尚未执行：GPT-5.6 Luna、其他兼容模型、SC2 运行和 LLM judge。')
append='''

## 11. DeepSeek 三条件正式评测（2026-09-05）

### 11.1 统一参数

- 模型：`deepseek-v4-flash`
- 题集：challenge v0.3，41 题，SHA-256 为 `e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044`
- 参数：`temperature=0`、`thinking=disabled`、`json_mode=false`、`max_output_tokens=2000`、`max_retries=0`
- 本轮不是首次离线盲测，也不与 2026-09-04 默认 thinking 的旧 RAG 结果视为同参数复现。

### 11.2 full-context 的实际实现

本轮 `full_context` 使用：

`knowledge/context/sc2_raw_api_context_full_compact_v2.jsonl`

它满足：

- 来源为 `knowledge/context/variables.jsonl`；
- 135/135 变量 ID 全覆盖且顺序保持；
- 不使用检索；
- 不按问题裁剪；
- 不截断；
- 只压缩重复结构和字段名；
- 不等于原始 Markdown 上下文的逐字副本，因此报告标签必须写作 `full_compact_context`。

对应 manifest：`knowledge/context/sc2_raw_api_context_full_compact_v2_manifest.json`。

### 11.3 输出兼容规则

DeepSeek 在 no-KB/full-context 下倾向返回完整 YAML，而 RAG 多为原生 JSON。运行器仅允许两类结果：

1. 严格 JSON 对象；
2. 单段、字段白名单内、无思维链标记的确定性 YAML 映射恢复。

观测到的 `_status` 仅在值属于 `answered|ambiguous|not_found` 且 `response_status` 缺失时，一对一恢复为 `response_status`。所有恢复均记录 `format_repaired=true`，不得静默处理。

### 11.4 结果摘要

| 条件 | 行为准确率 | 有效响应 | 模型错误 | 总 tokens |
|---|---:|---:|---:|---:|
| no_knowledge_base | 14.63% | 31/41 | 10 | 20,301 |
| full_compact_context | 90.24% | 40/41 | 1 | 1,214,822 |
| retrieval_augmented | 58.54% | 24/26 模型调用 | 2 | 82,502 |

完整分析：`knowledge/evals/analysis/20260905_deepseek_three_conditions/report.md`。
'''
if '## 11. DeepSeek 三条件正式评测（2026-09-05）' not in s: s += append
p.write_text(s,encoding='utf-8')

p=Path('knowledge/evals/configs/model_matrix.yaml')
s=p.read_text(encoding='utf-8-sig')
s=s.replace('status: planned','status: deepseek_three_conditions_completed',1)
s=s.replace('  note: DeepSeek 首次 41 题 RAG 运行误用了 800-token 冒烟配置，保留为故障审计。客户端修复后已使用正式 2000-token 参数完成 challenge v0.3 RAG 复测；完整多模型三条件矩阵仍未执行。','  note: DeepSeek 已在统一关闭 thinking 的参数下完成 challenge v0.3 三条件评测；其他模型尚未执行。')
s=s.replace('  response_format: json_object','  response_format: prompt_constrained_json_or_audited_yaml_repair')
s=s.replace('  max_retries: 1','  max_retries: 0')
s=s.replace('  context_source: knowledge/context/sc2_raw_api_context_full.md','  context_source: knowledge/context/sc2_raw_api_context_full_compact_v2.jsonl\n  context_manifest: knowledge/context/sc2_raw_api_context_full_compact_v2_manifest.json\n  context_record_coverage: 135/135\n  query_specific_filtering: false\n  truncated: false')
s=s.replace('  current_gate_status: deepseek_rag_protocol_retest_completed_other_conditions_runner_and_openai_pending','  current_gate_status: deepseek_three_conditions_completed_openai_pending')
append='''
latest_three_condition_evaluation:
  date: '2026-09-05'
  model: deepseek-v4-flash
  temperature: 0
  max_output_tokens: 2000
  thinking: disabled
  json_mode: false
  max_retries: 0
  benchmark_sha256: e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044
  results:
    no_knowledge_base:
      run_id: 20260905_deepseek_challenge_v0.3_no_kb_three_conditions
      behavior_accuracy: 0.146341
      model_valid_response_count: 31
      model_error_count: 10
      total_tokens: 20301
    full_compact_context:
      run_id: 20260905_deepseek_challenge_v0.3_full_compact_three_conditions
      behavior_accuracy: 0.902439
      model_valid_response_count: 40
      model_error_count: 1
      total_tokens: 1214822
    retrieval_augmented:
      run_id: 20260905_deepseek_challenge_v0.3_rag_three_conditions
      behavior_accuracy: 0.585366
      model_called_count: 26
      local_short_circuit_count: 15
      model_valid_response_count: 24
      model_error_count: 2
      total_tokens: 82502
  analysis: knowledge/evals/analysis/20260905_deepseek_three_conditions/report.md
'''
if 'latest_three_condition_evaluation:' not in s: s += '\n'+append
p.write_text(s,encoding='utf-8')
print('PROTOCOL_AND_MATRIX_UPDATED')
