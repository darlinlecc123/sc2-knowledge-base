"""严格校验步骤 05 变量卡片；不运行 SC2 或外部模型。"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator, FormatChecker

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[2]
KNOWLEDGE = ROOT / "knowledge"
VARIABLE_DIR = KNOWLEDGE / "variables"
TARGET_NAMES = ["raw_api", "tbox", "abox", "derived", "actions", "swm", "metrics"]
SCHEMA_PATH = KNOWLEDGE / "schemas" / "variable.schema.json"
CATEGORY_PATH = KNOWLEDGE / "taxonomy" / "categories.yaml"
LAYER_PATH = KNOWLEDGE / "taxonomy" / "source_layers.yaml"
VALIDATION_NAME = "步骤05严格静态 Schema、关系与证据校验"
VALIDATION_DATE = "2026-09-03"
ID_RE = re.compile(r"^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+$")
ABSOLUTE_WINDOWS_RE = re.compile(r"^[A-Za-z]:[\\/]")


def load_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def write_yaml(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(
        yaml.safe_dump(payload, allow_unicode=True, sort_keys=False, width=120),
        encoding="utf-8",
    )


def source_line_count(path: Path) -> int:
    return len(path.read_text(encoding="utf-8", errors="replace").splitlines())


def iter_strings(value: Any):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from iter_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from iter_strings(item)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--stamp",
        action="store_true",
        help="仅在全部检查通过后，把本校验结果写为 passed。",
    )
    parser.add_argument(
        "--require-stamp",
        action="store_true",
        help="要求每条记录都已写入本严格校验的 passed 结果。",
    )
    args = parser.parse_args()

    errors: list[str] = []
    warnings: list[str] = []
    payloads: dict[str, dict[str, Any]] = {}
    record_files: dict[str, str] = {}
    all_records: list[dict[str, Any]] = []

    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    category_registry = load_yaml(CATEGORY_PATH)
    layer_registry = load_yaml(LAYER_PATH)
    validator = Draft202012Validator(schema, format_checker=FormatChecker())

    category_by_schema = {
        item["schema_category"]: item for item in category_registry["categories"]
    }
    prefix_to_category: dict[str, str] = {}
    for schema_category, item in category_by_schema.items():
        for prefix in item.get("id_prefixes", []):
            if prefix in prefix_to_category:
                errors.append(f"taxonomy ID 前缀重复: {prefix}")
            prefix_to_category[prefix] = schema_category

    layer_to_allowed_schema_categories: dict[str, set[str]] = {}
    short_to_schema_category = {
        item["id"]: item["schema_category"] for item in category_registry["categories"]
    }
    for layer in layer_registry["layers"]:
        allowed = {
            short_to_schema_category[item]
            for item in layer.get("allowed_categories", [])
            if item in short_to_schema_category
        }
        for schema_layer in layer.get("schema_source_layers", []):
            layer_to_allowed_schema_categories[schema_layer] = allowed

    for name in TARGET_NAMES:
        path = VARIABLE_DIR / f"{name}.yaml"
        if not path.exists():
            errors.append(f"缺少目标文件: {path.relative_to(ROOT)}")
            continue
        try:
            payload = load_yaml(path)
        except Exception as exc:
            errors.append(f"YAML 解析失败 {path.relative_to(ROOT)}: {exc}")
            continue
        if not isinstance(payload, dict) or not isinstance(payload.get("records"), list):
            errors.append(f"顶层结构错误 {path.relative_to(ROOT)}: 需要 records 数组")
            continue
        payloads[name] = payload
        records = payload["records"]
        ids = [record.get("id") for record in records if isinstance(record, dict)]
        if ids != sorted(ids):
            errors.append(f"记录未按 ID 排序: {path.relative_to(ROOT)}")
        for index, record in enumerate(records):
            if not isinstance(record, dict):
                errors.append(f"非对象记录: {path.relative_to(ROOT)} records[{index}]")
                continue
            record_id = record.get("id", f"records[{index}]")
            all_records.append(record)
            record_files[str(record_id)] = str(path.relative_to(ROOT)).replace("\\", "/")
            for schema_error in sorted(validator.iter_errors(record), key=lambda e: list(e.path)):
                location = ".".join(str(item) for item in schema_error.path) or "<record>"
                errors.append(f"Schema {record_id} {location}: {schema_error.message}")

    ids = [str(record.get("id")) for record in all_records]
    counts = Counter(ids)
    for record_id, count in sorted(counts.items()):
        if count > 1:
            errors.append(f"全库 ID 重复: {record_id} × {count}")
    id_set = set(ids)

    for record in all_records:
        record_id = str(record.get("id"))
        category = record.get("category")
        if not ID_RE.fullmatch(record_id):
            errors.append(f"稳定 ID 格式错误: {record_id}")
        prefix = record_id.split(".", 1)[0]
        expected_category = prefix_to_category.get(prefix)
        if expected_category is None:
            errors.append(f"ID 前缀未登记: {record_id}")
        elif expected_category != category:
            errors.append(
                f"ID 前缀与 category 不一致: {record_id} -> {category}, 应为 {expected_category}"
            )

        source_layer = record.get("provenance", {}).get("source_layer")
        allowed_categories = layer_to_allowed_schema_categories.get(source_layer)
        if allowed_categories is None:
            errors.append(f"来源层未登记: {record_id} -> {source_layer}")
        elif category not in allowed_categories:
            errors.append(
                f"category/source_layer 组合未允许: {record_id} -> {category}/{source_layer}"
            )

        targets = list(record.get("provenance", {}).get("upstream_variable_ids", []))
        targets.extend(
            relationship.get("target_id")
            for relationship in record.get("relationships", [])
            if isinstance(relationship, dict)
        )
        for target in targets:
            if target not in id_set:
                errors.append(f"关系目标不存在: {record_id} -> {target}")

        e1 = [item for item in record.get("evidence", []) if item.get("evidence_type") == "E1"]
        if not e1:
            errors.append(f"缺少当前源码 E1 证据: {record_id}")
        source_locations = record.get("implementation", {}).get("source_locations", [])
        if not source_locations:
            errors.append(f"缺少 implementation.source_locations: {record_id}")

        for label, locations in (("evidence", e1), ("source_location", source_locations)):
            for location in locations:
                rel = location.get("path")
                if not isinstance(rel, str) or ABSOLUTE_WINDOWS_RE.match(rel):
                    errors.append(f"{label} 路径不是仓库相对路径: {record_id} -> {rel}")
                    continue
                path = ROOT / rel
                if not path.is_file():
                    errors.append(f"{label} 文件不存在: {record_id} -> {rel}")
                    continue
                total = source_line_count(path)
                start = location.get("line_start")
                end = location.get("line_end")
                if not isinstance(start, int) or not isinstance(end, int):
                    errors.append(f"{label} 缺少整数行号: {record_id} -> {rel}")
                elif not (1 <= start <= end <= total):
                    errors.append(
                        f"{label} 行号越界: {record_id} -> {rel}:{start}-{end}/{total}"
                    )

        snippets = record.get("implementation", {}).get("extraction_code", [])
        if snippets and source_locations:
            first = source_locations[0]
            path = ROOT / str(first.get("path", ""))
            start = first.get("line_start")
            end = first.get("line_end")
            if path.is_file() and isinstance(start, int) and isinstance(end, int):
                lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
                excerpt = "\n".join(lines[start - 1 : end])
                if not any(str(snippet).strip() in excerpt for snippet in snippets):
                    errors.append(f"抽取代码与证据行不一致: {record_id}")

        verification = record.get("verification", {})
        if args.require_stamp:
            strict_results = [
                test.get("result")
                for test in verification.get("tests_executed", [])
                if test.get("name") == VALIDATION_NAME
            ]
            if strict_results != ["passed"]:
                errors.append(f"缺少严格校验 passed 盖章: {record_id}")
        if verification.get("sc2_executed") is not False:
            errors.append(f"本步骤不得声称执行 SC2: {record_id}")
        if verification.get("external_sources_checked") is not False:
            errors.append(f"本步骤未检查外部来源: {record_id}")
        if any(ABSOLUTE_WINDOWS_RE.match(text) for text in iter_strings(record)):
            errors.append(f"记录包含私人绝对路径: {record_id}")

    expected_raw_fields = {
        "raw_unit.tag",
        "raw_unit.unit_type",
        "raw_unit.alliance",
        "raw_unit.x",
        "raw_unit.y",
        "raw_unit.health",
        "raw_unit.health_ratio",
        "raw_unit.shield",
        "raw_unit.shield_ratio",
        "raw_unit.weapon_cooldown",
    }
    missing_raw = sorted(expected_raw_fields - id_set)
    if missing_raw:
        errors.append(f"RawAgent.parse_raw_units 必需字段缺失: {missing_raw}")

    report_path = KNOWLEDGE / "reports" / "05_extraction_coverage.md"
    if not report_path.is_file():
        errors.append("缺少覆盖报告: knowledge/reports/05_extraction_coverage.md")
    else:
        report_text = report_path.read_text(encoding="utf-8")
        if str(len(all_records)) not in report_text:
            errors.append(f"覆盖报告未包含当前记录总数: {len(all_records)}")

    expected_files = {f"{name}.yaml" for name in TARGET_NAMES} | {"examples.yaml"}
    unexpected_yaml = sorted(
        path.name for path in VARIABLE_DIR.glob("*.yaml") if path.name not in expected_files
    )
    if unexpected_yaml:
        warnings.append(f"variables 目录存在额外 YAML: {unexpected_yaml}")

    summary = {
        "files": len(payloads),
        "records": len(all_records),
        "categories": dict(sorted(Counter(r.get("category") for r in all_records).items())),
        "source_layers": dict(
            sorted(Counter(r.get("provenance", {}).get("source_layer") for r in all_records).items())
        ),
        "errors": len(errors),
        "warnings": len(warnings),
    }

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    for warning in warnings:
        print(f"WARN: {warning}")
    for error in errors:
        print(f"ERROR: {error}")

    if errors:
        print("RESULT: FAIL")
        return 1

    if args.stamp:
        for name, payload in payloads.items():
            for record in payload["records"]:
                tests = [
                    test
                    for test in record["verification"]["tests_executed"]
                    if test.get("name") != VALIDATION_NAME
                    and test.get("name") != "步骤05静态 Schema 与证据校验"
                ]
                tests.append({"name": VALIDATION_NAME, "result": "passed"})
                record["verification"]["tests_executed"] = tests
                record["verification"]["verified_at"] = VALIDATION_DATE
                record["verification"]["notes"] = (
                    "已通过步骤05严格静态 Schema、关系与证据校验；"
                    "未启动 SC2，未调用外部 LLM/SWM，未检查外部官方资料。"
                )
            write_yaml(VARIABLE_DIR / f"{name}.yaml", payload)
        print("STAMP: 已将严格静态校验结果写回 7 份变量文件。")

    print("RESULT: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
