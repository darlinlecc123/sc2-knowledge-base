"""严格校验步骤 06 血缘和生命周期产物；不运行 SC2、外部模型或实验。"""
from __future__ import annotations

import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

import yaml

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[2]
K = ROOT / "knowledge"
VARIABLE_DIR = K / "variables"
LINEAGE_PATH = K / "lineage" / "variable_lineage.yaml"
DOC_PATH = K / "docs" / "06_provenance_and_lifecycle.md"
TARGET_NAMES = ["raw_api", "tbox", "abox", "derived", "actions", "swm", "metrics"]
EXPECTED_COUNTS = {
    "raw_api": 26,
    "tbox": 19,
    "abox": 28,
    "derived": 13,
    "actions": 21,
    "swm": 13,
    "metrics": 15,
}
LAYER_MAP = {
    "environment_config": "environment_config",
    "pysc2_timestep": "raw_observation",
    "pysc2_raw_observation": "raw_observation",
    "raw_unit_transformed": "raw_observation",
    "tbox_static": "static_ontology",
    "abox_runtime": "runtime_abox",
    "derived_runtime": "derived_runtime",
    "llm_output": "llm_output",
    "validated_action": "parser_validated",
    "executor_mapping": "executor_mapped",
    "swm_prediction": "model_predicted",
    "experiment_aggregate": "experiment_aggregated",
}
REQUIRED_LIFECYCLE = {
    "scope",
    "refresh_trigger",
    "refresh_granularity",
    "persistence",
    "reset_boundary",
    "update_timing",
    "game_loop_relation",
    "delay_revalidation",
    "training_stage",
}
ABSOLUTE_WINDOWS_RE = re.compile(r"[A-Za-z]:[\\/](?:Users|Documents and Settings)[\\/]", re.I)
PLACEHOLDER_TIMINGS = {
    "",
    "unknown",
    "todo",
    "tbd",
    "待补充",
    "待确认",
    "步骤六补充",
    "由步骤六补充",
}
BAD_UNICODE = {"\ufffd", "\x00"}


def load_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def iter_strings(value: Any):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from iter_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from iter_strings(item)


def check_counter(errors: list[str], label: str, actual: dict[str, int], expected: Counter):
    if actual != dict(sorted(expected.items())):
        errors.append(f"{label}统计不一致: actual={actual}, expected={dict(sorted(expected.items()))}")


def main() -> int:
    errors: list[str] = []
    warnings: list[str] = []

    step05: dict[str, dict[str, Any]] = {}
    input_counts: dict[str, int] = {}
    for name in TARGET_NAMES:
        path = VARIABLE_DIR / f"{name}.yaml"
        if not path.is_file():
            errors.append(f"缺少步骤五输入: {path.relative_to(ROOT)}")
            continue
        try:
            payload = load_yaml(path)
        except Exception as exc:
            errors.append(f"步骤五YAML解析失败 {path.relative_to(ROOT)}: {exc}")
            continue
        records = payload.get("records") if isinstance(payload, dict) else None
        if not isinstance(records, list):
            errors.append(f"步骤五结构错误 {path.relative_to(ROOT)}: 缺少records数组")
            continue
        input_counts[name] = len(records)
        if len(records) != EXPECTED_COUNTS[name]:
            errors.append(f"步骤五数量变化 {name}: {len(records)} != {EXPECTED_COUNTS[name]}")
        for record in records:
            rid = record.get("id") if isinstance(record, dict) else None
            if not isinstance(rid, str):
                errors.append(f"步骤五存在无效记录ID: {name}")
            elif rid in step05:
                errors.append(f"步骤五ID重复: {rid}")
            else:
                step05[rid] = record

    if not LINEAGE_PATH.is_file():
        errors.append("缺少 knowledge/lineage/variable_lineage.yaml")
        lineage = {}
    else:
        try:
            lineage = load_yaml(LINEAGE_PATH)
        except Exception as exc:
            errors.append(f"血缘YAML解析失败: {exc}")
            lineage = {}

    records = lineage.get("records") if isinstance(lineage, dict) else None
    if not isinstance(records, list):
        errors.append("血缘YAML顶层必须包含records数组")
        records = []

    if len(records) != 135:
        errors.append(f"血缘记录数错误: {len(records)} != 135")

    ids = [r.get("variable_id") for r in records if isinstance(r, dict)]
    if len(ids) != len(set(ids)):
        duplicates = sorted(k for k, v in Counter(ids).items() if v > 1)
        errors.append(f"血缘ID重复: {duplicates}")
    if ids != sorted(ids):
        errors.append("血缘记录未按variable_id确定性排序")
    if set(ids) != set(step05):
        errors.append(
            f"血缘ID集合与步骤五不一致: missing={sorted(set(step05)-set(ids))}, extra={sorted(set(ids)-set(step05))}"
        )

    lineage_by_id = {r.get("variable_id"): r for r in records if isinstance(r, dict)}
    all_ids = set(step05)
    for rid in sorted(set(ids) & all_ids):
        row = lineage_by_id[rid]
        source = step05[rid]
        source_layer = source.get("provenance", {}).get("source_layer")
        if row.get("source_layer") != source_layer:
            errors.append(f"source_layer与步骤五不一致: {rid}")
        expected_taxonomy = LAYER_MAP.get(source_layer)
        if expected_taxonomy is None:
            errors.append(f"未知source_layer: {rid} -> {source_layer}")
        elif row.get("taxonomy_source_layer") != expected_taxonomy:
            errors.append(
                f"步骤四来源层映射错误: {rid} -> {row.get('taxonomy_source_layer')} != {expected_taxonomy}"
            )

        value_class = row.get("value_class")
        if not isinstance(value_class, str) or not value_class.strip():
            errors.append(f"缺少value_class: {rid}")

        provenance = row.get("provenance")
        if not isinstance(provenance, dict):
            errors.append(f"缺少provenance对象: {rid}")
            provenance = {}
        expected_upstream = sorted(source.get("provenance", {}).get("upstream_variable_ids", []))
        actual_upstream = provenance.get("upstream_variable_ids")
        if actual_upstream != expected_upstream:
            errors.append(f"upstream与步骤五不一致: {rid}")
        for target in actual_upstream or []:
            if target not in all_ids:
                errors.append(f"上游变量不存在: {rid} -> {target}")

        producers = provenance.get("producer_locations")
        if not isinstance(producers, list) or not producers:
            errors.append(f"缺少producer_locations: {rid}")
        elif producers != source.get("implementation", {}).get("source_locations"):
            errors.append(f"producer_locations与步骤五不一致: {rid}")

        expected_evidence = [e.get("id") for e in source.get("evidence", [])]
        if provenance.get("evidence_ids") != expected_evidence:
            errors.append(f"evidence_ids与步骤五不一致: {rid}")

        lifecycle = row.get("lifecycle")
        if not isinstance(lifecycle, dict):
            errors.append(f"缺少lifecycle对象: {rid}")
            lifecycle = {}
        missing_lifecycle = sorted(REQUIRED_LIFECYCLE - set(lifecycle))
        if missing_lifecycle:
            errors.append(f"生命周期字段缺失: {rid} -> {missing_lifecycle}")
        timing = lifecycle.get("update_timing")
        if not isinstance(timing, str) or timing.strip().lower() in PLACEHOLDER_TIMINGS or len(timing.strip()) < 8:
            errors.append(f"update_timing为空、过短或仍为占位: {rid} -> {timing!r}")

        downstream = row.get("downstream")
        if not isinstance(downstream, dict):
            errors.append(f"缺少downstream对象: {rid}")
            downstream = {}
        for target in downstream.get("variable_ids", []):
            if target not in all_ids:
                errors.append(f"下游变量不存在: {rid} -> {target}")
        if not isinstance(downstream.get("consumers"), list) or not downstream.get("consumers"):
            errors.append(f"缺少下游消费者: {rid}")

        truth = row.get("truth_boundary")
        if not isinstance(truth, dict):
            errors.append(f"缺少truth_boundary对象: {rid}")
            truth = {}
        for field in ("definition_status", "runtime_value_status", "needs_runtime_verification", "reason"):
            if field not in truth:
                errors.append(f"truth_boundary缺少{field}: {rid}")
        needs_runtime = truth.get("needs_runtime_verification")
        if source_layer == "tbox_static":
            if row.get("value_class") != "static_knowledge" or needs_runtime is not False:
                errors.append(f"TBox静态知识分类错误: {rid}")
        else:
            if needs_runtime is not True:
                errors.append(f"非TBox记录必须保留运行验证需求: {rid}")
        if source_layer in {"pysc2_timestep", "pysc2_raw_observation", "raw_unit_transformed"}:
            if row.get("taxonomy_source_layer") != "raw_observation" or row.get("value_class") not in {"observation_value", "cross_frame_state"}:
                errors.append(f"Raw observation分类错误: {rid}")
        if source_layer in {"llm_output", "swm_prediction"} and needs_runtime is not True:
            errors.append(f"模型输出未标记运行验证: {rid}")

        verification = row.get("verification")
        if not isinstance(verification, dict):
            errors.append(f"缺少verification对象: {rid}")
            verification = {}
        for flag in ("sc2_executed", "external_llm_or_swm_called", "experiments_reexecuted"):
            if verification.get(flag) is not False:
                errors.append(f"不得虚称已执行 {flag}: {rid}")

        for text in iter_strings(row):
            if any(ch in text for ch in BAD_UNICODE):
                errors.append(f"检测到损坏Unicode字符: {rid}")
                break
            if ABSOLUTE_WINDOWS_RE.search(text):
                errors.append(f"包含私人绝对路径: {rid}")
                break

    stats = lineage.get("statistics", {}) if isinstance(lineage, dict) else {}
    if stats.get("total_records") != len(records):
        errors.append("statistics.total_records与实际记录数不一致")
    if stats.get("by_input_file") != input_counts:
        errors.append(f"by_input_file统计不一致: {stats.get('by_input_file')} != {input_counts}")
    check_counter(errors, "by_source_layer", stats.get("by_source_layer", {}), Counter(r.get("source_layer") for r in records))
    check_counter(errors, "by_taxonomy_source_layer", stats.get("by_taxonomy_source_layer", {}), Counter(r.get("taxonomy_source_layer") for r in records))
    check_counter(errors, "by_value_class", stats.get("by_value_class", {}), Counter(r.get("value_class") for r in records))
    check_counter(errors, "by_refresh_granularity", stats.get("by_refresh_granularity", {}), Counter(r.get("lifecycle", {}).get("refresh_granularity") for r in records))
    actual_needs = sum(r.get("truth_boundary", {}).get("needs_runtime_verification") is True for r in records)
    if stats.get("needs_runtime_verification") != actual_needs:
        errors.append("needs_runtime_verification统计不一致")

    boundary = lineage.get("runtime_boundary", {}) if isinstance(lineage, dict) else {}
    for flag in ("sc2_executed", "external_llm_or_swm_called", "experiments_reexecuted", "external_pysc2_docs_checked"):
        if boundary.get(flag) is not False:
            errors.append(f"runtime_boundary不得虚称已执行: {flag}")

    if not DOC_PATH.is_file():
        errors.append("缺少 knowledge/docs/06_provenance_and_lifecycle.md")
    else:
        text = DOC_PATH.read_text(encoding="utf-8")
        required_phrases = [
            "135条",
            "source_layer",
            "update_timing",
            "game loop",
            "delay_steps",
            "pending_actions",
            "needs_runtime_verification",
            "未启动StarCraft II",
            "未调用外部LLM/SWM",
            "实验复现：未执行",
        ]
        for phrase in required_phrases:
            if phrase not in text:
                errors.append(f"步骤六文档缺少关键声明: {phrase}")
        if any(ch in text for ch in BAD_UNICODE):
            errors.append("步骤六文档包含损坏Unicode字符")
        if ABSOLUTE_WINDOWS_RE.search(text):
            errors.append("步骤六文档包含私人绝对路径")

    print("步骤06严格静态校验")
    print(f"records: {len(records)}")
    print(f"source layers: {len(Counter(r.get('source_layer') for r in records))}")
    print(f"value classes: {len(Counter(r.get('value_class') for r in records))}")
    print(f"needs_runtime_verification: {actual_needs}")
    print(f"errors: {len(errors)}")
    for item in errors:
        print(f"  ERROR: {item}")
    print(f"warnings: {len(warnings)}")
    for item in warnings:
        print(f"  WARNING: {item}")
    print("RESULT:", "PASS" if not errors else "FAIL")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
