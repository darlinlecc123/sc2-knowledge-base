"""生成不参与当前检索调参的 STORM Raw API V0.1 泛化挑战集。"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
KB_ROOT = ROOT / "knowledge"
CONTEXT = KB_ROOT / "context" / "variables.jsonl"
OUTPUT = KB_ROOT / "evals" / "questions_challenge_v0.1.jsonl"
MANIFEST = KB_ROOT / "evals" / "challenge_v0.1_manifest.json"
SOURCE_SETS = [KB_ROOT / "evals" / "questions_dev.jsonl", KB_ROOT / "evals" / "questions_test.jsonl"]
VERSION = "0.1.0"
GENERATED_AT = "2026-09-04"


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", text.casefold())


def load_records() -> dict[str, dict[str, Any]]:
    return {
        record["variable_id"]: record
        for line in CONTEXT.read_text(encoding="utf-8").splitlines()
        if line.strip()
        for record in [json.loads(line)]
    }


def first_evidence(record: dict[str, Any]) -> dict[str, Any]:
    evidence = (record.get("evidence") or [None])[0]
    if not evidence:
        raise ValueError(f"变量缺少主证据：{record['variable_id']}")
    return {
        "evidence_id": evidence["id"],
        "fact_status": evidence.get("fact_status", "code_reality"),
        "path": evidence["path"],
        "symbol": evidence.get("symbol"),
    }


def build_cases(records: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    # 这些问题在冻结前只依据变量卡人工设计；生成器不导入 SearchEngine 或 QAAgent。
    specs = [
        ("identity-type-not-instance", "观测里的哪个编号说明单位是枪兵还是蟑螂，而不是区分两只同类单位？", ["raw_unit.unit_type"], "answer", "found", "oral", "medium"),
        ("identity-instance-not-type", "两只同类型单位混在一起时，Raw 观测靠什么稳定编号逐个追踪？", ["raw_unit.tag"], "answer", "found", "oral", "medium"),
        ("survival-two-bars", "若要分别读取单位肉身血条和能量盾的当前绝对值，需要哪两个 RawUnit 量？", ["raw_unit.health", "raw_unit.shield"], "answer", "found", "multi_variable_comparison", "medium"),
        ("health-normalized", "为了跨单位比较受伤程度，我不想用绝对血量，而想用当前值除以上限后的量，应查哪个字段？", ["raw_unit.health_ratio"], "answer", "found", "formula", "hard"),
        ("raw-grid-location", "一个兵在 64×64 raw 平面落在哪个格子，要联合读取哪两个坐标分量？", ["raw_unit.x", "raw_unit.y"], "answer", "found", "multi_variable_comparison", "medium"),
        ("cooldown-readiness-en", "Which RawUnit scalar does STORM use as an approximate clue that a weapon is ready again?", ["raw_unit.weapon_cooldown"], "answer", "found", "english", "medium"),
        ("abox-type-id", "进入 ABox 后，单位实例节点保留的类型数字 ID 叫什么？", ["abox.unit.unit_type_id"], "answer", "found", "direct", "medium"),
        ("position-lineage", "图节点里的 position 是怎样从原始横纵分量来的？请把 ABox 属性和上游 Raw 字段都找出来。", ["abox.unit.position", "raw_unit.x", "raw_unit.y"], "answer", "found", "lineage", "hard"),
        ("unknown-node-flag", "ABox 中哪个布尔属性标记这个实例是否用了未知单位回退逻辑？", ["abox.unit.is_unknown"], "answer", "found", "direct", "medium"),
        ("armor-shield-quirk", "当前实现里 ABox 节点名为 armor 的值真的来自静态护甲吗？请同时指出该属性和实际 Raw 来源。", ["abox.unit.armor", "raw_unit.shield"], "answer", "found", "known_issue_trap", "hard"),
        ("tbox-dps", "本体静态知识里用于表达每秒伤害能力的属性是哪一个？", ["tbox.entity.dps"], "answer", "found", "direct", "easy"),
        ("tbox-two-costs", "训练或建造成本若要拆成晶体矿和高能瓦斯两部分，应查哪两个 TBox 属性？", ["tbox.entity.mineral_cost", "tbox.entity.gas_cost"], "answer", "found", "multi_variable_comparison", "medium"),
        ("tbox-population-cost", "单位在静态本体里占多少人口，对应哪个变量？", ["tbox.entity.supply_cost"], "answer", "found", "direct", "easy"),
        ("force-balance", "战术摘要中哪一个派生量概括双方兵力数量的相对比例？", ["derived.tactical.force_ratio"], "answer", "found", "direct", "medium"),
        ("two-centers", "为了画出敌我两群单位各自的中心点，需要哪两个战术派生坐标？", ["derived.tactical.friendly_centroid", "derived.tactical.enemy_centroid"], "answer", "found", "multi_variable_comparison", "medium"),
        ("fire-ready-summary", "如果既要知道整体开火准备度，又要知道具体有多少单位可开火，应返回哪两个战术量？", ["derived.tactical.fire_readiness", "derived.tactical.ready_to_fire_count"], "answer", "found", "multi_variable_comparison", "hard"),
        ("health-bucket", "战术提示里把总体生命状态归纳成标签的字段是什么？", ["derived.tactical.health_status"], "answer", "found", "direct", "medium"),
        ("action-actors-and-kind", "一条计划动作中，谁来执行和目标属于哪种类型分别由什么字段表达？", ["action.units", "action.target_type"], "answer", "found", "multi_variable_comparison", "hard"),
        ("action-invalid-why", "批量动作计划校验后，想统计各种失败原因各出现几次，应读取哪个汇总变量？", ["action.invalid_reason_counts"], "answer", "found", "direct", "medium"),
        ("timing-three-clocks", "请区分环境一次交互推进的游戏循环数、常规决策间隔和单条动作延迟步数，对应哪三个量？", ["environment.step_mul", "environment.decision_interval", "action.delay_steps"], "answer", "found", "multi_variable_comparison", "hard"),
        ("function-arguments", "最终 PySC2 FunctionCall 中，被操作单位列表与目标参数分别落在哪两个接口字段？", ["pysc2.function.unit_tags", "pysc2.function.target"], "answer", "found", "multi_variable_comparison", "medium"),
        ("production-functions", "Which two canonical variables identify the BUILD and TRAIN raw function calls?", ["pysc2.build.function_id", "pysc2.train.function_id"], "answer", "found", "english", "medium"),
        ("supply-equation", "还剩多少人口槽位由哪三个 player 量构成？请返回上限、已用量和差值。", ["player.food_cap", "player.food_used", "player.supply_remaining"], "answer", "found", "formula", "hard"),
        ("reward-vs-score", "本步奖励变化和整局累计得分不能混为一谈，它们分别是哪两个 Timestep 量？", ["timestep.reward_delta", "timestep.score_cumulative_0"], "answer", "found", "multi_variable_comparison", "medium"),
        ("swm-actions-to-states", "世界模型接收候选动作计划并输出未来单位状态时，对应的输入和输出变量各是什么？", ["swm.input.planned_actions", "swm.predicted_unit_states"], "answer", "found", "lineage", "hard"),
        ("swm-position-change-error", "单位位置的预测增量和最终位置 RMSE 是两个层次的量，请分别指出它们。", ["swm.unit.position_delta", "metric.swm.position_rmse"], "answer", "found", "multi_variable_comparison", "hard"),
        ("token-accounting", "一次模型调用的输入 token、输出 token 和两者总和，在指标里分别叫什么？", ["metric.llm.prompt_tokens", "metric.llm.completion_tokens", "metric.llm.total_tokens"], "answer", "found", "multi_variable_comparison", "medium"),
        ("ambiguous-description", "description 这个名字在知识库里指哪个变量？", ["tbox.entity.description", "abox.unit.description"], "clarify", "ambiguous", "ambiguous", "medium"),
        ("ambiguous-tag", "tag 是 Raw 观测值还是 ABox 节点属性？我没有指定层级。", ["raw_unit.tag", "abox.unit.tag"], "clarify", "ambiguous", "ambiguous", "medium"),
        ("false-max-health", "RawUnit.health 就是单位最大生命值，对吗？请指出相关正式变量并纠正前提。", ["raw_unit.health"], "answer", "found", "false_premise", "hard"),
        ("out-of-scope-energy-regen", "请告诉我单位每秒恢复多少能量，这版知识库有正式变量吗？", [], "refuse", "not_found", "out_of_scope", "medium"),
        ("out-of-scope-camera", "feature layer 的镜头坐标变量在 V0.1 中是哪一个？", [], "refuse", "not_found", "out_of_scope", "medium"),
    ]

    result: list[dict[str, Any]] = []
    for index, (slug, question, variable_ids, behavior, status, qtype, difficulty) in enumerate(specs, 1):
        evidences = []
        refs = []
        categories = []
        for variable_id in variable_ids:
            record = records[variable_id]
            evidences.append(first_evidence(record))
            refs.append(record.get("record_ref", f"knowledge/context/variables.jsonl#variable_id={variable_id}"))
            categories.append(record.get("category"))
        if not variable_ids:
            evidences = [{
                "evidence_id": "scope-v0.1-manifest",
                "fact_status": "design_intent",
                "path": "knowledge/manifests/scope.yaml",
                "symbol": "scope.in_scope_rule",
            }]
        result.append({
            "benchmark_version": VERSION,
            "category": "generalization_challenge",
            "clarification_required": behavior == "clarify",
            "difficulty": difficulty,
            "expected_behavior": behavior,
            "expected_status": status,
            "expected_variable_ids": variable_ids,
            "forbidden_claims": [
                "声称执行了本题未记录的 SC2 运行时或外部模型测试",
                "使用知识库外常识补齐缺失变量",
            ],
            "generated_at": GENERATED_AT,
            "id": f"challenge.{index:03d}.{slug}",
            "intents": ["unseen_paraphrase", "retrieval_generalization"],
            "language": "en" if qtype == "english" else "zh",
            "notes": "冻结后首次运行；本轮不得依据该题结果修改检索器。",
            "question": question,
            "question_type": qtype,
            "required_evidence": evidences,
            "required_facts": [],
            "source_record_refs": refs,
            "split": "challenge",
            "variable_categories": sorted({x for x in categories if x}),
        })
    return result


def render_jsonl(cases: list[dict[str, Any]]) -> str:
    return "".join(json.dumps(case, ensure_ascii=False, sort_keys=True) + "\n" for case in cases)


def build_manifest(payload: bytes, cases: list[dict[str, Any]], source_norms: set[str]) -> dict[str, Any]:
    return {
        "challenge_version": VERSION,
        "created_at": GENERATED_AT,
        "frozen_before_first_evaluation": True,
        "tuning_policy": "首次评测后本轮禁止依据挑战集结果修改检索规则；失败项只记录。",
        "question_file": "knowledge/evals/questions_challenge_v0.1.jsonl",
        "sha256": hashlib.sha256(payload).hexdigest(),
        "case_count": len(cases),
        "source_benchmark_normalized_overlap": sum(norm(x["question"]) in source_norms for x in cases),
        "difficulty": dict(sorted(Counter(x["difficulty"] for x in cases).items())),
        "question_type": dict(sorted(Counter(x["question_type"] for x in cases).items())),
        "expected_behavior": dict(sorted(Counter(x["expected_behavior"] for x in cases).items())),
        "external_model_test": "未执行",
        "sc2_runtime": "未执行",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    records = load_records()
    cases = build_cases(records)
    source_norms = {
        norm(json.loads(line)["question"])
        for path in SOURCE_SETS
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    payload = render_jsonl(cases).encode("utf-8")
    manifest = build_manifest(payload, cases, source_norms)
    manifest_text = json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.check:
        ok = OUTPUT.read_bytes() == payload and MANIFEST.read_text(encoding="utf-8") == manifest_text
        print("PASS" if ok else "FAIL")
        return 0 if ok else 1
    OUTPUT.write_bytes(payload)
    MANIFEST.write_text(manifest_text, encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
