from __future__ import annotations

import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[2]
K = ROOT / "knowledge"
V = K / "variables"
LINEAGE = K / "lineage" / "variable_lineage.yaml"
ALIASES_OUT = K / "retrieval" / "aliases.yaml"
PATTERNS_OUT = K / "retrieval" / "query_patterns.yaml"
DOC_OUT = K / "docs" / "07_alias_guide.md"
DATE = "2026-09-03"
FILES = ["raw_api", "tbox", "abox", "derived", "actions", "swm", "metrics"]

LAYER_ZH = {
    "environment_config": "环境配置",
    "raw_observation": "PySC2原始观测",
    "static_ontology": "TBox静态本体",
    "runtime_abox": "ABox运行时实例",
    "derived_runtime": "运行时派生战术量",
    "llm_output": "LLM原始输出",
    "parser_validated": "Parser校验后动作",
    "executor_mapped": "执行器映射结果",
    "model_predicted": "SWM模型预测",
    "experiment_aggregated": "实验聚合指标",
}
LAYER_EN = {
    "environment_config": "environment configuration",
    "raw_observation": "PySC2 raw observation",
    "static_ontology": "TBox static ontology",
    "runtime_abox": "runtime ABox instance",
    "derived_runtime": "derived tactical runtime",
    "llm_output": "LLM raw output",
    "parser_validated": "parser-validated action",
    "executor_mapped": "executor-mapped FunctionCall",
    "model_predicted": "SWM model-predicted",
    "experiment_aggregated": "experiment-aggregated metric",
}

# 只补当前变量的检索表达，不借此引入新变量。
CURATED: dict[str, dict[str, list[str]]] = {
    "environment.step_mul": {"colloquial": ["一步跨多少游戏循环", "环境一步跨几帧", "步进倍数"], "paper": ["环境步进倍率", "SC2环境交互步长"]},
    "environment.decision_interval": {"colloquial": ["多久决策一次", "LLM决策频率", "决策周期"], "paper": ["智能体决策间隔"]},
    "environment.raw_resolution": {"colloquial": ["Raw坐标大小", "原始坐标分辨率", "地图坐标范围"], "paper": ["Raw API空间分辨率"]},
    "environment.use_raw_actions": {"colloquial": ["是否使用Raw动作", "开启原始动作接口", "raw actions", "启用raw actions", "使用raw actions"]},
    "environment.use_raw_units": {"colloquial": ["是否读取RawUnit", "开启原始单位观测", "raw units", "启用raw units", "使用raw units"]},
    "player.minerals": {"colloquial": ["矿", "当前矿物", "矿物数量"], "paper": ["玩家矿物资源量"]},
    "player.vespene": {"colloquial": ["气", "瓦斯", "当前气矿", "高能瓦斯"], "paper": ["玩家高能瓦斯资源量"]},
    "player.food_used": {"colloquial": ["当前人口", "已占人口", "人口使用量"]},
    "player.food_cap": {"colloquial": ["最大人口", "人口容量", "人口帽"]},
    "player.supply_remaining": {"colloquial": ["可用人口", "还剩多少人口", "人口余量", "剩余人口"]},
    "raw_unit.health": {"colloquial": ["单位当前血量", "当前血量", "剩余生命值", "绝对血量", "还剩多少血", "当前还剩多少血", "原始血量", "血和盾", "还剩多少血和盾"], "paper": ["观测单位当前生命值", "单位瞬时生命值"]},
    "raw_unit.health_ratio": {"colloquial": ["单位血量比例", "单位血量百分比", "当前血量百分比", "生命百分比", "归一化血量"], "paper": ["观测单位归一化生命值"]},
    "raw_unit.shield": {"colloquial": ["单位当前盾值", "当前盾", "剩余护盾", "还剩多少盾", "当前还剩多少盾", "原始盾值", "血和盾", "还剩多少血和盾"]},
    "raw_unit.shield_ratio": {"colloquial": ["单位护盾比例", "当前护盾百分比", "归一化护盾"]},
    "raw_unit.tag": {"colloquial": ["单位唯一标识", "单位ID", "单位tag", "unique unit identifier", "unit unique identifier", "uniquely identifies the unit", "parsed unit identifier"]},
    "raw_unit.unit_type": {"colloquial": ["单位类型ID", "兵种编号", "unit type id"]},
    "raw_unit.alliance": {"colloquial": ["单位敌我编码", "敌我关系", "阵营编号"]},
    "raw_unit.weapon_cooldown": {"colloquial": ["开火冷却", "攻击冷却", "还有多久能打", "武器CD"], "abbreviations": ["CD"]},
    "raw_unit.x": {"colloquial": ["单位x坐标", "横向位置", "raw x coordinate", "RawUnit x坐标", "RawUnit坐标", "RawUnit 坐标", "横纵坐标"]},
    "raw_unit.y": {"colloquial": ["单位y坐标", "纵向位置", "raw y coordinate", "RawUnit y坐标", "RawUnit坐标", "RawUnit 坐标", "横纵坐标"]},
    "timestep.is_last": {"colloquial": ["是否结束", "episode结束标志", "最后一步"]},
    "timestep.reward_delta": {"colloquial": ["本次得分变化", "增量奖励", "决策间奖励", "胜负奖励", "地图奖励"]},
    "timestep.score_cumulative_0": {"colloquial": ["累计分数", "当前累计得分"]},
    "tbox.entity.hp": {"colloquial": ["兵种基础血量", "类型默认生命值", "本体生命值"], "paper": ["TBox类型生命值"]},
    "abox.unit.hp": {"colloquial": ["图中单位血量", "ABox当前血量", "实例当前生命值"], "paper": ["ABox单位实例生命值"]},
    "abox.unit.hp_ratio": {"colloquial": ["图中单位血量比例", "ABox生命比例", "实例血量百分比"]},
    "abox.unit.position": {"colloquial": ["图中单位位置", "ABox坐标", "单位二维位置", "ABox单位节点位置", "ABox 单位节点的位置属性", "ABox位置属性"]},
    "abox.unit.tag": {"colloquial": ["图节点单位tag", "ABox单位标识"]},
    "abox.graph.enemy_count": {"colloquial": ["图里的敌军数量", "ABox敌方节点数"]},
    "abox.graph.step_count": {"colloquial": ["战场图更新次数", "ABox更新计数"]},
    "derived.tactical.friendly_count": {"colloquial": ["我方数量", "友军单位数", "己方兵力数量"]},
    "derived.tactical.enemy_count": {"colloquial": ["敌方数量", "敌军单位数", "敌方兵力数量"]},
    "derived.tactical.friendly_avg_hp": {"colloquial": ["我方平均血量", "友军平均生命比例", "己方平均HP"]},
    "derived.tactical.enemy_avg_hp": {"colloquial": ["敌方平均血量", "敌军平均生命比例", "敌方平均HP"]},
    "derived.tactical.friendly_centroid": {"colloquial": ["我方中心位置", "友军中心点", "己方质心"]},
    "derived.tactical.enemy_centroid": {"colloquial": ["敌方中心位置", "敌军中心点", "敌方质心"]},
    "derived.tactical.force_ratio": {"colloquial": ["敌我兵力比", "兵力比例", "数量优势"]},
    "derived.tactical.formation_distance": {"colloquial": ["双方中心距离", "阵型距离", "敌我距离"]},
    "derived.tactical.fire_readiness": {"colloquial": ["开火准备度", "可开火比例", "火力就绪程度"]},
    "derived.tactical.ready_to_fire_count": {"colloquial": ["可开火单位数", "武器就绪单位数量"]},
    "derived.tactical.critical_units": {"colloquial": ["残血单位", "危急单位", "低血量单位"]},
    "derived.tactical.engagement_type": {"colloquial": ["交战状态", "接敌类型", "战斗接触类型"]},
    "derived.tactical.health_status": {"colloquial": ["整体血量状态", "生命态势", "部队健康状态"]},
    "action.plan": {"colloquial": ["动作计划", "LLM计划"]},
    "action.reasoning": {"colloquial": ["决策理由", "动作推理"]},
    "action.type": {"colloquial": ["动作类型", "MOVE还是ATTACK", "动作大类"]},
    "action.subtype": {"colloquial": ["动作子类型", "动作细分类"]},
    "action.units": {"colloquial": ["执行单位", "哪些单位执行动作", "动作单位tag列表"]},
    "action.target": {"colloquial": ["动作目标", "攻击或移动目标", "动作Schema里的target", "Schema target"]},
    "action.target_type": {"colloquial": ["目标是坐标还是单位", "动作目标种类"]},
    "action.delay_steps": {"colloquial": ["延迟几步执行", "动作延迟步数", "计划等待步数", "延迟执行步数"]},
    "action.priority": {"colloquial": ["动作优先级", "计划优先程度"]},
    "action.invalid_actions": {"colloquial": ["无效动作数", "非法动作计数"]},
    "action.invalid_reason_counts": {"colloquial": ["无效原因统计", "动作失败原因计数"]},
    "action.planned_actions": {"colloquial": ["计划动作数量", "本次规划了几个动作"]},
    "pysc2.function.queued": {"colloquial": ["FunctionCall排队参数", "SC2命令队列标志"]},
    "pysc2.function.unit_tags": {"colloquial": ["FunctionCall单位tag", "执行单位标签参数"]},
    "pysc2.function.target": {"colloquial": ["FunctionCall目标参数", "PySC2动作目标参数", "执行层使用的target", "最终FunctionCall target"]},
    "swm.input.abox_state": {"colloquial": ["SWM当前状态", "世界模型状态输入"]},
    "swm.input.planned_actions": {"colloquial": ["SWM候选动作输入", "给世界模型的动作"]},
    "swm.predicted_unit_states": {"colloquial": ["SWM预测单位状态", "未来单位状态"]},
    "swm.predicted_relations": {"colloquial": ["SWM预测关系", "未来单位关系"]},
    "swm.prediction_steps": {"colloquial": ["预测未来几步", "世界模型预测长度", "预测多少个未来步骤", "未来步骤数量"]},
    "swm.confidence": {"colloquial": ["SWM置信度", "预测把握"]},
    "swm.unit.health_delta": {"colloquial": ["预测血量变化", "未来生命增量", "单位生命变化量", "SWM单位生命变化量"]},
    "swm.unit.position_delta": {"colloquial": ["预测位移", "未来位置变化"]},
    "metric.episode.final_score": {"colloquial": ["单局最终分数", "episode得分"]},
    "metric.experiment.avg_score": {"colloquial": ["实验平均分", "多局平均得分"]},
    "metric.action.failure_rate": {"colloquial": ["总体动作失败比例", "动作失败占比"]},
    "metric.action.decision_failure_rate": {"colloquial": ["决策失败比例", "LLM决策动作失败率"]},
    "metric.action.delayed_failure_rate": {"colloquial": ["延迟动作失效率", "到期动作失败比例"]},
    "metric.llm.avg_decision_time": {"colloquial": ["LLM平均响应时间", "平均决策延迟"]},
    "metric.llm.total_tokens": {"colloquial": ["LLM总token", "总Token消耗"]},
    "metric.llm.prompt_tokens": {"colloquial": ["输入token", "提示词Token消耗"]},
    "metric.llm.completion_tokens": {"colloquial": ["输出token", "补全Token消耗"]},
    "metric.llm.decision_calls": {"colloquial": ["LLM调用次数", "决策请求次数"]},
    "metric.swm.health_rmse": {"colloquial": ["血量预测RMSE", "生命预测误差", "SWM生命值预测误差", "SWM 生命值预测误差", "生命值预测RMSE"]},
    "metric.swm.position_rmse": {"colloquial": ["位置预测RMSE", "坐标预测误差"]},
    "metric.swm.relation_accuracy": {"colloquial": ["关系预测正确率", "SWM关系准确率"]},
}

COMMON_MISTAKES: dict[str, list[dict[str, str]]] = {
    "raw_unit.health": [{"term": "生命值比例", "correction": "该词表示归一化比例，应查询raw_unit.health_ratio；raw_unit.health是绝对当前生命值。"}, {"term": "最大生命值", "correction": "当前STORM的该字段是观测到的当前生命值，不是最大生命值。"}],
    "raw_unit.health_ratio": [{"term": "当前生命值", "correction": "该词通常表示绝对值，应查询raw_unit.health；health_ratio是归一化比例。"}],
    "raw_unit.tag": [{"term": "单位类型ID", "correction": "tag标识单位实例；单位类型应查询raw_unit.unit_type。"}],
    "raw_unit.unit_type": [{"term": "单位唯一ID", "correction": "unit_type标识类型；单位实例唯一标识应查询raw_unit.tag。"}],
    "abox.unit.armor": [{"term": "游戏护甲值", "correction": "当前STORM代码的ABox armor字段实际接收RawUnit shield，不能直接解释为游戏护甲。"}],
    "abox.unit.armor_ratio": [{"term": "护甲百分比", "correction": "当前STORM代码的armor_ratio实际接收shield_ratio，命名语义需要运行和接口核验。"}],
    "action.delay_steps": [{"term": "queued", "correction": "delay_steps是STORM的环境步延迟；queued是PySC2 FunctionCall命令队列参数。"}],
    "pysc2.function.queued": [{"term": "pending_actions", "correction": "queued是PySC2命令队列参数；pending_actions是RawAgent中的延迟动作容器。"}],
    "swm.predicted_unit_states": [{"term": "下一时刻真实状态", "correction": "该变量是模型预测，不是下一时刻PySC2真实观测。"}],
    "metric.experiment.avg_score": [{"term": "当前单局得分", "correction": "avg_score是多个episode聚合值；单局最终值应查询metric.episode.final_score。"}],
}

MANUAL_AMBIGUITIES: list[dict[str, Any]] = [
    {"id": "ambiguity.health_absolute", "terms": ["hp", "生命值", "血量"], "candidates": ["raw_unit.health", "tbox.entity.hp", "abox.unit.hp"], "question": "你要查询的是PySC2当前观测生命值、TBox兵种类型生命值，还是ABox单位实例生命值？"},
    {"id": "ambiguity.health_ratio", "terms": ["生命比例", "血量比例", "hp ratio"], "candidates": ["raw_unit.health_ratio", "abox.unit.hp_ratio", "derived.tactical.friendly_avg_hp", "derived.tactical.enemy_avg_hp"], "question": "你要查询单个RawUnit比例、ABox实例比例，还是友军/敌军聚合平均比例？"},
    {"id": "ambiguity.unit_type", "terms": ["单位类型编号", "unit type id"], "candidates": ["raw_unit.unit_type", "tbox.entity.unit_type_id", "abox.unit.unit_type_id"], "question": "你要查询RawUnit观测类型编号、TBox类型声明，还是ABox实例携带的类型编号？"},
    {"id": "ambiguity.alliance", "terms": ["alliance", "阵营编码", "敌我关系"], "candidates": ["raw_unit.alliance", "abox.unit.alliance"], "question": "你要查询PySC2原始阵营编码，还是写入ABox实例后的阵营字段？"},
    {"id": "ambiguity.armor", "terms": ["armor", "护甲"], "candidates": ["tbox.entity.armor", "abox.unit.armor"], "question": "你指TBox静态类型护甲，还是当前代码中实际接收shield值的ABox armor字段？"},
    {"id": "ambiguity.enemy_count", "terms": ["enemy_count", "敌军数量"], "candidates": ["abox.graph.enemy_count", "derived.tactical.enemy_count"], "question": "你指写入BattlefieldGraph的敌军节点计数，还是战术摘要中的敌军数量？"},
    {"id": "ambiguity.target", "terms": ["target", "目标"], "candidates": ["abox.relation.target_node", "action.target", "pysc2.function.target"], "question": "你指ABox关系目标节点、LLM动作目标，还是PySC2 FunctionCall目标参数？"},
    {"id": "ambiguity.planned_actions", "terms": ["planned_actions", "计划动作"], "candidates": ["action.planned_actions", "swm.input.planned_actions"], "question": "你指计划动作数量指标，还是传给SWM的候选动作列表？"},
    {"id": "ambiguity.function_id", "terms": ["function_id", "函数编号"], "candidates": ["pysc2.attack.function_id", "pysc2.build.function_id", "pysc2.move.function_id", "pysc2.no_op.function_id", "pysc2.train.function_id"], "question": "你要查询ATTACK、BUILD、MOVE、NO_OP还是TRAIN对应的FunctionCall编号？"},
    {"id": "ambiguity.step", "terms": ["step", "步数", "步长"], "candidates": ["environment.step_mul", "abox.graph.step_count", "action.delay_steps", "swm.prediction.step", "swm.prediction_steps"], "question": "你指SC2环境步进倍率、ABox更新计数、动作延迟步，还是SWM预测相对步/预测长度？"},
    {"id": "ambiguity.score", "terms": ["score", "得分", "分数"], "candidates": ["timestep.reward_delta", "timestep.score_cumulative_0", "metric.episode.final_score", "metric.experiment.avg_score"], "question": "你指决策间增量、TimeStep累计得分、单episode最终得分，还是多episode平均得分？"},
    {"id": "ambiguity.tag", "terms": ["tag", "单位标签"], "candidates": ["raw_unit.tag", "abox.unit.tag", "pysc2.function.unit_tags"], "question": "你指RawUnit实例tag、ABox节点保存的tag，还是FunctionCall的unit_tags参数？"},
]

INTENTS = [
    ("interface_query", "接口形式查询", "查询数据类型、Python类型、形状、单位、范围以及PySC2/STORM访问路径"),
    ("physical_meaning_query", "物理含义查询", "查询变量在SC2或STORM数据流中的含义及其层级边界"),
    ("source_location_query", "源码定位查询", "查询生产、读取、转换或消费该变量的仓库相对路径与符号"),
    ("formula_query", "公式查询", "查询归一化、聚合、阈值、映射或统计公式"),
    ("range_query", "取值范围查询", "查询代码已验证的范围、枚举、单位及未知边界"),
]


def load_records() -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    rows = []
    for name in FILES:
        data = yaml.safe_load((V / f"{name}.yaml").read_text(encoding="utf-8"))
        rows.extend(data["records"])
    rows.sort(key=lambda x: x["id"])
    lineage_data = yaml.safe_load(LINEAGE.read_text(encoding="utf-8"))
    lineage = {r["variable_id"]: r for r in lineage_data["records"]}
    return rows, lineage


def normalize(term: str) -> str:
    text = unicodedata.normalize("NFKC", str(term)).strip().lower()
    text = re.sub(r"\s+", " ", text)
    text = text.replace("－", "-").replace("_", " ").replace("-", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def unique(items: list[str]) -> list[str]:
    seen = set()
    result = []
    for item in items:
        value = str(item).strip()
        if not value:
            continue
        key = unicodedata.normalize("NFKC", value).casefold()
        if key not in seen:
            seen.add(key)
            result.append(value)
    return sorted(result, key=lambda x: (normalize(x), x))


def code_aliases(record: dict[str, Any]) -> list[str]:
    result = [record["id"], record["canonical_name"], record["names"]["code"]]
    result.extend(record.get("interface", {}).get("storm_paths", []))
    pysc2_path = record.get("interface", {}).get("pysc2_path", {}).get("value")
    if pysc2_path:
        result.append(pysc2_path)
    return unique(result)


def abbreviations(record: dict[str, Any]) -> list[str]:
    text = " ".join([record["id"], record["names"]["en"], record["names"]["code"]]).lower()
    result = list(CURATED.get(record["id"], {}).get("abbreviations", []))
    mapping = {
        "damage per second": "DPS", "dps": "DPS",
        "root mean square": "RMSE", "rmse": "RMSE",
        "weapon_cooldown": "CD",
    }
    for needle, short in mapping.items():
        if needle in text:
            result.append(short)
    return unique(result)


def paper_terms(record: dict[str, Any], taxonomy_layer: str) -> list[str]:
    curated = CURATED.get(record["id"], {}).get("paper", [])
    zh = record["names"]["zh"]
    en = record["names"]["en"]
    return unique([
        *curated,
        f"{LAYER_ZH[taxonomy_layer]}中的{zh}",
        f"{LAYER_EN[taxonomy_layer]} {en.lower()}",
    ])


def default_typo(record: dict[str, Any]) -> list[dict[str, str]]:
    code = record["names"]["code"]
    result = list(COMMON_MISTAKES.get(record["id"], []))
    if "_" in code and re.fullmatch(r"[A-Za-z0-9_]+", code):
        result.append({
            "term": code.replace("_", ""),
            "correction": f"代码字段应写为{code}；无下划线形式只作为拼写纠错，不代表新变量。",
        })
    return sorted(result, key=lambda x: (normalize(x["term"]), x["term"]))


def clarification(candidates: list[str], by_id: dict[str, dict[str, Any]]) -> str:
    descriptions = []
    for vid in candidates:
        row = by_id[vid]
        descriptions.append(f"{vid}（{LAYER_ZH[row['taxonomy_source_layer']]}）")
    return "该查询词有多个候选，请说明数据层或使用场景：" + "；".join(descriptions) + "。"


def main() -> None:
    records, lineage = load_records()
    ids = {r["id"] for r in records}
    by_id = {r["id"]: lineage[r["id"]] for r in records}
    manual_by_term: dict[str, set[str]] = defaultdict(set)
    group_ids_by_variable: dict[str, list[str]] = defaultdict(list)
    ambiguity_groups = []
    for group in MANUAL_AMBIGUITIES:
        candidates = sorted(group["candidates"])
        missing = set(candidates) - ids
        if missing:
            raise ValueError(f"歧义组引用不存在变量: {group['id']} -> {missing}")
        item = {
            "id": group["id"],
            "surface_forms": unique(group["terms"]),
            "candidate_variable_ids": candidates,
            "clarification_question": group["question"],
            "resolution_policy": "return_all_candidates_and_ask; never_silently_select",
        }
        ambiguity_groups.append(item)
        for vid in candidates:
            group_ids_by_variable[vid].append(group["id"])
        for term in group["terms"]:
            manual_by_term[normalize(term)].update(candidates)

    alias_records = []
    index_source: dict[str, dict[str, Any]] = {}
    for record in records:
        vid = record["id"]
        lr = lineage[vid]
        taxonomy_layer = lr["taxonomy_source_layer"]
        curated = CURATED.get(vid, {})
        buckets = {
            "chinese": unique([record["names"]["zh"]]),
            "english": unique([record["names"]["en"]]),
            "code": code_aliases(record),
            "abbreviations": abbreviations(record),
            "colloquial": unique(curated.get("colloquial", [])),
            "paper_terms": paper_terms(record, taxonomy_layer),
        }
        mistakes = default_typo(record)
        searchable = unique(sum(buckets.values(), []))
        item = {
            "variable_id": vid,
            "category": record["category"],
            "source_layer": lr["source_layer"],
            "taxonomy_source_layer": taxonomy_layer,
            "names": record["names"],
            "alias_groups": buckets,
            "common_mistakes": mistakes,
            "mistake_match_policy": "correction_only; do_not_treat_as_confirmed_semantic_alias",
            "searchable_terms": searchable,
            "ambiguity_group_ids": sorted(group_ids_by_variable.get(vid, [])),
            "evidence": {
                "step05_variable_id": vid,
                "evidence_ids": lr["provenance"]["evidence_ids"],
                "producer_locations": lr["provenance"]["producer_locations"],
            },
            "truth_boundary": lr["truth_boundary"],
        }
        alias_records.append(item)
        for group_name, terms in buckets.items():
            for term in terms:
                key = normalize(term)
                node = index_source.setdefault(key, {"surface_forms": set(), "matches": defaultdict(set)})
                node["surface_forms"].add(term)
                node["matches"][vid].add(group_name)

    # 人工歧义词即使不是某个变量的安全一对一别名，也进入“只返回候选”的索引。
    for key, candidates in manual_by_term.items():
        node = index_source.setdefault(key, {"surface_forms": set(), "matches": defaultdict(set)})
        for group in MANUAL_AMBIGUITIES:
            for term in group["terms"]:
                if normalize(term) == key:
                    node["surface_forms"].add(term)
        for vid in candidates:
            node["matches"][vid].add("ambiguous_surface_form")

    alias_index = []
    collision_count = 0
    for key in sorted(index_source):
        node = index_source[key]
        candidates = sorted(node["matches"])
        ambiguous = len(candidates) > 1
        if ambiguous:
            collision_count += 1
        alias_index.append({
            "normalized_term": key,
            "surface_forms": sorted(node["surface_forms"], key=lambda x: (normalize(x), x)),
            "candidate_matches": [
                {
                    "variable_id": vid,
                    "taxonomy_source_layer": by_id[vid]["taxonomy_source_layer"],
                    "matched_alias_groups": sorted(node["matches"][vid]),
                }
                for vid in candidates
            ],
            "ambiguous": ambiguous,
            "resolution": {
                "policy": "return_candidates_and_ask" if ambiguous else "direct_candidate",
                "clarification_question": clarification(candidates, by_id) if ambiguous else None,
            },
        })

    aliases_payload = {
        "knowledge_base": "storm-sc2kb-v1-raw",
        "schema_version": "1.0.0",
        "generated_at": DATE,
        "status": "static_alias_dictionary_built",
        "scope": "步骤五135条正式变量的中英文、代码、缩写、口语、论文表达、纠错词和歧义查询映射。",
        "runtime_boundary": {
            "sc2_executed": False,
            "external_llm_called": False,
            "external_corpus_mined": False,
        },
        "normalization": {
            "unicode": "NFKC",
            "case": "casefold/lower for lookup",
            "whitespace": "collapse",
            "underscore_and_hyphen": "normalized to spaces for retrieval only; original code aliases preserved",
            "mistakes": "correction-only and excluded from direct semantic aliases",
        },
        "statistics": {
            "variables": len(alias_records),
            "searchable_terms": sum(len(r["searchable_terms"]) for r in alias_records),
            "normalized_index_terms": len(alias_index),
            "ambiguous_index_terms": collision_count,
            "manual_ambiguity_groups": len(ambiguity_groups),
            "variables_with_colloquial_aliases": sum(bool(r["alias_groups"]["colloquial"]) for r in alias_records),
            "variables_with_abbreviations": sum(bool(r["alias_groups"]["abbreviations"]) for r in alias_records),
            "variables_with_common_mistakes": sum(bool(r["common_mistakes"]) for r in alias_records),
        },
        "ambiguity_policy": {
            "rule": "同一规范化查询词命中多个变量时，必须返回全部候选、层级和澄清问题，不得静默选择。",
            "health_vs_ratio": "绝对health/hp与health_ratio/hp_ratio分别建索引；宽泛血量词进入歧义候选。",
            "nonexistent_concepts": "错误叫法只用于纠正，不自动创建变量ID。",
        },
        "ambiguity_groups": sorted(ambiguity_groups, key=lambda x: x["id"]),
        "records": alias_records,
        "alias_index": alias_index,
    }

    per_variable = []
    for record in records:
        vid = record["id"]
        zh = record["names"]["zh"]
        code = record["names"]["code"]
        per_variable.append({
            "variable_id": vid,
            "preferred_query_terms": unique([zh, code, vid]),
            "patterns": {
                "interface_query": [f"{zh}的接口形式是什么？", f"{code}的数据类型、形状和访问路径是什么？"],
                "physical_meaning_query": [f"{zh}表示什么物理量？", f"{vid}在STORM数据流中的含义和层级是什么？"],
                "source_location_query": [f"{zh}在哪个.py文件中读取或计算？", f"请给出{vid}的源码路径、函数和证据行。"],
                "formula_query": [f"{zh}是怎么计算或转换的？", f"{code}有没有归一化、聚合、阈值或映射公式？"],
                "range_query": [f"{zh}的取值范围和单位是什么？", f"{vid}有哪些枚举、上下界或尚未确认的范围？"],
            },
        })

    patterns_payload = {
        "knowledge_base": "storm-sc2kb-v1-raw",
        "schema_version": "1.0.0",
        "generated_at": DATE,
        "status": "query_patterns_built",
        "runtime_boundary": {
            "external_llm_tested": False,
            "sc2_executed": False,
        },
        "intent_registry": [
            {"id": iid, "name_zh": name, "description": desc}
            for iid, name, desc in INTENTS
        ],
        "routing_rules": [
            {"priority": 1, "condition": "exact stable variable_id", "action": "direct lookup by variable_id"},
            {"priority": 2, "condition": "one normalized alias candidate", "action": "return candidate with evidence and truth boundary"},
            {"priority": 3, "condition": "multiple normalized alias candidates", "action": "return all candidates with taxonomy_source_layer and ask clarification_question"},
            {"priority": 4, "condition": "common mistake only", "action": "show correction; do not invent or silently redirect"},
            {"priority": 5, "condition": "no current variable candidate", "action": "report out_of_scope_or_not_found; do not create a PySC2 field"},
        ],
        "global_templates": {
            "interface_query": ["{term}的接口形式是什么？", "如何从PySC2或STORM中读取{term}？"],
            "physical_meaning_query": ["{term}是什么意思？", "{term}对应什么物理量，属于哪个数据层？"],
            "source_location_query": ["{term}在哪个.py文件实现？", "给出{term}的源码依据和消费者。"],
            "formula_query": ["{term}是如何计算的？", "{term}的转换公式和上游变量是什么？"],
            "range_query": ["{term}的范围、单位和枚举是什么？", "{term}哪些取值已由代码确认，哪些仍需验证？"],
        },
        "required_response_fields": [
            "matched_variable_id", "candidate_variables_if_ambiguous", "taxonomy_source_layer",
            "answer", "evidence_ids", "source_locations", "truth_boundary", "clarification_question_if_needed",
        ],
        "per_variable_patterns": per_variable,
    }

    ALIASES_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    ALIASES_OUT.write_text(yaml.safe_dump(aliases_payload, allow_unicode=True, sort_keys=False, width=120), encoding="utf-8")
    PATTERNS_OUT.write_text(yaml.safe_dump(patterns_payload, allow_unicode=True, sort_keys=False, width=120), encoding="utf-8")
    DOC_OUT.write_text(build_doc(aliases_payload), encoding="utf-8")
    print(yaml.safe_dump(aliases_payload["statistics"], allow_unicode=True, sort_keys=False))


def build_doc(payload: dict[str, Any]) -> str:
    s = payload["statistics"]
    groups = "\n".join(
        f"| `{g['id']}` | {'、'.join(g['surface_forms'])} | {len(g['candidate_variable_ids'])} | {g['clarification_question']} |"
        for g in payload["ambiguity_groups"]
    )
    return f'''# 步骤 07：自然语言别名与查询词典

- 报告日期：{DATE}
- 范围：步骤五和步骤六的135条正式变量
- 状态：静态别名与查询规则已生成；未调用外部LLM、未挖掘外部语料

## 1. 一句话结论

步骤七把研究者可能使用的中文、英文、代码名、缩写、口语和论文表达映射到稳定变量ID；如果一个词可能指向多个层级，检索器必须返回候选和澄清问题，不能擅自选择。

## 2. 正式输出

- `knowledge/retrieval/aliases.yaml`：逐变量别名卡片、歧义组和反向alias_index
- `knowledge/retrieval/query_patterns.yaml`：五类查询意图、路由规则和每变量查询模板
- `knowledge/docs/07_alias_guide.md`：本说明文档

## 3. 数量统计

| 项目 | 数量 |
|---|---:|
| 正式变量 | {s['variables']} |
| 逐变量可检索表达总数 | {s['searchable_terms']} |
| 规范化反向索引词 | {s['normalized_index_terms']} |
| 自动识别的歧义索引词 | {s['ambiguous_index_terms']} |
| 人工高风险歧义组 | {s['manual_ambiguity_groups']} |
| 有口语别名的变量 | {s['variables_with_colloquial_aliases']} |
| 有缩写的变量 | {s['variables_with_abbreviations']} |
| 有错误叫法纠正规则的变量 | {s['variables_with_common_mistakes']} |

## 4. 别名卡片结构

每个变量保留`chinese`、`english`、`code`、`abbreviations`、`colloquial`和`paper_terms`六类安全别名；`common_mistakes`单独保存，采用correction-only策略，不把错误叫法当成已确认的同义词，也不会因此创建新变量。

## 5. 歧义处理规则

1. 稳定变量ID精确匹配时直接检索。
2. 一个规范化别名只命中一个变量时返回该变量及证据。
3. 命中多个变量时返回全部候选、来源层和`clarification_question`。
4. 只命中错误叫法时先纠正，不静默重定向。
5. 没有候选时返回超出范围或未找到，不补造PySC2字段。

### 高风险歧义组

| 组 | 表面词 | 候选数 | 必须追问 |
|---|---|---:|---|
{groups}

## 6. health与health_ratio严格分离

`raw_unit.health`表示当前绝对生命值；`raw_unit.health_ratio`表示归一化比例。宽泛的“血量”“HP”会进入绝对生命值的多层候选，而“生命比例”“health ratio”进入比例候选。知识库不会因为名字相似把绝对值和比例合并成同一个物理量。

```text
“单位当前血量” → raw_unit.health
“单位血量百分比” → raw_unit.health_ratio
“图中单位血量” → abox.unit.hp
“友军平均血量” → derived.tactical.friendly_avg_hp
```

## 7. 五类查询模式

- `interface_query`：接口形式、数据类型、形状、单位和访问路径；
- `physical_meaning_query`：物理含义、数据层和真值边界；
- `source_location_query`：`.py`源码路径、函数、证据行和消费者；
- `formula_query`：上游变量、归一化、聚合、阈值或映射公式；
- `range_query`：范围、枚举、单位以及仍需验证的边界。

`query_patterns.yaml`为135个变量分别生成上述五类模板，合计675个意图槽位，每个槽位提供两种自然语言问法。

## 8. 检索响应建议

Agent回答时至少返回：命中的稳定变量ID、来源层、直接答案、证据ID、源码位置和可信边界。若歧义，则先列候选并提问，不能把TBox类型属性、RawUnit当前观测、ABox实例值和派生战术量混写。

## 9. 典型纠错

- “最大生命值”不能直接映射为`raw_unit.health`，因为当前字段是观测到的当前生命值；
- `tag`是单位实例标识，`unit_type`是单位类型编号；
- `action.delay_steps`不是`pysc2.function.queued`；
- ABox的`armor/armor_ratio`在当前代码中实际接收RawUnit的`shield/shield_ratio`；
- SWM预测状态不是下一时刻环境真值；
- 历史平均分不是当前单episode得分。

## 10. 验证边界

- 未启动StarCraft II；
- 未调用外部LLM测试自然语言命中率；
- 未挖掘搜索日志、论文语料或用户查询语料；
- 所有正式变量ID严格来自步骤五，未添加当前代码不存在的变量；
- 口语和论文表达是检索工程表达，实际召回率需要在后续自动化测试中验证。
'''


if __name__ == "__main__":
    main()
