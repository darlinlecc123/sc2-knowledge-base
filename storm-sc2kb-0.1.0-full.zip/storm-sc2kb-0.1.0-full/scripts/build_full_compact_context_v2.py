from __future__ import annotations
import hashlib, json
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "knowledge/context/variables.jsonl"
OUTPUT = ROOT / "knowledge/context/sc2_raw_api_context_full_compact_v2.jsonl"
MANIFEST = ROOT / "knowledge/context/sc2_raw_api_context_full_compact_v2_manifest.json"
LEGEND = {
    "id": "variable_id", "n": "names", "a": "aliases", "d": "meaning.definition",
    "t": "interface.python_type", "s.k": "interface.shape.kind", "s.d": "interface.shape.dimensions",
    "p.v": "interface.pysc2_path.value", "p.s": "interface.pysc2_path.status",
    "sp": "interface.storm_paths", "loc": "implementation.source_locations",
    "f": "implementation.transformation_formula", "e": "evidence(id/path/symbol)", "l": "limitations",
}

def digest(data: bytes) -> str: return hashlib.sha256(data).hexdigest()

def main() -> None:
    source_bytes = SOURCE.read_bytes()
    rows = [json.loads(x) for x in source_bytes.decode("utf-8").splitlines() if x.strip()]
    out = []
    for r in rows:
        interface = r.get("interface") or {}; shape = interface.get("shape") or {}; path = interface.get("pysc2_path") or {}; impl = r.get("implementation") or {}
        out.append({
            "id": r["variable_id"], "n": r.get("names") or {}, "a": r.get("aliases") or [],
            "d": (r.get("meaning") or {}).get("definition"), "t": interface.get("python_type"),
            "s": {"k": shape.get("kind"), "d": shape.get("dimensions")},
            "p": {"v": path.get("value"), "s": path.get("status")}, "sp": interface.get("storm_paths") or [],
            "loc": [{k: z.get(k) for k in ("path", "symbol", "line_start", "line_end") if z.get(k) is not None} for z in impl.get("source_locations") or []],
            "f": impl.get("transformation_formula") or [],
            "e": [{k: z.get(k) for k in ("id", "path", "symbol") if z.get(k) is not None} for z in r.get("evidence") or []],
            "l": r.get("limitations") or [],
        })
    source_ids = [r["variable_id"] for r in rows]; output_ids = [r["id"] for r in out]
    if len(source_ids) != len(set(source_ids)) or source_ids != output_ids: raise ValueError("变量 ID 唯一性、集合或顺序验证失败")
    header = json.dumps({"format":"full_compact_context_v2","field_legend":LEGEND,"record_count":len(out),"retrieval_used":False,"query_specific_filtering":False,"truncated":False}, ensure_ascii=False, separators=(",", ":"))
    text = header + "\n" + "".join(json.dumps(r, ensure_ascii=False, separators=(",", ":")) + "\n" for r in out)
    output_bytes = text.encode("utf-8"); OUTPUT.write_bytes(output_bytes)
    manifest = {
        "schema_version":"1.0.0", "generated_at":date.today().isoformat(), "condition_label":"full_compact_context_v2",
        "source_file":SOURCE.relative_to(ROOT).as_posix(), "source_sha256":digest(source_bytes),
        "output_file":OUTPUT.relative_to(ROOT).as_posix(), "output_sha256":digest(output_bytes),
        "source_record_count":len(rows), "output_record_count":len(out), "variable_id_coverage":1.0,
        "variable_id_order_preserved":True, "field_legend":LEGEND, "query_specific_filtering":False,
        "retrieval_used":False, "truncated":False,
        "semantic_note":"包含全部变量；对重复结构和字段名做无损语义压缩，不按问题筛选，不等于原始 Markdown 逐字全文。"
    }
    MANIFEST.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(manifest,ensure_ascii=False,indent=2)); print(f"output_bytes={len(output_bytes)}; characters={len(text)}")
if __name__ == "__main__": main()
