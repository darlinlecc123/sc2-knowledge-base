"""生成并冻结 STORM Raw API challenge v0.3；本脚本不导入检索器或问答 Agent。"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
CONTEXT = KB / "context" / "variables.jsonl"
OUTPUT = KB / "evals" / "questions_challenge_v0.3.jsonl"
MANIFEST = KB / "evals" / "challenge_v0.3_manifest.json"
SOURCE_SETS = [
    KB / "evals" / "questions_dev.jsonl",
    KB / "evals" / "questions_test.jsonl",
    KB / "evals" / "questions_generalization_dev_v0.1.jsonl",
    KB / "evals" / "questions_generalization_dev_v0.2.jsonl",
    KB / "evals" / "questions_challenge_v0.1.jsonl",
    KB / "evals" / "questions_challenge_v0.2.jsonl",
]
VERSION = "0.3.0"
GENERATED_AT = "2026-09-04"


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", text.casefold())


def load_records() -> dict[str, dict[str, Any]]:
    return {
        item["variable_id"]: item
        for line in CONTEXT.read_text(encoding="utf-8").splitlines()
        if line.strip()
        for item in [json.loads(line)]
    }


def first_evidence(record: dict[str, Any]) -> dict[str, Any]:
    evidence = (record.get("evidence") or [None])[0]
    if not evidence:
        raise ValueError(f"变量缺少主证据: {record['variable_id']}")
    return {
        "evidence_id": evidence["id"],
        "fact_status": evidence.get("fact_status", "code_reality"),
        "path": evidence["path"],
        "symbol": evidence.get("symbol"),
    }


def build_cases(records: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    # 只依据变量卡设计问题；冻结前后均不导入 SearchEngine/QAAgent。
    specs = [
        ("raw-identity-triple", "逐帧合并单位记录时，要同时判断所属阵营、兵种编号和对象身份，原始观测应联合读取哪三项？", ["raw_unit.alliance", "raw_unit.unit_type", "raw_unit.tag"], "answer", "found", "multi_variable_comparison", "hard"),
        ("raw-survival-four", "若特征工程既保留血盾原值，又保留二者的比例编码，Raw 单位需要输出哪四个生存量？", ["raw_unit.health", "raw_unit.shield", "raw_unit.health_ratio", "raw_unit.shield_ratio"], "answer", "found", "multi_variable_comparison", "hard"),
        ("raw-motion-fire", "我要把单位的平面位置和距离下次开火还要等多久一起送入模型，应取哪三个 Raw 字段？", ["raw_unit.x", "raw_unit.y", "raw_unit.weapon_cooldown"], "answer", "found", "multi_variable_comparison", "hard"),
        ("raw-abox-identity-chain", "从原始单位变成图节点后，阵营与唯一标识在前后两层各叫什么？请给出四个变量。", ["raw_unit.alliance", "raw_unit.tag", "abox.unit.alliance", "abox.unit.tag"], "answer", "found", "lineage", "hard"),
        ("health-three-sources", "论文中要区分观测血量、实例节点血量和静态类型生命基准，这三个层级分别是哪一变量？", ["raw_unit.health", "abox.unit.hp", "tbox.entity.hp"], "answer", "found", "lineage", "hard"),
        ("shield-armor-mismatch", "图中名为 armor 的运行时属性并非静态护甲；请给出它实际接收的 Raw 量和目标 ABox 量。", ["raw_unit.shield", "abox.unit.armor"], "answer", "found", "known_issue_trap", "hard"),
        ("tbox-offense-bundle", "做静态火力表时，需要单次伤害、攻击周期、每秒输出和射程四列，对应哪些 TBox 字段？", ["tbox.entity.attack_damage", "tbox.entity.attack_speed", "tbox.entity.dps", "tbox.entity.attack_range"], "answer", "found", "multi_variable_comparison", "hard"),
        ("tbox-mobility-perception", "静态单位画像里，移动快慢、可见范围和攻击距离应该分别查什么？", ["tbox.entity.movement_speed", "tbox.entity.sight", "tbox.entity.attack_range"], "answer", "found", "multi_variable_comparison", "medium"),
        ("tbox-production-bundle", "估算生产代价时，矿、气、人口和建造耗时要分开记录，请列出四个静态属性。", ["tbox.entity.mineral_cost", "tbox.entity.gas_cost", "tbox.entity.supply_cost", "tbox.entity.build_time"], "answer", "found", "multi_variable_comparison", "hard"),
        ("tbox-description-classes", "TBox 实体卡片中，文字说明、节点类型、实体大类和资源细类分别由什么字段承载？", ["tbox.entity.description", "tbox.entity.node_type", "tbox.entity.category", "tbox.entity.resource_type"], "answer", "found", "multi_variable_comparison", "hard"),
        ("abox-descriptor-bundle", "查看一个实例节点时，我要它的种族、单位类别、节点类别和说明文本，对应哪四个 ABox 属性？", ["abox.unit.race", "abox.unit.unit_class", "abox.unit.node_type", "abox.unit.description"], "answer", "found", "multi_variable_comparison", "hard"),
        ("abox-combat-bundle", "实例图保存的攻击伤害、攻击距离、攻击速度和移动速度分别是什么变量？", ["abox.unit.attack_damage", "abox.unit.attack_range", "abox.unit.attack_speed", "abox.unit.movement_speed"], "answer", "found", "multi_variable_comparison", "medium"),
        ("abox-edge-identity", "一条图关系若要说明起点、终点、边类别和具体边型，需读取哪四个关系字段？", ["abox.relation.source_node", "abox.relation.target_node", "abox.relation.edge_class", "abox.relation.edge_type"], "answer", "found", "interface", "hard"),
        ("abox-edge-explanation", "关系边的有效程度与建立该关系的解释理由，分别存在哪两个字段？", ["abox.relation.effectiveness", "abox.relation.reason"], "answer", "found", "interface", "medium"),
        ("abox-graph-counters", "BattlefieldGraph 的图级状态里，当前步编号和敌方实例总数分别叫什么？", ["abox.graph.step_count", "abox.graph.enemy_count"], "answer", "found", "multi_variable_comparison", "medium"),
        ("tactical-side-counts", "战术摘要比较双方规模时，我方单位数与敌方单位数分别是哪两个派生量？", ["derived.tactical.friendly_count", "derived.tactical.enemy_count"], "answer", "found", "multi_variable_comparison", "medium"),
        ("tactical-spatial-triple", "描述双方空间态势时，需要我方质心、敌方质心以及两阵中心间隔，三个量分别是什么？", ["derived.tactical.friendly_centroid", "derived.tactical.enemy_centroid", "derived.tactical.formation_distance"], "answer", "found", "multi_variable_comparison", "hard"),
        ("tactical-fire-pair", "摘要里既有可以立即开火的单位数量，也有整体火力就绪程度，这两个派生结果叫什么？", ["derived.tactical.ready_to_fire_count", "derived.tactical.fire_readiness"], "answer", "found", "multi_variable_comparison", "medium"),
        ("tactical-health-triple", "评估双方生存态势时，要报告友军平均生命、敌军平均生命和总体健康等级，应选哪三项？", ["derived.tactical.friendly_avg_hp", "derived.tactical.enemy_avg_hp", "derived.tactical.health_status"], "answer", "found", "multi_variable_comparison", "hard"),
        ("action-decision-metadata", "一项模型决策除动作主类和子类外，还带优先级及推理说明，这四项 Schema 字段是什么？", ["action.type", "action.subtype", "action.priority", "action.reasoning"], "answer", "found", "interface", "hard"),
        ("action-target-contract-v3", "动作契约如何分别表示执行单位集合、目标解释方式和目标数据？请列出三个字段。", ["action.units", "action.target_type", "action.target"], "answer", "found", "interface", "hard"),
        ("action-queue-bundle", "主计划进入延时调度后，需要区分计划对象、队列内动作集合和每项等待步数，分别是什么？", ["action.plan", "action.planned_actions", "action.delay_steps"], "answer", "found", "lineage", "hard"),
        ("invalid-action-bundle", "解析器拒绝动作时，保存失败条目与按原因聚合的计数字典分别对应哪两个量？", ["action.invalid_actions", "action.invalid_reason_counts"], "answer", "found", "multi_variable_comparison", "medium"),
        ("environment-raw-contract", "创建 SC2Env 的 Raw 接口时，Raw 单位开关、Raw 动作开关、Raw 分辨率和地图名分别是哪四项配置？", ["environment.use_raw_units", "environment.use_raw_actions", "environment.raw_resolution", "environment.map_name"], "answer", "found", "interface", "hard"),
        ("environment-clock-display", "环境运行节奏与显示方式由步长倍率、实时模式和可视化开关共同控制，对应哪些配置？", ["environment.step_mul", "environment.realtime", "environment.visualize"], "answer", "found", "multi_variable_comparison", "medium"),
        ("player-economy", "玩家状态中当前晶体矿和高能瓦斯分别通过哪两个量读取？", ["player.minerals", "player.vespene"], "answer", "found", "multi_variable_comparison", "medium"),
        ("player-supply-triple", "人口面板的已占用、容量上限与尚可使用数量分别映射到哪三个 player 变量？", ["player.food_used", "player.food_cap", "player.supply_remaining"], "answer", "found", "formula", "hard"),
        ("timestep-result-triple", "每次 TimeStep 若要同时判断终局、本步奖励变化和累计分数，应检查哪三个量？", ["timestep.is_last", "timestep.reward_delta", "timestep.score_cumulative_0"], "answer", "found", "multi_variable_comparison", "hard"),
        ("functioncall-common-payload", "构造 Raw FunctionCall 时，函数编号之外还要提供排队标志、Raw 标志、单位 tag 列表和目标，请列出四个通用参数。", ["pysc2.function.queued", "pysc2.function.raw_flag", "pysc2.function.unit_tags", "pysc2.function.target"], "answer", "found", "interface", "hard"),
        ("function-id-family", "执行器对 NO_OP、MOVE、ATTACK、BUILD 和 TRAIN 分别使用哪个 Function ID 变量？", ["pysc2.no_op.function_id", "pysc2.move.function_id", "pysc2.attack.function_id", "pysc2.build.function_id", "pysc2.train.function_id"], "answer", "found", "interface", "hard"),
        ("swm-input-control", "SWM 一次候选预测需要 ABox 状态、候选动作、预测步数和候选序号，四项输入或控制量是什么？", ["swm.input.abox_state", "swm.input.planned_actions", "swm.prediction_steps", "swm.candidate_index"], "answer", "found", "multi_variable_comparison", "hard"),
        ("swm-result-envelope", "世界模型结果包中，完整预测集合、单步编号、解析前原文和 token 用量分别存在哪里？", ["swm.predictions", "swm.prediction.step", "swm.raw_response", "swm.token_usage"], "answer", "found", "multi_variable_comparison", "hard"),
        ("swm-quality-bundle", "评估世界模型时，要联合观察生命 RMSE、位置 RMSE、关系准确率和总体误差，应报告哪四个指标？", ["metric.swm.health_rmse", "metric.swm.position_rmse", "metric.swm.relation_accuracy", "metric.swm.overall_error"], "answer", "found", "multi_variable_comparison", "hard"),
        ("llm-usage-bundle", "统计决策模型开销时，需要调用次数、平均决策耗时、平均每次 token、输入 token 与输出 token，分别是什么指标？", ["metric.llm.decision_calls", "metric.llm.avg_decision_time", "metric.llm.avg_tokens_per_decision", "metric.llm.prompt_tokens", "metric.llm.completion_tokens"], "answer", "found", "multi_variable_comparison", "hard"),
        ("experiment-outcome-bundle", "实验汇总要同时查看单回合最终分数、多回合平均分和三类动作失败率，请列出五项指标。", ["metric.episode.final_score", "metric.experiment.avg_score", "metric.action.failure_rate", "metric.action.delayed_failure_rate", "metric.action.decision_failure_rate"], "answer", "found", "multi_variable_comparison", "hard"),
        ("ambiguous-hp-v3", "研究笔记只写了 hp，既没注明来自观测、实例图还是静态类型表；应保留哪三个候选并要求澄清？", ["raw_unit.health", "abox.unit.hp", "tbox.entity.hp"], "clarify", "ambiguous", "ambiguous", "hard"),
        ("ambiguous-alliance-v3", "接口说明只出现 alliance，没有指出是 RawUnit 数组还是 ABox 节点属性；应列出哪些候选？", ["raw_unit.alliance", "abox.unit.alliance"], "clarify", "ambiguous", "ambiguous", "medium"),
        ("ambiguous-range-v3", "别人只说 attack_range，却没有交代是静态本体属性还是运行时实例属性，知识库应该如何保留两个可能量？", ["tbox.entity.attack_range", "abox.unit.attack_range"], "clarify", "ambiguous", "ambiguous", "medium"),
        ("out-camera-zoom", "请返回 feature-layer 摄像机当前缩放比例；若 Raw 主路径未提供就不要猜。", [], "refuse", "not_found", "out_of_scope", "medium"),
        ("out-unit-energy", "我需要单位当前能量值与能量上限；若当前 V0.1 没有正式卡片，请明确说明范围外。", [], "refuse", "not_found", "out_of_scope", "medium"),
        ("out-minimap-visibility", "查询 feature screen 小地图像素的可见性掩码，当前 Raw API 知识库能否回答？", [], "refuse", "not_found", "out_of_scope", "medium"),
    ]
    cases: list[dict[str, Any]] = []
    for index, (slug, question, variable_ids, behavior, status, question_type, difficulty) in enumerate(specs, 1):
        missing = set(variable_ids) - records.keys()
        if missing:
            raise KeyError(f"{slug} 引用不存在变量: {sorted(missing)}")
        evidence = [first_evidence(records[variable_id]) for variable_id in variable_ids]
        refs = [records[variable_id].get("record_ref") for variable_id in variable_ids]
        if not variable_ids:
            evidence = [{"evidence_id": "scope-v0.1-manifest", "fact_status": "design_intent", "path": "knowledge/manifests/scope.yaml", "symbol": "scope.in_scope_rule"}]
            refs = []
        cases.append({
            "id": f"challenge.v0.3.{index:03d}.{slug}",
            "benchmark_version": VERSION,
            "split": "challenge_v0.3",
            "category": "generalization_challenge",
            "question": question,
            "language": "zh",
            "question_type": question_type,
            "difficulty": difficulty,
            "expected_behavior": behavior,
            "expected_status": status,
            "clarification_required": behavior == "clarify",
            "expected_variable_ids": sorted(variable_ids),
            "required_facts": [],
            "required_evidence": evidence,
            "forbidden_claims": ["声称执行了本题未记录的 SC2 运行时或外部模型测试", "使用知识库外常识补齐缺失变量"],
            "source_record_refs": [ref for ref in refs if ref],
            "variable_categories": sorted({records[x]["category"] for x in variable_ids}),
            "intents": ["third_frozen_challenge", "compositional_generalization"],
            "generated_at": GENERATED_AT,
            "notes": "v0.3 已在首次评测前冻结；首次测试前禁止调用检索器预跑，首次测试后不得改写本题集。",
        })
    return cases


def source_norms() -> set[str]:
    return {
        norm(item["question"])
        for path in SOURCE_SETS
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
        for item in [json.loads(line)]
    }


def render(cases: list[dict[str, Any]]) -> bytes:
    return "".join(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n" for item in cases).encode("utf-8")


def build_manifest(payload: bytes, cases: list[dict[str, Any]], overlaps: int) -> dict[str, Any]:
    return {
        "challenge_version": VERSION,
        "created_at": GENERATED_AT,
        "question_file": "knowledge/evals/questions_challenge_v0.3.jsonl",
        "sha256": hashlib.sha256(payload).hexdigest(),
        "case_count": len(cases),
        "frozen_before_first_evaluation": True,
        "first_evaluation_status": "not_run_at_freeze_time",
        "tuning_policy": "v0.3 首次评测前禁止预跑；首次评测后禁止修改题集及清单。",
        "normalized_overlap_with_all_prior_sets": overlaps,
        "prior_sets": [str(path.relative_to(ROOT)).replace("\\", "/") for path in SOURCE_SETS],
        "difficulty": dict(sorted(Counter(x["difficulty"] for x in cases).items())),
        "question_type": dict(sorted(Counter(x["question_type"] for x in cases).items())),
        "expected_behavior": dict(sorted(Counter(x["expected_behavior"] for x in cases).items())),
        "retrieval_imported_or_called_during_generation": False,
        "external_model_test": "未执行",
        "sc2_runtime": "未执行",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    cases = build_cases(load_records())
    overlaps = sum(norm(case["question"]) in source_norms() for case in cases)
    if overlaps:
        raise ValueError(f"v0.3 与既有题集存在 {overlaps} 道规范化文本重合")
    payload = render(cases)
    manifest = build_manifest(payload, cases, overlaps)
    manifest_text = json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.check:
        ok = OUTPUT.exists() and MANIFEST.exists() and OUTPUT.read_bytes() == payload and MANIFEST.read_text(encoding="utf-8") == manifest_text
        print("PASS" if ok else "FAIL")
        return 0 if ok else 1
    if OUTPUT.exists() or MANIFEST.exists():
        raise FileExistsError("challenge v0.3 已存在；冻结集禁止覆盖，请使用 --check")
    OUTPUT.write_bytes(payload)
    MANIFEST.write_text(manifest_text, encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
