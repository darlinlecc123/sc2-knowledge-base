"""生成并冻结不参与调参的 STORM Raw API challenge v0.2；本脚本不导入检索器。"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
CONTEXT = KB / "context" / "variables.jsonl"
OUTPUT = KB / "evals" / "questions_challenge_v0.2.jsonl"
MANIFEST = KB / "evals" / "challenge_v0.2_manifest.json"
SOURCE_SETS = [
    KB / "evals" / "questions_dev.jsonl",
    KB / "evals" / "questions_test.jsonl",
    KB / "evals" / "questions_challenge_v0.1.jsonl",
    KB / "evals" / "questions_generalization_dev_v0.1.jsonl",
]
VERSION = "0.2.0"
GENERATED_AT = "2026-09-04"


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", text.casefold())


def load_records() -> dict[str, dict[str, Any]]:
    return {r["variable_id"]: r for line in CONTEXT.read_text(encoding="utf-8").splitlines() if line.strip() for r in [json.loads(line)]}


def first_evidence(record: dict[str, Any]) -> dict[str, Any]:
    item = (record.get("evidence") or [None])[0]
    if not item:
        raise ValueError(f"变量缺少主证据: {record['variable_id']}")
    return {"evidence_id": item["id"], "fact_status": item.get("fact_status", "code_reality"), "path": item["path"], "symbol": item.get("symbol")}


def build_cases(records: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    # 全部题目只依据变量卡和关系设计；冻结前不得调用 SearchEngine/QAAgent。
    specs = [
        ("two-identities", "做单位去重时，我既要知道它属于哪种兵，也要知道它是哪一个具体对象，应联合取哪两个 Raw 字段？", ["raw_unit.unit_type", "raw_unit.tag"], "answer", "found", "multi_variable_comparison", "hard"),
        ("side-and-object", "我要从原始单位表中锁定某一方的某个独立单位，阵营码和实例标识分别是什么变量？", ["raw_unit.alliance", "raw_unit.tag"], "answer", "found", "multi_variable_comparison", "hard"),
        ("normalized-survival", "若模型只接收零到一附近的生存状态，而非血条原数值，生命与护盾应选哪两个归一量？", ["raw_unit.health_ratio", "raw_unit.shield_ratio"], "answer", "found", "formula", "hard"),
        ("health-value-vs-ratio", "同一个 Raw 单位的现有生命点数与生命占比不是一回事，请把两者的变量都列出。", ["raw_unit.health", "raw_unit.health_ratio"], "answer", "found", "multi_variable_comparison", "medium"),
        ("raw-to-node-location", "从观测数组的两个平面分量一路追到图实例的位置属性，这条位置链涉及哪三个变量？", ["raw_unit.x", "raw_unit.y", "abox.unit.position"], "answer", "found", "lineage", "hard"),
        ("cooldown-stored-node", "武器再次可用前的等待量从 RawUnit 写入 ABox 后，源字段和节点字段各叫什么？", ["raw_unit.weapon_cooldown", "abox.unit.weapon_cooldown"], "answer", "found", "lineage", "hard"),
        ("type-id-three-layers", "单位类型数字从原始观测进入实例图，并与静态本体类型对应时，三个层级分别用什么变量？", ["raw_unit.unit_type", "abox.unit.unit_type_id", "tbox.entity.unit_type_id"], "answer", "found", "lineage", "hard"),
        ("unknown-static-live-hp", "未知类型采用静态默认值时，哪个标记说明发生回退？同时哪两个量分别表示 ABox 实时生命和 TBox 静态生命？", ["abox.unit.is_unknown", "abox.unit.hp", "tbox.entity.hp"], "answer", "found", "known_issue_trap", "hard"),
        ("armor-ratio-source", "当前图节点的 armor_ratio 若实际承接护盾比例，请同时找出目标属性与 Raw 来源比例字段。", ["abox.unit.armor_ratio", "raw_unit.shield_ratio"], "answer", "found", "known_issue_trap", "hard"),
        ("enemy-count-two-levels", "图对象记录的敌方节点数和战术摘要重新汇总的敌军数量分别对应什么变量？", ["abox.graph.enemy_count", "derived.tactical.enemy_count"], "answer", "found", "multi_variable_comparison", "hard"),
        ("range-and-vision", "静态单位卡里，攻击能打多远与能看多远是两个属性，请分别指出。", ["tbox.entity.attack_range", "tbox.entity.sight"], "answer", "found", "multi_variable_comparison", "medium"),
        ("speed-and-dps", "论文表格要同时报告静态攻击频率和每秒伤害，应从 TBox 取哪两个字段？", ["tbox.entity.attack_speed", "tbox.entity.dps"], "answer", "found", "multi_variable_comparison", "medium"),
        ("three-costs", "评估一个单位的生产负担时，要把矿、气和人口占用拆开，三个静态成本变量是什么？", ["tbox.entity.mineral_cost", "tbox.entity.gas_cost", "tbox.entity.supply_cost"], "answer", "found", "multi_variable_comparison", "hard"),
        ("resource-classification", "静态本体怎样区分资源的具体种类以及实体所属大类？请返回两个分类属性。", ["tbox.entity.resource_type", "tbox.entity.category"], "answer", "found", "multi_variable_comparison", "medium"),
        ("both-side-average-hp", "想比较双方队伍的平均生命水平，战术摘要里友军和敌军各用哪个聚合量？", ["derived.tactical.friendly_avg_hp", "derived.tactical.enemy_avg_hp"], "answer", "found", "multi_variable_comparison", "medium"),
        ("formation-and-engagement", "判断两军是否接战时，摘要中哪个量描述队形间距，哪个量给出交战类型？", ["derived.tactical.formation_distance", "derived.tactical.engagement_type"], "answer", "found", "multi_variable_comparison", "hard"),
        ("health-label-and-list", "战术提示既有总体健康标签，也会列出危险单位；这两个输出变量分别是什么？", ["derived.tactical.health_status", "derived.tactical.critical_units"], "answer", "found", "multi_variable_comparison", "medium"),
        ("plan-representations", "主动作计划对象与延迟队列里保存的计划动作集合在知识库中是同一个变量吗？请列出两者。", ["action.plan", "action.planned_actions"], "answer", "found", "multi_variable_comparison", "hard"),
        ("action-kind-subkind", "BUILD 或 TRAIN 的顶层动作类别与更具体的建造训练子类，分别落在哪两个字段？", ["action.type", "action.subtype"], "answer", "found", "multi_variable_comparison", "medium"),
        ("selection-target-contract", "一条动作要说明由谁执行、目标按位置还是单位解释、以及目标值本身，分别是哪三个 Schema 字段？", ["action.units", "action.target_type", "action.target"], "answer", "found", "multi_variable_comparison", "hard"),
        ("invalid-action-accounting", "无效动作既保留明细又按失败原因计数，这两个统计载体叫什么？", ["action.invalid_actions", "action.invalid_reason_counts"], "answer", "found", "multi_variable_comparison", "medium"),
        ("three-time-controls", "从环境步长倍率到决策间隔，再到单条动作延迟次数，时间控制链上的三个变量是什么？", ["environment.step_mul", "environment.decision_interval", "action.delay_steps"], "answer", "found", "lineage", "hard"),
        ("functioncall-payload", "动作执行对象列表和目标在转换成 PySC2 调用后，分别装入 FunctionCall 的哪两个参数？", ["pysc2.function.unit_tags", "pysc2.function.target"], "answer", "found", "interface", "medium"),
        ("production-function-ids", "执行器为建造和训练分别选择哪个 PySC2 函数编号变量？", ["pysc2.build.function_id", "pysc2.train.function_id"], "answer", "found", "interface", "medium"),
        ("supply-equation", "若要由人口上限减去已使用人口得到剩余人口，公式两端涉及哪三个 player 量？", ["player.food_cap", "player.food_used", "player.supply_remaining"], "answer", "found", "formula", "hard"),
        ("score-increment", "累计分数与相邻观测的得分增量分别保存在哪里？", ["timestep.score_cumulative_0", "timestep.reward_delta"], "answer", "found", "multi_variable_comparison", "medium"),
        ("token-accounting", "一次模型调用的输入、输出和合计 token 三个计数分别是什么指标？", ["metric.llm.prompt_tokens", "metric.llm.completion_tokens", "metric.llm.total_tokens"], "answer", "found", "multi_variable_comparison", "medium"),
        ("failure-rate-family", "总体动作失败、延迟动作失败和决策阶段失败需要分开看，对应哪三个实验指标？", ["metric.action.failure_rate", "metric.action.delayed_failure_rate", "metric.action.decision_failure_rate"], "answer", "found", "multi_variable_comparison", "hard"),
        ("swm-two-inputs", "世界模型作预测前同时接收当前 ABox 快照和计划动作，这两项输入变量是什么？", ["swm.input.abox_state", "swm.input.planned_actions"], "answer", "found", "multi_variable_comparison", "medium"),
        ("swm-output-bundle", "SWM 返回的整组预测中，单位未来状态、未来关系和置信度分别对应哪些变量？", ["swm.predicted_unit_states", "swm.predicted_relations", "swm.confidence"], "answer", "found", "multi_variable_comparison", "hard"),
        ("delta-error-pairs", "世界模型对生命和位置给出变化量，评估时又各有 RMSE；请列出两组预测量与误差量。", ["swm.unit.health_delta", "swm.unit.position_delta", "metric.swm.health_rmse", "metric.swm.position_rmse"], "answer", "found", "multi_variable_comparison", "hard"),
        ("armor-no-layer", "只说 armor 而没有说明是静态本体还是运行时实例，我应该在两个候选之间如何确认？", ["tbox.entity.armor", "abox.unit.armor"], "clarify", "ambiguous", "ambiguous", "medium"),
        ("tag-no-layer", "有人只写 tag，却没交代来自观测数组还是图节点；知识库应保留哪些可能项？", ["raw_unit.tag", "abox.unit.tag"], "clarify", "ambiguous", "ambiguous", "medium"),
        ("out-buff-duration", "请查询单位增益效果还剩多少秒；如果 V0.1 主路径没读取这个量就明确拒答。", [], "refuse", "not_found", "out_of_scope", "medium"),
        ("out-camera-world", "我要 RGB/feature-layer 镜头的世界坐标，当前 Raw API 知识库是否有正式变量？", [], "refuse", "not_found", "out_of_scope", "medium"),
    ]
    cases = []
    for index, (slug, question, variable_ids, behavior, status, qtype, difficulty) in enumerate(specs, 1):
        evidences, refs, categories = [], [], []
        for variable_id in variable_ids:
            record = records[variable_id]
            evidences.append(first_evidence(record))
            refs.append(record.get("record_ref", f"knowledge/context/variables.jsonl#variable_id={variable_id}"))
            categories.append(record.get("category"))
        if not variable_ids:
            evidences = [{"evidence_id": "scope-v0.1-manifest", "fact_status": "design_intent", "path": "knowledge/manifests/scope.yaml", "symbol": "scope.in_scope_rule"}]
        cases.append({
            "benchmark_version": VERSION,
            "category": "generalization_challenge",
            "clarification_required": behavior == "clarify",
            "difficulty": difficulty,
            "expected_behavior": behavior,
            "expected_status": status,
            "expected_variable_ids": variable_ids,
            "forbidden_claims": ["声称执行了本题未记录的 SC2 运行时或外部模型测试", "使用知识库外常识补齐缺失变量"],
            "generated_at": GENERATED_AT,
            "id": f"challenge.v0.2.{index:03d}.{slug}",
            "intents": ["second_frozen_challenge", "retrieval_generalization"],
            "language": "zh",
            "notes": "v0.2 冻结后首次运行；本轮不得依据结果修改检索器或题集。",
            "question": question,
            "question_type": qtype,
            "required_evidence": evidences,
            "required_facts": [],
            "source_record_refs": refs,
            "split": "challenge_v0.2",
            "variable_categories": sorted({x for x in categories if x}),
        })
    return cases


def render(cases: list[dict[str, Any]]) -> bytes:
    return "".join(json.dumps(case, ensure_ascii=False, sort_keys=True) + "\n" for case in cases).encode("utf-8")


def source_norms() -> set[str]:
    return {norm(q["question"]) for source in SOURCE_SETS for line in source.read_text(encoding="utf-8").splitlines() if line.strip() for q in [json.loads(line)]}


def build_manifest(payload: bytes, cases: list[dict[str, Any]], overlaps: int) -> dict[str, Any]:
    return {
        "challenge_version": VERSION,
        "created_at": GENERATED_AT,
        "frozen_before_first_evaluation": True,
        "first_evaluation_status": "not_run_at_freeze_time",
        "tuning_policy": "v0.2 首次评测后本轮禁止依据结果修改检索器或题集；失败项原样记录。",
        "question_file": "knowledge/evals/questions_challenge_v0.2.jsonl",
        "sha256": hashlib.sha256(payload).hexdigest(),
        "case_count": len(cases),
        "normalized_overlap_with_all_prior_sets": overlaps,
        "prior_sets": [str(p.relative_to(ROOT)).replace("\\", "/") for p in SOURCE_SETS],
        "difficulty": dict(sorted(Counter(x["difficulty"] for x in cases).items())),
        "question_type": dict(sorted(Counter(x["question_type"] for x in cases).items())),
        "expected_behavior": dict(sorted(Counter(x["expected_behavior"] for x in cases).items())),
        "retrieval_imported_or_called_during_generation": False,
        "external_model_test": "未执行",
        "sc2_runtime": "未执行",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    cases = build_cases(load_records())
    prior = source_norms()
    overlaps = sum(norm(case["question"]) in prior for case in cases)
    payload = render(cases)
    manifest = build_manifest(payload, cases, overlaps)
    manifest_text = json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.check:
        ok = OUTPUT.exists() and MANIFEST.exists() and OUTPUT.read_bytes() == payload and MANIFEST.read_text(encoding="utf-8") == manifest_text
        print("PASS" if ok else "FAIL")
        return 0 if ok else 1
    if OUTPUT.exists() or MANIFEST.exists():
        raise FileExistsError("challenge v0.2 已存在；冻结集禁止覆盖，请使用 --check")
    OUTPUT.write_bytes(payload)
    MANIFEST.write_text(manifest_text, encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
