from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[2]
K = ROOT / "knowledge"
V = K / "variables"
OUT = K / "lineage" / "variable_lineage.yaml"
DOC = K / "docs" / "06_provenance_and_lifecycle.md"
DATE = "2026-09-03"
FILES = ["raw_api", "tbox", "abox", "derived", "actions", "swm", "metrics"]
LAYER_MAP = {
    "environment_config": "environment_config",
    "pysc2_timestep": "raw_observation",
    "pysc2_raw_observation": "raw_observation",
    "raw_unit_transformed": "raw_observation",
    "tbox_static": "static_ontology",
    "abox_runtime": "runtime_abox",
    "derived_runtime": "derived_runtime",
    "llm_output": "llm_output",
    "validated_action": "parser_validated",
    "executor_mapping": "executor_mapped",
    "swm_prediction": "model_predicted",
    "experiment_aggregate": "experiment_aggregated",
}
DELAY_FIELDS = {
    "action.delay_steps", "action.planned_actions", "action.priority", "action.subtype",
    "action.target", "action.target_type", "action.type", "action.units",
}


def load_records():
    rows, counts = [], {}
    for name in FILES:
        data = yaml.safe_load((V / f"{name}.yaml").read_text(encoding="utf-8"))
        counts[name] = len(data["records"])
        rows.extend(data["records"])
    return sorted(rows, key=lambda x: x["id"]), counts


def classify_value(record: dict[str, Any]) -> str:
    vid = record["id"]
    layer = record["provenance"]["source_layer"]
    if vid in {"timestep.reward_delta", "abox.graph.step_count"}:
        return "cross_frame_state"
    return {
        "environment_config": "configuration",
        "pysc2_timestep": "observation_value",
        "pysc2_raw_observation": "observation_value",
        "raw_unit_transformed": "observation_value",
        "tbox_static": "static_knowledge",
        "abox_runtime": "runtime_abox_state",
        "derived_runtime": "runtime_derived",
        "llm_output": "llm_generated",
        "validated_action": "parser_validated",
        "executor_mapping": "executor_mapped",
        "swm_prediction": "model_predicted",
        "experiment_aggregate": "experiment_aggregated",
    }[layer]


def lifecycle(record: dict[str, Any]) -> dict[str, str]:
    vid = record["id"]
    layer = record["provenance"]["source_layer"]
    if layer == "environment_config":
        result = dict(
            scope="application_or_agent_instance",
            refresh_trigger="entrypoint or component initialization",
            refresh_granularity="initialization",
            persistence="初始化后持续到相关环境或组件被重新创建或重新配置。",
            reset_boundary="通常不因RawAgent.reset自动刷新；是否重建取决于外层入口。",
            update_timing="在SC2Env、RawAgent或SWMPredictor初始化并读取参数时确定。",
            game_loop_relation="配置影响环境步进或决策，但自身不是game loop观测值。",
            delay_revalidation="not_applicable",
            training_stage="not_applicable",
        )
    elif layer == "tbox_static":
        result = dict(
            scope="repository_and_loaded_ontology",
            refresh_trigger="ontology source edit, graph rebuild, or loader initialization",
            refresh_granularity="ontology_build_or_load",
            persistence="作为仓库静态定义或已加载本体持续存在。",
            reset_boundary="不随observation、decision step或episode自动刷新。",
            update_timing="修改marine_ontology.py并重建缓存，或OntologyLoader加载本体时变化。",
            game_loop_relation="与game loop无直接刷新关系。",
            delay_revalidation="not_applicable",
            training_stage="not_applicable",
        )
    elif layer in {"pysc2_timestep", "pysc2_raw_observation", "raw_unit_transformed"}:
        result = dict(
            scope="agent_observation",
            refresh_trigger="RawAgent.step receives a new PySC2 TimeStep",
            refresh_granularity="per_agent_observation",
            persistence="仅代表当前Agent可见观测；下一次观测重新读取或覆盖。",
            reset_boundary="episode结束后旧快照不应作为新episode当前值。",
            update_timing="每次RawAgent.step收到新TimeStep时读取；RawUnit转换紧邻本次读取完成。",
            game_loop_relation="一次Agent观测可能跨越step_mul个SC2 game loops，不能解释为逐game-loop刷新。",
            delay_revalidation="not_applicable",
            training_stage="not_applicable",
        )
    elif layer == "abox_runtime":
        result = dict(
            scope="battlefield_graph_runtime",
            refresh_trigger="BattlefieldGraph.update_from_observation",
            refresh_granularity="per_agent_observation",
            persistence="图对象跨观测保留；节点被更新，新单位创建，消失单位删除。",
            reset_boundary="RawAgent.reset未显式重建BattlefieldGraph；新episode首帧会对齐节点，但图级计数可能延续。",
            update_timing="通常在每次观测解析后由update_from_observation更新。",
            game_loop_relation="随Agent观测更新，不保证覆盖step_mul跨过的中间game loops。",
            delay_revalidation="not_applicable",
            training_stage="not_applicable",
        )
        if vid == "abox.graph.enemy_count":
            result.update(scope="decision_summary_state", refresh_trigger="BattlefieldGraph.generate_tactical_summary", refresh_granularity="per_decision_summary", update_timing="仅在生成战术摘要时重新统计并写入。")
        elif vid == "abox.graph.step_count":
            result.update(scope="cross_observation_counter", persistence="每次图更新自增并跨观测保留。", update_timing="每次update_from_observation入口执行step_count += 1。")
        elif vid == "swm.input.abox_state":
            result.update(scope="decision_prediction_snapshot", refresh_trigger="SWMPredictor.predict", refresh_granularity="per_swm_prediction_call", persistence="作为该次SWM调用的ABox序列化快照。", update_timing="决策阶段序列化ABox后、发起SWM预测前捕获。", training_stage="可作为TrajectoryCollector的state_t，在下一状态到达后写入轨迹。")
    elif layer == "derived_runtime":
        result = dict(
            scope="decision_or_observation_derived_value",
            refresh_trigger="explicit formula evaluation",
            refresh_granularity="per_decision_summary",
            persistence="只对应本次计算所使用的输入快照。",
            reset_boundary="随输入快照失效；新episode不得沿用旧派生值。",
            update_timing="生成战术摘要或执行对应运行时公式时重新计算。",
            game_loop_relation="从Agent可见观测派生，不是引擎逐game-loop真值。",
            delay_revalidation="not_applicable",
            training_stage="not_applicable",
        )
        if vid == "timestep.reward_delta":
            result.update(scope="cross_observation_delta", refresh_trigger="RawAgent.step score update", refresh_granularity="per_agent_observation", persistence="保存本次score与previous_score之差，依赖上一观测。", reset_boundary="per_episode", update_timing="每次step读取score_cumulative后与上一观测分数相减。")
        elif vid == "player.supply_remaining":
            result.update(scope="decision_summary_value", refresh_trigger="BattlefieldGraph.generate_tactical_summary", update_timing="生成战术摘要时由food_cap-food_used计算。")
        elif vid == "metric.llm.avg_decision_time":
            result.update(scope="episode_cumulative_metric", refresh_trigger="LLM decision completion", refresh_granularity="per_llm_decision", persistence="当前episode内累计，RawAgent.reset时清零。", reset_boundary="per_episode", update_timing="每次LLM决策完成后由累计耗时除以决策次数更新。", training_stage="可由实验脚本进一步汇总；不是训练参数。")
    elif layer == "llm_output":
        result = dict(
            scope="llm_response",
            refresh_trigger="LLM response received and parsed",
            refresh_granularity="per_llm_call_or_retry",
            persistence="当前响应或解析结果中的决策局部值，后续响应可替换。",
            reset_boundary="decision-local；决策历史只保留摘要，不等于原字段对象。",
            update_timing="每次主决策LLM或SWM模型返回响应时产生。",
            game_loop_relation="模型调用发生在Agent决策点，不随每个game loop刷新。",
            delay_revalidation="该字段本身不进入延迟动作重验证。",
            training_stage="not_applicable",
        )
        if vid == "swm.raw_response":
            result.update(scope="swm_model_response", refresh_trigger="SWMPredictor.predict model request", refresh_granularity="per_swm_prediction_call", update_timing="每次SWM模型调用返回后写入预测结果。", training_stage="可随prediction写入轨迹；本步骤未实际调用模型。")
    elif layer == "validated_action":
        result = dict(
            scope="validated_decision_action",
            refresh_trigger="ResponseParser.parse and schema validation",
            refresh_granularity="per_successful_parse",
            persistence="立即动作持续到本次执行；延迟动作可保存到pending_actions的计划步。",
            reset_boundary="RawAgent.reset清空pending_actions。",
            update_timing="LLM响应解析成功并经过ResponseParser规则时产生、补默认值或修正。",
            game_loop_relation="按Agent step调度；delay_steps不能直接解释为game loop数。",
            delay_revalidation="该字段本身不进入延迟动作重验证。",
            training_stage="not_applicable",
        )
        if vid in DELAY_FIELDS:
            result["delay_revalidation"] = "随动作进入pending_actions；到期后重查unit tags和unit目标，失效则丢弃并计数。"
        elif vid in {"action.invalid_actions", "action.invalid_reason_counts"}:
            result.update(scope="parser_result_diagnostics", persistence="属于本次解析结果的无效动作诊断；实验代码可再累计。", delay_revalidation="初次Parser诊断；延迟执行失败走独立统计路径。")
    elif layer == "executor_mapping":
        result = dict(
            scope="action_execution_attempt",
            refresh_trigger="ActionExecutor.execute",
            refresh_granularity="per_action_execution_attempt",
            persistence="FunctionCall作为本次环境step动作返回；不代表引擎一定执行成功。",
            reset_boundary="动作调用局部；相关执行统计按episode重置。",
            update_timing="动作通过Parser及必要的延迟重验证后，在ActionExecutor映射时产生。",
            game_loop_relation="提交给环境step；实际引擎执行语义需运行时核验。",
            delay_revalidation="延迟动作在到期重验证后才映射。pysc2.function.queued是命令队列参数，不是pending_actions。",
            training_stage="not_applicable",
        )
    elif layer == "swm_prediction":
        result = dict(
            scope="swm_prediction_result",
            refresh_trigger="SWMPredictor.predict",
            refresh_granularity="per_swm_prediction_call",
            persistence="保存在该次预测结果或last_prediction中，可缓存或写入轨迹；不是环境真值。",
            reset_boundary="与生成它的state/action快照绑定，跨episode复用没有环境真值含义。",
            update_timing="每次候选动作触发SWM预测并成功解析模型响应时产生。",
            game_loop_relation="预测step是模型预测步，不自动等同SC2 game loop。",
            delay_revalidation="not_applicable",
            training_stage="下一真实ABox快照到达后可与units_snapshot比较并计算误差。",
        )
    else:
        result = dict(
            scope="experiment_aggregate",
            refresh_trigger="experiment loop or trajectory evaluation",
            refresh_granularity="per_episode_or_experiment_summary",
            persistence="写入实验统计、CSV或JSON产物后跨运行保存。",
            reset_boundary="由实验脚本决定；历史产物不能自动视为当前checkout新结果。",
            update_timing="在episode、模型调用、动作统计或实验汇总阶段更新。",
            game_loop_relation="由Agent可见步骤或episode结果聚合，不是逐game-loop原始值。",
            delay_revalidation="not_applicable",
            training_stage="属于评估/汇总阶段；SWM误差在轨迹state_t到state_t1闭合时计算。",
        )
        if vid == "metric.episode.final_score":
            result.update(scope="episode_result", refresh_trigger="episode termination", refresh_granularity="per_episode", update_timing="TimeStep.last后记录该episode最终得分。")
        elif vid == "metric.experiment.avg_score":
            result.update(scope="experiment_result", refresh_trigger="variant episodes completed", refresh_granularity="per_experiment_variant", update_timing="多个episode得分收集后计算平均值。")
        elif vid.startswith("metric.swm."):
            result.update(scope="trajectory_prediction_error", refresh_trigger="next real ABox snapshot available", refresh_granularity="per_completed_trajectory_transition", update_timing="TrajectoryCollector获得state_t1/units_snapshot后调用compute_prediction_error。", training_stage="与state_t、actions、prediction、state_t1组成轨迹，可供后续训练或评估。")
        elif vid.startswith("metric.llm."):
            result.update(scope="episode_or_experiment_llm_metric", refresh_trigger="LLM request completion and experiment aggregation", refresh_granularity="per_llm_call_then_per_episode_or_variant", update_timing="RawAgent按LLM请求累计，实验脚本在episode或variant结束时汇总。")
        elif vid.startswith("metric.action."):
            result.update(scope="episode_or_experiment_action_metric", refresh_trigger="action event and experiment aggregation", refresh_granularity="per_action_event_then_per_episode_or_variant", update_timing="动作验证或延迟执行事件更新计数，实验结束时计算比率。")
    return result


def truth(record):
    layer = record["provenance"]["source_layer"]
    if layer == "tbox_static":
        return dict(definition_status="code_reality", runtime_value_status="not_applicable", needs_runtime_verification=False, reason="当前静态声明可确认；与pickle缓存和游戏版本一致性仍需单独核验。")
    if layer == "derived_runtime":
        return dict(definition_status="derived_runtime", runtime_value_status="not_observed", needs_runtime_verification=True, reason="公式由代码确认，但未运行环境获得具体派生值。")
    if layer in {"llm_output", "swm_prediction"}:
        return dict(definition_status="needs_verification", runtime_value_status="model_output_not_observed", needs_runtime_verification=True, reason="接口由代码确认，但未调用外部模型。")
    if layer == "experiment_aggregate":
        return dict(definition_status="code_reality", runtime_value_status="historical_or_not_reproduced", needs_runtime_verification=True, reason="公式和落盘接口可确认，但未重新执行实验。")
    return dict(definition_status="code_reality", runtime_value_status="not_observed", needs_runtime_verification=True, reason="读写或映射路径可静态确认，但未启动SC2验证运行值和引擎语义。")


def main():
    records, file_counts = load_records()
    ids = {r["id"] for r in records}
    downstream = defaultdict(set)
    for r in records:
        for up in r["provenance"].get("upstream_variable_ids", []):
            if up in ids:
                downstream[up].add(r["id"])
        for rel in r.get("relationships", []):
            other = rel.get("target_id")
            if other not in ids:
                continue
            if rel.get("type") == "derived_from":
                downstream[other].add(r["id"])
            elif rel.get("type") in {"transformed_to", "consumed_by", "feeds", "produces"}:
                downstream[r["id"]].add(other)
    rows = []
    for r in records:
        source = r["provenance"]["source_layer"]
        rows.append({
            "variable_id": r["id"],
            "canonical_name": r["canonical_name"],
            "category": r["category"],
            "source_layer": source,
            "taxonomy_source_layer": LAYER_MAP[source],
            "value_class": classify_value(r),
            "provenance": {
                "derivation_kind": r["provenance"]["derivation_kind"],
                "upstream_variable_ids": sorted(r["provenance"].get("upstream_variable_ids", [])),
                "producer_locations": r["implementation"]["source_locations"],
                "transformation_formula": r["implementation"].get("transformation_formula", []),
                "evidence_ids": [e["id"] for e in r.get("evidence", [])],
            },
            "lifecycle": lifecycle(r),
            "downstream": {"variable_ids": sorted(downstream[r["id"]]), "consumers": r.get("consumers", [])},
            "truth_boundary": truth(r),
            "verification": {"step05_status": r["verification"]["status"], "sc2_executed": False, "external_llm_or_swm_called": False, "experiments_reexecuted": False, "step06_status": "static_lineage_verified"},
        })
    by_source = Counter(r["source_layer"] for r in rows)
    by_tax = Counter(r["taxonomy_source_layer"] for r in rows)
    by_class = Counter(r["value_class"] for r in rows)
    by_refresh = Counter(r["lifecycle"]["refresh_granularity"] for r in rows)
    stats = {
        "total_records": len(rows),
        "by_input_file": file_counts,
        "by_source_layer": dict(sorted(by_source.items())),
        "by_taxonomy_source_layer": dict(sorted(by_tax.items())),
        "by_value_class": dict(sorted(by_class.items())),
        "by_refresh_granularity": dict(sorted(by_refresh.items())),
        "needs_runtime_verification": sum(r["truth_boundary"]["needs_runtime_verification"] for r in rows),
    }
    data = {
        "knowledge_base": "storm-sc2kb-v1-raw",
        "schema_version": "1.0.0",
        "generated_at": DATE,
        "status": "static_lineage_classified",
        "scope": "步骤五135条正式变量的来源、血缘、刷新时机、生命周期和可信边界。",
        "runtime_boundary": {"sc2_executed": False, "external_llm_or_swm_called": False, "experiments_reexecuted": False, "external_pysc2_docs_checked": False},
        "source_files": [f"knowledge/variables/{x}.yaml" for x in FILES],
        "statistics": stats,
        "classification_contract": {
            "source_layer": "步骤三Schema存储枚举，表示实际数据来源。",
            "taxonomy_source_layer": "步骤四规范来源层名称。",
            "value_class": "区分配置、静态知识、观测、ABox、跨帧、派生、LLM、动作、预测和聚合。",
            "update_timing": "说明当前代码在什么事件上刷新变量。",
            "needs_runtime_verification": "true表示没有在本步骤实际观测运行值或外部语义。",
        },
        "records": rows,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=120), encoding="utf-8")
    DOC.write_text(build_doc(stats, file_counts), encoding="utf-8")
    print(yaml.safe_dump(stats, allow_unicode=True, sort_keys=False))


def build_doc(stats, file_counts):
    source_rows = "\n".join(f"| `{k}` | `{LAYER_MAP[k]}` | {v} |" for k, v in stats["by_source_layer"].items())
    class_rows = "\n".join(f"| `{k}` | {v} |" for k, v in stats["by_value_class"].items())
    inputs = "\n".join(f"- `knowledge/variables/{k}.yaml`：{v}条" for k, v in file_counts.items())
    return f'''# 步骤 06：变量来源、生命周期与可信度

- 报告日期：{DATE}
- 范围：步骤五的135条正式变量卡片
- 状态：静态血缘分析完成；SC2运行时、外部模型和实验复现未执行

## 1. 一句话结论

本步骤没有新增PySC2字段，而是把步骤五的每个变量放回真实数据流：说明它从哪里产生、何时刷新、能保留多久、由谁消费，以及当前证据只能证明接口还是已经证明运行值。

## 2. 输入与输出

{inputs}

输出：
- `knowledge/lineage/variable_lineage.yaml`：逐变量机器可读血缘表
- `knowledge/docs/06_provenance_and_lifecycle.md`：本说明文档

## 3. 来源层数量统计

| Schema source_layer | 步骤四规范层 | 数量 |
|---|---|---:|
{source_rows}

## 4. 值类型统计

| value_class | 数量 |
|---|---:|
{class_rows}

## 5. 生命周期时间轴

```text
初始化：environment_config确定；TBox构建或加载
episode开始：RawAgent.reset清空延迟动作、决策历史和episode统计
每次Agent观测：读取TimeStep/player/RawUnit，更新ABox与跨帧量
决策触发：计算战术派生量，调用LLM，Parser校验，可选SWM预测
动作执行：立即映射FunctionCall；延迟动作到期重验证后映射
下一状态/结束：计算SWM误差，聚合得分、Token、耗时和失败率
```

## 6. game loop、环境步和decision step不能混用

`step_mul`控制一次环境交互跨越多少SC2 game loops。RawUnit、player和ABox在Agent收到新observation时刷新，并不表示代码观察到了被跨越的每一个game loop。`decision_interval`控制常规LLM决策间隔，`delay_steps`表示动作延迟的Agent环境步数，三者必须分开解释。

## 7. 延迟动作生命周期

Parser通过的动作若`delay_steps > 0`，可进入`RawAgent.pending_actions`。计划step到达时，当前实现检查动作单位tag以及unit目标是否仍存在；失效动作被丢弃并计入延迟失败统计，剩余动作才交给ActionExecutor。`pysc2.function.queued`是PySC2 FunctionCall命令队列参数，不是`pending_actions`。

## 8. ABox跨episode边界

`RawAgent.reset`会重置Agent计数、延迟动作和决策历史，但没有显式重新创建`BattlefieldGraph`。新episode首个观测会通过tag集合删除、创建和更新节点，但`BattlefieldGraph.step_count`等图对象状态可能继续累积。该现象属于当前代码现实，实际多episode行为仍需运行验证。

## 9. 可信状态规则

| 对象 | 静态代码能够确认 | 本步骤不能确认 |
|---|---|---|
| Raw observation | 读取位置、转换公式、下游路径 | SC2运行值和官方字段语义 |
| TBox | 当前Python静态声明 | 与pickle缓存和游戏版本完全一致 |
| ABox/派生量 | 更新与计算代码 | 实际episode具体数值 |
| LLM/SWM | 输入输出接口、Parser结构 | 模型真实输出和预测准确性 |
| FunctionCall | 当前编号与参数映射 | 游戏引擎是否成功执行 |
| 实验指标 | 公式和落盘接口 | 当前checkout能否复现历史结果 |

## 10. 变量血缘示例

```text
raw_unit.health → abox.unit.hp → derived.tactical.friendly_avg_hp → derived.tactical.health_status
LLM actions → action.delay_steps → pending_actions → 到期重验证 → pysc2.function.*
swm.input.abox_state + swm.input.planned_actions → swm.predictions → state_t1 → metric.swm.*
```

## 11. 机器可读记录结构

每条记录包含`source_layer`、`taxonomy_source_layer`、`value_class`、上游变量、生产源码、转换公式、证据ID、`update_timing`、刷新粒度、持久性、重置边界、game loop关系、延迟重验证、训练阶段、下游消费者和`needs_runtime_verification`。

## 12. 已知问题与待验证项

1. 未启动StarCraft II，所有具体运行值仍未观测。
2. RawUnit位置索引只证明当前STORM代码现实，未访问PySC2官方资料。
3. TBox Python定义与`ontology_graph.pkl`缓存可能不同步。
4. ABox动态`armor/armor_ratio`实际来自RawUnit的`shield/shield_ratio`。
5. FunctionCall编号未对当前ActionSpec做运行时核验。
6. 未调用外部LLM/SWM，模型输出变量仍需验证。
7. 历史实验指标没有重新执行。

## 13. 验收结论

- [x] {stats['total_records']}条变量全部进入血缘表；
- [x] 每条记录都有source_layer和非占位update_timing；
- [x] 静态知识、实时观测、跨帧状态、LLM值、预测值和聚合值分开；
- [x] 每条记录包含上游、下游消费者、生命周期与可信边界；
- [x] 未知运行时语义标记needs_runtime_verification；
- [x] 所有步骤六产物位于knowledge/；
- [ ] SC2运行时验证：未执行；
- [ ] 外部LLM/SWM验证：未执行；
- [ ] 实验复现：未执行。
'''


if __name__ == "__main__":
    main()
