"""严格校验步骤09产物。"""
from pathlib import Path
from collections import defaultdict
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[2]
K = ROOT / "knowledge"
YAML_PATH = K / "known_issues.yaml"
DOC_PATH = K / "docs" / "09_known_issues.md"
VARIABLE_FILES = ["raw_api", "tbox", "abox", "derived", "actions", "swm", "metrics"]
KINDS = {"confirmed_bug", "implementation_quirk", "documentation_mismatch", "needs_runtime_test"}
SEVERITIES = {"critical", "high", "medium", "low"}
TRUTHS = {"design_intent", "code_reality", "runtime_observation", "needs_verification"}
REQUIRED_IDS = {
    "issue.abox_armor_stores_shield", "issue.unknown_unit_hp_default_is_static_only",
    "issue.action_coordinate_clip_not_written_back", "issue.action_priority_not_validated_or_consumed",
    "issue.main_confidence_documented_but_disabled", "issue.build_train_dual_representation",
    "issue.swm_confidence_not_a_gate", "issue.swm_error_uses_future_state_as_baseline"}


def main():
    errors, warnings = [], []
    def check(ok, message):
        if not ok: errors.append(message)

    check(YAML_PATH.exists(), "缺少 knowledge/known_issues.yaml")
    check(DOC_PATH.exists(), "缺少 knowledge/docs/09_known_issues.md")
    if errors:
        finish(errors, warnings)

    try:
        data = yaml.safe_load(YAML_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append("YAML 无法解析: " + str(exc)); finish(errors, warnings)

    variables = set()
    for name in VARIABLE_FILES:
        p = K / "variables" / (name + ".yaml")
        check(p.exists(), "缺少变量文件: " + str(p.relative_to(ROOT)))
        if p.exists():
            body = yaml.safe_load(p.read_text(encoding="utf-8"))
            variables.update(x["id"] for x in body.get("records", []))
    check(len(variables) == 135, "正式变量集合应为135，实际" + str(len(variables)))

    issues = data.get("issues", []) if isinstance(data, dict) else []
    ids = [x.get("id") for x in issues]
    check(bool(issues), "issues 不能为空")
    check(ids == sorted(ids), "issue ID 未确定性排序")
    check(len(ids) == len(set(ids)), "issue ID 不唯一")
    check(REQUIRED_IDS <= set(ids), "未覆盖提示词重点: " + str(sorted(REQUIRED_IDS - set(ids))))
    check({x.get("issue_type") for x in issues} == KINDS, "四类问题未完整出现")

    expected_vi = defaultdict(list)
    expected_fi = defaultdict(list)
    for item in issues:
        iid = item.get("id", "")
        check(bool(re.fullmatch(r"issue\.[a-z0-9_]+", iid)), "非法稳定 ID: " + iid)
        check(item.get("issue_type") in KINDS, iid + " 类型非法")
        check(item.get("severity") in SEVERITIES, iid + " 严重度非法")
        check(item.get("truth_status") in TRUTHS, iid + " 可信状态非法")
        for key in ["title_zh", "phenomenon", "concise_explanation", "expected_or_documented_behavior", "current_implementation"]:
            check(bool(item.get(key)), iid + " 缺少 " + key)
        impact = item.get("impact", {})
        check(bool(impact.get("knowledge_answer_constraint")), iid + " 缺少回答约束")
        check(bool(impact.get("code_or_experiment_risk")), iid + " 缺少影响说明")
        verify = item.get("recommended_verification", {})
        check(bool(verify.get("method")), iid + " 缺少验证方法")
        check(verify.get("execution_status") == "not_executed", iid + " 不得虚构已执行验证")
        check(bool(verify.get("steps")), iid + " 缺少验证步骤")
        check(bool(verify.get("success_criteria")), iid + " 缺少通过标准")
        check(bool(item.get("limitations")), iid + " 缺少限制")
        evidences = item.get("evidence", [])
        check(bool(evidences), iid + " 至少需要一条证据")
        for e in evidences:
            rel = e.get("path", "")
            check(bool(rel) and not Path(rel).is_absolute(), iid + " 证据必须是相对路径")
            source = ROOT / rel
            check(source.exists() and source.is_file(), iid + " 证据文件不存在: " + rel)
            check(bool(e.get("symbol")) and bool(e.get("claim")), iid + " 证据缺少符号或结论")
            if source.exists():
                count = len(source.read_text(encoding="utf-8").splitlines())
                a, b = e.get("line_start"), e.get("line_end")
                check(isinstance(a, int) and isinstance(b, int) and 1 <= a <= b <= count,
                      iid + " 证据行号非法: " + rel)
        for variable_id in item.get("affected_variable_ids", []):
            check(variable_id in variables, iid + " 引用了非正式变量: " + variable_id)
            expected_vi[variable_id].append(iid)
        for field in item.get("affected_noncanonical_fields", []):
            expected_fi[field].append(iid)

    vi = {x.get("variable_id"): sorted(x.get("issue_ids", [])) for x in data.get("variable_issue_index", [])}
    fi = {x.get("field"): sorted(x.get("issue_ids", [])) for x in data.get("noncanonical_field_issue_index", [])}
    check(vi == {k: sorted(v) for k, v in sorted(expected_vi.items())}, "variable_issue_index 与问题反链不一致")
    check(fi == {k: sorted(v) for k, v in sorted(expected_fi.items())}, "noncanonical_field_issue_index 不一致")
    check("action.confidence" not in variables and "action.confidence" not in vi, "不得虚构 action.confidence")
    check(fi.get("decision_response.confidence") == ["issue.main_confidence_documented_but_disabled"],
          "主决策 confidence 必须进入非正式字段索引")

    rb = data.get("runtime_boundary", {})
    check(rb.get("sc2_executed") is False, "必须声明 SC2 未执行")
    check(rb.get("external_llm_or_swm_called") is False, "必须声明外部模型未调用")
    check(rb.get("experiments_reexecuted") is False, "必须声明实验未重跑")
    stats = data.get("statistics", {})
    check(stats.get("issue_count") == len(issues), "issue_count 统计错误")
    check(stats.get("affected_variable_count") == len(expected_vi), "affected_variable_count 统计错误")

    doc = DOC_PATH.read_text(encoding="utf-8")
    for title in ["确认缺陷", "实现特性/陷阱", "文档不一致", "待运行验证", "未执行声明", "知识库回答约束", "证据依据"]:
        check(title in doc, "Markdown 缺少: " + title)
    for iid in ids:
        check(iid in doc, "Markdown 未包含问题: " + iid)
    check("未启动 SC2" in doc and "未调用外部 LLM/SWM" in doc and "未重跑实验" in doc,
          "Markdown 未完整披露运行边界")

    combined = YAML_PATH.read_text(encoding="utf-8") + "\n" + doc
    check("C:\\Users\\" not in combined and "C:/Users/" not in combined, "产物含私人绝对路径")
    check("�" not in combined, "产物含乱码替换符")
    check("runtime_verified" not in combined, "本步骤不得声称 runtime_verified")
    finish(errors, warnings)


def finish(errors, warnings):
    print("STEP09 VALIDATION")
    for e in errors: print("ERROR:", e)
    for w in warnings: print("WARNING:", w)
    print("errors:", len(errors))
    print("warnings:", len(warnings))
    print("RESULT:", "PASS" if not errors and not warnings else "FAIL")
    raise SystemExit(0 if not errors and not warnings else 1)


if __name__ == "__main__":
    main()
