"""生成步骤08变量关系边表、Mermaid总览和图审计报告。"""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Any

import yaml


ROOT = Path(__file__).resolve().parents[2]
KNOWLEDGE = ROOT / "knowledge"
VARIABLE_DIR = KNOWLEDGE / "variables"
LINEAGE_PATH = KNOWLEDGE / "lineage" / "variable_lineage.yaml"
ALIASES_PATH = KNOWLEDGE / "retrieval" / "aliases.yaml"
RELATIONS_OUT = KNOWLEDGE / "relations" / "variable_relations.jsonl"
DOC_OUT = KNOWLEDGE / "docs" / "08_variable_graph.md"
AUDIT_OUT = KNOWLEDGE / "reports" / "08_graph_audit.md"

DATE = "2026-09-04"
VARIABLE_FILES = [
    "raw_api",
    "tbox",
    "abox",
    "derived",
    "actions",
    "swm",
    "metrics",
]
RELATION_TYPES = [
    "read_from",
    "transformed_to",
    "normalized_as",
    "aggregated_into",
    "stored_as",
    "used_by",
    "validated_by",
    "mapped_to",
    "predicts",
    "evaluated_by",
    "aliases",
]
CAUSAL_RELATIONS = {
    "read_from",
    "transformed_to",
    "normalized_as",
    "aggregated_into",
    "stored_as",
    "validated_by",
    "mapped_to",
    "predicts",
    "evaluated_by",
}
AGGREGATED_DERIVED_IDS = {
    "abox.graph.enemy_count",
    "derived.tactical.critical_units",
    "derived.tactical.enemy_avg_hp",
    "derived.tactical.enemy_centroid",
    "derived.tactical.enemy_count",
    "derived.tactical.fire_readiness",
    "derived.tactical.force_ratio",
    "derived.tactical.formation_distance",
    "derived.tactical.friendly_avg_hp",
    "derived.tactical.friendly_centroid",
    "derived.tactical.friendly_count",
    "derived.tactical.ready_to_fire_count",
}
PROMPT_VARIABLE_IDS = {
    "player.minerals",
    "player.vespene",
    "player.food_used",
    "player.food_cap",
    "player.supply_remaining",
}


def load_inputs() -> tuple[
    list[dict[str, Any]], dict[str, dict[str, Any]], dict[str, Any]
]:
    records: list[dict[str, Any]] = []
    for name in VARIABLE_FILES:
        path = VARIABLE_DIR / f"{name}.yaml"
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
        records.extend(payload["records"])
    records.sort(key=lambda row: row["id"])

    lineage_payload = yaml.safe_load(LINEAGE_PATH.read_text(encoding="utf-8"))
    lineage = {row["variable_id"]: row for row in lineage_payload["records"]}
    aliases = yaml.safe_load(ALIASES_PATH.read_text(encoding="utf-8"))
    return records, lineage, aliases


def stable_hash(text: str, length: int = 16) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:length]


def safe_component_id(path: str, symbol: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", ".", f"{path}.{symbol}".lower()).strip(".")
    slug = slug[:72].rstrip(".")
    return f"component.{slug}.{stable_hash(path + '::' + symbol, 10)}"


def endpoint(
    node_id: str,
    kind: str,
    *,
    label: str | None = None,
    layer: str | None = None,
    category: str | None = None,
) -> dict[str, Any]:
    return {
        "id": node_id,
        "kind": kind,
        "label": label or node_id,
        "layer": layer,
        "category": category,
    }


def normalize_evidence(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: dict[tuple[Any, ...], dict[str, Any]] = {}
    for item in items:
        normalized = {
            "evidence_id": item.get("evidence_id"),
            "path": item.get("path"),
            "symbol": item.get("symbol"),
            "line_start": item.get("line_start"),
            "line_end": item.get("line_end"),
        }
        key = tuple(normalized.values())
        unique[key] = normalized
    return sorted(
        unique.values(),
        key=lambda row: (
            str(row.get("path") or ""),
            str(row.get("symbol") or ""),
            int(row.get("line_start") or 0),
            str(row.get("evidence_id") or ""),
        ),
    )


def evidence_from_record(
    record: dict[str, Any], lineage: dict[str, Any]
) -> list[dict[str, Any]]:
    evidence_ids = lineage["provenance"].get("evidence_ids", [])
    locations = lineage["provenance"].get("producer_locations", [])
    items = []
    for index, location in enumerate(locations):
        items.append(
            {
                "evidence_id": (
                    evidence_ids[index]
                    if index < len(evidence_ids)
                    else (evidence_ids[0] if evidence_ids else None)
                ),
                **location,
            }
        )
    if not items:
        for evidence_id in evidence_ids:
            items.append(
                {
                    "evidence_id": evidence_id,
                    "path": None,
                    "symbol": None,
                    "line_start": None,
                    "line_end": None,
                }
            )
    return normalize_evidence(items)


def truth_status(lineage: dict[str, Any]) -> str:
    status = lineage.get("truth_boundary", {}).get(
        "definition_status", "needs_verification"
    )
    if status in {"code_reality", "runtime_observation", "design_intent"}:
        return status
    if status == "derived_runtime":
        return "code_reality"
    return "needs_verification"


def unique_text(items: list[str]) -> list[str]:
    return sorted({str(item).strip() for item in items if str(item).strip()})


class EdgeBuilder:
    def __init__(
        self,
        records_by_id: dict[str, dict[str, Any]],
        lineage_by_id: dict[str, dict[str, Any]],
    ) -> None:
        self.records_by_id = records_by_id
        self.lineage_by_id = lineage_by_id
        self.edges: dict[tuple[str, str, str], dict[str, Any]] = {}

    def variable(self, variable_id: str) -> dict[str, Any]:
        record = self.records_by_id[variable_id]
        lineage = self.lineage_by_id[variable_id]
        return endpoint(
            variable_id,
            "variable",
            label=record["names"]["zh"],
            layer=lineage["taxonomy_source_layer"],
            category=record["category"],
        )

    def node(self, node_id: str) -> dict[str, Any]:
        if node_id in self.records_by_id:
            return self.variable(node_id)
        if node_id.startswith("component."):
            kind = "component"
            layer = "pipeline_component"
        elif node_id.startswith("alias."):
            kind = "alias"
            layer = "retrieval_index"
        elif node_id.startswith("pysc2.raw_unit.index_"):
            kind = "interface_field"
            layer = "raw_observation"
        else:
            kind = "artifact"
            layer = "pipeline_artifact"
        return endpoint(node_id, kind, layer=layer)

    def add(
        self,
        relation_type: str,
        source: dict[str, Any],
        target: dict[str, Any],
        summary_zh: str,
        *,
        basis: str = "source_evidence",
        status: str = "code_reality",
        evidence: list[dict[str, Any]] | None = None,
        formulas: list[str] | None = None,
        limitations: list[str] | None = None,
        mediator: str | None = None,
    ) -> None:
        if relation_type not in RELATION_TYPES:
            raise ValueError(f"未知关系类型: {relation_type}")
        key = (relation_type, source["id"], target["id"])
        incoming = {
            "schema_version": "1.0.0",
            "id": "",
            "relation_type": relation_type,
            "source": source,
            "target": target,
            "direction": "source_to_target",
            "summary_zh": summary_zh,
            "evidence_basis": basis,
            "truth_status": status,
            "runtime_value_status": (
                "not_applicable"
                if basis == "structural_index"
                else "not_observed"
            ),
            "mediator": mediator,
            "evidence": normalize_evidence(evidence or []),
            "formulas": unique_text(formulas or []),
            "limitations": unique_text(limitations or []),
        }
        if key not in self.edges:
            self.edges[key] = incoming
            return

        current = self.edges[key]
        current["evidence"] = normalize_evidence(
            current["evidence"] + incoming["evidence"]
        )
        current["formulas"] = unique_text(
            current["formulas"] + incoming["formulas"]
        )
        current["limitations"] = unique_text(
            current["limitations"] + incoming["limitations"]
        )
        if incoming["evidence_basis"] == "source_evidence":
            current["evidence_basis"] = "source_evidence"
        if incoming["truth_status"] == "needs_verification":
            current["truth_status"] = "needs_verification"
        if not current.get("mediator"):
            current["mediator"] = incoming.get("mediator")

    def finalize(self) -> list[dict[str, Any]]:
        result = []
        for key in sorted(self.edges):
            edge = self.edges[key]
            relation_type, source_id, target_id = key
            edge["id"] = (
                f"rel.{relation_type}."
                f"{stable_hash(source_id + '|' + relation_type + '|' + target_id)}"
            )
            result.append(edge)
        return result


def relation_for_upstream(target: dict[str, Any]) -> str:
    target_id = target["id"]
    source_layer = target["provenance"]["source_layer"]
    kind = target["provenance"]["derivation_kind"]
    if kind == "normalized":
        return "normalized_as"
    if kind == "aggregated":
        return "aggregated_into"
    if source_layer == "abox_runtime":
        return "stored_as"
    if source_layer == "swm_prediction":
        return "predicts"
    if source_layer == "validated_action":
        return "validated_by"
    if target_id in AGGREGATED_DERIVED_IDS:
        return "aggregated_into"
    return "transformed_to"


def source_artifact_for(record: dict[str, Any]) -> tuple[str, str] | None:
    layer = record["provenance"]["source_layer"]
    if layer == "pysc2_raw_observation":
        return "artifact.pysc2.observation", "PySC2 observation.raw_units"
    if layer == "pysc2_timestep":
        return "artifact.pysc2.timestep", "PySC2 TimeStep observation"
    if layer == "environment_config":
        return "component.environment_configuration", "环境构造参数和Agent配置"
    if layer == "tbox_static":
        return "artifact.ontology.static_definitions", "当前仓库TBox静态定义"
    return None


def manual_evidence(
    path: str, symbol: str, line_start: int | None = None, line_end: int | None = None
) -> list[dict[str, Any]]:
    return [
        {
            "evidence_id": None,
            "path": path,
            "symbol": symbol,
            "line_start": line_start,
            "line_end": line_end,
        }
    ]


def add_manual_core_edges(
    builder: EdgeBuilder,
    records: list[dict[str, Any]],
    lineage: dict[str, dict[str, Any]],
) -> None:
    prompt_builder = endpoint(
        "component.battlefield_graph.prompt_builder",
        "component",
        label="BattlefieldGraph.build_full_prompt",
        layer="pipeline_component",
    )
    prompt_artifact = endpoint(
        "artifact.storm.llm_prompt",
        "artifact",
        label="STORM完整决策Prompt",
        layer="llm_input",
    )
    llm_response = endpoint(
        "artifact.llm.response_text",
        "artifact",
        label="LLM原始响应文本",
        layer="llm_output",
    )
    response_parser = endpoint(
        "component.response_parser",
        "component",
        label="ResponseParser",
        layer="pipeline_component",
    )
    validated_actions = endpoint(
        "artifact.storm.validated_actions",
        "artifact",
        label="校验后的动作列表",
        layer="parser_validated",
    )
    action_executor = endpoint(
        "component.action_executor",
        "component",
        label="ActionExecutor.execute",
        layer="pipeline_component",
    )
    pending_actions = endpoint(
        "artifact.storm.pending_actions",
        "artifact",
        label="延迟动作队列",
        layer="cross_frame_state",
    )
    function_call = endpoint(
        "artifact.pysc2.function_call",
        "artifact",
        label="PySC2 Raw FunctionCall",
        layer="executor_mapped",
    )

    prompt_evidence = manual_evidence(
        "ontology/bridge.py", "BattlefieldGraph.build_full_prompt"
    )
    for record in records:
        variable_id = record["id"]
        source_layer = record["provenance"]["source_layer"]
        if (
            source_layer in {"tbox_static", "abox_runtime"}
            or variable_id.startswith("derived.tactical.")
            or variable_id in PROMPT_VARIABLE_IDS
        ):
            builder.add(
                "used_by",
                builder.variable(variable_id),
                prompt_builder,
                f"{variable_id}作为战场上下文的一部分供Prompt构建使用。",
                evidence=prompt_evidence,
                limitations=[
                    "该边表示当前Prompt构建链可访问该层数据，不保证每次Prompt都逐字展开全部字段。"
                ],
            )

    builder.add(
        "stored_as",
        prompt_builder,
        prompt_artifact,
        "BattlefieldGraph把TBox、ABox、战术摘要和任务信息组织成决策Prompt。",
        evidence=prompt_evidence,
    )
    builder.add(
        "transformed_to",
        prompt_artifact,
        llm_response,
        "决策Prompt被发送给外部LLM并期望得到动作响应文本。",
        status="needs_verification",
        evidence=manual_evidence(
            "agents/raw_agent.py", "RawAgent._make_llm_decision"
        ),
        limitations=["步骤08未调用外部LLM，当前只确认代码调用链。"],
    )
    builder.add(
        "validated_by",
        llm_response,
        response_parser,
        "LLM响应由ResponseParser提取JSON并执行Schema及语义校验。",
        evidence=manual_evidence(
            "agents/response_parser.py", "ResponseParser.parse", 63, 126
        ),
    )

    action_ids = [
        row["id"]
        for row in records
        if row["id"].startswith("action.")
    ]
    action_element_ids = {
        "action.delay_steps",
        "action.priority",
        "action.subtype",
        "action.target",
        "action.target_type",
        "action.type",
        "action.units",
    }
    for variable_id in action_ids:
        row = builder.records_by_id[variable_id]
        lr = lineage[variable_id]
        builder.add(
            "stored_as",
            response_parser,
            builder.variable(variable_id),
            f"ResponseParser输出或统计字段{variable_id}。",
            evidence=evidence_from_record(row, lr),
            formulas=row["implementation"].get("transformation_formula", []),
            status=truth_status(lr),
        )
        if variable_id in action_element_ids:
            builder.add(
                "stored_as",
                builder.variable(variable_id),
                validated_actions,
                f"{variable_id}作为校验后动作对象的字段保存。",
                evidence=evidence_from_record(row, lr),
            )
            builder.add(
                "used_by",
                builder.variable(variable_id),
                action_executor,
                f"ActionExecutor读取{variable_id}完成动作映射。",
                evidence=manual_evidence(
                    "agents/action_executor.py", "ActionExecutor.execute", 130, 242
                ),
            )

    builder.add(
        "used_by",
        validated_actions,
        action_executor,
        "校验后的动作列表交给ActionExecutor转换为PySC2 FunctionCall。",
        evidence=manual_evidence(
            "agents/raw_agent.py", "RawAgent._convert_actions_to_pysc2", 828, 1023
        ),
    )
    builder.add(
        "stored_as",
        builder.variable("action.delay_steps"),
        pending_actions,
        "delay_steps大于0的动作按目标环境步保存到pending_actions。",
        evidence=manual_evidence(
            "agents/raw_agent.py", "RawAgent._convert_actions_to_pysc2", 900, 991
        ),
        limitations=["delay_steps的单位是Agent环境步，不是SC2 game loop。"],
    )
    builder.add(
        "used_by",
        pending_actions,
        action_executor,
        "延迟动作到期并通过二次有效性检查后才进入ActionExecutor。",
        evidence=manual_evidence("agents/raw_agent.py", "RawAgent.step", 294, 324),
    )

    mappings = [
        ("action.type", "pysc2.move.function_id"),
        ("action.type", "pysc2.attack.function_id"),
        ("action.type", "pysc2.build.function_id"),
        ("action.type", "pysc2.train.function_id"),
        ("action.subtype", "pysc2.build.function_id"),
        ("action.subtype", "pysc2.train.function_id"),
        ("action.units", "pysc2.function.unit_tags"),
        ("action.target", "pysc2.function.target"),
        ("action.target_type", "pysc2.function.target"),
        ("environment.use_raw_actions", "pysc2.function.raw_flag"),
    ]
    for source_id, target_id in mappings:
        target_record = builder.records_by_id[target_id]
        target_lineage = lineage[target_id]
        builder.add(
            "mapped_to",
            builder.variable(source_id),
            builder.variable(target_id),
            f"{source_id}由ActionExecutor映射到{target_id}。",
            evidence=evidence_from_record(target_record, target_lineage),
            formulas=target_record["implementation"].get(
                "transformation_formula", []
            ),
            limitations=target_record.get("limitations", []),
            status=truth_status(target_lineage),
            mediator="component.action_executor",
        )

    builder.add(
        "mapped_to",
        action_executor,
        builder.variable("pysc2.no_op.function_id"),
        "无可提交动作时ActionExecutor生成NO_OP FunctionCall。",
        evidence=evidence_from_record(
            builder.records_by_id["pysc2.no_op.function_id"],
            lineage["pysc2.no_op.function_id"],
        ),
    )
    builder.add(
        "mapped_to",
        action_executor,
        builder.variable("pysc2.function.queued"),
        "ActionExecutor为当前Raw FunctionCall写入queued参数。",
        evidence=evidence_from_record(
            builder.records_by_id["pysc2.function.queued"],
            lineage["pysc2.function.queued"],
        ),
    )

    for record in records:
        if record["provenance"]["source_layer"] != "executor_mapping":
            continue
        builder.add(
            "stored_as",
            builder.variable(record["id"]),
            function_call,
            f"{record['id']}构成PySC2 Raw FunctionCall的一部分。",
            evidence=evidence_from_record(record, lineage[record["id"]]),
            status=truth_status(lineage[record["id"]]),
            limitations=[
                "步骤08只确认FunctionCall构造代码，未运行SC2验证引擎接受或执行结果。"
            ],
        )

    builder.add(
        "used_by",
        function_call,
        endpoint(
            "component.pysc2.sc2_env",
            "component",
            label="PySC2 SC2Env",
            layer="external_runtime",
        ),
        "Raw FunctionCall作为Agent.step返回值交给SC2环境。",
        status="needs_verification",
        evidence=manual_evidence("agents/raw_agent.py", "RawAgent.step"),
        limitations=["步骤08未启动SC2，实际执行成功与否未验证。"],
    )


def add_swm_and_metric_edges(
    builder: EdgeBuilder,
    records: list[dict[str, Any]],
    lineage: dict[str, dict[str, Any]],
) -> None:
    abox_serialization = endpoint(
        "artifact.storm.abox_serialization",
        "artifact",
        label="序列化ABox状态",
        layer="runtime_abox",
    )
    validated_actions = endpoint(
        "artifact.storm.validated_actions",
        "artifact",
        label="校验后的动作列表",
        layer="parser_validated",
    )
    swm_predictor = endpoint(
        "component.swm_predictor",
        "component",
        label="SWMPredictor.predict",
        layer="pipeline_component",
    )
    swm_parser = endpoint(
        "component.swm_response_parser",
        "component",
        label="SWMPredictor._parse_prediction_response",
        layer="pipeline_component",
    )
    experiment_report = endpoint(
        "artifact.experiment.metrics_report",
        "artifact",
        label="实验指标记录",
        layer="experiment_aggregated",
    )

    serialize_evidence = manual_evidence(
        "ontology/bridge.py", "BattlefieldGraph.serialize_for_llm"
    )
    for record in records:
        if (
            record["provenance"]["source_layer"] == "abox_runtime"
            and record["id"] != "swm.input.abox_state"
        ):
            builder.add(
                "stored_as",
                builder.variable(record["id"]),
                abox_serialization,
                f"{record['id']}可进入BattlefieldGraph的LLM/SWM序列化状态。",
                evidence=serialize_evidence,
                limitations=[
                    "该边表示序列化层可承载该字段；具体输出还受序列化过滤和当前节点内容影响。"
                ],
            )

    builder.add(
        "stored_as",
        abox_serialization,
        builder.variable("swm.input.abox_state"),
        "当前BattlefieldGraph序列化文本作为SWM的abox_state输入。",
        evidence=manual_evidence(
            "agents/raw_agent.py", "RawAgent._apply_swm_prediction", 702, 714
        ),
    )
    builder.add(
        "stored_as",
        validated_actions,
        builder.variable("swm.input.planned_actions"),
        "校验后的动作列表initial_parsed['actions']作为SWM planned_actions输入。",
        evidence=manual_evidence(
            "agents/raw_agent.py", "RawAgent._apply_swm_prediction", 702, 714
        ),
        limitations=[
            "该输入是动作字典列表，不等同于整数统计变量action.planned_actions。"
        ],
    )

    swm_inputs = [
        "swm.input.abox_state",
        "swm.input.planned_actions",
        "swm.prediction_steps",
    ]
    for variable_id in swm_inputs:
        builder.add(
            "used_by",
            builder.variable(variable_id),
            swm_predictor,
            f"{variable_id}由SWMPredictor.predict读取。",
            evidence=manual_evidence(
                "ontology/swm_predictor.py", "SWMPredictor.predict", 93, 158
            ),
        )

    builder.add(
        "predicts",
        builder.variable("swm.input.abox_state"),
        builder.variable("swm.raw_response"),
        "SWM根据当前ABox状态生成未来状态预测响应。",
        status="needs_verification",
        evidence=manual_evidence(
            "ontology/swm_predictor.py", "SWMPredictor.predict", 93, 158
        ),
        limitations=["步骤08未调用SWM所依赖的外部模型。"],
        mediator="component.swm_predictor",
    )
    builder.add(
        "predicts",
        builder.variable("swm.input.planned_actions"),
        builder.variable("swm.raw_response"),
        "SWM把候选动作作为未来状态预测条件。",
        status="needs_verification",
        evidence=manual_evidence(
            "ontology/swm_predictor.py", "SWMPredictor.predict", 93, 158
        ),
        limitations=["步骤08未调用SWM所依赖的外部模型。"],
        mediator="component.swm_predictor",
    )
    builder.add(
        "predicts",
        builder.variable("swm.prediction_steps"),
        builder.variable("swm.raw_response"),
        "prediction_steps限制SWM要求生成的未来相对步数量。",
        status="needs_verification",
        evidence=manual_evidence(
            "ontology/swm_predictor.py", "SWMPredictor.predict", 93, 158
        ),
        mediator="component.swm_predictor",
    )
    builder.add(
        "validated_by",
        builder.variable("swm.raw_response"),
        swm_parser,
        "SWM原始响应由内部解析器提取、裁剪并校验预测结构。",
        evidence=manual_evidence(
            "ontology/swm_predictor.py",
            "SWMPredictor._parse_prediction_response",
            387,
            427,
        ),
    )

    for variable_id in ["swm.predictions", "swm.confidence", "swm.token_usage"]:
        builder.add(
            "stored_as",
            swm_parser,
            builder.variable(variable_id),
            f"SWM响应解析后保存为{variable_id}。",
            status="needs_verification",
            evidence=evidence_from_record(
                builder.records_by_id[variable_id], lineage[variable_id]
            ),
        )

    nested_edges = [
        ("swm.predictions", "swm.prediction.step"),
        ("swm.predictions", "swm.predicted_unit_states"),
        ("swm.predictions", "swm.predicted_relations"),
        ("swm.predicted_unit_states", "swm.unit.health_delta"),
        ("swm.predicted_unit_states", "swm.unit.position_delta"),
        ("swm.predictions", "swm.candidate_index"),
    ]
    for source_id, target_id in nested_edges:
        builder.add(
            "stored_as",
            builder.variable(source_id),
            builder.variable(target_id),
            f"{target_id}是{source_id}结构中的字段或候选包装字段。",
            status="needs_verification",
            evidence=evidence_from_record(
                builder.records_by_id[target_id], lineage[target_id]
            ),
        )

    evaluations = [
        ("swm.predicted_unit_states", "metric.swm.health_rmse"),
        ("swm.predicted_unit_states", "metric.swm.position_rmse"),
        ("swm.predicted_relations", "metric.swm.relation_accuracy"),
    ]
    for source_id, target_id in evaluations:
        target_record = builder.records_by_id[target_id]
        builder.add(
            "evaluated_by",
            builder.variable(source_id),
            builder.variable(target_id),
            f"{source_id}与下一状态观测比较后由{target_id}评估。",
            status="needs_verification",
            evidence=evidence_from_record(target_record, lineage[target_id]),
            formulas=target_record["implementation"].get(
                "transformation_formula", []
            ),
            limitations=["步骤08未运行SWM轨迹或误差评估。"],
        )

    for source_id in [
        "metric.swm.health_rmse",
        "metric.swm.position_rmse",
        "metric.swm.relation_accuracy",
    ]:
        builder.add(
            "aggregated_into",
            builder.variable(source_id),
            builder.variable("metric.swm.overall_error"),
            f"{source_id}按权重汇总到SWM overall_error。",
            evidence=evidence_from_record(
                builder.records_by_id["metric.swm.overall_error"],
                lineage["metric.swm.overall_error"],
            ),
            formulas=builder.records_by_id["metric.swm.overall_error"][
                "implementation"
            ].get("transformation_formula", []),
        )

    metric_edges = [
        ("timestep.score_cumulative_0", "metric.episode.final_score"),
        ("metric.episode.final_score", "metric.experiment.avg_score"),
        ("metric.action.decision_failure_rate", "metric.action.failure_rate"),
        ("metric.action.delayed_failure_rate", "metric.action.failure_rate"),
        ("metric.llm.total_tokens", "metric.llm.avg_tokens_per_decision"),
        ("metric.llm.decision_calls", "metric.llm.avg_tokens_per_decision"),
    ]
    for source_id, target_id in metric_edges:
        target_record = builder.records_by_id[target_id]
        relation_type = (
            "stored_as"
            if target_id == "metric.episode.final_score"
            else "aggregated_into"
        )
        builder.add(
            relation_type,
            builder.variable(source_id),
            builder.variable(target_id),
            f"{source_id}按照当前实验统计公式产生{target_id}。",
            evidence=evidence_from_record(target_record, lineage[target_id]),
            formulas=target_record["implementation"].get(
                "transformation_formula", []
            ),
            status=truth_status(lineage[target_id]),
        )

    for record in records:
        if record["provenance"]["source_layer"] == "experiment_aggregate":
            builder.add(
                "stored_as",
                builder.variable(record["id"]),
                experiment_report,
                f"{record['id']}作为实验统计结果写入记录或汇总。",
                evidence=evidence_from_record(record, lineage[record["id"]]),
                status=truth_status(lineage[record["id"]]),
                limitations=[
                    "步骤08未重新执行实验，当前只确认指标计算和写出接口。"
                ],
            )


def add_alias_edges(
    builder: EdgeBuilder, aliases: dict[str, Any]
) -> None:
    for index_row in aliases["alias_index"]:
        term = index_row["normalized_term"]
        alias_id = f"alias.{stable_hash(term)}"
        alias_node = endpoint(
            alias_id,
            "alias",
            label=term,
            layer="retrieval_index",
        )
        ambiguous = bool(index_row.get("ambiguous"))
        for match in index_row["candidate_matches"]:
            variable_id = match["variable_id"]
            builder.add(
                "aliases",
                alias_node,
                builder.variable(variable_id),
                f"自然语言检索词“{term}”可召回变量{variable_id}。",
                basis="structural_index",
                status="not_applicable",
                evidence=[
                    {
                        "evidence_id": None,
                        "path": "knowledge/retrieval/aliases.yaml",
                        "symbol": "alias_index",
                        "line_start": None,
                        "line_end": None,
                    }
                ],
                limitations=(
                    ["该词命中多个变量，检索Agent必须返回全部候选并追问。"]
                    if ambiguous
                    else []
                ),
            )


def find_cycle(
    edges: list[dict[str, Any]], allowed_relations: set[str]
) -> list[str] | None:
    adjacency: dict[str, list[str]] = defaultdict(list)
    nodes: set[str] = set()
    for edge in edges:
        if edge["relation_type"] not in allowed_relations:
            continue
        source_id = edge["source"]["id"]
        target_id = edge["target"]["id"]
        adjacency[source_id].append(target_id)
        nodes.update({source_id, target_id})

    state: dict[str, int] = {}
    stack: list[str] = []
    position: dict[str, int] = {}

    def visit(node: str) -> list[str] | None:
        state[node] = 1
        position[node] = len(stack)
        stack.append(node)
        for target in adjacency.get(node, []):
            if state.get(target, 0) == 0:
                cycle = visit(target)
                if cycle:
                    return cycle
            elif state.get(target) == 1:
                start = position[target]
                return stack[start:] + [target]
        stack.pop()
        position.pop(node, None)
        state[node] = 2
        return None

    for node in sorted(nodes):
        if state.get(node, 0) == 0:
            cycle = visit(node)
            if cycle:
                return cycle
    return None


def reachable(
    edges: list[dict[str, Any]], source: str, target: str
) -> bool:
    adjacency: dict[str, list[str]] = defaultdict(list)
    for edge in edges:
        if edge["relation_type"] == "aliases":
            continue
        adjacency[edge["source"]["id"]].append(edge["target"]["id"])
    queue: deque[str] = deque([source])
    seen = {source}
    while queue:
        node = queue.popleft()
        if node == target:
            return True
        for next_node in adjacency.get(node, []):
            if next_node not in seen:
                seen.add(next_node)
                queue.append(next_node)
    return False


def build_audit_data(
    records: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    aliases: dict[str, Any],
) -> dict[str, Any]:
    variable_ids = {row["id"] for row in records}
    degree_all = Counter()
    degree_factual = Counter()
    referenced_nodes: dict[str, dict[str, Any]] = {}
    for edge in edges:
        source_id = edge["source"]["id"]
        target_id = edge["target"]["id"]
        referenced_nodes[source_id] = edge["source"]
        referenced_nodes[target_id] = edge["target"]
        degree_all[source_id] += 1
        degree_all[target_id] += 1
        if edge["relation_type"] != "aliases":
            degree_factual[source_id] += 1
            degree_factual[target_id] += 1

    canonical_groups: dict[str, list[str]] = defaultdict(list)
    for record in records:
        canonical_groups[record["canonical_name"]].append(record["id"])
    conflicts = {
        name: sorted(ids)
        for name, ids in canonical_groups.items()
        if len(ids) > 1
    }

    relation_counts = Counter(edge["relation_type"] for edge in edges)
    status_counts = Counter(edge["truth_status"] for edge in edges)
    basis_counts = Counter(edge["evidence_basis"] for edge in edges)
    node_kind_counts = Counter(
        node["kind"] for node in referenced_nodes.values()
    )
    isolated_all = sorted(variable_ids - set(degree_all))
    isolated_factual = sorted(variable_ids - set(degree_factual))
    cycle = find_cycle(edges, CAUSAL_RELATIONS)
    core_reachable = reachable(
        edges,
        "artifact.pysc2.observation",
        "artifact.pysc2.function_call",
    )

    endpoint_ids = set(referenced_nodes)
    broken_variable_references = sorted(
        node_id
        for node_id, node in referenced_nodes.items()
        if node["kind"] == "variable" and node_id not in variable_ids
    )

    return {
        "variables": len(variable_ids),
        "edges": len(edges),
        "nodes": len(referenced_nodes),
        "relation_counts": dict(sorted(relation_counts.items())),
        "truth_status_counts": dict(sorted(status_counts.items())),
        "evidence_basis_counts": dict(sorted(basis_counts.items())),
        "node_kind_counts": dict(sorted(node_kind_counts.items())),
        "isolated_all": isolated_all,
        "isolated_factual": isolated_factual,
        "causal_cycle": cycle,
        "core_observation_to_function_call_reachable": core_reachable,
        "broken_variable_references": broken_variable_references,
        "cross_layer_canonical_conflicts": conflicts,
        "ambiguous_alias_terms": aliases["statistics"][
            "ambiguous_index_terms"
        ],
        "endpoint_ids": len(endpoint_ids),
        "known_lineage_conflict": {
            "source": "action.planned_actions",
            "target": "swm.input.planned_actions",
            "reason": (
                "前者是ResponseParser输出的整数动作数量，后者是传给SWM的动作字典列表；"
                "步骤08按当前代码改用artifact.storm.validated_actions作为直接上游。"
            ),
        },
    }


def relation_definition_table() -> str:
    definitions = {
        "read_from": "目标变量从源接口、配置或静态定义中读取。",
        "transformed_to": "源数据经过非纯存储的转换形成目标。",
        "normalized_as": "源编码按明确归一化公式形成目标比例量。",
        "aggregated_into": "一个或多个源值通过计数、均值、比率或统计公式汇总成目标。",
        "stored_as": "源值被复制、重命名、序列化或嵌入目标结构。",
        "used_by": "源变量或数据结构被目标组件消费。",
        "validated_by": "源响应或字段由目标校验器检查和修正。",
        "mapped_to": "STORM动作语义被映射成PySC2 FunctionCall字段或编号。",
        "predicts": "源状态、动作或预测器产生未来状态预测。",
        "evaluated_by": "预测结果由目标误差或准确率指标评估。",
        "aliases": "自然语言规范化词可检索到目标变量；属于结构性索引关系。",
    }
    return "\n".join(
        f"| `{relation}` | {definitions[relation]} |"
        for relation in RELATION_TYPES
    )


def build_doc(audit: dict[str, Any]) -> str:
    relation_rows = "\n".join(
        f"| `{name}` | {count} |"
        for name, count in audit["relation_counts"].items()
    )
    return f"""# 步骤 08：变量关系图

- 报告日期：{DATE}
- 范围：当前STORM主路径实际使用的135条变量
- 机器边表：`knowledge/relations/variable_relations.jsonl`
- 运行边界：SC2运行未执行；外部LLM/SWM未调用；实验复现未执行

## 1. 一句话结论

当前知识库已经把“变量卡片”连接为可追踪的有向图：既能沿
`PySC2 observation → RawUnit → ABox/BattlefieldGraph → Prompt → Parser → ActionExecutor → FunctionCall`
查动作链，也能沿
`ABox + 候选动作 → SWM预测 → 预测误差指标`
查预测链。源码能证明的是数据读取、转换和调用路径；真实SC2值、模型输出和游戏引擎执行结果仍需运行验证。

## 2. 关系类型

| 关系 | 含义 |
|---|---|
{relation_definition_table()}

## 3. Mermaid总览

```mermaid
flowchart LR
    OBS["PySC2 observation"] -->|read_from| RAW["RawUnit / player / score"]
    TBOX["TBox静态定义"] -->|stored_as| ABOX["ABox / BattlefieldGraph"]
    RAW -->|normalized_as / stored_as| ABOX
    ABOX -->|aggregated_into| TACT["战术派生状态"]
    TACT -->|used_by| PROMPT["STORM决策Prompt"]
    ABOX -->|used_by| PROMPT
    PROMPT -->|transformed_to| LLM["LLM响应"]
    LLM -->|validated_by| PARSER["ResponseParser"]
    PARSER -->|stored_as| ACT["校验后动作"]
    ACT -->|stored_as| DELAY["pending_actions"]
    ACT -->|mapped_to| FC["PySC2 Raw FunctionCall"]
    DELAY -->|used_by| FC
    ABOX -->|stored_as| SWMIN["SWM ABox输入"]
    ACT -->|stored_as| SWMIN
    SWMIN -->|predicts| SWMOUT["SWM预测"]
    SWMOUT -->|evaluated_by| METRIC["SWM误差指标"]
    SCORE["TimeStep累计得分"] -->|aggregated_into| METRIC2["实验指标"]
```

## 4. 边表结构

JSONL每行是一条完整关系，核心字段包括：

- `id`：由源ID、关系类型和目标ID计算的稳定关系ID；
- `source` / `target`：节点ID、节点类型、层级和变量类别；
- `relation_type`：本步骤定义的11类关系之一；
- `evidence_basis`：`source_evidence`或`structural_index`；
- `truth_status`：`code_reality`、`design_intent`、`runtime_observation`、`needs_verification`或不适用；
- `evidence`：仓库相对路径、符号和可稳定取得的行号；
- `formulas` / `limitations`：转换公式和事实边界。

## 5. 关系统计

| 关系 | 边数 |
|---|---:|
{relation_rows}

总计：{audit['variables']}条正式变量、{audit['nodes']}个图节点、{audit['edges']}条边。

## 6. 关键查询示例

### “单位当前血量最后在哪里使用？”

```text
artifact.pysc2.observation
  → raw_unit.health
  → abox.unit.hp
  → derived.tactical.friendly_avg_hp / enemy_avg_hp
  → derived.tactical.health_status
  → STORM决策Prompt
```

### “动作怎样变成PySC2调用？”

```text
LLM response
  → ResponseParser
  → action.type / units / target / subtype
  → ActionExecutor
  → pysc2.*.function_id + unit_tags + target + queued + raw_flag
  → artifact.pysc2.function_call
```

### “SWM误差从哪里来？”

```text
ABox序列化状态 + 校验后动作列表 + prediction_steps
  → SWM raw_response
  → predictions / predicted_unit_states / predicted_relations
  → health_rmse / position_rmse / relation_accuracy
  → overall_error
```

## 7. 可信边界

- `code_reality`：当前源码明确存在读取、转换、校验或构造路径；
- `design_intent`：只代表设计或文档意图，不能冒充当前实现；
- `runtime_observation`：需要实际运行产生的观测证据；步骤08没有此类证据；
- `needs_verification`：LLM/SWM输出、SC2引擎执行、外部接口语义或运行值尚未验证；
- `aliases`边只是检索索引，不代表物理量之间存在因果关系。

## 8. 重要冲突：planned_actions不是同一种量

`action.planned_actions`是ResponseParser返回的**整数动作数量**；`swm.input.planned_actions`
是传给SWM的**动作字典列表**。当前代码实际传入`initial_parsed["actions"]`。因此关系图没有把整数计数
直接当成SWM动作列表，而是通过`artifact.storm.validated_actions`连接，并在审计报告中保留上游血缘冲突。

## 9. 使用建议

LLM Agent查询变量时，应先用`aliases`定位候选变量，再沿事实边回答上游、下游、公式和源码依据。
歧义别名不能静默选一个；`needs_verification`边不能描述成“已经在SC2中验证成功”。
"""


def build_audit_report(audit: dict[str, Any]) -> str:
    relation_rows = "\n".join(
        f"| `{name}` | {count} |"
        for name, count in audit["relation_counts"].items()
    )
    node_rows = "\n".join(
        f"| `{name}` | {count} |"
        for name, count in audit["node_kind_counts"].items()
    )
    status_rows = "\n".join(
        f"| `{name}` | {count} |"
        for name, count in audit["truth_status_counts"].items()
    )
    conflicts = "\n".join(
        f"- `{name}`：{', '.join(f'`{item}`' for item in ids)}"
        for name, ids in audit["cross_layer_canonical_conflicts"].items()
    ) or "- 无"
    cycle_text = (
        " → ".join(audit["causal_cycle"])
        if audit["causal_cycle"]
        else "未发现"
    )
    return f"""# 步骤 08：变量关系图审计

- 审计日期：{DATE}
- 审计方式：离线静态解析JSONL和有向图检查
- SC2运行：未执行
- 外部LLM/SWM：未调用
- 实验复现：未执行

## 1. 验收摘要

| 检查项 | 结果 |
|---|---|
| 正式变量数量 | {audit['variables']} |
| 图节点数量 | {audit['nodes']} |
| 关系边数量 | {audit['edges']} |
| observation到FunctionCall可达 | {'通过' if audit['core_observation_to_function_call_reachable'] else '失败'} |
| 全图孤立正式变量 | {len(audit['isolated_all'])} |
| 排除aliases后的孤立正式变量 | {len(audit['isolated_factual'])} |
| 损坏的变量引用 | {len(audit['broken_variable_references'])} |
| 因果转换子图循环 | {cycle_text} |
| 歧义别名索引词 | {audit['ambiguous_alias_terms']} |

## 2. 关系类型统计

| 关系 | 边数 |
|---|---:|
{relation_rows}

## 3. 节点类型统计

| 节点类型 | 数量 |
|---|---:|
{node_rows}

## 4. 事实状态统计

| 状态 | 边数 |
|---|---:|
{status_rows}

当前没有`runtime_observation`边，因为步骤08没有运行SC2、LLM、SWM或实验。

## 5. 孤立项和断链

- 全图孤立正式变量：{audit['isolated_all'] or '无'}；
- 排除纯别名索引后的孤立正式变量：{audit['isolated_factual'] or '无'}；
- 不存在的正式变量引用：{audit['broken_variable_references'] or '无'}；
- 核心链路已从`artifact.pysc2.observation`静态追踪到`artifact.pysc2.function_call`。

注意：这里的“可达”只表示当前代码结构存在路径，不表示SC2引擎已经接受或成功执行动作。

## 6. 循环依赖

因果转换子图仅检查`read_from`、`transformed_to`、`normalized_as`、`aggregated_into`、
`stored_as`、`validated_by`、`mapped_to`、`predicts`和`evaluated_by`，结果为：{cycle_text}。
`aliases`是检索索引，`used_by`是消费关系，不参与数值因果循环判定。

## 7. 跨层同名冲突

以下规范字段名出现在多个正式变量层，检索时不能只按短名称合并：

{conflicts}

此外，`action.planned_actions`与`swm.input.planned_actions`存在更强的接口冲突：
前者是整数计数，后者是动作列表。步骤06血缘表把二者直接关联，但当前源码实际传递
`initial_parsed["actions"]`。步骤08已使用`artifact.storm.validated_actions`表示真实上游，
没有把整数计数伪装成动作列表。

## 8. 仍需验证

1. RawUnit索引和FunctionCall编号尚未对当前PySC2 ActionSpec做运行时核验；
2. TBox Python定义与`data/ontology/ontology_graph.pkl`缓存可能不同步；
3. ABox `armor/armor_ratio`当前代码实际保存RawUnit `shield/shield_ratio`；
4. 外部LLM和SWM没有调用，预测内容、置信度和token用量没有运行值；
5. FunctionCall只确认构造路径，未启动SC2验证执行结果；
6. 指标只确认公式和写出接口，没有重新执行实验。

## 9. 审计结论

- [x] JSONL设计为每行一条完整关系；
- [x] 11类关系均有明确定义；
- [x] 核心观测到动作执行链静态可达；
- [x] 每条边有源码证据或标记为结构性索引；
- [x] 孤立变量、断链、循环和跨层同名冲突均进入检查；
- [x] 所有产物位于`knowledge/`；
- [ ] SC2运行时验证：未执行；
- [ ] 外部LLM/SWM验证：未执行；
- [ ] 实验复现：未执行。
"""


def main() -> None:
    records, lineage, aliases = load_inputs()
    records_by_id = {row["id"]: row for row in records}
    if len(records) != 135 or len(records_by_id) != 135:
        raise ValueError(
            f"步骤08要求135条唯一正式变量，实际records={len(records)}, "
            f"unique={len(records_by_id)}"
        )
    if set(records_by_id) != set(lineage):
        raise ValueError("步骤05变量ID与步骤06血缘ID不一致")

    builder = EdgeBuilder(records_by_id, lineage)

    # 每个变量先连接到其当前代码/接口来源。
    for record in records:
        source_artifact = source_artifact_for(record)
        if source_artifact:
            source_id, source_label = source_artifact
            lr = lineage[record["id"]]
            builder.add(
                "read_from",
                endpoint(
                    source_id,
                    (
                        "component"
                        if source_id.startswith("component.")
                        else "artifact"
                    ),
                    label=source_label,
                    layer=(
                        "pipeline_component"
                        if source_id.startswith("component.")
                        else lr["taxonomy_source_layer"]
                    ),
                ),
                builder.variable(record["id"]),
                f"{record['id']}从{source_label}读取或声明。",
                evidence=evidence_from_record(record, lr),
                formulas=record["implementation"].get(
                    "transformation_formula", []
                ),
                limitations=record.get("limitations", []),
                status=truth_status(lr),
            )

    # 从步骤05/06上游ID生成变量到变量的数据流边。
    skipped_lineage_edge = (
        "action.planned_actions",
        "swm.input.planned_actions",
    )
    for record in records:
        target_id = record["id"]
        lr = lineage[target_id]
        for source_id in lr["provenance"].get(
            "upstream_variable_ids", []
        ):
            if (source_id, target_id) == skipped_lineage_edge:
                continue
            source_node = (
                builder.variable(source_id)
                if source_id in records_by_id
                else builder.node(source_id)
            )
            relation_type = relation_for_upstream(record)
            builder.add(
                relation_type,
                source_node,
                builder.variable(target_id),
                f"{target_id}由上游{source_id}产生。",
                evidence=evidence_from_record(record, lr),
                formulas=lr["provenance"].get(
                    "transformation_formula", []
                ),
                limitations=record.get("limitations", []),
                status=truth_status(lr),
            )

    # 步骤06漏记了shield_ratio的直接编码上游，按当前parse_raw_units源码补建。
    builder.add(
        "normalized_as",
        endpoint(
            "pysc2.raw_unit.index_8",
            "interface_field",
            label="obs.observation.raw_units[*][8]",
            layer="raw_observation",
        ),
        builder.variable("raw_unit.shield_ratio"),
        "RawUnit索引8除以255后保存为shield_ratio。",
        evidence=evidence_from_record(
            records_by_id["raw_unit.shield_ratio"],
            lineage["raw_unit.shield_ratio"],
        ),
        formulas=["shield_ratio = unit[8] / 255"],
        status="code_reality",
        limitations=[
            "当前只确认STORM代码索引和除法，未对PySC2官方字段编码做外部核验。"
        ],
    )

    # 只保留真正不同于生产位置的消费位置，避免把“定义自己的函数”误写成消费者。
    for record in records:
        producer_keys = {
            (item.get("path"), item.get("symbol"))
            for item in record["implementation"].get(
                "source_locations", []
            )
        }
        for consumer in record.get("consumers", []):
            consumer_key = (
                consumer.get("path"),
                consumer.get("symbol"),
            )
            if consumer_key in producer_keys:
                continue
            component_id = safe_component_id(
                str(consumer.get("path") or "unknown"),
                str(consumer.get("symbol") or consumer.get("name") or "unknown"),
            )
            builder.add(
                "used_by",
                builder.variable(record["id"]),
                endpoint(
                    component_id,
                    "component",
                    label=str(
                        consumer.get("symbol")
                        or consumer.get("name")
                        or component_id
                    ),
                    layer="pipeline_component",
                ),
                f"{record['id']}由{consumer.get('symbol') or consumer.get('name')}消费。",
                evidence=manual_evidence(
                    str(consumer.get("path") or ""),
                    str(
                        consumer.get("symbol")
                        or consumer.get("name")
                        or ""
                    ),
                ),
            )

    add_manual_core_edges(builder, records, lineage)
    add_swm_and_metric_edges(builder, records, lineage)
    add_alias_edges(builder, aliases)

    edges = builder.finalize()
    audit = build_audit_data(records, edges, aliases)

    RELATIONS_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    AUDIT_OUT.parent.mkdir(parents=True, exist_ok=True)
    RELATIONS_OUT.write_text(
        "\n".join(
            json.dumps(edge, ensure_ascii=False, sort_keys=True)
            for edge in edges
        )
        + "\n",
        encoding="utf-8",
    )
    DOC_OUT.write_text(build_doc(audit), encoding="utf-8")
    AUDIT_OUT.write_text(build_audit_report(audit), encoding="utf-8")

    print(f"variables: {audit['variables']}")
    print(f"nodes: {audit['nodes']}")
    print(f"edges: {audit['edges']}")
    for relation_type in RELATION_TYPES:
        print(
            f"relation.{relation_type}: "
            f"{audit['relation_counts'].get(relation_type, 0)}"
        )
    print(
        "core_observation_to_function_call_reachable: "
        f"{audit['core_observation_to_function_call_reachable']}"
    )
    print(f"isolated_all: {len(audit['isolated_all'])}")
    print(f"isolated_factual: {len(audit['isolated_factual'])}")
    print(
        "causal_cycle: "
        f"{' -> '.join(audit['causal_cycle']) if audit['causal_cycle'] else 'none'}"
    )


if __name__ == "__main__":
    main()
