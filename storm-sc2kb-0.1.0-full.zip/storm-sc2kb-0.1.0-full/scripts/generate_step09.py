"""生成步骤09机器清单和中文文档。"""
from collections import Counter, defaultdict
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]
K = ROOT / "knowledge"
YAML_OUT = K / "known_issues.yaml"
DOC_OUT = K / "docs" / "09_known_issues.md"
DATE = "2026-09-04"


def ev(path, symbol, start, end, claim):
    lines = (ROOT / path).read_text(encoding="utf-8").splitlines()
    a = next(i for i, x in enumerate(lines) if start in x)
    b = next(i for i in range(a, len(lines)) if end in lines[i])
    return {"path": path, "symbol": symbol, "line_start": a + 1,
            "line_end": b + 1, "claim": claim}


def add(slug, title, kind, severity, truth, phenomenon, explanation,
        expected, current, variables, evidence, constraint, risk, method,
        steps, success, limitations, fields=None):
    issues.append({
        "id": "issue." + slug, "title_zh": title, "issue_type": kind,
        "severity": severity, "truth_status": truth, "status": "open",
        "phenomenon": phenomenon, "concise_explanation": explanation,
        "expected_or_documented_behavior": expected,
        "current_implementation": current,
        "affected_variable_ids": sorted(variables),
        "affected_noncanonical_fields": sorted(fields or []), "evidence": evidence,
        "impact": {"knowledge_answer_constraint": constraint, "code_or_experiment_risk": risk},
        "recommended_verification": {"method": method, "execution_status": "not_executed",
            "steps": steps, "success_criteria": success}, "limitations": limitations})


issues = []

add("abox_armor_stores_shield", "ABox armor 字段实际保存 shield", "implementation_quirk", "high", "code_reality",
    "ABox 的 armor/armor_ratio 由 shield/shield_ratio 赋值。", "字段名称表达护甲，但当前数值语义是护盾。",
    "armor 应保存护甲；若保存护盾应采用 shield 语义。", "创建和更新 ABox 时均使用 shield 映射。",
    ["abox.unit.armor", "abox.unit.armor_ratio", "raw_unit.shield", "raw_unit.shield_ratio"],
    [ev("ontology/bridge.py", "BattlefieldGraph._add_unit_instance", '"armor": raw_unit.get("shield", 0)', '"armor_ratio": raw_unit.get("shield_ratio", 0)', "创建路径把 shield 写入 armor。"),
     ev("ontology/bridge.py", "BattlefieldGraph._update_unit_instance", "self.abox.nodes[instance_node_id].update(", '"armor_ratio": raw_unit.get("shield_ratio", 0)', "更新路径沿用同一映射。")],
    "必须说明当前 ABox armor 实际是 shield，不能解释为 SC2 护甲。", "论文或代码可能错误解释物理量。", "static_unit_test",
    ["构造 shield 非零的 raw_unit。", "检查 ABox 创建和更新结果。"], "字段命名、文档语义和数据源一致。", ["未启动 SC2。"])

add("action_coordinate_clip_not_written_back", "坐标裁剪结果未写回 action.target", "confirmed_bug", "high", "code_reality",
    "np.clip 只修改局部 x/y，没有更新动作对象。", "越界坐标看似被裁剪，后续仍可能收到原始 target。",
    "裁剪值应写回 action['target']，或明确拒绝越界动作。", "代码计算 x/y 后直接返回 True。",
    ["action.target", "pysc2.function.target"],
    [ev("agents/response_parser.py", "ResponseParser._validate_semantics", "x = np.clip(x, MAP_MIN, MAP_MAX)", "y = np.clip(y, MAP_MIN, MAP_MAX)", "局部裁剪值未写回 action['target']。")],
    "不得声称 Parser 已把越界坐标修正后传给执行器。", "越界参数可能进入转换或执行阶段。", "static_unit_test",
    ["提交 target=[-1,80]。", "检查校验后动作对象中的 target。"], "通过校验的动作实际携带 [0,63]，或被明确拒绝。", ["测试未执行。"])

add("action_priority_not_validated_or_consumed", "priority 声明存在但未校验或调度", "documentation_mismatch", "medium", "code_reality",
    "VALID_PRIORITIES 已定义，README 称会校验，但当前验证和执行链未读取 priority。", "priority 更接近设计字段，而不是已生效的调度量。",
    "priority 应限制为 high/medium/low 并有明确消费点。", "常量和文档承诺存在，主路径未见强制校验或排序。", ["action.priority"],
    [ev("agents/response_parser.py", "VALID_PRIORITIES", "VALID_PRIORITIES =", "VALID_PRIORITIES =", "允许值常量已声明。"),
     ev("agents/README.md", "ResponseParser semantic validation", "`priority` is in {high, medium, low}", "`priority` is in {high, medium, low}", "README 声称会校验。")],
    "不得说 priority 当前会被强制校验或决定执行顺序。", "错误值不会被拒绝，调度语义可能被误读。", "static_unit_test",
    ["输入 priority='urgent'。", "跟踪解析结果和执行顺序。"], "非法值被拒绝且有消费逻辑，或文档明确未使用。", ["结论来自静态搜索。"])

add("build_train_dual_representation", "BUILD/TRAIN 动作表示形式不一致", "documentation_mismatch", "high", "code_reality",
    "提示示例使用 BUILD-Barracks/TRAIN-Marine，Schema 又列 BUILD/TRAIN；执行器依赖 subtype。", "纯 BUILD/TRAIN 若不另给 subtype，不能满足当前执行链。",
    "提示、Schema、Parser、Executor 应统一一种规范。", "Parser 拆分连字符形式；ActionExecutor 读取并要求 subtype。", ["action.subtype", "action.type"],
    [ev("ontology/prompt_template.py", "ACTION_TYPES", "BUILD-<building_type>", "TRAIN-<unit_type>", "动作说明使用连字符形式。"),
     ev("agents/response_parser.py", "ResponseParser._validate_schema", 'if "-" in action["action"]', 'action["subtype"] = rich_action[1]', "Parser 将连字符动作拆为 action 与 subtype。"),
     ev("agents/action_executor.py", "ActionExecutor.execute_actions", 'subtype = action.get("subtype", "")', "if subtype not in BUILD_CALLS:", "执行器读取并要求 subtype。")],
    "推荐写 BUILD-Barracks/TRAIN-Marine，或显式提供 subtype；不能说纯动作名一定足够。", "模型照 Schema 生成纯动作名时可能失败。", "static_unit_test",
    ["比较 BUILD、BUILD-Barracks、BUILD+subtype。", "对 TRAIN 重复测试。"], "四处接口使用同一规范并有回归测试。", ["未启动 SC2。"])

add("function_ids_require_runtime_actionspec_check", "硬编码 FunctionCall ID 尚未核验", "needs_runtime_test", "high", "needs_verification",
    "ActionExecutor 硬编码 NO_OP/MOVE/ATTACK/BUILD/TRAIN 函数编号。", "静态代码只能确认这些值被使用，不能证明与当前 ActionSpec 一致。",
    "应从当前 PySC2/SC2 ActionSpec 核对 ID、名称和参数签名。", "执行器直接用常量构造 FunctionCall。",
    ["pysc2.attack.function_id", "pysc2.build.function_id", "pysc2.move.function_id", "pysc2.no_op.function_id", "pysc2.train.function_id"],
    [ev("agents/action_executor.py", "BUILD_CALLS/TRAIN_CALLS", 'BUILD_CALLS = {', '"Marine": 511', "BUILD/TRAIN 函数编号以常量形式硬编码。"),
     ev("agents/action_executor.py", "ActionExecutor.execute_actions", "sc2_actions.FunctionCall.init_with_validation(0", "3, arguments=args, raw=True", "NO_OP、MOVE、ATTACK 调用使用数值 ID 0、13、3。")],
    "回答 ID 时须标注为当前源码硬编码值、尚未运行核验。", "版本或动作可用性差异可能导致无效调用。", "runtime_sc2_test",
    ["启动 Raw API 环境。", "读取 ActionSpec。", "逐项比对并做最小冒烟测试。"], "所有 ID 与参数签名匹配且调用可被环境接受。", ["本步骤未启动 SC2。"])

add("main_confidence_documented_but_disabled", "主决策 confidence 文档声明但实现停用", "documentation_mismatch", "medium", "code_reality",
    "README 仍称 confidence 必填且校验范围，Parser 返回和校验代码已注释。", "主决策 confidence 不是步骤05正式动作变量，也不同于 swm.confidence。",
    "文档与代码应统一决定是否保留和校验该字段。", "主解析与消融解析均不返回该字段。", [],
    [ev("agents/README.md", "ResponseParser schema validation", "Required fields present (reasoning, confidence, actions)", "Confidence is float in [0.0, 1.0]", "README 声称必填并校验。"),
     ev("agents/response_parser.py", "ResponseParser.parse_response", '# "confidence": json_data.get("confidence", 0.5)', '# "confidence": json_data.get("confidence", 0.5)', "主解析返回已注释。"),
     ev("agents/raw_agent.py", "RawAgent._parse_response_without_validation", '# "confidence": float(json_data.get("confidence", 0.5) or 0.5)', '# "confidence": float(json_data.get("confidence", 0.5) or 0.5)', "消融解析返回也已注释。")],
    "不能虚构 action.confidence；必须区分 decision_response.confidence 与 swm.confidence。", "下游按 README 取键时可能缺失。", "static_unit_test",
    ["解析带/不带 confidence 的响应。", "根据设计决策同步实现、README 和变量表。"], "代码、README、知识库对字段存在性一致。", ["没有对应正式变量 ID。"], ["decision_response.confidence"])

add("ontology_pickle_may_be_stale", "TBox pickle 可能与 Python 定义不同步", "needs_runtime_test", "medium", "needs_verification",
    "OntologyLoader 默认在 pickle 存在时优先加载，未自动比对源码定义。", "修改本体定义后若未重建缓存，运行时可能继续使用旧 TBox。",
    "缓存应有一致性检查或版本标记。", "reload(use_pickle=True) 只在 pickle 不存在时重建。", ["tbox.entity.armor", "tbox.entity.hp"],
    [ev("ontology/loader.py", "OntologyLoader.reload", "if use_pickle and Path(pickle_path).exists()", "self._graph = build_ontology_graph()", "存在 pickle 时优先加载。")],
    "回答 TBox 数值时应披露缓存来源；未比对前不能断言与 Python 定义同步。", "静态属性和 BUILD/TRAIN 校验可能使用陈旧值。", "cache_consistency_check",
    ["分别加载 pickle 与源码重建图。", "规范化后输出节点、边和属性差异。"], "两图一致，或缓存可追溯且变更时自动重建。", ["离线检查未执行。"])

add("swm_confidence_not_a_gate", "SWM confidence 被规范化但不是硬阈值门控", "implementation_quirk", "medium", "code_reality",
    "confidence 缺失时默认 0.5 并裁剪到 0..1；RawAgent 记录它，但未见阈值分支。", "该值当前是预测元数据，不是自动决定采用预测的开关。",
    "若需要门控，应定义阈值、分支和日志。", "校验器规范化 confidence；非数值字符串还可能触发 float 异常。", ["swm.confidence"],
    [ev("ontology/swm_predictor.py", "SWMPredictor._validate_prediction", 'if "confidence" not in parsed', 'parsed["confidence"] = max(0.0, min(1.0, float(parsed["confidence"])))', "confidence 有默认和裁剪，但直接 float 转换。"),
     ev("agents/raw_agent.py", "RawAgent._run_swm_prediction", 'SWM预测成功, confidence=', 'SWM预测成功, confidence=', "RawAgent 在成功日志中读取该值。")],
    "只能说它被默认、裁剪、记录和传递；不得声称存在采用阈值。", "可能被误当成安全门控；格式漂移也可能引发转换异常。", "static_unit_test",
    ["测试 0、0.5、1 和非数值输入。", "跟踪后续路径是否因阈值改变。"], "门控可测试或文档明确仅为元数据；非法类型被结构化处理。", ["未调用外部 SWM。"])

add("swm_error_uses_future_state_as_baseline", "SWM health/position 误差基线错误", "confirmed_bug", "critical", "code_reality",
    "误差函数用 actual(t+1) 同时构造预测值和真实值。", "health 误差退化为 delta²，position 误差退化为预测位移模长。",
    "预测绝对值应由 t 状态加 delta，再与 t+1 真值比较。", "函数没有接收 t 时刻单位基线。",
    ["metric.swm.health_rmse", "metric.swm.overall_error", "metric.swm.position_rmse"],
    [ev("ontology/swm_predictor.py", "SWMPredictor.compute_prediction_error", 'pred_hp = actual.get("hp", 100) + pred_unit.get("health_delta", 0)', 'actual_pos = [actual.get("x", 0), actual.get("y", 0)]', "health 与 position 都从 actual_state 构造预测值。"),
     ev("agents/raw_agent.py", "RawAgent._record_swm_ground_truth", "units_snapshot =", "self.trajectory_collector.record_next_state(next_abox, units_snapshot)", "训练器记录下一帧快照。")],
    "不得称这些值为严格未来状态 RMSE；须提示基线缺陷及其传播到 overall_error。", "实验指标可能无法反映真实预测误差。", "static_unit_test",
    ["构造 t、delta、t+1 的已知样例。", "手算并回归三个指标。"], "误差等于预测未来绝对状态与 t+1 真值之差。", ["未重跑历史实验。"])

add("swm_relation_accuracy_is_prediction_precision", "relation_accuracy 更接近预测关系命中率", "implementation_quirk", "high", "code_reality",
    "指标只以预测关系为分母；不惩罚漏报，空预测返回 1.0，当前真值快照 relations 为空。", "它不等同于覆盖假阴性的完整关系准确率。",
    "应明确 precision/recall/F1 或定义空集合与漏报规则。", "实现遍历 predicted_relations；无预测时保留 1.0。",
    ["metric.swm.overall_error", "metric.swm.relation_accuracy"],
    [ev("ontology/swm_predictor.py", "SWMPredictor.compute_prediction_error", "relation_correct = 0", "relation_accuracy = relation_correct / relation_total if relation_total > 0 else 1.0", "只用预测关系作分母且空预测为 1.0。"),
     ev("agents/raw_agent.py", "RawAgent._record_swm_ground_truth", '"relations": [],', '"relations": [],', "当前下一帧关系真值为空。")],
    "应称预测关系命中比例，并披露空预测=1.0与当前真值为空。", "overall_error 可能偏乐观。", "static_unit_test",
    ["构造命中、误报、漏报和空预测案例。", "比较 precision/recall/F1。"], "指标名、公式和空集合规则一致。", ["未重跑 SWM 实验。"])

add("unknown_unit_hp_default_is_static_only", "未知单位 hp=100 不覆盖实时 health", "implementation_quirk", "low", "code_reality",
    "UNKNOWN_UNIT_DEFAULTS 定义 hp=100，但 ABox hp 仍读取 raw_unit['health']。", "100 是未知类型静态占位，不是动态生命值覆盖。",
    "静态默认与动态观测应明确分层。", "合并 static_info 后，instance_attrs.hp 单独使用实时 health。",
    ["abox.unit.hp", "raw_unit.health", "tbox.entity.hp"],
    [ev("ontology/bridge.py", "UNKNOWN_UNIT_DEFAULTS", '"hp": 100', '"hp": 100', "未知类型静态默认 hp 为 100。"),
     ev("ontology/bridge.py", "BattlefieldGraph._add_unit_instance", 'static_info = {"name": unit_name, **UNKNOWN_UNIT_DEFAULTS}', '"hp": raw_unit["health"]', "ABox 动态 hp 读取实时 health。")],
    "不能说未知单位生命值总被设为100；要解释静态占位和动态 hp 的层次。", "混淆两层会错误判断未知单位状态。", "static_unit_test",
    ["构造未知类型且 health=37。", "断言 ABox hp=37。"], "动态 hp 保持实时值，静态占位仍可保留。", ["结论来自静态赋值路径。"])


def payload():
    ordered = sorted(issues, key=lambda x: x["id"])
    vi, fi = defaultdict(list), defaultdict(list)
    for item in ordered:
        for variable_id in item["affected_variable_ids"]: vi[variable_id].append(item["id"])
        for field in item["affected_noncanonical_fields"]: fi[field].append(item["id"])
    return {"knowledge_base": "storm-sc2kb-v1-raw", "schema_version": "1.0.0", "generated_at": DATE,
        "status": "static_known_issues_recorded", "scope": "当前 STORM 主路径使用的 PySC2 Raw API 变量及直接转换、动作、SWM 与指标。",
        "runtime_boundary": {"sc2_executed": False, "external_llm_or_swm_called": False, "experiments_reexecuted": False, "statement": "仅执行静态源码审计和离线校验。"},
        "truth_status_definitions": {"design_intent": "注释、提示或文档表达的预期。", "code_reality": "由当前源码控制流或赋值路径直接确认。", "runtime_observation": "实际运行观测；本步骤未新增。", "needs_verification": "静态证据不足，必须按建议方式确认。"},
        "issue_types": ["confirmed_bug", "implementation_quirk", "documentation_mismatch", "needs_runtime_test"],
        "severity_levels": ["critical", "high", "medium", "low"],
        "statistics": {"issue_count": len(ordered), "by_type": dict(sorted(Counter(x["issue_type"] for x in ordered).items())), "by_severity": dict(sorted(Counter(x["severity"] for x in ordered).items())), "affected_variable_count": len(vi), "affected_noncanonical_field_count": len(fi)},
        "issues": ordered, "variable_issue_index": [{"variable_id": k, "issue_ids": sorted(v)} for k, v in sorted(vi.items())],
        "noncanonical_field_issue_index": [{"field": k, "issue_ids": sorted(v)} for k, v in sorted(fi.items())]}


def markdown(data):
    labels = {"confirmed_bug": "确认缺陷", "implementation_quirk": "实现特性/陷阱", "documentation_mismatch": "文档不一致", "needs_runtime_test": "待运行验证"}
    out = ["# 步骤 09：实现差异、限制与已知问题", "", "> 生成日期：" + DATE, "> 范围：仅限当前 STORM 主路径使用的 Raw API 变量及直接下游。", "> 未启动 SC2、未调用外部 LLM/SWM、未重跑实验；结论以静态审计为主。", "", "## 使用方法", "", "回答变量问题时先查 knowledge/known_issues.yaml 的 variable_issue_index。命中后必须给出当前代码现实、限制和证据；needs_runtime_test 不得写成已验证事实。", "", "## 总览", "", "| ID | 类型 | 严重度 | 题目 |", "|---|---|---|---|"]
    for x in data["issues"]: out.append("| " + x["id"] + " | " + labels[x["issue_type"]] + " | " + x["severity"] + " | " + x["title_zh"] + " |")
    for kind in data["issue_types"]:
        out += ["", "## " + labels[kind], ""]
        for x in [z for z in data["issues"] if z["issue_type"] == kind]:
            vars_text = "、".join(x["affected_variable_ids"]) or "无正式变量 ID"
            out += ["### " + x["title_zh"], "", "- 稳定 ID：" + x["id"], "- 严重度 / 可信状态：" + x["severity"] + " / " + x["truth_status"], "- 涉及正式变量：" + vars_text]
            if x["affected_noncanonical_fields"]: out.append("- 涉及非正式字段：" + "、".join(x["affected_noncanonical_fields"]))
            out += ["- 现象：" + x["phenomenon"], "- 简明解释：" + x["concise_explanation"], "- 文档或预期行为：" + x["expected_or_documented_behavior"], "- 当前实现：" + x["current_implementation"], "- 知识库回答约束：" + x["impact"]["knowledge_answer_constraint"], "- 代码/实验风险：" + x["impact"]["code_or_experiment_risk"], "- 证据依据："]
            for e in x["evidence"]: out.append("  - " + e["path"] + ":" + str(e["line_start"]) + "-" + str(e["line_end"]) + "，" + e["symbol"] + "：" + e["claim"])
            v = x["recommended_verification"]
            out.append("- 建议验证（" + v["method"] + "，当前 " + v["execution_status"] + "）：")
            out += ["  " + str(i) + ". " + step for i, step in enumerate(v["steps"], 1)]
            out += ["- 通过标准：" + v["success_criteria"], "- 限制：" + "；".join(x["limitations"]), ""]
    out += ["## 未执行声明", "", "本步骤没有启动 StarCraft II、访问外部账号、调用 LLM/SWM、重跑实验或修改 STORM 业务源码。所有建议验证项均为 not_executed。", "", "## 维护规则", "", "1. 修复代码后先更新机器文件，再重建本文。", "2. 保留稳定 ID，用 status 管理生命周期。", "3. 同步维护 affected_variable_ids 与 variable_issue_index。", "4. 行号可能漂移，引用时同时保留路径、符号和结论。", ""]
    return "\n".join(out)


def main():
    data = payload()
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    YAML_OUT.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=120), encoding="utf-8")
    DOC_OUT.write_text(markdown(data), encoding="utf-8")
    print("generated:", YAML_OUT.relative_to(ROOT))
    print("generated:", DOC_OUT.relative_to(ROOT))
    print("issues:", len(data["issues"]))


if __name__ == "__main__":
    main()
