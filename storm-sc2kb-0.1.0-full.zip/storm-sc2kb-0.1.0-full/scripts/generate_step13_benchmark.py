"""确定性生成步骤 13 benchmark，不调用外部模型。"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
KNOWLEDGE = ROOT / "knowledge"
SOURCE = KNOWLEDGE / "context" / "variables.jsonl"
DEV_PATH = KNOWLEDGE / "evals" / "questions_dev.jsonl"
TEST_PATH = KNOWLEDGE / "evals" / "questions_test.jsonl"

# spec: split, slug, question, language, question_type, evaluation category,
# difficulty, expected ids, intents, expected behavior/status, forbidden claims.
SPECS: list[dict[str, Any]] = []


def add(split: str, slug: str, question: str, language: str, question_type: str,
        category: str, difficulty: str, ids: list[str], intents: list[str],
        behavior: str = "answer", status: str = "found",
        forbidden: list[str] | None = None, notes: str = "",
        extra_facts: list[dict[str, Any]] | None = None) -> None:
    SPECS.append({
        "split": split, "slug": slug, "question": question, "language": language,
        "question_type": question_type, "category": category, "difficulty": difficulty,
        "ids": ids, "intents": intents, "behavior": behavior, "status": status,
        "forbidden": forbidden or [], "notes": notes, "extra_facts": extra_facts or [],
    })


# -------------------- development: 36 --------------------
add("dev", "raw-health-meaning", "RawUnit 的 health 表示什么？请给出接口和源码依据。", "zh", "direct", "explanation", "easy", ["raw_unit.health"], ["retrieval", "meaning", "interface", "source_location"], forbidden=["把 health 解释成最大生命值", "把 health_ratio 当成绝对 health", "声称已启动 SC2 验证"])
add("dev", "raw-shield-meaning", "单位当前护盾值在 RawUnit 中对应哪个变量？", "zh", "direct", "retrieval", "easy", ["raw_unit.shield"], ["retrieval", "meaning", "source_location"], forbidden=["把 shield 解释成 armor"])
add("dev", "raw-unit-type-interface", "raw_unit.unit_type 的接口形式和提取位置是什么？", "zh", "direct", "interface", "easy", ["raw_unit.unit_type"], ["retrieval", "interface", "source_location"])
add("dev", "raw-alliance-specific", "只讨论 RawUnit 层：alliance 的含义和代码来源是什么？", "zh", "direct", "explanation", "easy", ["raw_unit.alliance"], ["meaning", "source_location"], forbidden=["把 ABox alliance 当成原始观测字段"])
add("dev", "raw-health-ratio-formula", "health_ratio 是怎么从 RawUnit 记录换算出来的？", "zh", "direct", "formula", "medium", ["raw_unit.health_ratio"], ["meaning", "formula", "source_location"], forbidden=["声称使用 health/max_health 计算"])
add("dev", "raw-shield-ratio-formula", "请给出 raw_unit.shield_ratio 的转换公式与证据。", "zh", "direct", "formula", "medium", ["raw_unit.shield_ratio"], ["formula", "source_location"])
add("dev", "raw-position-compare", "RawUnit 中单位的横纵坐标分别是哪两个变量？它们从哪里读取？", "zh", "multi_variable_comparison", "interface", "medium", ["raw_unit.x", "raw_unit.y"], ["retrieval", "interface", "source_location"])
add("dev", "raw-cooldown-english", "What does raw_unit.weapon_cooldown represent, and where is it extracted in STORM?", "en", "english", "source_location", "medium", ["raw_unit.weapon_cooldown"], ["meaning", "source_location"])
add("dev", "raw-tag-source", "raw_unit.tag 是什么？请定位 STORM 的读取代码。", "zh", "direct", "source_location", "easy", ["raw_unit.tag"], ["meaning", "source_location"])
add("dev", "health-vs-ratio", "health 和 health_ratio 有什么区别？不要把绝对值与比例混为一谈。", "zh", "multi_variable_comparison", "level_disambiguation", "medium", ["raw_unit.health", "raw_unit.health_ratio"], ["meaning", "formula"], forbidden=["声称二者单位和数值范围相同"])
add("dev", "hp-ambiguous", "hp 是什么变量？", "zh", "ambiguous", "level_disambiguation", "medium", ["raw_unit.health", "abox.unit.hp", "tbox.entity.hp"], ["retrieval", "level_disambiguation"], "clarify", "ambiguous", ["不经澄清就只选择一个层级"])
add("dev", "alliance-ambiguous", "alliance 是什么意思？", "zh", "ambiguous", "level_disambiguation", "medium", ["raw_unit.alliance", "abox.unit.alliance"], ["retrieval", "level_disambiguation"], "clarify", "ambiguous", ["不说明 RawUnit 与 ABox 层级差别"])
add("dev", "cooldown-ambiguous", "weapon_cooldown 指哪个量？", "zh", "ambiguous", "level_disambiguation", "medium", ["raw_unit.weapon_cooldown", "abox.unit.weapon_cooldown"], ["retrieval", "level_disambiguation"], "clarify", "ambiguous", ["不经澄清就固定为某一层"])
add("dev", "action-type", "动作计划中的 action.type 表示什么，允许值依据在哪里？", "zh", "direct", "boundary_condition", "medium", ["action.type"], ["meaning", "interface", "source_location"])
add("dev", "action-units", "LLM 动作里的 units 字段如何表示执行单位？", "zh", "oral", "explanation", "easy", ["action.units"], ["meaning", "interface"])
add("dev", "action-target-layers", "action.target 与 pysc2.function.target 有什么区别？", "zh", "multi_variable_comparison", "level_disambiguation", "hard", ["action.target", "pysc2.function.target"], ["meaning", "interface", "formula", "source_location"], forbidden=["声称二者是同一处理阶段的同一对象"])
add("dev", "action-target-type", "target_type 在动作 Schema 中起什么作用？", "zh", "direct", "explanation", "medium", ["action.target_type"], ["meaning", "interface", "source_location"])
add("dev", "delay-steps-range", "导师说 delay_steps 可以取 20，这与当前代码一致吗？", "zh", "false_premise", "boundary_condition", "hard", ["action.delay_steps"], ["interface", "formula", "source_location", "false_premise"], forbidden=["接受 delay_steps=20 为当前合法值"])
add("dev", "action-priority", "action.priority 有哪些接口约束，在哪段代码校验？", "zh", "direct", "boundary_condition", "medium", ["action.priority"], ["interface", "source_location"])
add("dev", "function-unit-tags", "动作执行阶段传给 PySC2 的 unit_tags 对应哪个变量？", "zh", "direct", "interface", "medium", ["pysc2.function.unit_tags"], ["meaning", "interface", "source_location"])
add("dev", "function-queued", "pysc2.function.queued 当前在 MOVE、ATTACK、BUILD 中如何传值？", "zh", "direct", "formula", "medium", ["pysc2.function.queued"], ["meaning", "formula", "source_location"])
add("dev", "move-function-id", "STORM 执行 MOVE 时使用哪个 PySC2 function id？", "zh", "direct", "interface", "easy", ["pysc2.move.function_id"], ["meaning", "formula", "source_location"])
add("dev", "attack-function-id", "STORM 执行 ATTACK 时使用哪个 function id？请给依据。", "zh", "direct", "source_location", "easy", ["pysc2.attack.function_id"], ["meaning", "formula", "source_location"])
add("dev", "abox-armor-trap", "ABox 的 armor 字段现在存的是单位护甲值吗？", "zh", "known_issue_trap", "known_issue", "hard", ["abox.unit.armor", "raw_unit.shield"], ["known_issue", "formula", "source_location", "false_premise"], forbidden=["把当前 abox.unit.armor 无条件解释成 SC2 护甲", "忽略 issue.abox_armor_stores_shield"])
add("dev", "tbox-vs-raw-hp", "raw_unit.health 与 tbox.entity.hp 分别属于动态观测还是静态知识？", "zh", "multi_variable_comparison", "level_disambiguation", "hard", ["raw_unit.health", "tbox.entity.hp"], ["meaning", "level_disambiguation", "source_location"])
add("dev", "derived-force-ratio", "derived.tactical.force_ratio 是什么派生战术量，如何计算？", "zh", "direct", "formula", "medium", ["derived.tactical.force_ratio"], ["meaning", "formula", "source_location"])
add("dev", "player-minerals", "当前玩家矿物数量在知识库中对应哪个变量？", "zh", "direct", "retrieval", "easy", ["player.minerals"], ["meaning", "interface", "source_location"])
add("dev", "swm-health-delta", "SWM 预测中的单位生命变化量对应哪个变量？", "zh", "direct", "retrieval", "medium", ["swm.unit.health_delta"], ["meaning", "interface", "source_location"])
add("dev", "metric-action-failure", "动作失败率使用哪个实验指标变量，其计算依据是什么？", "zh", "direct", "formula", "medium", ["metric.action.failure_rate"], ["meaning", "formula", "source_location"])
add("dev", "environment-step-mul", "environment.step_mul 控制什么？它属于观测变量还是环境配置？", "zh", "direct", "level_disambiguation", "medium", ["environment.step_mul"], ["meaning", "interface", "source_location"])
add("dev", "timestep-score", "timestep.score_cumulative_0 从哪里读取，表示什么？", "zh", "direct", "source_location", "medium", ["timestep.score_cumulative_0"], ["meaning", "interface", "source_location"])
add("dev", "out-energy", "单位当前 energy 在这版知识库里对应哪个正式变量？", "zh", "out_of_scope", "refusal", "medium", [], ["scope_boundary"], "refuse", "not_found", ["凭 PySC2 常识补出 energy 字段", "伪造当前 STORM 对 energy 的读取代码"])
add("dev", "out-all-raw-fields", "请列出 PySC2 RawUnit 的全部官方字段。", "zh", "out_of_scope", "refusal", "hard", [], ["scope_boundary"], "refuse", "not_found", ["把 V0.1 的 10 个字段说成完整官方字段集", "凭记忆补齐官方 API"])
add("dev", "official-index-verified", "STORM 已经用 PySC2 官方文档验证 unit[2] 一定是 health，对吗？", "zh", "false_premise", "boundary_condition", "hard", ["raw_unit.health"], ["source_location", "truth_boundary", "false_premise"], forbidden=["声称已完成外部官方资料核验", "声称已通过 SC2 运行时验证"])
add("dev", "health-from-max", "raw_unit.health 是通过 max_health 计算出来的吗？", "zh", "false_premise", "formula", "medium", ["raw_unit.health"], ["formula", "source_location", "false_premise"], forbidden=["声称当前实现使用 max_health 计算 health"])
add("dev", "tbox-cache-issue", "修改 marine_ontology.py 后 TBox 静态 hp 会立刻更新吗？", "zh", "known_issue_trap", "known_issue", "hard", ["tbox.entity.hp"], ["known_issue", "source_location"], forbidden=["忽略 ontology_graph.pkl 缓存优先行为"])

# -------------------- held-out test: 18 --------------------
add("test", "unique-unit-id", "Which RawUnit variable uniquely identifies the unit in STORM's parsed record?", "en", "english", "retrieval", "medium", ["raw_unit.tag"], ["meaning", "source_location"])
add("test", "oral-health-shield", "我想看兵现在还剩多少血和盾，该找哪两个原始量？", "zh", "oral", "retrieval", "medium", ["raw_unit.health", "raw_unit.shield"], ["meaning", "level_disambiguation"])
add("test", "position-source-en", "Where are the raw x and y coordinates extracted, and what are their variable IDs?", "en", "english", "source_location", "medium", ["raw_unit.x", "raw_unit.y"], ["interface", "source_location"])
add("test", "alliance-layer-en", "If I ask for alliance without naming a layer, which STORM variables are plausible candidates?", "en", "ambiguous", "level_disambiguation", "hard", ["raw_unit.alliance", "abox.unit.alliance"], ["level_disambiguation"], "clarify", "ambiguous", ["returning only one layer without clarification"])
add("test", "delay-priority-compare", "延迟执行步数和动作优先级分别由哪些字段控制？", "zh", "multi_variable_comparison", "boundary_condition", "medium", ["action.delay_steps", "action.priority"], ["meaning", "interface", "source_location"])
add("test", "target-interface", "动作 Schema 里的 target 是什么接口形式，后续如何被执行层使用？", "zh", "direct", "interface", "hard", ["action.target", "pysc2.function.target"], ["meaning", "interface", "formula", "source_location"])
add("test", "function-target-tags", "Compare pysc2.function.target and pysc2.function.unit_tags in the final FunctionCall.", "en", "multi_variable_comparison", "interface", "hard", ["pysc2.function.target", "pysc2.function.unit_tags"], ["meaning", "interface", "source_location"])
add("test", "move-attack-ids", "MOVE 与 ATTACK 最终使用的 PySC2 function id 是否相同？", "zh", "multi_variable_comparison", "formula", "medium", ["pysc2.move.function_id", "pysc2.attack.function_id"], ["formula", "source_location"], forbidden=["声称 MOVE 与 ATTACK 使用相同 function id"])
add("test", "fire-readiness", "战术摘要里的开火准备度对应哪个派生变量，依据哪些上游状态？", "zh", "direct", "formula", "hard", ["derived.tactical.fire_readiness"], ["meaning", "formula", "source_location"])
add("test", "abox-position", "ABox 单位节点的位置属性用哪个变量保存，它来自哪些 RawUnit 坐标？", "zh", "direct", "formula", "hard", ["abox.unit.position", "raw_unit.x", "raw_unit.y"], ["meaning", "formula", "source_location"])
add("test", "attack-range-layer", "attack_range 是实时 RawUnit 字段吗，还是知识库中其他层的量？", "zh", "ambiguous", "level_disambiguation", "hard", ["abox.unit.attack_range", "tbox.entity.attack_range"], ["meaning", "level_disambiguation", "source_location"], "clarify", "ambiguous", ["编造 raw_unit.attack_range 正式变量"])
add("test", "swm-health-rmse", "评估 SWM 生命值预测误差时使用哪个 RMSE 指标？", "zh", "direct", "retrieval", "medium", ["metric.swm.health_rmse"], ["meaning", "formula", "source_location"])
add("test", "swm-prediction-steps", "SWM 要预测多少个未来步骤由哪个变量表示？", "zh", "direct", "interface", "medium", ["swm.prediction_steps"], ["meaning", "interface", "source_location"])
add("test", "raw-flags", "环境必须开启哪些配置才能让当前 STORM 使用 raw units 和 raw actions？", "zh", "multi_variable_comparison", "boundary_condition", "medium", ["environment.use_raw_units", "environment.use_raw_actions"], ["meaning", "interface", "source_location"])
add("test", "out-warp-cooldown", "星灵折跃门的游戏内冷却时间是多少秒？", "zh", "out_of_scope", "refusal", "medium", [], ["scope_boundary"], "refuse", "not_found", ["使用外部游戏常识直接回答具体秒数", "把 weapon_cooldown 当成折跃门技能冷却"])
add("test", "armor-current-reality", "既然字段叫 armor，ABox 里保存的一定就是护甲，对吧？", "zh", "false_premise", "known_issue", "hard", ["abox.unit.armor", "raw_unit.shield"], ["known_issue", "formula", "false_premise"], forbidden=["按字段名覆盖当前代码现实", "遗漏 needs_verification"])
add("test", "unknown-score-claim", "当前知识库能证明所有地图的 final_score 都等于胜负奖励吗？", "zh", "false_premise", "boundary_condition", "hard", ["metric.episode.final_score", "timestep.reward_delta"], ["meaning", "truth_boundary", "false_premise"], forbidden=["声称已经对所有地图运行验证"])
add("test", "supply-remaining", "剩余人口是哪个变量，它与 food_cap、food_used 的关系是什么？", "zh", "multi_variable_comparison", "formula", "medium", ["player.supply_remaining", "player.food_cap", "player.food_used"], ["meaning", "formula", "source_location"])


def load_records() -> dict[str, dict[str, Any]]:
    records: dict[str, dict[str, Any]] = {}
    for line in SOURCE.read_text(encoding="utf-8").splitlines():
        if line.strip():
            record = json.loads(line)
            records[record["variable_id"]] = record
    return records


def fact(record: dict[str, Any], field: str, value: Any, status: str = "code_reality") -> dict[str, Any]:
    return {"variable_id": record["variable_id"], "field": field, "value": value, "fact_status": status}


def build_question(spec: dict[str, Any], ordinal: int, records: dict[str, dict[str, Any]]) -> dict[str, Any]:
    selected = []
    for variable_id in spec["ids"]:
        if variable_id not in records:
            raise KeyError(f"benchmark 引用了不存在的变量：{variable_id}")
        selected.append(records[variable_id])

    required_facts: list[dict[str, Any]] = []
    required_evidence: list[dict[str, Any]] = []
    for record in selected:
        meaning = (record.get("meaning") or {}).get("definition")
        if meaning:
            required_facts.append(fact(record, "meaning.definition", meaning))
        if "interface" in spec["intents"] or "boundary_condition" in spec["intents"]:
            interface = record.get("interface") or {}
            required_facts.append(fact(record, "interface", {
                "python_type": interface.get("python_type"),
                "data_type": interface.get("data_type"),
                "shape": interface.get("shape"),
                "range": interface.get("range"),
                "enum_values": interface.get("enum_values"),
                "storm_paths": interface.get("storm_paths"),
                "pysc2_path": interface.get("pysc2_path"),
            }))
        if "formula" in spec["intents"] or "false_premise" in spec["intents"]:
            formulas = (record.get("implementation") or {}).get("transformation_formula", [])
            if formulas:
                required_facts.append(fact(record, "implementation.transformation_formula", formulas))
        if "truth_boundary" in spec["intents"] or "false_premise" in spec["intents"]:
            required_facts.append(fact(record, "truth_boundary", record.get("truth_boundary", {}), "mixed_status"))
        if "known_issue" in spec["intents"]:
            issues = record.get("known_issues") or {}
            required_facts.append(fact(record, "known_issues", issues, "needs_verification"))
        for evidence in (record.get("evidence") or [])[:2]:
            item = {
                "evidence_id": evidence.get("id"),
                "path": evidence.get("path"),
                "symbol": evidence.get("symbol"),
                "fact_status": evidence.get("fact_status"),
            }
            if item not in required_evidence:
                required_evidence.append(item)
        if "known_issue" in spec["intents"]:
            for issue in (record.get("known_issues") or {}).get("step09", []):
                for evidence in issue.get("evidence", [])[:2]:
                    item = {
                        "evidence_id": issue.get("id"),
                        "path": evidence.get("path"),
                        "symbol": evidence.get("symbol"),
                        "fact_status": issue.get("truth_status", "needs_verification"),
                    }
                    if item not in required_evidence:
                        required_evidence.append(item)

    if not selected:
        required_facts.append({
            "variable_id": None,
            "field": "scope_boundary",
            "value": "V0.1 仅覆盖当前 STORM 实际使用及直接衍生的正式变量；范围外问题必须拒答。",
            "fact_status": "evaluation_rule",
        })
        required_evidence.append({
            "evidence_id": "scope-v0.1-manifest",
            "path": "knowledge/manifests/scope.yaml",
            "symbol": "scope.in_scope_rule",
            "fact_status": "design_intent",
        })

    required_facts.extend(spec["extra_facts"])
    prefix = "dev" if spec["split"] == "dev" else "test"
    return {
        "id": f"{prefix}.{ordinal:03d}.{spec['slug']}",
        "split": spec["split"],
        "question": spec["question"],
        "language": spec["language"],
        "question_type": spec["question_type"],
        "category": spec["category"],
        "difficulty": spec["difficulty"],
        "intents": spec["intents"],
        "expected_status": spec["status"],
        "expected_behavior": spec["behavior"],
        "expected_variable_ids": spec["ids"],
        "variable_categories": sorted({record["category"] for record in selected}),
        "required_facts": required_facts,
        "required_evidence": required_evidence,
        "forbidden_claims": spec["forbidden"] + ["声称执行了本题未记录的 SC2 运行时或外部模型测试"],
        "clarification_required": spec["behavior"] == "clarify",
        "source_record_refs": [record.get("record_ref") for record in selected],
        "notes": spec["notes"],
        "benchmark_version": "0.1.0",
        "generated_at": "2026-09-04",
    }


def render(records: dict[str, dict[str, Any]]) -> dict[Path, str]:
    outputs: dict[Path, str] = {}
    for split, path in (("dev", DEV_PATH), ("test", TEST_PATH)):
        specs = [spec for spec in SPECS if spec["split"] == split]
        rows = [build_question(spec, index, records) for index, spec in enumerate(specs, 1)]
        rows.sort(key=lambda row: row["id"])
        outputs[path] = "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows)
    return outputs


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="只检查当前文件是否可确定性重建")
    args = parser.parse_args()
    outputs = render(load_records())
    mismatches: list[str] = []
    for path, content in outputs.items():
        if args.check:
            if not path.exists() or path.read_text(encoding="utf-8") != content:
                mismatches.append(str(path.relative_to(ROOT)))
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8", newline="\n")
            print(f"WROTE {path.relative_to(ROOT)} lines={content.count(chr(10))}")
    if mismatches:
        print("MISMATCH: " + ", ".join(mismatches))
        return 1
    if args.check:
        print("PASS: benchmark files are deterministic")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
