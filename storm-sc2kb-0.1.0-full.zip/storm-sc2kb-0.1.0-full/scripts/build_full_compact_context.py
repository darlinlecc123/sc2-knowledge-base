from __future__ import annotations

import hashlib
import json
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "knowledge/context/variables.jsonl"
OUTPUT = ROOT / "knowledge/context/sc2_raw_api_context_full_compact.jsonl"
MANIFEST = ROOT / "knowledge/context/sc2_raw_api_context_full_compact_manifest.json"

SELECTED_FIELDS = {
    "variable_id": "id",
    "names": "names",
    "aliases": "aliases",
    "meaning.definition": "meaning.definition",
    "interface.python_type": "interface.python_type",
    "interface.shape": "interface.shape",
    "interface.pysc2_path": "interface.pysc2_path",
    "interface.storm_paths": "interface.storm_paths",
    "implementation.source_locations": "implementation.source_locations",
    "implementation.transformation_formula": "implementation.transformation_formula",
    "evidence": "evidence",
    "limitations": "limitations",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def compact_record(row: dict) -> dict:
    interface = row.get("interface") or {}
    implementation = row.get("implementation") or {}
    evidence = []
    for item in row.get("evidence") or []:
        evidence.append({
            key: item.get(key)
            for key in ("id", "path", "symbol", "claim")
            if item.get(key) is not None
        })
    return {
        "id": row["variable_id"],
        "names": row.get("names") or {},
        "aliases": row.get("aliases") or [],
        "meaning": {"definition": (row.get("meaning") or {}).get("definition")},
        "interface": {
            "python_type": interface.get("python_type"),
            "shape": interface.get("shape"),
            "pysc2_path": interface.get("pysc2_path"),
            "storm_paths": interface.get("storm_paths") or [],
        },
        "implementation": {
            "source_locations": implementation.get("source_locations") or [],
            "transformation_formula": implementation.get("transformation_formula") or [],
        },
        "evidence": evidence,
        "limitations": row.get("limitations") or [],
    }


def main() -> None:
    source_bytes = SOURCE.read_bytes()
    rows = [json.loads(line) for line in source_bytes.decode("utf-8").splitlines() if line.strip()]
    compact = [compact_record(row) for row in rows]

    source_ids = [row["variable_id"] for row in rows]
    output_ids = [row["id"] for row in compact]
    if len(source_ids) != len(set(source_ids)):
        raise ValueError("源 variables.jsonl 存在重复 variable_id")
    if source_ids != output_ids or set(source_ids) != set(output_ids):
        raise ValueError("紧凑上下文的变量 ID 集合或顺序与源文件不一致")

    text = "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in compact)
    output_bytes = text.encode("utf-8")
    OUTPUT.write_bytes(output_bytes)

    manifest = {
        "schema_version": "1.0.0",
        "generated_at": date.today().isoformat(),
        "condition_label": "full_compact_context",
        "source_file": SOURCE.relative_to(ROOT).as_posix(),
        "source_sha256": sha256(source_bytes),
        "output_file": OUTPUT.relative_to(ROOT).as_posix(),
        "output_sha256": sha256(output_bytes),
        "source_record_count": len(rows),
        "output_record_count": len(compact),
        "variable_id_coverage": len(set(output_ids)) / len(set(source_ids)) if source_ids else 1.0,
        "variable_id_order_preserved": source_ids == output_ids,
        "selected_fields": list(SELECTED_FIELDS),
        "query_specific_filtering": False,
        "retrieval_used": False,
        "truncated": False,
        "semantic_note": "包含 variables.jsonl 的全部变量，但仅保留三条件评测所需的核心语义、接口、实现和证据字段；不等于原始完整 Markdown 的逐字副本。",
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(f"output_bytes={len(output_bytes)}")


if __name__ == "__main__":
    main()
