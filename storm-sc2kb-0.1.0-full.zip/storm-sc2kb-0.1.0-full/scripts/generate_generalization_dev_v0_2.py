"""从冻结 challenge v0.2 的首次失败记录生成可调试开发集。"""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
QUESTIONS = KB / "evals" / "questions_challenge_v0.2.jsonl"
ANALYSIS = KB / "evals" / "challenge_v0.2_analysis.json"
OUTPUT = KB / "evals" / "questions_generalization_dev_v0.2.jsonl"
MANIFEST = KB / "evals" / "generalization_dev_v0.2_manifest.json"


def main() -> int:
    questions = {
        item["id"]: item
        for line in QUESTIONS.read_text(encoding="utf-8").splitlines()
        if line.strip()
        for item in [json.loads(line)]
    }
    analysis = json.loads(ANALYSIS.read_text(encoding="utf-8"))
    failed = [item for item in analysis["cases"] if not item["strict_pass"]]
    cases = []
    for index, failure in enumerate(failed, 1):
        source = dict(questions[failure["question_id"]])
        source["id"] = f"generalization.dev.v0.2.{index:03d}.{source['id'].split('.', 4)[-1]}"
        source["benchmark_version"] = "0.2.1-dev"
        source["split"] = "generalization_dev_v0.2"
        source["category"] = "retrieval_generalization_development"
        source["intents"] = ["v0.2_failure_development", failure["failure_mode"]]
        source["notes"] = (
            "由冻结 challenge v0.2 首次失败案例复制形成的可调试开发题；"
            "允许用于改进检索器，但不得据此改写原 challenge v0.2。"
        )
        cases.append(source)
    payload = "".join(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n" for item in cases).encode("utf-8")
    OUTPUT.write_bytes(payload)
    manifest = {
        "version": "0.2.1-dev",
        "created_at": "2026-09-04",
        "source_challenge": "knowledge/evals/questions_challenge_v0.2.jsonl",
        "source_challenge_sha256": hashlib.sha256(QUESTIONS.read_bytes()).hexdigest(),
        "source_first_run": analysis["run_id"],
        "case_count": len(cases),
        "development_set_sha256": hashlib.sha256(payload).hexdigest(),
        "failure_modes": dict(sorted(Counter(item["failure_mode"] for item in failed).items())),
        "policy": "本文件可参与调参；冻结 challenge v0.2 及其首次结果不得修改。",
        "external_model_test": "未执行",
        "sc2_runtime": "未执行",
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
