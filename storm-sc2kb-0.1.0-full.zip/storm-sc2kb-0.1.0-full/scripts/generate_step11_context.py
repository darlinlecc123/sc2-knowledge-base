"""从步骤05-10产物确定性生成步骤11的 LLM 上下文包。"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[2]
KNOWLEDGE = ROOT / "knowledge"
SRC = KNOWLEDGE / "src"
sys.path.insert(0, str(SRC))

from sc2kb.loader import KnowledgeBase, load_knowledge_base  # noqa: E402

OUTPUTS = {
    "short": KNOWLEDGE / "context/sc2_raw_api_context_short.md",
    "standard": KNOWLEDGE / "context/sc2_raw_api_context_standard.md",
    "full": KNOWLEDGE / "context/sc2_raw_api_context_full.md",
    "jsonl": KNOWLEDGE / "context/variables.jsonl",
    "index": KNOWLEDGE / "context/index.yaml",
}

CATEGORY_LABELS = {
    "raw_unit": "PySC2 RawUnit 观测与直接转换",
    "timestep_player_score": "TimeStep、玩家资源与得分",
    "tbox_static": "TBox 静态类型知识",
    "abox_dynamic": "ABox 运行时实例与关系",
    "derived_tactical_state": "派生战术状态",
    "action_schema_and_scheduling": "动作计划、校验与调度",
    "pysc2_function_call": "PySC2 FunctionCall 参数",
    "swm": "SWM 预测与重验证",
    "experiment_metric": "实验与模型指标",
    "environment_config": "环境配置",
}

TOPIC_RULES = {
    "identity_and_affiliation": ("unit_type", "unit_class", "category", "race", "alliance", "tag", "node_type"),
    "health_and_survivability": ("health", ".hp", "shield", "armor", "critical", "health_status"),
    "position_and_geometry": (".x", ".y", "position", "centroid", "distance", "range", "sight", "formation"),
    "combat_and_weapons": ("attack", "weapon", "cooldown", "damage", "dps", "fire", "effectiveness"),
    "resources_and_supply": ("mineral", "vespene", "gas", "food", "supply", "resource", "build_time"),
    "counts_and_aggregation": ("count", "avg", "total", "ratio", "score", "rate"),
    "actions_and_execution": ("action", "target", "priority", "delay", "queued", "function", "move", "build", "train", "no_op"),
    "ontology_and_graph": ("tbox", "abox", "graph", "relation", "edge", "entity", "description"),
    "swm_prediction": ("swm", "predict", "confidence", "candidate", "delta"),
    "evaluation_and_tokens": ("metric", "reward", "error", "rmse", "accuracy", "token", "decision", "failure"),
    "environment_and_timing": ("environment", "timestep", "step", "map", "resolution", "realtime", "visualize", "interval"),
}

CHAIN_CATEGORIES = {
    "observation_to_abox": {"raw_unit", "timestep_player_score", "abox_dynamic"},
    "ontology_tbox_abox": {"tbox_static", "abox_dynamic"},
    "abox_to_tactical_state": {"abox_dynamic", "derived_tactical_state"},
    "llm_action_to_function_call": {"action_schema_and_scheduling", "pysc2_function_call"},
    "swm_prediction_and_revalidation": {"swm", "action_schema_and_scheduling"},
    "environment_and_evaluation": {"environment_config", "experiment_metric", "timestep_player_score"},
}

SHORT_PRIORITY = [
    "environment.use_raw_units", "environment.use_raw_actions", "environment.step_mul", "environment.raw_resolution",
    "raw_unit.unit_type", "raw_unit.alliance", "raw_unit.health", "raw_unit.health_ratio",
    "raw_unit.shield", "raw_unit.weapon_cooldown", "raw_unit.x", "raw_unit.y", "raw_unit.tag",
    "player.minerals", "player.vespene", "player.food_used", "player.food_cap", "player.supply_remaining",
    "abox.unit.hp", "abox.unit.position", "abox.unit.alliance", "abox.unit.weapon_cooldown",
    "derived.tactical.friendly_count", "derived.tactical.enemy_count", "derived.tactical.force_ratio",
    "derived.tactical.fire_readiness", "derived.tactical.health_status",
    "action.type", "action.units", "action.target", "action.delay_steps", "action.priority",
    "pysc2.function.unit_tags", "pysc2.function.target", "pysc2.function.queued",
    "swm.predictions", "swm.confidence", "metric.episode.final_score",
]

ANSWER_RULES = """## 回答规则（必须遵守）

1. **先识别层级**：先说明变量属于 Raw observation、TimeStep/player、TBox、ABox、派生战术状态、动作、PySC2 FunctionCall、SWM、实验指标或环境配置中的哪一层。
2. **歧义不强选**：同名词对应多个变量时，列出候选 `variable_id` 并询问层级或使用场景。
3. **固定回答顺序**：给出 `variable_id` → 简明含义 → 接口形式 → 公式/转换 → 源码依据 → 限制与已知问题。
4. **证据优先**：以记录中的仓库相对路径、符号、代码片段和 evidence ID 为依据，不用外部常识替代当前代码事实。
5. **保留事实边界**：区分 `design_intent`、`code_reality`、`runtime_observation` 和 `needs_verification`；静态校验不等于 SC2 运行时验证。
6. **证据不足就说不知道**：字段缺失、编码损坏、范围未验证或当前 V0.1 未收录时，明确回答“不知道/当前知识库未验证”，不得补造 PySC2 字段。
7. **范围边界**：这里只覆盖当前 STORM 主路径实际使用及直接产生的 135 个正式变量，不是完整 PySC2 或 StarCraft II 百科。
"""


def is_corrupt(text: str) -> bool:
    return "�" in text or "\ufffd" in text


def clean(value: Any, path: str = "", omitted: list[str] | None = None) -> Any:
    """递归剔除含替换字符的损坏字符串，并记录字段路径。"""
    omitted = omitted if omitted is not None else []
    if isinstance(value, str):
        if is_corrupt(value):
            omitted.append(path or "$")
            return None
        return value
    if isinstance(value, list):
        result = []
        for index, item in enumerate(value):
            cooked = clean(item, f"{path}[{index}]", omitted)
            if cooked is not None:
                result.append(cooked)
        return result
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            cooked = clean(item, f"{path}.{key}" if path else str(key), omitted)
            if cooked is not None:
                result[key] = cooked
        return result
    return value


def topics_for(variable_id: str, record: dict[str, Any]) -> list[str]:
    haystack = " ".join((variable_id, str(record.get("canonical_name", "")), str(record.get("category", "")))).casefold()
    topics = [topic for topic, needles in TOPIC_RULES.items() if any(needle in haystack for needle in needles)]
    return topics or ["other_project_variable"]


def chains_for(record: dict[str, Any]) -> list[str]:
    category = record.get("category")
    chains = [name for name, categories in CHAIN_CATEGORIES.items() if category in categories]
    return chains or ["uncategorized_chain"]


def compact_interface(interface: dict[str, Any]) -> dict[str, Any]:
    return {
        "data_type": interface.get("data_type"),
        "python_type": interface.get("python_type"),
        "shape": interface.get("shape"),
        "unit": interface.get("unit"),
        "range": interface.get("range"),
        "enum_values": interface.get("enum_values"),
        "nullable": interface.get("nullable"),
        "pysc2_path": interface.get("pysc2_path"),
        "storm_paths": interface.get("storm_paths", []),
    }


def build_rows(kb: KnowledgeBase) -> list[dict[str, Any]]:
    rows = []
    for variable_id in sorted(kb.records):
        record = kb.records[variable_id]
        omitted: list[str] = []
        incoming = []
        for relation in kb.upstream(variable_id):
            source_id = relation.get("source", {}).get("id")
            if source_id in kb.records:
                incoming.append({"variable_id": source_id, "relation_type": relation.get("relation_type"), "relation_id": relation.get("id")})
        outgoing = []
        for relation in kb.downstream(variable_id):
            target_id = relation.get("target", {}).get("id")
            if target_id in kb.records:
                outgoing.append({"variable_id": target_id, "relation_type": relation.get("relation_type"), "relation_id": relation.get("id")})
        source_file = variable_id.split(".", 1)[0]
        if source_file in {"player", "timestep", "environment"}:
            source_file = "raw_api"
        elif source_file == "action" or source_file == "pysc2":
            source_file = "actions"
        elif source_file == "metric":
            source_file = "metrics"
        row = {
            "schema_version": "1.0.0",
            "variable_id": variable_id,
            "canonical_name": record.get("canonical_name"),
            "names": clean(record.get("names", {}), "names", omitted),
            "category": record.get("category"),
            "source_layer": record.get("provenance", {}).get("source_layer"),
            "derivation_kind": record.get("provenance", {}).get("derivation_kind"),
            "aliases": clean(record.get("aliases", []), "aliases", omitted),
            "meaning": clean({"definition": record.get("definition"), "intuitive_explanation": record.get("intuitive_explanation")}, "meaning", omitted),
            "interface": clean(compact_interface(record.get("interface", {})), "interface", omitted),
            "implementation": clean(record.get("implementation", {}), "implementation", omitted),
            "evidence": clean(record.get("evidence", []), "evidence", omitted),
            "truth_boundary": clean({
                "design_intent": record.get("design_intent", []),
                "code_reality": record.get("code_reality", []),
                "verification": record.get("verification", {}),
            }, "truth_boundary", omitted),
            "limitations": clean(record.get("limitations", []), "limitations", omitted),
            "known_issues": clean({
                "record_level": record.get("known_issues", []),
                "step09": kb.known_issues_for(variable_id),
            }, "known_issues", omitted),
            "relationships": {"upstream": incoming, "downstream": outgoing},
            "retrieval": {"topics": topics_for(variable_id, record), "data_chains": chains_for(record)},
            "record_ref": f"knowledge/variables/{source_file}.yaml#id={variable_id}",
            "corrupt_fields_omitted": sorted(set(omitted)),
        }
        rows.append(row)
    return rows


def text_or_unknown(value: Any) -> str:
    if isinstance(value, str) and value.strip():
        return " ".join(value.split())
    return "当前记录未提供可安全注入的文本；请依据英文名、接口和源码证据。"


def evidence_refs(row: dict[str, Any], limit: int | None = None) -> list[str]:
    refs = []
    for item in row.get("evidence", []):
        path = item.get("path", "?")
        symbol = item.get("symbol", "?")
        line_start, line_end = item.get("line_start"), item.get("line_end")
        lines = f":{line_start}-{line_end}" if line_start is not None else ""
        refs.append(f"{item.get('id', '?')} @ {path}{lines} ({symbol}; {item.get('fact_status', '?')})")
    return refs if limit is None else refs[:limit]


def formulas(row: dict[str, Any]) -> list[str]:
    return row.get("implementation", {}).get("transformation_formula", []) or []


def aliases_display(row: dict[str, Any], limit: int = 5) -> str:
    values = [str(x) for x in row.get("aliases", []) if x]
    return "、".join(values[:limit]) if values else "无可安全注入别名"


def interface_line(row: dict[str, Any]) -> str:
    interface = row.get("interface", {})
    paths = []
    pysc2_path = interface.get("pysc2_path", {})
    if isinstance(pysc2_path, dict) and pysc2_path.get("value"):
        paths.append(str(pysc2_path["value"]))
    paths.extend(str(x) for x in interface.get("storm_paths", []) if x)
    return (
        f"data_type={interface.get('data_type', '?')}; python_type={interface.get('python_type', '?')}; "
        f"shape={json.dumps(interface.get('shape', {}), ensure_ascii=False, separators=(',', ':'))}; "
        f"paths={paths or ['未记录']}"
    )


def header(profile: str, count: int) -> str:
    return (
        f"# STORM PySC2 Raw API 知识上下文（{profile}）\n\n"
        f"> 版本：V0.1；正式变量：135；本文件注入变量卡：{count}。\n"
        "> 证据边界：静态仓库证据；本步骤未启动 SC2、未调用外部 LLM/SWM、未核验外部官方资料。\n"
        "> 若任何上游字段含明确的 Unicode U+FFFD 损坏标记，该字段将不注入；必须依据其余接口、公式和源码证据回答，不得猜测。\n\n"
        + ANSWER_RULES
        + "\n"
    )


def short_markdown(rows: list[dict[str, Any]]) -> str:
    by_id = {row["variable_id"]: row for row in rows}
    selected = [by_id[vid] for vid in SHORT_PRIORITY if vid in by_id]
    lines = [header("short", len(selected))]
    lines.append("## 使用方法\n\n先用 `knowledge/context/index.yaml` 或步骤10检索器定位变量，再加载 standard/full 中对应记录。short 只保留主链高频变量，不代表其余变量不存在。\n")
    lines.append("## 层级速查\n")
    for category, label in CATEGORY_LABELS.items():
        count = sum(row["category"] == category for row in rows)
        lines.append(f"- `{category}`：{label}（{count} 个正式变量）")
    lines.append("\n## 主链高频变量\n")
    for row in selected:
        meaning = text_or_unknown(row.get("meaning", {}).get("definition"))
        refs = evidence_refs(row, 1)
        lines.append(
            f"- [id=`{row['variable_id']}`; category=`{row['category']}`; source_layer=`{row['source_layer']}`] "
            f"meaning={meaning}; interface=({interface_line(row)}); formula={formulas(row) or ['direct/no formula recorded']}; "
            f"evidence={refs or [row['record_ref']]}; limits={row.get('limitations') or ['未记录']}"
        )
    lines.append("\n## 数据链入口\n")
    for chain in CHAIN_CATEGORIES:
        members = [row["variable_id"] for row in rows if chain in row["retrieval"]["data_chains"]]
        lines.append(f"- `{chain}`：{len(members)} 个变量；完整 ID 列表见 `index.yaml`。")
    return "\n".join(lines).rstrip() + "\n"


def standard_markdown(rows: list[dict[str, Any]]) -> str:
    lines = [header("standard", len(rows))]
    lines.append("## 检索流程\n\n1. 从 `index.yaml` 的类别、主题或数据链选择候选 ID。2. 从 `variables.jsonl` 按行号加载记录。3. 若只需概览，可直接使用下列全部变量紧凑卡。\n")
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row["category"]].append(row)
    for category in CATEGORY_LABELS:
        items = grouped.get(category, [])
        if not items:
            continue
        lines.append(f"## {category}：{CATEGORY_LABELS[category]}（{len(items)}）\n")
        for row in items:
            meaning = text_or_unknown(row.get("meaning", {}).get("definition"))
            paths = evidence_refs(row, 1) or [row["record_ref"]]
            lines.append(
                f"- `{row['variable_id']}` | layer=`{row['source_layer']}` | name=`{row.get('canonical_name')}` | "
                f"meaning={meaning} | interface={interface_line(row)} | formula={formulas(row) or ['未记录']} | "
                f"evidence={paths} | verification={row.get('truth_boundary', {}).get('verification', {}).get('status', 'unknown')} | "
                f"limits={row.get('limitations') or ['未记录']}"
            )
        lines.append("")
    lines.append("## 查询主题索引\n")
    for topic in TOPIC_RULES:
        members = [row["variable_id"] for row in rows if topic in row["retrieval"]["topics"]]
        lines.append(f"- `{topic}`：{len(members)} 个；详见 `index.yaml`。")
    lines.append("\n## 数据链索引\n")
    for chain in CHAIN_CATEGORIES:
        members = [row["variable_id"] for row in rows if chain in row["retrieval"]["data_chains"]]
        lines.append(f"- `{chain}`：{len(members)} 个；详见 `index.yaml`。")
    return "\n".join(lines).rstrip() + "\n"


def full_markdown(rows: list[dict[str, Any]]) -> str:
    lines = [header("full", len(rows))]
    lines.append("## 使用说明\n\n本文件包含 135 个正式变量的完整上下文卡。机器检索优先使用 `variables.jsonl` 与 `index.yaml`，避免每次注入全文。\n")
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row["category"]].append(row)
    for category in CATEGORY_LABELS:
        items = grouped.get(category, [])
        if not items:
            continue
        lines.append(f"## {category}：{CATEGORY_LABELS[category]}\n")
        for row in items:
            lines.extend([
                f"### `{row['variable_id']}`",
                f"- **层级**：category=`{row['category']}`；source_layer=`{row['source_layer']}`；derivation=`{row['derivation_kind']}`",
                f"- **名称**：canonical=`{row.get('canonical_name')}`；zh={text_or_unknown(row.get('names', {}).get('zh'))}；en={text_or_unknown(row.get('names', {}).get('en'))}",
                f"- **别名**：{aliases_display(row)}",
                f"- **简明含义**：{text_or_unknown(row.get('meaning', {}).get('definition'))}",
                f"- **直观解释**：{text_or_unknown(row.get('meaning', {}).get('intuitive_explanation'))}",
                f"- **接口**：`{json.dumps(row.get('interface', {}), ensure_ascii=False, sort_keys=True, separators=(',', ':'))}`",
                f"- **公式/转换**：`{json.dumps(formulas(row), ensure_ascii=False)}`",
                f"- **实现**：`{json.dumps(row.get('implementation', {}), ensure_ascii=False, sort_keys=True, separators=(',', ':'))}`",
                f"- **源码证据**：{'; '.join(evidence_refs(row)) or row['record_ref']}",
                f"- **直接上游**：`{json.dumps(row.get('relationships', {}).get('upstream', []), ensure_ascii=False, sort_keys=True, separators=(',', ':'))}`",
                f"- **直接下游**：`{json.dumps(row.get('relationships', {}).get('downstream', []), ensure_ascii=False, sort_keys=True, separators=(',', ':'))}`",
                f"- **限制**：`{json.dumps(row.get('limitations', []), ensure_ascii=False)}`",
                f"- **已知问题**：`{json.dumps(row.get('known_issues', {}), ensure_ascii=False, sort_keys=True, separators=(',', ':'))}`",
                f"- **事实边界**：`{json.dumps(row.get('truth_boundary', {}), ensure_ascii=False, sort_keys=True, separators=(',', ':'))}`",
                f"- **检索分片**：topics={row['retrieval']['topics']}；data_chains={row['retrieval']['data_chains']}",
                f"- **原始记录引用**：`{row['record_ref']}`",
                f"- **因编码损坏未注入字段**：`{json.dumps(row.get('corrupt_fields_omitted', []), ensure_ascii=False)}`",
                "",
            ])
    return "\n".join(lines).rstrip() + "\n"


def estimate_tokens(text: str) -> int:
    cjk = len(re.findall(r"[\u3400-\u9fff]", text))
    other = max(0, len(text) - cjk)
    return math.ceil(cjk * 1.5 + other / 4)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def make_index(rows: list[dict[str, Any]], texts: dict[str, str]) -> dict[str, Any]:
    line_map = {row["variable_id"]: index for index, row in enumerate(rows, 1)}

    def slice_entry(ids: list[str]) -> dict[str, Any]:
        ordered = sorted(ids)
        return {"count": len(ordered), "variable_ids": ordered, "jsonl_lines": [line_map[vid] for vid in ordered]}

    categories = {category: slice_entry([row["variable_id"] for row in rows if row["category"] == category]) for category in CATEGORY_LABELS}
    topics = {topic: slice_entry([row["variable_id"] for row in rows if topic in row["retrieval"]["topics"]]) for topic in list(TOPIC_RULES) + ["other_project_variable"]}
    topics = {key: value for key, value in topics.items() if value["count"]}
    chains = {chain: slice_entry([row["variable_id"] for row in rows if chain in row["retrieval"]["data_chains"]]) for chain in list(CHAIN_CATEGORIES) + ["uncategorized_chain"]}
    chains = {key: value for key, value in chains.items() if value["count"]}
    profiles = {}
    descriptions = {
        "short": "主链高频变量、回答规则和层级速查；适合小上下文或路由前置。",
        "standard": "全部135变量的单行紧凑卡；适合一般问答。",
        "full": "全部135变量的完整字段、关系、证据、限制和事实边界；适合审计与深度回答。",
    }
    for name in ("short", "standard", "full"):
        profiles[name] = {
            "path": str(OUTPUTS[name].relative_to(ROOT)).replace("\\", "/"),
            "description": descriptions[name],
            "characters": len(texts[name]),
            "estimated_tokens": estimate_tokens(texts[name]),
            "sha256": sha256_text(texts[name]),
        }
    return {
        "knowledge_base": "storm-sc2kb-v1-raw",
        "schema_version": "1.0.0",
        "generated_at": "2026-09-04",
        "status": "llm_context_generated",
        "scope": {"formal_variable_count": len(rows), "complete_pysc2_api": False, "external_llm_tested": False, "sc2_executed": False},
        "answer_rules_path": "knowledge/context/sc2_raw_api_context_short.md#回答规则必须遵守",
        "routing": {
            "recommended": "先使用步骤10本地检索或本索引确定 variable_id，再按 JSONL 行号加载相关记录。",
            "ambiguity_policy": "返回所有同分候选并询问层级；不得静默选择。",
            "insufficient_evidence_policy": "回答不知道或当前知识库未验证，不得补造字段。",
        },
        "token_budget_profiles": profiles,
        "jsonl": {
            "path": "knowledge/context/variables.jsonl",
            "record_count": len(rows),
            "one_record_per_line": True,
            "ordering": "variable_id ascending",
            "variable_id_to_line": line_map,
            "sha256": sha256_text(texts["jsonl"]),
        },
        "slices": {"by_category": categories, "by_query_topic": topics, "by_data_chain": chains},
        "encoding_safety": {
            "policy": "仅当字符串含明确 Unicode U+FFFD replacement character 时不注入；在 corrupt_fields_omitted 中记录路径；不凭显示异常猜测编码损坏。",
            "records_with_omissions": sum(bool(row["corrupt_fields_omitted"]) for row in rows),
            "omitted_field_occurrences": sum(len(row["corrupt_fields_omitted"]) for row in rows),
        },
    }


def render() -> dict[Path, str]:
    kb = load_knowledge_base()
    rows = build_rows(kb)
    jsonl = "".join(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n" for row in rows)
    texts = {
        "short": short_markdown(rows),
        "standard": standard_markdown(rows),
        "full": full_markdown(rows),
        "jsonl": jsonl,
    }
    index = make_index(rows, texts)
    texts["index"] = yaml.safe_dump(index, allow_unicode=True, sort_keys=False, width=120)
    return {OUTPUTS[name]: text for name, text in texts.items()}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="只比较现有文件，不写入")
    args = parser.parse_args()
    rendered = render()
    if args.check:
        mismatches = []
        for path, expected in rendered.items():
            actual = path.read_text(encoding="utf-8-sig") if path.exists() else None
            if actual != expected:
                mismatches.append(str(path.relative_to(ROOT)))
        print("STEP11_GENERATION_CHECK")
        print("mismatches:", len(mismatches))
        for path in mismatches:
            print("-", path)
        print("RESULT:", "PASS" if not mismatches else "FAIL")
        return 0 if not mismatches else 1
    for path, content in rendered.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8", newline="\n")
        print(f"WROTE {path.relative_to(ROOT)} bytes={len(content.encode('utf-8'))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

