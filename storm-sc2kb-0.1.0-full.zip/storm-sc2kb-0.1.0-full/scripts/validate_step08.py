"""严格校验步骤 08 变量关系图；不运行 SC2、外部模型或实验。"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from collections import Counter, defaultdict, deque
from pathlib import Path, PurePosixPath
from typing import Any

import yaml

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[2]
K = ROOT / "knowledge"
V = K / "variables"
RELATIONS_PATH = K / "relations" / "variable_relations.jsonl"
ALIASES_PATH = K / "retrieval" / "aliases.yaml"
LINEAGE_PATH = K / "lineage" / "variable_lineage.yaml"
DOC_PATH = K / "docs" / "08_variable_graph.md"
AUDIT_PATH = K / "reports" / "08_graph_audit.md"
VARIABLE_FILES = [
    "raw_api",
    "tbox",
    "abox",
    "derived",
    "actions",
    "swm",
    "metrics",
]
RELATION_TYPES = {
    "read_from",
    "transformed_to",
    "normalized_as",
    "aggregated_into",
    "stored_as",
    "used_by",
    "validated_by",
    "mapped_to",
    "predicts",
    "evaluated_by",
    "aliases",
}
CAUSAL_RELATIONS = RELATION_TYPES - {"used_by", "aliases"}
ENDPOINT_KINDS = {
    "variable",
    "component",
    "artifact",
    "interface_field",
    "alias",
}
TRUTH_STATUSES = {
    "code_reality",
    "design_intent",
    "runtime_observation",
    "needs_verification",
    "not_applicable",
}
BAD_UNICODE = {"\ufffd", "\x00"}
ABSOLUTE_PATH_RE = re.compile(r"^[A-Za-z]:[\\/]|^[/\\]{2}")


def load_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def stable_hash(text: str, length: int = 16) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:length]


def iter_strings(value: Any):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from iter_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from iter_strings(item)


def reachable(
    edges: list[dict[str, Any]], source: str, target: str
) -> bool:
    adjacency: dict[str, list[str]] = defaultdict(list)
    for edge in edges:
        if edge.get("relation_type") == "aliases":
            continue
        adjacency[edge["source"]["id"]].append(edge["target"]["id"])
    queue: deque[str] = deque([source])
    seen = {source}
    while queue:
        node = queue.popleft()
        if node == target:
            return True
        for next_node in adjacency.get(node, []):
            if next_node not in seen:
                seen.add(next_node)
                queue.append(next_node)
    return False


def find_cycle(edges: list[dict[str, Any]]) -> list[str] | None:
    adjacency: dict[str, list[str]] = defaultdict(list)
    nodes: set[str] = set()
    for edge in edges:
        if edge.get("relation_type") not in CAUSAL_RELATIONS:
            continue
        source_id = edge["source"]["id"]
        target_id = edge["target"]["id"]
        adjacency[source_id].append(target_id)
        nodes.update({source_id, target_id})

    state: dict[str, int] = {}
    stack: list[str] = []
    positions: dict[str, int] = {}

    def visit(node: str) -> list[str] | None:
        state[node] = 1
        positions[node] = len(stack)
        stack.append(node)
        for target in sorted(adjacency.get(node, [])):
            if state.get(target, 0) == 0:
                cycle = visit(target)
                if cycle:
                    return cycle
            elif state.get(target) == 1:
                return stack[positions[target] :] + [target]
        stack.pop()
        positions.pop(node, None)
        state[node] = 2
        return None

    for node in sorted(nodes):
        if state.get(node, 0) == 0:
            cycle = visit(node)
            if cycle:
                return cycle
    return None


def main() -> int:
    errors: list[str] = []
    warnings: list[str] = []

    # 上游正式变量和血缘集合。
    variables: dict[str, dict[str, Any]] = {}
    for name in VARIABLE_FILES:
        path = V / f"{name}.yaml"
        if not path.is_file():
            errors.append(f"缺少步骤五文件: {path.relative_to(ROOT)}")
            continue
        payload = load_yaml(path)
        for row in payload.get("records", []):
            variable_id = row.get("id")
            if variable_id in variables:
                errors.append(f"步骤五变量ID重复: {variable_id}")
            variables[variable_id] = row
    if len(variables) != 135:
        errors.append(f"步骤五变量数量错误: {len(variables)} != 135")

    if not LINEAGE_PATH.is_file():
        errors.append("缺少步骤六血缘文件")
        lineage: dict[str, dict[str, Any]] = {}
    else:
        lineage_payload = load_yaml(LINEAGE_PATH)
        lineage = {
            row["variable_id"]: row
            for row in lineage_payload.get("records", [])
        }
    if set(lineage) != set(variables):
        errors.append("步骤六血缘ID集合与步骤五不一致")

    if not ALIASES_PATH.is_file():
        errors.append("缺少步骤七别名文件")
        aliases: dict[str, Any] = {}
    else:
        aliases = load_yaml(ALIASES_PATH)

    # JSONL逐行解析，空行也视为格式问题。
    edges: list[dict[str, Any]] = []
    if not RELATIONS_PATH.is_file():
        errors.append("缺少 knowledge/relations/variable_relations.jsonl")
    else:
        raw_lines = RELATIONS_PATH.read_text(encoding="utf-8").splitlines()
        for line_number, line in enumerate(raw_lines, 1):
            if not line.strip():
                errors.append(f"JSONL存在空行: line {line_number}")
                continue
            try:
                edge = json.loads(line)
            except json.JSONDecodeError as exc:
                errors.append(f"JSONL解析失败 line {line_number}: {exc}")
                continue
            if not isinstance(edge, dict):
                errors.append(f"JSONL行不是对象: line {line_number}")
                continue
            edges.append(edge)
    if not edges:
        errors.append("关系边表为空")

    relation_counts = Counter()
    edge_ids: list[str] = []
    edge_keys: list[tuple[str, str, str]] = []
    endpoint_metadata: dict[str, dict[str, Any]] = {}
    variable_degree = Counter()
    factual_degree = Counter()
    actual_alias_pairs: set[tuple[str, str]] = set()

    required_fields = {
        "schema_version",
        "id",
        "relation_type",
        "source",
        "target",
        "direction",
        "summary_zh",
        "evidence_basis",
        "truth_status",
        "runtime_value_status",
        "mediator",
        "evidence",
        "formulas",
        "limitations",
    }

    for index, edge in enumerate(edges, 1):
        missing = required_fields - set(edge)
        if missing:
            errors.append(f"边{index}缺少字段: {sorted(missing)}")
            continue

        relation_type = edge.get("relation_type")
        if relation_type not in RELATION_TYPES:
            errors.append(f"非法关系类型: {relation_type}")
            continue
        relation_counts[relation_type] += 1

        source = edge.get("source")
        target = edge.get("target")
        if not isinstance(source, dict) or not isinstance(target, dict):
            errors.append(f"边{index}的source/target不是对象")
            continue
        for endpoint_name, node in (("source", source), ("target", target)):
            if set(node) != {"id", "kind", "label", "layer", "category"}:
                errors.append(f"边{index}.{endpoint_name}字段集合错误")
            node_id = node.get("id")
            if not isinstance(node_id, str) or not node_id:
                errors.append(f"边{index}.{endpoint_name}缺少节点ID")
                continue
            if node.get("kind") not in ENDPOINT_KINDS:
                errors.append(
                    f"非法节点类型: {node_id} -> {node.get('kind')}"
                )
            prior = endpoint_metadata.get(node_id)
            if prior is not None and prior != node:
                errors.append(f"同一节点元数据不一致: {node_id}")
            endpoint_metadata[node_id] = node

            if node.get("kind") == "variable":
                if node_id not in variables:
                    errors.append(f"变量节点引用不存在的正式变量: {node_id}")
                else:
                    expected = variables[node_id]
                    expected_lineage = lineage.get(node_id, {})
                    if node.get("label") != expected.get("names", {}).get("zh"):
                        errors.append(f"变量节点中文标签错误: {node_id}")
                    if node.get("category") != expected.get("category"):
                        errors.append(f"变量节点category错误: {node_id}")
                    if node.get("layer") != expected_lineage.get(
                        "taxonomy_source_layer"
                    ):
                        errors.append(f"变量节点layer错误: {node_id}")
                variable_degree[node_id] += 1
                if relation_type != "aliases":
                    factual_degree[node_id] += 1

        source_id = source.get("id")
        target_id = target.get("id")
        key = (relation_type, source_id, target_id)
        edge_keys.append(key)
        edge_id = edge.get("id")
        edge_ids.append(edge_id)
        expected_id = (
            f"rel.{relation_type}."
            f"{stable_hash(source_id + '|' + relation_type + '|' + target_id)}"
        )
        if edge_id != expected_id:
            errors.append(f"关系稳定ID错误: {edge_id} != {expected_id}")
        if edge.get("schema_version") != "1.0.0":
            errors.append(f"schema_version错误: {edge_id}")
        if edge.get("direction") != "source_to_target":
            errors.append(f"关系方向错误: {edge_id}")
        if not str(edge.get("summary_zh", "")).strip():
            errors.append(f"缺少中文关系说明: {edge_id}")
        if edge.get("truth_status") not in TRUTH_STATUSES:
            errors.append(f"truth_status非法: {edge_id}")
        if not isinstance(edge.get("formulas"), list):
            errors.append(f"formulas不是数组: {edge_id}")
        if not isinstance(edge.get("limitations"), list):
            errors.append(f"limitations不是数组: {edge_id}")

        basis = edge.get("evidence_basis")
        evidence = edge.get("evidence")
        if not isinstance(evidence, list):
            errors.append(f"evidence不是数组: {edge_id}")
            evidence = []
        if relation_type == "aliases":
            if basis != "structural_index":
                errors.append(f"aliases边未标记structural_index: {edge_id}")
            if edge.get("truth_status") != "not_applicable":
                errors.append(f"aliases边truth_status错误: {edge_id}")
            if edge.get("runtime_value_status") != "not_applicable":
                errors.append(f"aliases边runtime状态错误: {edge_id}")
            if source.get("kind") != "alias" or target.get("kind") != "variable":
                errors.append(f"aliases边节点类型错误: {edge_id}")
            actual_alias_pairs.add((source_id, target_id))
        else:
            if basis != "source_evidence":
                errors.append(f"事实边未标记source_evidence: {edge_id}")
            if edge.get("runtime_value_status") != "not_observed":
                errors.append(f"事实边runtime状态错误: {edge_id}")
            if not evidence or not any(
                item.get("path") or item.get("evidence_id")
                for item in evidence
                if isinstance(item, dict)
            ):
                errors.append(f"事实边缺少可追溯证据: {edge_id}")

        for evidence_item in evidence:
            if not isinstance(evidence_item, dict):
                errors.append(f"证据项不是对象: {edge_id}")
                continue
            path_text = evidence_item.get("path")
            if not path_text:
                continue
            if ABSOLUTE_PATH_RE.search(path_text):
                errors.append(f"证据包含绝对路径: {edge_id} -> {path_text}")
                continue
            posix_path = PurePosixPath(path_text.replace("\\", "/"))
            if ".." in posix_path.parts:
                errors.append(f"证据路径越界: {edge_id} -> {path_text}")
                continue
            if not (ROOT / Path(*posix_path.parts)).is_file():
                errors.append(f"证据文件不存在: {edge_id} -> {path_text}")
            line_start = evidence_item.get("line_start")
            line_end = evidence_item.get("line_end")
            if line_start is not None and (
                not isinstance(line_start, int) or line_start < 1
            ):
                errors.append(f"证据起始行非法: {edge_id}")
            if line_end is not None and (
                not isinstance(line_end, int)
                or line_end < 1
                or (isinstance(line_start, int) and line_end < line_start)
            ):
                errors.append(f"证据结束行非法: {edge_id}")

    if set(relation_counts) != RELATION_TYPES:
        errors.append(
            "关系类型覆盖不完整: "
            f"missing={sorted(RELATION_TYPES-set(relation_counts))}, "
            f"extra={sorted(set(relation_counts)-RELATION_TYPES)}"
        )
    for relation_type in RELATION_TYPES:
        if relation_counts[relation_type] < 1:
            errors.append(f"关系类型没有任何边: {relation_type}")
    if len(edge_ids) != len(set(edge_ids)):
        duplicates = sorted(
            edge_id for edge_id, count in Counter(edge_ids).items() if count > 1
        )
        errors.append(f"关系ID重复: {duplicates}")
    if len(edge_keys) != len(set(edge_keys)):
        errors.append("存在重复的关系类型-源-目标三元组")
    if edge_keys != sorted(edge_keys):
        errors.append("JSONL未按relation_type/source/target确定性排序")

    missing_variable_nodes = sorted(set(variables) - set(variable_degree))
    isolated_factual = sorted(set(variables) - set(factual_degree))
    if missing_variable_nodes:
        errors.append(f"全图孤立正式变量: {missing_variable_nodes}")
    if isolated_factual:
        errors.append(f"排除aliases后孤立正式变量: {isolated_factual}")

    if not reachable(
        edges,
        "artifact.pysc2.observation",
        "artifact.pysc2.function_call",
    ):
        errors.append("核心链路observation到FunctionCall不可达")
    cycle = find_cycle(edges)
    if cycle:
        errors.append(f"因果转换子图存在循环: {' -> '.join(cycle)}")

    # aliases边必须与步骤七反向索引完全一致。
    expected_alias_pairs: set[tuple[str, str]] = set()
    for index_row in aliases.get("alias_index", []):
        term = index_row.get("normalized_term")
        if not isinstance(term, str):
            errors.append("步骤七alias_index存在非法normalized_term")
            continue
        alias_id = f"alias.{stable_hash(term)}"
        for match in index_row.get("candidate_matches", []):
            variable_id = match.get("variable_id")
            expected_alias_pairs.add((alias_id, variable_id))
            node = endpoint_metadata.get(alias_id)
            if node and node.get("label") != term:
                errors.append(f"alias节点标签与步骤七不一致: {term}")
    if actual_alias_pairs != expected_alias_pairs:
        errors.append(
            "aliases边与步骤七索引不一致: "
            f"missing={len(expected_alias_pairs-actual_alias_pairs)}, "
            f"extra={len(actual_alias_pairs-expected_alias_pairs)}"
        )

    # 保护两个关键语义边界，防止自动关系把不同接口量静默合并。
    absolute_health = {
        "abox.unit.hp",
        "raw_unit.health",
        "tbox.entity.hp",
    }
    ratio_health = {
        "abox.unit.hp_ratio",
        "derived.tactical.enemy_avg_hp",
        "derived.tactical.friendly_avg_hp",
        "raw_unit.health_ratio",
    }
    alias_targets_by_label: dict[str, set[str]] = defaultdict(set)
    for edge in edges:
        if edge.get("relation_type") == "aliases":
            alias_targets_by_label[edge["source"]["label"]].add(
                edge["target"]["id"]
            )
    for term in {"hp", "生命值", "血量"}:
        if alias_targets_by_label.get(term) != absolute_health:
            errors.append(f"绝对血量别名候选错误: {term}")
    for term in {"hp ratio", "生命比例", "血量比例"}:
        if alias_targets_by_label.get(term) != ratio_health:
            errors.append(f"血量比例别名候选错误: {term}")

    forbidden_pair = ("action.planned_actions", "swm.input.planned_actions")
    if any(
        edge["source"]["id"] == forbidden_pair[0]
        and edge["target"]["id"] == forbidden_pair[1]
        for edge in edges
    ):
        errors.append("整数action.planned_actions被错误直连到SWM动作列表")
    if not any(
        edge["source"]["id"] == "artifact.storm.validated_actions"
        and edge["target"]["id"] == "swm.input.planned_actions"
        and edge["relation_type"] == "stored_as"
        for edge in edges
    ):
        errors.append("缺少校验后动作列表到SWM planned_actions的真实连接")

    # 人类文档必须如实声明静态边界并包含Mermaid和冲突说明。
    for path in (DOC_PATH, AUDIT_PATH):
        if not path.is_file():
            errors.append(f"缺少步骤八文档: {path.relative_to(ROOT)}")
            continue
        text = path.read_text(encoding="utf-8")
        if any(marker in text for marker in BAD_UNICODE):
            errors.append(f"文档存在乱码标记: {path.relative_to(ROOT)}")
        for phrase in ("未执行", "未调用"):
            if phrase not in text:
                errors.append(
                    f"文档缺少运行边界“{phrase}”: {path.relative_to(ROOT)}"
                )
        if "action.planned_actions" not in text or "swm.input.planned_actions" not in text:
            errors.append(f"文档未说明planned_actions冲突: {path.relative_to(ROOT)}")
    if DOC_PATH.is_file():
        doc_text = DOC_PATH.read_text(encoding="utf-8")
        if "```mermaid" not in doc_text or "flowchart LR" not in doc_text:
            errors.append("变量图文档缺少Mermaid总览")
        for relation_type in RELATION_TYPES:
            if f"`{relation_type}`" not in doc_text:
                errors.append(f"变量图文档缺少关系定义: {relation_type}")
    if AUDIT_PATH.is_file():
        audit_text = AUDIT_PATH.read_text(encoding="utf-8")
        for expected in (
            "| 正式变量数量 | 135 |",
            "| observation到FunctionCall可达 | 通过 |",
            "| 全图孤立正式变量 | 0 |",
            "| 排除aliases后的孤立正式变量 | 0 |",
            "| 损坏的变量引用 | 0 |",
            "| 因果转换子图循环 | 未发现 |",
        ):
            if expected not in audit_text:
                errors.append(f"审计报告摘要不匹配: {expected}")

    for path in (RELATIONS_PATH, DOC_PATH, AUDIT_PATH):
        if path.is_file():
            try:
                path.relative_to(K)
            except ValueError:
                errors.append(f"步骤八产物不在knowledge内: {path}")

    for value in iter_strings(edges):
        if any(marker in value for marker in BAD_UNICODE):
            errors.append("关系边表存在乱码标记")
            break

    print(f"variables: {len(variables)}")
    print(f"edges: {len(edges)}")
    print(f"nodes: {len(endpoint_metadata)}")
    for relation_type in sorted(RELATION_TYPES):
        print(f"relation.{relation_type}: {relation_counts[relation_type]}")
    print(
        "core_observation_to_function_call_reachable: "
        f"{reachable(edges, 'artifact.pysc2.observation', 'artifact.pysc2.function_call')}"
    )
    print(f"isolated_all: {len(missing_variable_nodes)}")
    print(f"isolated_factual: {len(isolated_factual)}")
    print(f"causal_cycle: {'none' if not cycle else ' -> '.join(cycle)}")
    print(f"errors: {len(errors)}")
    print(f"warnings: {len(warnings)}")
    for message in errors:
        print(f"ERROR: {message}")
    for message in warnings:
        print(f"WARNING: {message}")
    print(f"RESULT: {'PASS' if not errors else 'FAIL'}")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
