# Challenge v0.2 首次冻结盲测报告

> 日期：2026-09-04  
> 模式：本地 `dry-run`，未调用外部 LLM，未启动 SC2。  
> 冻结题集 SHA-256：`10dd404a28eebf146a150b3191f25591f4b5d901dd027899e5a3ba6f1b6accc4`

## 结论

这次结果说明：当前检索器在原 benchmark 和由 v0.1 失败题形成的开发集上表现很好，但对完全新写法和更复杂的多变量组合仍缺乏稳定泛化。v0.2 首次运行后没有继续修改检索器或题集。

## 首次盲测指标

| 指标 | 结果 |
|---|---:|
| 题数 | 35 |
| variable_hit_rate | 0.352381 |
| variable_precision | 0.491667 |
| variable_exact_match_rate | 0.057143 |
| evidence_hit_rate | 0.509524 |
| refusal_accuracy | 0.628571 |
| behavior_accuracy | 0.571429 |
| status_accuracy | 0.571429 |
| 严格通过 | 2 / 35 |
| 运行失败 | 0 |

## 失败模式

| 模式 | 数量 | 含义 |
|---|---:|---|
| expected_nonempty_but_not_found | 12 | 应命中变量，但检索器直接返回未找到 |
| partial_or_mixed_recall | 15 | 多变量问题只找回一部分，或混入错误候选 |
| all_expected_plus_extras | 3 | 找全期望变量，但带入额外变量 |
| out_of_scope_false_positive | 1 | 范围外问题被错误映射到正式变量 |
| wrong_candidates_only | 2 | 只返回错误候选 |
| pass | 2 | 变量、行为、状态和证据均严格通过 |

严格通过题为：

- `challenge.v0.2.024.production-function-ids`
- `challenge.v0.2.034.out-buff-duration`

## 主要观察

1. **复合意图拆解不足**：35 题中有 21 题是多变量比较，许多题只召回一个分量。
2. **层级链路语言泛化不足**：Raw → ABox → TBox、动作 → FunctionCall、预测量 → RMSE 等新表述容易返回 `not_found`。
3. **歧义触发词依赖明显**：新的“没交代来源/没有说明静态还是运行时”表达没有稳定触发 ambiguous。
4. **范围识别仍会泄漏**：RGB/feature-layer 镜头题被错误映射为 Raw x/y。
5. **开发集满分不代表真实泛化**：泛化开发集已参与规则改进；v0.2 的低分更能反映当前未见表达下的能力边界。

## 冻结纪律

- v0.2 在首次运行前生成、校验并记录哈希；
- 与 dev、test、challenge v0.1、generalization dev v0.1 的规范化题面重合为 0；
- 首次盲测后未修改检索器、语义规则、题集或期望答案；
- 后续若改进，应复制失败题为新的开发集，并另建 challenge v0.3，而不是重跑后覆盖本结果。

## 证据文件

- `knowledge/evals/questions_challenge_v0.2.jsonl`
- `knowledge/evals/challenge_v0.2_manifest.json`
- `knowledge/evals/results/20260904_172500_challenge_v0.2_frozen_dry-run/`
- `knowledge/evals/challenge_v0.2_analysis.json`
