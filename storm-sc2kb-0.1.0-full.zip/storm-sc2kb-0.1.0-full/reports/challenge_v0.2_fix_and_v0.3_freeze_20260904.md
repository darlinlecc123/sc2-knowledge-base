# challenge v0.2 泛化修复与 challenge v0.3 冻结报告

> 日期：2026-09-04  
> 范围：STORM PySC2 Raw API 知识库离线检索层  
> 运行边界：未调用外部 LLM，未启动 StarCraft II，未读取密钥，未修改 STORM 业务源码。

## 1. 目标与冻结策略

1. 永久保留 `questions_challenge_v0.2.jsonl` 及首次盲测结果；
2. 将 v0.2 的失败题复制为可参与调参的 `generalization_dev_v0.2`；
3. 修复多变量拆解、跨层血缘、歧义和范围外误召回；
4. 完整回归旧数据集；
5. 创建全新 challenge v0.3，先冻结、后测试；本轮不运行 v0.3。

## 2. v0.2 原始基线保持不变

- 冻结题数：35；
- SHA-256：`10dd404a28eebf146a150b3191f25591f4b5d901dd027899e5a3ba6f1b6accc4`；
- 首次严格通过：2/35；
- 本轮未覆盖题集、清单或首次结果。

## 3. 可调开发集

从 v0.2 首次运行的 33 道失败题确定性生成：

- `knowledge/evals/questions_generalization_dev_v0.2.jsonl`；
- `knowledge/evals/generalization_dev_v0.2_manifest.json`；
- `knowledge/scripts/generate_generalization_dev_v0_2.py`。

开发集明确标注可参与调参，不再作为盲测集使用。

## 4. 修复内容

### 4.1 可组合语义概念

`knowledge/retrieval/semantic_concepts.json` 从 26 条扩展至 58 条规则。新增能力覆盖：

- Raw 单位类型、实例身份和阵营的组合；
- 生命/护盾原值与比例的组合；
- Raw → ABox → TBox 多层链路；
- TBox 火力、视野、生产成本和分类属性组合；
- ABox 图级、节点和关系字段组合；
- 战术摘要双方统计及空间态势；
- 动作类型、目标契约、延迟队列及无效动作统计；
- FunctionCall 参数和 Function ID；
- player 人口公式、TimeStep 得分；
- SWM 输入、输出、误差指标；
- 跨层 `armor`、`tag` 歧义。

规则保存概念短语和槽位，不保存 question ID，也不在运行时读取 benchmark 答案。

### 4.2 范围边界优先判断

`knowledge/src/sc2kb/qa_agent.py` 新增声明式 `scope_exclusions` 支持。在普通相似度检索前识别明确的 RGB、feature-layer、camera、screen/minimap feature 查询，防止误映射为 `raw_unit.x/y`。

### 4.3 防回归测试

- 33 道 v0.2 失败开发题加入精确变量与状态回归；
- v0.3 SHA-256 加入固定单元测试；
- JSON/JSONL 清单增加 v0.2 开发集和 v0.3；
- scope exclusion ID 增加唯一性检查。

## 5. 修复后结果

### generalization_dev_v0.2（33 题）

| 指标 | 结果 |
|---|---:|
| variable_hit_rate | 1.0 |
| variable_precision | 1.0 |
| variable_exact_match_rate | 1.0 |
| evidence_hit_rate | 1.0 |
| behavior_accuracy | 1.0 |
| status_accuracy | 1.0 |
| failure_count | 0 |

结果目录：`knowledge/evals/results/20260904_generalization_dev_v0.2_round1_dry-run/`。

### 旧集合回归

| 集合 | 题数 | 变量精确匹配 | 证据命中 | 行为/状态 |
|---|---:|---:|---:|---:|
| dev | 36 | 1.0 | 1.0 | 1.0 |
| test | 18 | 1.0 | 1.0 | 1.0 |
| generalization dev v0.1 | 26 | 1.0 | 1.0 | 1.0 |
| challenge v0.1 | 32 | 1.0 | 1.0 | 1.0 |

上述集合已参与开发或回归，不能解释为新的盲测成绩。

## 6. challenge v0.3 冻结信息

- 题数：41；
- answer：35；clarify：3；refuse：3；
- hard：27；medium：14；
- 题型：多变量、lineage、known issue、interface、formula、ambiguous、out-of-scope；
- 与 dev、test、generalization dev v0.1/v0.2、challenge v0.1/v0.2 的规范化题面重合：0；
- SHA-256：`e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044`；
- 生成阶段未导入或调用检索器；
- 首次评测状态：`not_run_at_freeze_time`。

冻结文件：

- `knowledge/evals/questions_challenge_v0.3.jsonl`；
- `knowledge/evals/challenge_v0.3_manifest.json`；
- `knowledge/scripts/generate_challenge_v0_3.py`；
- `knowledge/tests/validate_challenge_v0_3.py`。

本轮没有生成任何 challenge v0.3 评测结果目录。

## 7. 最终测试

```text
Ran 23 tests in 18.027s
OK
```

v0.1、v0.2、v0.3 冻结校验和三个生成器 `--check` 均为 PASS。

## 8. 尚未执行

- challenge v0.3 的首次离线盲测；
- DeepSeek、Codex/OpenAI 等真实模型测试；
- SC2 运行时语义核验。

## 9. 下一步

下一步应只执行一次 challenge v0.3 dry-run，保存完整结果并生成失败模式报告。首次结果产生后不得修改 v0.3 题集和清单；若需继续调参，应把失败题复制成新的开发集，再创建 v0.4。
