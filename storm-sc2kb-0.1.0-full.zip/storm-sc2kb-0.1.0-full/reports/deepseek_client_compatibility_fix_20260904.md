# DeepSeek 客户端兼容性修复与复杂题复测报告

- 日期：2026-09-04
- 状态：客户端修复完成，离线回归通过，非 challenge 复杂题真实复测通过
- 外部请求：2 次，均不重试（1 次脱敏诊断 + 1 次修复后复杂题 smoke）
- 冻结 challenge v0.3 SHA-256：`e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044`

## 1. 诊断结论

脱敏诊断使用 `test.002.oral-health-shield`。接口返回 `finish_reason=stop`，同时存在非空 `content` 和 `reasoning_content`，并返回完整 usage。诊断没有保存提示词、回答正文或密钥。

诊断同时发现，首次 41 题评测使用的是冒烟配置 `max_output_tokens=800`，而统一正式协议要求 2000。复杂题可能在推理阶段接近或耗尽 800-token 上限，导致最终 `content` 为空。因此首次结果只能作为故障审计，不能进入统一参数比较。

## 2. 实现修改

- `knowledge/src/sc2kb/model_clients.py`
  - 保存脱敏 `last_call_metadata`；
  - 记录 `finish_reason`、文本字段长度、正文来源与 usage；
  - 仅当 `reasoning_content` 本身是合法 JSON 对象时才允许回退，避免暴露或采用普通思维链；
  - 区分输出截断、仅有推理字段、完全空内容和缺少 choice。
- `knowledge/src/sc2kb/qa_agent.py`
  - 把模型元数据和具体 `failure_reason` 写入 Agent 结果。
- `knowledge/evals/run_evaluation.py`
  - 从模型元数据提取 token usage；
  - 分开记录循环 attempts 和真实 `api_call_attempts`。
- `knowledge/evals/scorers.py`
  - 新增模型调用数、可用回答数、模型错误数、本地短路数、调用成功率、空正文数和截断数。
- `knowledge/evals/report.py`
  - 在总体表中展示新的模型运行指标，并补充指标解释边界。
- `knowledge/evals/configs/deepseek_v4_flash_formal.yaml`
  - 正式参数固定为 `temperature=0`、`max_output_tokens=2000`、`max_retries=0`。

## 3. 离线验证

通过：

```text
MODEL_RUNTIME_METADATA_TEST_OK
validate_step12: PASS
validate_step14: PASS
STEP16_PLANNED_VALIDATION_OK
```

离线测试覆盖：正文成功、合法 JSON 推理字段回退、输出截断分类、usage 聚合和模型调用统计。

## 4. 修复后真实复杂题 smoke

- 运行 ID：`20260904_deepseek_v4_flash_formal_complex_smoke`
- 题目：`test.006.target-interface`，非 challenge
- 最大输出 tokens：2000
- API 调用：1
- 重试：0
- 状态：`answered`
- `finish_reason=stop`
- 正文来源：`content`
- `model_called_count=1`
- `model_answered_count=1`
- `model_error_count=0`
- `variable_exact_match=true`
- `required_fact_coverage=0.833333`
- `evidence_hit_rate=1.0`
- `behavior_correct=true`
- `status_correct=true`
- prompt tokens：2795
- completion tokens：1975，其中 reasoning tokens：1208
- total tokens：4770
- 费用：服务端/配置未提供单价，保持 `null`，不作估算

这道复杂题的 completion tokens 达到 1975，已经非常接近 2000 上限，进一步支持“800-token 冒烟配置不适合正式复杂题”的判断。

## 5. 产物

- 脱敏诊断脚本：`knowledge/evals/diagnose_deepseek_response.py`
- 脱敏诊断结果：`knowledge/evals/results/20260904_deepseek_response_diagnostic_health_shield.json`
- 正式模型配置：`knowledge/evals/configs/deepseek_v4_flash_formal.yaml`
- 离线回归测试：`knowledge/tests/test_model_runtime_metadata.py`
- 复杂题复测目录：`knowledge/evals/results/20260904_deepseek_v4_flash_formal_complex_smoke/`

## 6. 下一执行门

客户端已具备重新运行 DeepSeek RAG 的条件，但修复后的 41 题运行必须使用新的运行 ID，并明确标注为“协议参数修复后复测”。本报告没有自动启动该批量复测，也没有执行另外两种知识条件。
