# STORM Raw API 知识库证据修复与冻结挑战集报告

- 日期：2026-09-04
- 运行模式：本地确定性 `dry-run`
- 外部 LLM：未调用
- StarCraft II：未启动
- LLM Judge：未调用

## 1. 本轮完成内容

1. 修复三道范围外题缺少 `scope-v0.1-manifest` 的问题；
2. 将步骤 09 已知问题的 issue ID 和源码位置聚合到 QA grounding；
3. 复跑原 36 道开发集和 18 道保留测试集；
4. 创建、去重、哈希并冻结 32 道全新泛化挑战题；
5. 在冻结后进行一次盲测，测试后未修改检索规则；
6. 保存机器可读逐题分析。

## 2. 四道题的证据绑定修复

### 2.1 范围外拒答

当检索状态为 `not_found` 时，grounding 现在会明确加入：

- evidence ID：`scope-v0.1-manifest`；
- 路径：`knowledge/manifests/scope.yaml`；
- 符号：`scope.in_scope_rule`；
- 事实状态：`design_intent`。

因此 `dev.032`、`dev.033` 和 `test.015` 在正确拒答的同时，也能给出为什么拒答的范围依据。

### 2.2 TBox 缓存问题

grounding 除变量主证据外，现在还会遍历 `known_issues.step09`，加入：

- `issue.ontology_pickle_may_be_stale`；
- `issue.unknown_unit_hp_default_is_static_only`；
- `ontology/loader.py` 与 `ontology/bridge.py` 中的问题证据位置。

因此 `dev.036.tbox-cache-issue` 要求的四项证据全部命中。

### 2.3 修复后原 benchmark

| 数据集 | 题数 | 变量命中率 | 精确率 | 完全匹配率 | 证据命中率 | 行为准确率 | 状态准确率 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 开发集 `20260904_163620_evidence_fix_dev_dry-run` | 36 | 1.0 | 1.0 | 1.0 | **1.0** | 1.0 | 1.0 |
| 保留测试集 `20260904_163620_evidence_fix_test_dry-run` | 18 | 1.0 | 1.0 | 1.0 | **1.0** | 1.0 | 1.0 |

## 3. 冻结挑战集设计

- 题目数量：32；
- 与原 54 题规范化文本重叠：0；
- SHA-256：`68f04650fca4183d213bdfa149a9f9526c2d457fc065dc0a57f52be3016f1c04`；
- 题型：口语、英文、公式、跨层来源、多变量比较、已知问题、歧义、错误前提和范围外拒答；
- 行为分布：28 道回答、2 道澄清、2 道拒答；
- 冻结前生成器和校验器均未导入或调用检索器；
- 首次评测后没有修改检索算法、别名或题目。

## 4. 首次盲测结果

结果目录：`knowledge/evals/results/20260904_164301_challenge_v0.1_frozen_dry-run/`

| 指标 | 数值 |
|---|---:|
| 题数 | 32 |
| 变量命中率 | 0.354167 |
| 变量精确率 | 0.427083 |
| 变量完全匹配率 | 0.1875 |
| 证据命中率 | 0.546875 |
| 拒答准确率 | 0.6875 |
| 行为准确率 | 0.65625 |
| 状态准确率 | 0.65625 |
| 程序失败数 | 0 |

- 严格通过：**6/32**；
- 严格未通过：**26/32**；
- `required_fact_coverage=1.0` 是因为这套挑战集专测检索，未设置最终自然语言事实项，不能解释为回答事实全部正确。

## 5. 失败模式

| 模式 | 数量 | 含义 |
|---|---:|---|
| `all_expected_plus_extras` | 2 | 期望变量全部出现，但还混入无关候选 |
| `ambiguity_not_preserved` | 1 | 应保留跨层歧义，却被压缩为单一候选 |
| `expected_nonempty_but_not_found` | 10 | 存在正式变量，但新措辞没有触发任何候选 |
| `partial_or_mixed_recall` | 6 | 命中部分期望变量，同时漏召回或混入错误项 |
| `pass` | 6 | 变量集合、行为、状态和证据均符合预期 |
| `wrong_candidates_only` | 7 | 返回了候选，但没有一个是期望变量 |

主要暴露出四类泛化短板：

1. **语义同义表达不足**：如“同类单位逐个追踪”“肉身血条”“人口成本”“总体生命标签”无法稳定映射到正式字段；
2. **多意图拆解不足**：一句话要求两个或三个量时，经常只返回其中一个；
3. **泛词压制具体语义**：`Raw` 容易误导到 `raw_flag`，瓦斯表达容易只命中 `player.vespene`；
4. **跨层歧义不稳定**：`description` 能正确保留 TBox/ABox 歧义，但新措辞下的 `tag` 被压成 ABox 单候选。

## 6. 逐题结果

| ID | 结果 | 期望变量 | 实际变量 | 实际状态 | 证据 |
|---|---|---|---|---|---:|
| `challenge.001.identity-type-not-instance` | 未通过 | `raw_unit.unit_type` | 无 | `not_found` | 0.0 |
| `challenge.002.identity-instance-not-type` | 未通过 | `raw_unit.tag` | `pysc2.function.raw_flag` | `ready` | 0.0 |
| `challenge.003.survival-two-bars` | 未通过 | `raw_unit.health`<br>`raw_unit.shield` | 无 | `not_found` | 0.0 |
| `challenge.004.health-normalized` | 未通过 | `raw_unit.health_ratio` | `abox.unit.hp`<br>`raw_unit.health`<br>`tbox.entity.hp` | `ready` | 1.0 |
| `challenge.005.raw-grid-location` | 未通过 | `raw_unit.x`<br>`raw_unit.y` | `pysc2.function.raw_flag` | `ready` | 0.0 |
| `challenge.006.cooldown-readiness-en` | 未通过 | `raw_unit.weapon_cooldown` | 无 | `not_found` | 0.0 |
| `challenge.007.abox-type-id` | 未通过 | `abox.unit.unit_type_id` | 无 | `not_found` | 0.0 |
| `challenge.008.position-lineage` | 未通过 | `abox.unit.position`<br>`raw_unit.x`<br>`raw_unit.y` | `abox.unit.position` | `ready` | 0.333333 |
| `challenge.009.unknown-node-flag` | 未通过 | `abox.unit.is_unknown` | 无 | `not_found` | 0.0 |
| `challenge.010.armor-shield-quirk` | 通过 | `abox.unit.armor`<br>`raw_unit.shield` | `abox.unit.armor`<br>`raw_unit.shield` | `ready` | 1.0 |
| `challenge.011.tbox-dps` | 通过 | `tbox.entity.dps` | `tbox.entity.dps` | `ready` | 1.0 |
| `challenge.012.tbox-two-costs` | 未通过 | `tbox.entity.gas_cost`<br>`tbox.entity.mineral_cost` | `player.vespene` | `ready` | 0.0 |
| `challenge.013.tbox-population-cost` | 未通过 | `tbox.entity.supply_cost` | 无 | `not_found` | 0.0 |
| `challenge.014.force-balance` | 未通过 | `derived.tactical.force_ratio` | 无 | `not_found` | 0.0 |
| `challenge.015.two-centers` | 未通过 | `derived.tactical.enemy_centroid`<br>`derived.tactical.friendly_centroid` | 无 | `not_found` | 0.0 |
| `challenge.016.fire-ready-summary` | 未通过 | `derived.tactical.fire_readiness`<br>`derived.tactical.ready_to_fire_count` | `derived.tactical.fire_readiness` | `ready` | 1.0 |
| `challenge.017.health-bucket` | 未通过 | `derived.tactical.health_status` | 无 | `not_found` | 0.0 |
| `challenge.018.action-actors-and-kind` | 未通过 | `action.target_type`<br>`action.units` | `abox.relation.target_node`<br>`action.planned_actions`<br>`action.target`<br>`pysc2.function.target`<br>`swm.input.planned_actions` | `ready` | 1.0 |
| `challenge.019.action-invalid-why` | 未通过 | `action.invalid_reason_counts` | `action.plan` | `ready` | 1.0 |
| `challenge.020.timing-three-clocks` | 未通过 | `action.delay_steps`<br>`environment.decision_interval`<br>`environment.step_mul` | `environment.decision_interval`<br>`environment.step_mul` | `ready` | 0.666667 |
| `challenge.021.function-arguments` | 未通过 | `pysc2.function.target`<br>`pysc2.function.unit_tags` | `pysc2.function.target` | `ready` | 1.0 |
| `challenge.022.production-functions` | 未通过 | `pysc2.build.function_id`<br>`pysc2.train.function_id` | `pysc2.function.raw_flag` | `ready` | 1.0 |
| `challenge.023.supply-equation` | 未通过 | `player.food_cap`<br>`player.food_used`<br>`player.supply_remaining` | `player.supply_remaining` | `ready` | 1.0 |
| `challenge.024.reward-vs-score` | 未通过 | `timestep.reward_delta`<br>`timestep.score_cumulative_0` | `metric.episode.final_score`<br>`metric.experiment.avg_score`<br>`timestep.reward_delta`<br>`timestep.score_cumulative_0` | `ready` | 1.0 |
| `challenge.025.swm-actions-to-states` | 未通过 | `swm.input.planned_actions`<br>`swm.predicted_unit_states` | `action.plan`<br>`swm.input.planned_actions`<br>`swm.predicted_unit_states` | `ready` | 1.0 |
| `challenge.026.swm-position-change-error` | 未通过 | `metric.swm.position_rmse`<br>`swm.unit.position_delta` | `metric.swm.health_rmse`<br>`metric.swm.position_rmse` | `ready` | 1.0 |
| `challenge.027.token-accounting` | 未通过 | `metric.llm.completion_tokens`<br>`metric.llm.prompt_tokens`<br>`metric.llm.total_tokens` | 无 | `not_found` | 0.0 |
| `challenge.028.ambiguous-description` | 通过 | `abox.unit.description`<br>`tbox.entity.description` | `abox.unit.description`<br>`tbox.entity.description` | `ambiguous` | 1.0 |
| `challenge.029.ambiguous-tag` | 未通过 | `abox.unit.tag`<br>`raw_unit.tag` | `abox.unit.tag` | `ready` | 0.5 |
| `challenge.030.false-max-health` | 通过 | `raw_unit.health` | `raw_unit.health` | `ready` | 1.0 |
| `challenge.031.out-of-scope-energy-regen` | 通过 | 无（应拒答） | 无 | `not_found` | 1.0 |
| `challenge.032.out-of-scope-camera` | 通过 | 无（应拒答） | 无 | `not_found` | 1.0 |

## 7. 正确解释

原 54 题满分说明系统对已覆盖表达和回归契约稳定；冻结挑战集只有 18.75% 的变量完全匹配率，说明当前基于别名、规则和有限关系扩展的检索器对真正未见措辞的泛化仍然较弱。两者并不矛盾。

本结果不能证明知识库内容本身错误，也不能证明真实 LLM Agent 只能达到相同分数。它主要测量当前离线确定性查询规划器，在没有语言模型参与时将新自然语言映射到正式变量的能力。

## 8. 后续迭代原则

为保持挑战集的独立性，不应直接修改 `questions_challenge_v0.1.jsonl` 或在同一版本上反复调到满分。建议：

1. 永久保留 challenge v0.1 的题目、哈希和首次盲测结果；
2. 将本次失败模式抽象成能力需求，而不是逐题添加原句别名；
3. 使用变量定义、接口名、关系图和主题分片构建通用语义召回与多意图拆解；
4. 把 v0.1 失败题作为后续开发诊断集；
5. 完成通用改进后，再创建从未见过的 challenge v0.2 作为新的保留集；
6. 若获得授权，再分别测试“纯检索”和“知识库上下文 + 真实 LLM”的效果。

## 9. 产物

- 冻结题集：`knowledge/evals/questions_challenge_v0.1.jsonl`；
- 冻结清单：`knowledge/evals/challenge_v0.1_manifest.json`；
- 生成器：`knowledge/scripts/generate_challenge_set.py`；
- 校验器：`knowledge/tests/validate_challenge_set.py`；
- 机器可读分析：`knowledge/evals/challenge_v0.1_analysis.json`；
- 首次盲测：`knowledge/evals/results/20260904_164301_challenge_v0.1_frozen_dry-run/`。
