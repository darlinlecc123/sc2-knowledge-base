# Challenge v0.3 首次离线盲测报告

- 评测日期：2026-09-04（Asia/Shanghai）
- 运行性质：冻结后唯一一次首次离线盲测
- 模式：`dry-run`（未调用外部 LLM，未启动 SC2）
- 题集：`knowledge/evals/questions_challenge_v0.3.jsonl`
- 题数：41
- 冻结 SHA-256（运行前）：`e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044`
- 运行后 SHA-256：`e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044`
- 结果目录：`knowledge/evals/results/20260904_challenge_v0.3_frozen_first_dry-run/`

## 1. 冻结与盲测完整性

1. 运行前题集哈希与冻结清单一致。
2. 运行前不存在 challenge v0.3 结果目录。
3. 评测使用全量 41 题，`resume=false`，没有按题筛选或限制数量。
4. 运行完成后题集哈希保持不变。
5. 本次运行后未修改题集、清单、`qa_agent.py` 或 `semantic_concepts.json`，也未进行调参或二次运行。
6. 冻结清单文件当前 SHA-256 为 `261b98ed85005eaf93de58ef0cb1e374e53923dbd0e978ab2c282439e1b06428`。

## 2. 核心结果

| 指标 | 结果 |
|---|---:|
| 严格通过（变量完全匹配 + 证据满分 + 行为/状态/拒答正确） | 4/41（9.76%） |
| 变量完全匹配 | 6/41（14.63%） |
| variable_hit_rate | 0.409350 |
| variable_precision | 0.591260 |
| evidence_hit_rate | 0.639024 |
| required_fact_coverage | 1.000000 |
| behavior_accuracy | 0.634146（26/41） |
| status_accuracy | 0.634146（26/41） |
| refusal_accuracy | 0.682927（28/41，评测器全题口径） |
| forbidden_assertion_rate | 0.000000 |
| 运行异常数 | 0 |

> `failure_count=0` 仅表示 41 条评测记录均未出现运行异常（`error is None`），不表示知识库回答全部通过。质量上仍有 37 道题未达到本报告定义的严格通过条件。

严格通过题：

- `challenge.v0.3.025.environment-clock-display`
- `challenge.v0.3.036.ambiguous-hp-v3`
- `challenge.v0.3.040.out-unit-energy`
- `challenge.v0.3.041.out-minimap-visibility`

## 3. 按题型表现

| 题型 | 数量 | 变量完全匹配 | 平均召回 | 平均精度 | 平均证据命中 | 行为正确 |
|---|---:|---:|---:|---:|---:|---:|
| multi_variable_comparison | 23 | 1/23 | 0.339 | 0.587 | 0.603 | 15/23 |
| lineage | 3 | 0/3 | 0.222 | 0.400 | 0.444 | 2/3 |
| known_issue_trap | 1 | 0/1 | 1.000 | 0.667 | 1.000 | 1/1 |
| interface | 7 | 0/7 | 0.331 | 0.554 | 0.714 | 5/7 |
| formula | 1 | 0/1 | 0.000 | 0.000 | 0.000 | 0/1 |
| ambiguous | 3 | 3/3 | 1.000 | 1.000 | 1.000 | 1/3 |
| out_of_scope | 3 | 2/3 | 0.667 | 0.667 | 0.667 | 2/3 |

## 4. 按预期行为表现

| 预期行为 | 正确/总数 |
|---|---:|
| answer | 23/35 |
| clarify | 1/3 |
| refuse | 2/3 |

- `clarify`：仅 HP 歧义题正确触发澄清；alliance 与 attack range 歧义题虽找到了两层变量，但错误地直接回答。
- `refuse`：单位能量与 minimap visibility 正确拒答；camera zoom 被误匹配到 `pysc2.function.raw_flag`。

## 5. 主要泛化问题

1. **多变量组合召回不足**：23 道多变量比较题仅 1 道变量集合完全匹配，常见表现是只返回组合中的一个或两个字段。
2. **同域“字段束”识别不足**：TBox 的攻击、机动/视野、生产成本，ABox 的边字段、图计数，SWM 输出封装等组合出现整组未命中。
3. **跨层 lineage 不稳定**：Raw→ABox 身份链完全未命中；Raw/TBox/ABox 的生命值三来源只返回 ABox 字段。
4. **精度污染**：已命中目标字段时仍夹带相邻但非问题所需变量，例如 FunctionCall 公共参数混入各动作的 `function_id`。
5. **歧义策略泛化不足**：新措辞下 alliance、attack range 未触发 `ambiguous`。
6. **范围外拒答存在误触发**：camera zoom 被“raw”相关词误吸附到 `raw_flag`。
7. **公式题失效**：唯一公式题变量召回、证据与行为均未通过。

## 6. 行为或状态失败的 15 道题

| 题号 | 题型 | 期望行为/状态 | 实际状态 | 返回变量 |
|---|---|---|---|---|
| challenge.v0.3.004.raw-abox-identity-chain | lineage | answer/found | not_found | 空 |
| challenge.v0.3.007.tbox-offense-bundle | multi_variable_comparison | answer/found | not_found | 空 |
| challenge.v0.3.008.tbox-mobility-perception | multi_variable_comparison | answer/found | not_found | 空 |
| challenge.v0.3.009.tbox-production-bundle | multi_variable_comparison | answer/found | not_found | 空 |
| challenge.v0.3.013.abox-edge-identity | interface | answer/found | not_found | 空 |
| challenge.v0.3.014.abox-edge-explanation | interface | answer/found | not_found | 空 |
| challenge.v0.3.015.abox-graph-counters | multi_variable_comparison | answer/found | not_found | 空 |
| challenge.v0.3.016.tactical-side-counts | multi_variable_comparison | answer/found | not_found | 空 |
| challenge.v0.3.019.tactical-health-triple | multi_variable_comparison | answer/found | not_found | 空 |
| challenge.v0.3.023.invalid-action-bundle | multi_variable_comparison | answer/found | not_found | 空 |
| challenge.v0.3.027.player-supply-triple | formula | answer/found | not_found | 空 |
| challenge.v0.3.032.swm-result-envelope | multi_variable_comparison | answer/found | not_found | 空 |
| challenge.v0.3.037.ambiguous-alliance-v3 | ambiguous | clarify/ambiguous | ready | abox.unit.alliance, raw_unit.alliance |
| challenge.v0.3.038.ambiguous-range-v3 | ambiguous | clarify/ambiguous | ready | abox.unit.attack_range, tbox.entity.attack_range |
| challenge.v0.3.039.out-camera-zoom | out_of_scope | refuse/not_found | ready | pysc2.function.raw_flag |

## 7. 结论与后续纪律

本次结果是 challenge v0.3 的唯一首次冻结盲测基线。它表明当前离线 QA Agent 在单一概念、部分拒答与部分证据绑定上可用，但对未见过的多变量组合、跨层链路、歧义表达和范围外近义干扰仍缺乏稳定泛化。

后续若修复，不得修改或重新定义 v0.3 的首次成绩。应把失败题复制到新的可调开发集（建议命名 `questions_generalization_dev_v0.3.jsonl`），在开发集上修复与回归；下一次真正盲测必须创建并预先冻结新的 challenge v0.4。
