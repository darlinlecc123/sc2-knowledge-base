# DeepSeek challenge v0.3 检索增强评测审计报告

- 日期：2026-09-04
- 运行 ID：`20260904_deepseek_v4_flash_challenge_v0.3_rag_first`
- 模型：`deepseek-v4-flash`
- 条件：`retrieval_augmented`，`context_tier=standard`
- 冻结题集：`knowledge/evals/questions_challenge_v0.3.jsonl`
- 题数：41
- SHA-256：`e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044`
- 重试：0

> **协议合规性补充（2026-09-04）：** 本次 41 题运行误用了 `deepseek_v4_flash_smoke.yaml` 的 `max_output_tokens=800`，而步骤 16 统一正式参数为 2000。因此本结果保留为接口/截断故障审计，不纳入正式统一参数模型比较，也不得覆盖。

## 1. 简明结论

本轮已完成 DeepSeek 在当前知识库 RAG 链路上的首次 41 题正式运行，但结果暴露出严重的接口生成稳定性问题：26 个实际模型调用中，仅 2 个获得可解析正文，24 个被客户端记录为“模型返回了空内容”。因此，本轮可以作为端到端稳定性与故障审计结果保存，但不能把检索指标直接解释为 DeepSeek 的知识回答能力。

## 2. 调用与状态

| 项目 | 数值 |
|---|---:|
| 总题数 | 41 |
| 最多允许的 API 调用 | 41 |
| 实际进入模型调用 | 26 |
| 本地检索短路、未调用模型 | 15 |
| 获得可用模型正文 | 2 |
| 空内容 `model_error` | 24 |
| 模型调用可用生成率 | 2/26 = 7.69% |
| 自动重试 | 0 |

15 个未调用模型的案例由本地 QAAgent 直接形成状态：14 个 `not_found`，1 个 `ambiguous`。

## 3. 端到端自动评分

| 指标 | 结果 |
|---|---:|
| `behavior_accuracy` | 4/41 = 9.76% |
| `status_accuracy` | 4/41 = 9.76% |
| `variable_exact_match_rate` | 6/41 = 14.63% |
| `variable_hit_rate` | 40.94% |
| `variable_precision` | 59.13% |
| `evidence_hit_rate` | 63.90% |
| `refusal_accuracy` | 68.29% |
| `forbidden_assertion_rate` | 0% |

## 4. 按题型拆分

| 预期行为 | 题数 | 正确 | 主要失败 |
|---|---:|---:|---|
| answer | 35 | 1 | 22 个模型空内容错误；12 个检索未命中并短路 |
| clarify | 3 | 1 | 2 个模型空内容错误 |
| refuse | 3 | 2 | 1 个越界问题被错误回答 |

唯一正确完成模型回答的题目是 `challenge.v0.3.025.environment-clock-display`。另一个获得正文的题目 `challenge.v0.3.039.out-camera-zoom` 本应拒答，但错误关联到 `pysc2.function.raw_flag`。

## 5. 指标解释边界

1. **变量指标不是纯模型指标。** `candidate_variable_ids` 在调用模型之前由检索器产生；即使模型返回空内容，仍会参与变量命中评分。
2. **证据指标主要反映 grounding。** 当前评分会搜索 Agent 返回中的 grounding，因此模型生成失败时仍可能获得较高证据分。
3. **`required_fact_coverage=1.0` 无法解释。** challenge v0.3 的 41 道题中，`required_facts` 均为空，空集合默认得到 1.0。
4. **`failure_count=0` 不等于没有失败。** 该字段只统计顶层 runner 异常；24 个失败存放在 `agent_result.status=model_error`。
5. **Token 与费用未知。** 当前兼容客户端没有把服务端 usage 写入结果，因此 token 与 `estimated_cost_usd` 均为 `null`，本报告不作虚假估算。

## 6. 故障分类

- 接口/客户端兼容性错误：24 题，表现为 HTTP 调用未抛顶层异常，但 `message.content` 为空。
- 检索错误或召回不足：至少 12 道应回答题被本地规则直接判为 `not_found`。
- 越界拒答错误：1 题，摄像机缩放问题被错误回答。
- 成功回答：1 道 answer 题。
- 本地正确澄清/拒答：3 道。

## 7. 后续建议

1. 在不覆盖本轮结果的前提下，对 OpenAI-compatible 返回对象做脱敏结构审计，检查是否把正文放在 `reasoning_content`、其他字段或非预期 choice 中。
2. 将“模型调用成功率”和“模型正文可用率”加入正式聚合指标，避免 `failure_count=0` 掩盖 Agent 内部错误。
3. 将检索指标与模型生成指标拆开：检索候选、最终模型变量、grounding 证据、模型显式引用分别评分。
4. 修复前不要继续执行 `full_context` 或 `no_knowledge_base` 正式矩阵，否则可能重复产生大量空内容调用。
5. 若修复客户端后复测，应创建新运行 ID，并明确标注为接口修复后的复测，不得覆盖本次首次结果。

## 8. 产物

- 原始逐题结果：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_first/results.jsonl`
- 原始自动摘要：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_first/summary.json`
- 原始运行清单：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_first/run_manifest.json`
- 本审计摘要：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_first/audit_summary.json`
- 本报告：`knowledge/reports/deepseek_challenge_v0.3_rag_evaluation_audit_20260904.md`
