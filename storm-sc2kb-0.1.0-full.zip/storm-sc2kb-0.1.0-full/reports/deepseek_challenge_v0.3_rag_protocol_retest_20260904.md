# DeepSeek challenge v0.3 RAG 正式参数复测报告

## 1. 结论摘要

本轮在 **不修改冻结题集、不覆盖旧结果、不边测边调参** 的前提下，使用 `deepseek-v4-flash` 对 challenge v0.3 的 41 题执行了新一轮 `retrieval_augmented` 评测。参数符合当前协议：`temperature=0`、`max_output_tokens=2000`、`max_retries=0`。

- 41 题中，15 题由本地规则短路，26 题实际调用模型。
- 26 次调用中，12 题形成可采纳回答，14 题为 `model_error`，调用成功率为 **46.15%**。
- 相比旧的 800-token 故障审计，可采纳回答由 2 题提高到 12 题，`model_error` 由 24 题降到 14 题。
- 端到端 `behavior_accuracy` / `status_accuracy` 均由 **9.76%** 提高到 **29.27%**。
- 仍有 9 题在输出上限处截断且没有最终正文；另有 4 题正文不是合法 JSON 对象，1 题引用了检索候选以外的变量而被安全校验拒绝。
- 当前主要瓶颈已从“几乎全部空正文”转为“推理 token 占用较大、部分复杂题在 2000-token 上限前未产出最终 JSON，以及少量格式/候选约束错误”。

本轮是**协议修复后的复测**，不是 challenge v0.3 的首次离线盲测，也不是完整的多模型、三条件横向实验。

## 2. 运行依据

| 项目 | 值 |
|---|---|
| 运行 ID | `20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest` |
| 日期 | 2026-09-04 |
| 模型 | `deepseek-v4-flash` |
| 条件 | `retrieval_augmented` |
| context tier | `standard` |
| 题数 | 41 |
| 冻结题集 SHA-256 | `e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044` |
| temperature | 0 |
| max output tokens | 2000 |
| max retries | 0 |
| SC2 runtime | 未执行 |
| LLM judge | 未执行 |
| 结果目录 | `knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest/` |

题集哈希在运行后重新计算，与冻结清单一致。

## 3. 与 800-token 旧轮对比

旧轮 `20260904_deepseek_v4_flash_challenge_v0.3_rag_first` 误用了冒烟配置的 800-token 上限，只能作为故障审计；本轮使用正式 2000-token 配置。

| 指标 | 800-token 旧轮 | 2000-token 本轮 | 变化 |
|---|---:|---:|---:|
| 总题数 | 41 | 41 | 0 |
| 实际模型调用 | 26 | 26 | 0 |
| 本地短路 | 15 | 15 | 0 |
| 可采纳模型回答 | 2 | 12 | +10 |
| `model_error` | 24 | 14 | -10 |
| 空最终正文 | 24 | 9 | -15 |
| 已识别截断 | 旧客户端未记录 | 9 | 新增可观测性 |
| 模型调用成功率 | 7.69% | 46.15% | +38.46 个百分点 |
| behavior accuracy | 9.76% | 29.27% | +19.51 个百分点 |
| status accuracy | 9.76% | 29.27% | +19.51 个百分点 |
| variable exact match | 14.63% | 14.63% | 不变 |
| variable hit rate | 40.94% | 40.94% | 不变 |
| variable precision | 59.13% | 59.13% | 不变 |
| evidence hit rate | 63.90% | 63.90% | 不变 |
| token 统计 | 不可用 | 117,021 | 本轮接口已返回 usage |
| 估算费用 | `null` | `null` | 不编造 |

检索变量和证据指标完全不变，说明这部分主要由同一冻结题集、同一检索链路和 grounding 产生，**不能把它们直接解释成模型能力没有变化**。真正随客户端修复和输出上限变化的，是正文可用率、模型错误数及端到端行为正确率。

## 4. 本轮运行明细

### 4.1 调用与状态

| 项目 | 数量 |
|---|---:|
| `case_count` | 41 |
| `model_called_count` | 26 |
| `local_short_circuit_count` | 15 |
| `model_answered_count` | 12 |
| `model_error_count` | 14 |
| `runner_failure_count` | 0 |
| 非空最终正文 | 17 |
| 空最终正文 | 9 |
| 输出截断 | 9 |

状态分布：`answered=12`、`model_error=14`、`not_found=14`、`ambiguous=1`。

`finish_reason` 在 26 次调用中为：`stop=13`、`length=13`。其中 9 次 `length` 没有最终正文，被明确标为 `output_truncated_before_final_content`；另外 4 次虽然有正文，但正文未形成可接受结果。

### 4.2 错误分类

14 个 `model_error` 可分为：

1. **输出截断且无最终 JSON：9 题**  
   `challenge.v0.3.012`、`.020`、`.021`、`.022`、`.026`、`.028`、`.030`、`.031`、`.035`。
2. **返回正文但不是合法 JSON 对象：4 题**  
   `challenge.v0.3.006`、`.010`、`.017`、`.029`。
3. **引用检索候选之外的变量，被安全校验拒绝：1 题**  
   `challenge.v0.3.005`。

这说明安全边界正常工作：不把空正文、截断的 reasoning、非法 JSON 或越界变量引用当作有效回答。

### 4.3 不同行为类型

| 期望行为 | 正确 / 总数 | 正确率 |
|---|---:|---:|
| answer | 9 / 35 | 25.71% |
| clarify | 1 / 3 | 33.33% |
| refuse | 2 / 3 | 66.67% |
| 合计 | 12 / 41 | 29.27% |

15 个本地短路案例中有 3 个行为正确；26 个模型调用案例中有 9 个行为正确。12 个最终 `answered` 案例中有 9 个行为/状态正确。

## 5. Token 与费用

接口对全部 26 个真实调用返回了 usage：

| Token 项 | 数量 |
|---|---:|
| prompt tokens | 72,081 |
| completion tokens | 44,940 |
| 其中 reasoning tokens | 35,770 |
| total tokens | 117,021 |
| 每次实际调用平均 total tokens | 4,500.808 |
| prompt cache hit tokens | 70,272 |
| prompt cache miss tokens | 1,809 |

reasoning tokens 占 completion tokens 的约 79.59%，与多道复杂题在输出上限处才结束的现象一致。但这是运行观测，不应在没有进一步对照实验时直接推断唯一因果。

`estimated_cost_usd` 仍为 `null`。当前结果没有可验证的计费单价或账单数据，因此报告不自行估算费用。

## 6. 指标解释边界

- `required_fact_coverage=1.0` 不具备事实能力解释力，因为 challenge v0.3 当前各题的 `required_facts` 为空。
- `variable_exact_match`、`variable_hit_rate`、`variable_precision` 与 `evidence_hit_rate` 含有检索候选和 grounding 的贡献，不能直接归因于 DeepSeek 最终生成。
- `refusal_accuracy=68.29%` 是当前评分器口径，不等同于仅统计三道 `expected_behavior=refuse` 的 2/3。
- `failure_count=0` 和 `runner_failure_count=0` 仅说明评测运行器没有崩溃；不代表模型无错误。本轮仍有 14 个 `agent_result.status=model_error`。
- 本轮仅覆盖 RAG 条件；不能据此声称步骤 16 的“多模型 × 三条件”整体完成。

## 7. 建议下一步

1. **冻结本轮结果，不在 challenge v0.3 上继续边测边调。** 本轮已经足以暴露 2000-token 下的截断和 JSON 契约问题。
2. 在非 challenge 开发题上优化“先输出短 JSON、限制解释长度”的生成契约，并验证是否能减少 reasoning 抢占输出预算。
3. 为 `invalid_json`、`candidate_out_of_scope` 增加独立机器可读 `failure_reason`，避免目前只有异常消息可区分。
4. 若要继续正式横向比较，先实现并离线验证真正的 `no_knowledge_base` 与 `full_context` 运行路径，再用同一冻结题集、同一参数测试其他模型。
5. GPT-5.6 Luna 尚未完成凭证 smoke，不应与本轮 DeepSeek 结果作能力对比。

## 8. 产物

- 原始逐题结果：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest/results.jsonl`
- 自动汇总：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest/summary.json`
- 运行清单：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest/run_manifest.json`
- 自动报告：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest/report.md`
- 补充审计摘要：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest/audit_summary.json`
