# 步骤 08：变量关系图审计

- 审计日期：2026-09-04
- 审计方式：离线静态解析JSONL和有向图检查
- SC2运行：未执行
- 外部LLM/SWM：未调用
- 实验复现：未执行

## 1. 验收摘要

| 检查项 | 结果 |
|---|---|
| 正式变量数量 | 135 |
| 图节点数量 | 1207 |
| 关系边数量 | 1430 |
| observation到FunctionCall可达 | 通过 |
| 全图孤立正式变量 | 0 |
| 排除aliases后的孤立正式变量 | 0 |
| 损坏的变量引用 | 0 |
| 因果转换子图循环 | 未发现 |
| 歧义别名索引词 | 52 |

## 2. 关系类型统计

| 关系 | 边数 |
|---|---:|
| `aggregated_into` | 26 |
| `aliases` | 1146 |
| `evaluated_by` | 3 |
| `mapped_to` | 12 |
| `normalized_as` | 1 |
| `predicts` | 3 |
| `read_from` | 42 |
| `stored_as` | 109 |
| `transformed_to` | 7 |
| `used_by` | 79 |
| `validated_by` | 2 |

## 3. 节点类型统计

| 节点类型 | 数量 |
|---|---:|
| `alias` | 1054 |
| `artifact` | 10 |
| `component` | 7 |
| `interface_field` | 1 |
| `variable` | 135 |

## 4. 事实状态统计

| 状态 | 边数 |
|---|---:|
| `code_reality` | 265 |
| `needs_verification` | 19 |
| `not_applicable` | 1146 |

当前没有`runtime_observation`边，因为步骤08没有运行SC2、LLM、SWM或实验。

## 5. 孤立项和断链

- 全图孤立正式变量：无；
- 排除纯别名索引后的孤立正式变量：无；
- 不存在的正式变量引用：无；
- 核心链路已从`artifact.pysc2.observation`静态追踪到`artifact.pysc2.function_call`。

注意：这里的“可达”只表示当前代码结构存在路径，不表示SC2引擎已经接受或成功执行动作。

## 6. 循环依赖

因果转换子图仅检查`read_from`、`transformed_to`、`normalized_as`、`aggregated_into`、
`stored_as`、`validated_by`、`mapped_to`、`predicts`和`evaluated_by`，结果为：未发现。
`aliases`是检索索引，`used_by`是消费关系，不参与数值因果循环判定。

## 7. 跨层同名冲突

以下规范字段名出现在多个正式变量层，检索时不能只按短名称合并：

- `enemy_count`：`abox.graph.enemy_count`, `derived.tactical.enemy_count`
- `alliance`：`abox.unit.alliance`, `raw_unit.alliance`
- `armor`：`abox.unit.armor`, `tbox.entity.armor`
- `attack_damage`：`abox.unit.attack_damage`, `tbox.entity.attack_damage`
- `attack_range`：`abox.unit.attack_range`, `tbox.entity.attack_range`
- `attack_speed`：`abox.unit.attack_speed`, `tbox.entity.attack_speed`
- `category`：`abox.unit.category`, `tbox.entity.category`
- `description`：`abox.unit.description`, `tbox.entity.description`
- `hp`：`abox.unit.hp`, `tbox.entity.hp`
- `movement_speed`：`abox.unit.movement_speed`, `tbox.entity.movement_speed`
- `node_type`：`abox.unit.node_type`, `tbox.entity.node_type`
- `race`：`abox.unit.race`, `tbox.entity.race`
- `tag`：`abox.unit.tag`, `raw_unit.tag`
- `unit_type_id`：`abox.unit.unit_type_id`, `tbox.entity.unit_type_id`
- `weapon_cooldown`：`abox.unit.weapon_cooldown`, `raw_unit.weapon_cooldown`
- `planned_actions`：`action.planned_actions`, `swm.input.planned_actions`
- `target`：`action.target`, `pysc2.function.target`
- `function_id`：`pysc2.attack.function_id`, `pysc2.build.function_id`, `pysc2.move.function_id`, `pysc2.no_op.function_id`, `pysc2.train.function_id`

此外，`action.planned_actions`与`swm.input.planned_actions`存在更强的接口冲突：
前者是整数计数，后者是动作列表。步骤06血缘表把二者直接关联，但当前源码实际传递
`initial_parsed["actions"]`。步骤08已使用`artifact.storm.validated_actions`表示真实上游，
没有把整数计数伪装成动作列表。

## 8. 仍需验证

1. RawUnit索引和FunctionCall编号尚未对当前PySC2 ActionSpec做运行时核验；
2. TBox Python定义与`data/ontology/ontology_graph.pkl`缓存可能不同步；
3. ABox `armor/armor_ratio`当前代码实际保存RawUnit `shield/shield_ratio`；
4. 外部LLM和SWM没有调用，预测内容、置信度和token用量没有运行值；
5. FunctionCall只确认构造路径，未启动SC2验证执行结果；
6. 指标只确认公式和写出接口，没有重新执行实验。

## 9. 审计结论

- [x] JSONL设计为每行一条完整关系；
- [x] 11类关系均有明确定义；
- [x] 核心观测到动作执行链静态可达；
- [x] 每条边有源码证据或标记为结构性索引；
- [x] 孤立变量、断链、循环和跨层同名冲突均进入检查；
- [x] 所有产物位于`knowledge/`；
- [ ] SC2运行时验证：未执行；
- [ ] 外部LLM/SWM验证：未执行；
- [ ] 实验复现：未执行。
