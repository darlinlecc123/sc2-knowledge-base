# 步骤 16 完成报告（安全准备阶段）

### 步骤 16 完成报告

- 状态：**部分完成**。DeepSeek V4 Flash 已完成正式 2000-token 的 challenge v0.3 RAG 协议复测；GPT-5.6 Luna、`no_knowledge_base` 和真正的 `full_context` 尚未执行，因此多模型三条件矩阵仍未完成。
- 日期：2026-09-04。
- 读取的关键证据：
  - `knowledge/prompts/00_master_prompt.md`
  - `knowledge/prompts/16_run_multi_model_evaluation.md`
  - `knowledge/src/sc2kb/model_clients.py`
  - `knowledge/src/sc2kb/qa_agent.py`
  - `knowledge/evals/run_evaluation.py`
  - `knowledge/evals/scorers.py`
  - `knowledge/docs/14_evaluation_usage.md`
  - `knowledge/evals/challenge_v0.3_manifest.json`
- 新建或修改的文件：
  - `knowledge/evals/configs/model_matrix.yaml`
  - `knowledge/docs/16_multi_model_protocol.md`
  - `knowledge/tests/validate_step16.py`（辅助离线验证文件）
  - `knowledge/reports/step16_planned_completion_20260904.md`
- 未创建的真实结果文件：
  - `raw_answers.jsonl`
  - `scores.json`
  - 真实多模型 `report.md`
- 主要发现：现有评测器支持多个 OpenAI-compatible 配置，但 live 路径固定使用 QAAgent，只直接支持 retrieval-augmented 条件；`context_tier=full` 仍是检索后的完整记录，不等于无检索的全知识库上下文。
- 未解决问题：DeepSeek 凭证已通过单题 smoke；仍需要用户指定完整矩阵的费用/调用上限，并为 GPT 模型提供 OPENAI_API_KEY；真实三条件运行还需要专用运行器或显式 knowledge-condition 参数。
- 建议下一步：先实现并离线验证三条件运行器；配置 OpenAI 凭证后对 GPT-5.6 Luna 做 1 道非冻结题 smoke；最后在明确完整矩阵硬上限后再运行正式评测。


## DeepSeek 单题 smoke test（2026-09-04）

- 运行 ID：`20260904_deepseek_v4_flash_single_smoke`
- 问题：`test.001.unique-unit-id`（非 challenge）
- 条件：`retrieval_augmented`，`context_tier=standard`
- 外部请求：1 次
- 重试：0 次
- 本地检索：正确找到 `raw_unit.tag`
- 外部结果：HTTP 401 `AuthenticationError`，当前 API Key 无效
- 模型生成：未获得
- token/费用：接口未返回，记录为 `null`
- 结论：这是凭证配置失败，不是 DeepSeek 模型回答质量结果；不得纳入多模型能力比较。
- 原始结果：`knowledge/evals/results/20260904_deepseek_v4_flash_single_smoke/`


## DeepSeek 单题 smoke test：凭证重配后复测（2026-09-04）

- 运行 ID：`20260904_deepseek_v4_flash_single_smoke_retry2`
- 问题：`test.001.unique-unit-id`（非 challenge）
- 条件：`retrieval_augmented`，`context_tier=standard`
- 外部请求：1 次
- 重试：0 次
- 输出目录：全新目录，未覆盖第一次失败记录
- 模型调用：成功，获得模型生成；`agent_result.status=answered`
- 预测变量：`raw_unit.tag`
- `variable_exact_match=true`
- `evidence_hit_rate=1.0`
- `behavior_correct=true`
- `status_correct=true`
- 延迟：`6249.752 ms`
- token/费用：接口/当前运行器未返回，保持为 `null`，不作估算
- 结论：`DEEPSEEK_API_KEY` 已通过真实单题调用验证；该结果仅是连接和基本回答能力 smoke，不代表 41 题或三条件正式评测结论。
- 原始结果：`knowledge/evals/results/20260904_deepseek_v4_flash_single_smoke_retry2/`
- 冻结保护：未读取为调参目标、未修改、未重跑 challenge v0.3。

## DeepSeek challenge v0.3 RAG 正式参数复测（2026-09-04）

- 运行 ID：`20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest`
- 冻结题集：41 题；SHA-256 `e7fbfa05317d01bc93593dbfd354c34e7dc33f2ac34818cacf0e8171479e2044`
- 参数：`temperature=0`、`max_output_tokens=2000`、`max_retries=0`
- 实际模型调用：26；本地短路：15；没有重试
- 可采纳回答：12；`model_error`：14；调用成功率：46.15%
- 空最终正文：9；输出截断：9；另有 4 个非法 JSON 和 1 个候选变量越界
- `behavior_accuracy=0.292683`；`status_accuracy=0.292683`
- Token：26 个调用均有 usage，总计 117,021；费用保持 `null`
- 对比 800-token 故障审计：可采纳回答 2→12，`model_error` 24→14，行为正确率 9.76%→29.27%
- 结果目录：`knowledge/evals/results/20260904_deepseek_v4_flash_challenge_v0.3_rag_protocol_retest/`
- 审计报告：`knowledge/reports/deepseek_challenge_v0.3_rag_protocol_retest_20260904.md`
- 说明：本轮不是首次盲测，也不代表完整步骤 16 已完成。

