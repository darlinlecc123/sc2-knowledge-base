"""创建并冻结 challenge v0.6。构题过程不得导入或调用问答代理、检索器或外部模型。"""
from __future__ import annotations

import collections
import hashlib
import json
import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
EVALS = KB / "evals"
VERSION = "0.6.0"
SPLIT = "challenge_v0.6"
TODAY = "2026-09-06"
LOCK_FILE = EVALS / "rag_v0.6_preblind_lock.json"
FORMAL_FILES = ("abox.yaml", "actions.yaml", "derived.yaml", "metrics.yaml", "raw_api.yaml", "swm.yaml", "tbox.yaml")
SPECS = json.loads(r'''[
  [
    "raw-object-footprint",
    "给一个 Raw 单位建立“身份—归属—位置”五元组时，需要类型编号、对象 tag、alliance 与 x/y，规范变量分别是什么？",
    [
      "raw_unit.unit_type",
      "raw_unit.tag",
      "raw_unit.alliance",
      "raw_unit.x",
      "raw_unit.y"
    ],
    "multi_variable_comparison"
  ],
  [
    "raw-survivability-pairs",
    "若观测记录必须同时保留生命、护盾的当前值及各自 ratio，RawUnit 层应绑定哪四项？",
    [
      "raw_unit.health",
      "raw_unit.health_ratio",
      "raw_unit.shield",
      "raw_unit.shield_ratio"
    ],
    "interface"
  ],
  [
    "raw-fire-location-snapshot",
    "构造单位即时开火态势时，把 health、weapon cooldown 和平面坐标一并交给上层，需要哪四个 Raw 字段？",
    [
      "raw_unit.health",
      "raw_unit.weapon_cooldown",
      "raw_unit.x",
      "raw_unit.y"
    ],
    "multi_variable_comparison"
  ],
  [
    "player-resource-capacity",
    "描述玩家当前资源与人口容量，矿物、气体、已占用人口、人口容量和可用余量对应哪五个量？",
    [
      "player.minerals",
      "player.vespene",
      "player.food_used",
      "player.food_cap",
      "player.supply_remaining"
    ],
    "multi_variable_comparison"
  ],
  [
    "environment-raw-contract-clock",
    "复核环境使用原始单位/原始动作的契约，并同时登记 raw resolution、step_mul 与两次决策间隔，应查看哪些配置？",
    [
      "environment.use_raw_units",
      "environment.use_raw_actions",
      "environment.raw_resolution",
      "environment.step_mul",
      "environment.decision_interval"
    ],
    "interface"
  ],
  [
    "environment-scene-switches",
    "为了复现实验场景，需要保存 map name、是否 realtime 和是否 visualize；它们的变量 ID 是什么？",
    [
      "environment.map_name",
      "environment.realtime",
      "environment.visualize"
    ],
    "interface"
  ],
  [
    "timestep-ending-feedback",
    "智能体每轮接收反馈时，要合并“是否最后一步”“本步奖励”和“累计得分”，对应哪三个 TimeStep 量？",
    [
      "timestep.is_last",
      "timestep.reward_delta",
      "timestep.score_cumulative_0"
    ],
    "interface"
  ],
  [
    "raw-abox-protection-lineage",
    "按代码现实追踪生命/护盾从 Raw 进入实例图：源端四个绝对或比例量和目标端 hp、hp_ratio、armor、armor_ratio 都要列出。",
    [
      "raw_unit.health",
      "raw_unit.health_ratio",
      "raw_unit.shield",
      "raw_unit.shield_ratio",
      "abox.unit.hp",
      "abox.unit.hp_ratio",
      "abox.unit.armor",
      "abox.unit.armor_ratio"
    ],
    "known_issue_trap"
  ],
  [
    "raw-abox-address-lineage",
    "从 Raw 对象定位到 ABox 节点，需要把 tag、unit type、两个坐标与实例 tag、unit_type_id、position 成套对应，请返回七项。",
    [
      "raw_unit.tag",
      "raw_unit.unit_type",
      "raw_unit.x",
      "raw_unit.y",
      "abox.unit.tag",
      "abox.unit.unit_type_id",
      "abox.unit.position"
    ],
    "lineage"
  ],
  [
    "raw-abox-cooldown-lineage",
    "说明武器冷却在原始观测和动态实例中的前后名称，两个端点变量是什么？",
    [
      "raw_unit.weapon_cooldown",
      "abox.unit.weapon_cooldown"
    ],
    "lineage"
  ],
  [
    "abox-instance-identity-bundle",
    "只在 ABox 当前实例层刻画单位身份，需要 alliance、tag、unit_type_id、category、race 哪五个字段？",
    [
      "abox.unit.alliance",
      "abox.unit.tag",
      "abox.unit.unit_type_id",
      "abox.unit.category",
      "abox.unit.race"
    ],
    "multi_variable_comparison"
  ],
  [
    "abox-live-combat-bundle",
    "动态实例的作战快照要联合 hp ratio、weapon cooldown、attack damage 与 attack range，请给规范 ID。",
    [
      "abox.unit.hp_ratio",
      "abox.unit.weapon_cooldown",
      "abox.unit.attack_damage",
      "abox.unit.attack_range"
    ],
    "multi_variable_comparison"
  ],
  [
    "abox-edge-audit-fields",
    "一条 ABox 实例关系若要可完整审计，应记录 source node、target node、edge type、edge class、effectiveness、reason 和 timestamp，分别是什么？",
    [
      "abox.relation.source_node",
      "abox.relation.target_node",
      "abox.relation.edge_type",
      "abox.relation.edge_class",
      "abox.relation.effectiveness",
      "abox.relation.reason",
      "abox.relation.timestamp"
    ],
    "multi_variable_comparison"
  ],
  [
    "abox-graph-progress-size",
    "从实例图整体而非单个节点观察进度和敌军规模，要读取 step count 与 enemy count 哪两个图级量？",
    [
      "abox.graph.step_count",
      "abox.graph.enemy_count"
    ],
    "interface"
  ],
  [
    "abox-unknown-fallback",
    "未知单位进入 ABox 后，识别标志、回退类别和说明文字分别由哪三个属性承载？",
    [
      "abox.unit.is_unknown",
      "abox.unit.category",
      "abox.unit.description"
    ],
    "known_issue_trap"
  ],
  [
    "tbox-static-survival-mobility",
    "静态实体的耐久和机动基础由 hp、armor、movement speed、sight 共同描述，对应哪四个 TBox 属性？",
    [
      "tbox.entity.hp",
      "tbox.entity.armor",
      "tbox.entity.movement_speed",
      "tbox.entity.sight"
    ],
    "multi_variable_comparison"
  ],
  [
    "tbox-classification-signature",
    "在 TBox 里确认实体分类，需要 unit_type_id、node_type、category、race 的完整组合，变量是什么？",
    [
      "tbox.entity.unit_type_id",
      "tbox.entity.node_type",
      "tbox.entity.category",
      "tbox.entity.race"
    ],
    "multi_variable_comparison"
  ],
  [
    "tbox-resource-text-edge",
    "查询静态本体的资源种类、实体文字说明以及关系 edge，应分别返回哪三项？",
    [
      "tbox.entity.resource_type",
      "tbox.entity.description",
      "tbox.relation.edge"
    ],
    "interface"
  ],
  [
    "tbox-weapon-profile",
    "静态武器画像中的 attack damage、attack speed、attack range 和 dps 分别对应什么属性？",
    [
      "tbox.entity.attack_damage",
      "tbox.entity.attack_speed",
      "tbox.entity.attack_range",
      "tbox.entity.dps"
    ],
    "multi_variable_comparison"
  ],
  [
    "tbox-production-cost",
    "描述静态单位生产代价，需要 mineral cost、gas cost、supply cost 与 build time 四个变量。",
    [
      "tbox.entity.mineral_cost",
      "tbox.entity.gas_cost",
      "tbox.entity.supply_cost",
      "tbox.entity.build_time"
    ],
    "multi_variable_comparison"
  ],
  [
    "tactical-side-count-health",
    "若战术摘要要同时比较双方兵力数和双方平均血量，友军/敌军的四个聚合量是什么？",
    [
      "derived.tactical.friendly_count",
      "derived.tactical.enemy_count",
      "derived.tactical.friendly_avg_hp",
      "derived.tactical.enemy_avg_hp"
    ],
    "multi_variable_comparison"
  ],
  [
    "tactical-centers-spacing",
    "用我方中心、敌方中心及编队间距表达空间格局时，要取哪三个战术派生变量？",
    [
      "derived.tactical.friendly_centroid",
      "derived.tactical.enemy_centroid",
      "derived.tactical.formation_distance"
    ],
    "multi_variable_comparison"
  ],
  [
    "tactical-readiness-count",
    "同时报告整体射击准备程度和可立即开火单位的计数，应选择哪两个摘要量？",
    [
      "derived.tactical.fire_readiness",
      "derived.tactical.ready_to_fire_count"
    ],
    "multi_variable_comparison"
  ],
  [
    "tactical-force-ratio-dependency",
    "兵力比例由哪两个阵营计数构成，并形成哪个 force ratio 结果？请给三个公式节点。",
    [
      "derived.tactical.friendly_count",
      "derived.tactical.enemy_count",
      "derived.tactical.force_ratio"
    ],
    "formula"
  ],
  [
    "tactical-contact-critical",
    "摘要中的交战形态和优先关注单位集合，各自用什么变量表达？",
    [
      "derived.tactical.engagement_type",
      "derived.tactical.critical_units"
    ],
    "multi_variable_comparison"
  ],
  [
    "tactical-health-status",
    "知识库中对整体战术健康状态的派生描述使用哪个变量？",
    [
      "derived.tactical.health_status"
    ],
    "meaning"
  ],
  [
    "action-command-four-slots",
    "解析后的动作命令需要主动作、子动作、目标值与目标类别四个槽位，它们的 schema ID 是什么？",
    [
      "action.type",
      "action.subtype",
      "action.target",
      "action.target_type"
    ],
    "interface"
  ],
  [
    "action-scheduling-four-slots",
    "给动作安排执行顺序时，单位集合、priority、delay steps 和 reasoning 分别绑定哪四项？",
    [
      "action.units",
      "action.priority",
      "action.delay_steps",
      "action.reasoning"
    ],
    "interface"
  ],
  [
    "action-validation-accounting",
    "动作计划审计需要原始 plan、planned actions、invalid actions 与 invalid reason counts，请列全。",
    [
      "action.plan",
      "action.planned_actions",
      "action.invalid_actions",
      "action.invalid_reason_counts"
    ],
    "multi_variable_comparison"
  ],
  [
    "move-function-complete",
    "MOVE 转为 PySC2 原始调用时，除移动 function id 外，queued、target、unit tags、raw flag 的变量也要全部返回。",
    [
      "pysc2.move.function_id",
      "pysc2.function.queued",
      "pysc2.function.target",
      "pysc2.function.unit_tags",
      "pysc2.function.raw_flag"
    ],
    "interface"
  ],
  [
    "attack-function-complete",
    "ATTACK 的 Raw FunctionCall 由攻击函数编号和四个公共载荷字段组成，请完整列出五项。",
    [
      "pysc2.attack.function_id",
      "pysc2.function.queued",
      "pysc2.function.target",
      "pysc2.function.unit_tags",
      "pysc2.function.raw_flag"
    ],
    "interface"
  ],
  [
    "build-function-id",
    "BUILD 动作最终使用哪个 PySC2 Function ID 变量？",
    [
      "pysc2.build.function_id"
    ],
    "interface"
  ],
  [
    "train-function-id",
    "TRAIN 动作最终使用哪个 PySC2 Function ID 变量？",
    [
      "pysc2.train.function_id"
    ],
    "interface"
  ],
  [
    "noop-function-id",
    "无操作分支对应哪个 no_op 函数编号变量？",
    [
      "pysc2.no_op.function_id"
    ],
    "interface"
  ],
  [
    "functioncall-common-payload",
    "跨 MOVE/ATTACK 共用的调用载荷里，queued、target、unit tags、raw flag 四项如何命名？",
    [
      "pysc2.function.queued",
      "pysc2.function.target",
      "pysc2.function.unit_tags",
      "pysc2.function.raw_flag"
    ],
    "multi_variable_comparison"
  ],
  [
    "swm-request-inputs",
    "提交世界模型预测请求时，ABox 状态、计划动作、预测跨度和候选编号分别用哪四个输入量？",
    [
      "swm.input.abox_state",
      "swm.input.planned_actions",
      "swm.prediction_steps",
      "swm.candidate_index"
    ],
    "interface"
  ],
  [
    "swm-step-change-record",
    "对 SWM 某个未来步，步号、置信度、位置差量和生命差量应记录在哪四个字段？",
    [
      "swm.prediction.step",
      "swm.confidence",
      "swm.unit.position_delta",
      "swm.unit.health_delta"
    ],
    "multi_variable_comparison"
  ],
  [
    "swm-response-containers",
    "世界模型响应中，原始文本、解析后的 predictions、单位状态预测和关系预测分别是什么变量？",
    [
      "swm.raw_response",
      "swm.predictions",
      "swm.predicted_unit_states",
      "swm.predicted_relations"
    ],
    "interface"
  ],
  [
    "metric-token-three-way",
    "统计模型上下文消耗时，要分别累计 prompt tokens、completion tokens、total tokens，三项指标 ID 是什么？",
    [
      "metric.llm.prompt_tokens",
      "metric.llm.completion_tokens",
      "metric.llm.total_tokens"
    ],
    "multi_variable_comparison"
  ],
  [
    "metric-decision-efficiency",
    "比较决策效率，需要 decision calls、平均决策时间和平均每次 token，三项指标是什么？",
    [
      "metric.llm.decision_calls",
      "metric.llm.avg_decision_time",
      "metric.llm.avg_tokens_per_decision"
    ],
    "multi_variable_comparison"
  ],
  [
    "metric-token-average-formula",
    "平均每决策 token 依赖总 token 与调用次数，请同时给两个输入和一个平均输出。",
    [
      "metric.llm.total_tokens",
      "metric.llm.decision_calls",
      "metric.llm.avg_tokens_per_decision"
    ],
    "formula"
  ],
  [
    "metric-action-failure-slices",
    "把动作失败拆成总体失败率、决策阶段失败率和延迟执行失败率，需要哪三个指标？",
    [
      "metric.action.failure_rate",
      "metric.action.decision_failure_rate",
      "metric.action.delayed_failure_rate"
    ],
    "multi_variable_comparison"
  ],
  [
    "metric-swm-four-dimensions",
    "SWM 评估要联合位置误差、生命误差、关系正确率和 overall error，分别对应哪些指标？",
    [
      "metric.swm.position_rmse",
      "metric.swm.health_rmse",
      "metric.swm.relation_accuracy",
      "metric.swm.overall_error"
    ],
    "multi_variable_comparison"
  ],
  [
    "metric-score-summary",
    "回合最终分数和跨实验平均分数分别使用哪两个指标？",
    [
      "metric.episode.final_score",
      "metric.experiment.avg_score"
    ],
    "multi_variable_comparison"
  ],
  [
    "formula-supply-capacity",
    "人口余量由容量减去已占用得到：请列出 food cap、food used 和 supply remaining 三个公式变量。",
    [
      "player.food_cap",
      "player.food_used",
      "player.supply_remaining"
    ],
    "formula"
  ],
  [
    "formula-raw-health-shield-ratios",
    "解释 RawUnit 两种 ratio 时，请把 health/shield 的绝对字段与对应比例字段成对返回。",
    [
      "raw_unit.health",
      "raw_unit.health_ratio",
      "raw_unit.shield",
      "raw_unit.shield_ratio"
    ],
    "formula"
  ],
  [
    "cross-layer-range-comparison",
    "明确比较 TBox 静态攻击距离与 ABox 当前实例攻击距离时，前后两层分别是什么变量？",
    [
      "tbox.entity.attack_range",
      "abox.unit.attack_range"
    ],
    "lineage"
  ],
  [
    "cross-layer-type-number",
    "把 Raw unit type、ABox unit_type_id、TBox unit_type_id 横向对照，需要返回哪三个规范量？",
    [
      "raw_unit.unit_type",
      "abox.unit.unit_type_id",
      "tbox.entity.unit_type_id"
    ],
    "lineage"
  ],
  [
    "ambiguous-reason",
    "只给出“reason/理由”而没有说明是动作解释还是实例关系原因，请保留全部候选。",
    [
      "action.reasoning",
      "abox.relation.reason"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "ambiguous-attack-distance",
    "问题只有“射程是多少”，未指定静态本体层或动态实例层；应列候选并追问层级。",
    [
      "tbox.entity.attack_range",
      "abox.unit.attack_range"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "ambiguous-token-usage",
    "用户只说 token usage，没有交代是 SWM 响应记录还是 LLM 总 token 指标，请返回候选。",
    [
      "swm.token_usage",
      "metric.llm.total_tokens"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "ambiguous-hp-layer",
    "只问 hp 的物理量但没有指出 Raw、ABox 还是 TBox，应列出三个层级候选。",
    [
      "raw_unit.health",
      "abox.unit.hp",
      "tbox.entity.hp"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "ambiguous-unit-type-layer",
    "只说 unit type 编号，未指定原始观测、实例图或静态本体，请给出三层候选。",
    [
      "raw_unit.unit_type",
      "abox.unit.unit_type_id",
      "tbox.entity.unit_type_id"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "ambiguous-target-layer",
    "只问 target 字段却没有说明动作 schema、FunctionCall 或关系目标节点，应保留三个候选。",
    [
      "action.target",
      "pysc2.function.target",
      "abox.relation.target_node"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "out-feature-screen-density",
    "feature_screen 的 unit_density 通道在当前 V0.1 中对应什么变量？",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-feature-minimap-camera",
    "feature_minimap 里的 camera mask 是否属于本 Raw 变量库？",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-rgb-shape",
    "RGB observation 的画面尺寸和颜色通道有哪些接口字段？",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-replay-apm",
    "从 replay 统计玩家 APM 的变量和代码位置是什么？",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-ui-control-groups",
    "界面 control groups 的编队槽内容能否从该知识库查询？",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-feature-selection",
    "feature screen 上的 selected 单位掩码用哪个字段表示？",
    [],
    "out_of_scope",
    "refuse"
  ]
]''')

if not LOCK_FILE.exists():
    raise FileNotFoundError("必须先创建 v0.6 pre-blind RAG 锁")
records = {}
record_file = {}
for name in FORMAL_FILES:
    payload = yaml.safe_load((KB / "variables" / name).read_text(encoding="utf-8"))
    for record in payload["records"]:
        if record["id"] in records:
            raise ValueError(f"正式变量 ID 重复: {record['id']}")
        records[record["id"]] = record
        record_file[record["id"]] = name

def normalize(text: str) -> str:
    return re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+", "", text).casefold()

question_file = EVALS / "questions_challenge_v0.6.jsonl"
manifest_file = EVALS / "challenge_v0.6_manifest.json"
if question_file.exists() or manifest_file.exists():
    raise FileExistsError("v0.6 冻结产物已存在，拒绝覆盖")
prior_files = sorted(p for p in EVALS.glob("questions*.jsonl") if p != question_file)
prior_questions = {}
for p in prior_files:
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            row = json.loads(line)
            prior_questions[normalize(row["question"])] = f"{p.name}:{row.get('id')}"
rows = []
seen_questions = set()
for index, spec in enumerate(SPECS, 1):
    slug, question, ids, qtype, *behavior_override = spec
    missing = [vid for vid in ids if vid not in records]
    if missing:
        raise ValueError(f"{slug} 引用非法变量: {missing}")
    norm = normalize(question)
    if norm in prior_questions:
        raise ValueError(f"{slug} 与旧题完全重复: {prior_questions[norm]}")
    if norm in seen_questions:
        raise ValueError(f"v0.6 内部题目重复: {slug}")
    seen_questions.add(norm)
    behavior = behavior_override[0] if behavior_override else "answer"
    status = {"answer": "found", "clarify": "ambiguous", "refuse": "not_found"}[behavior]
    evidence = []
    refs = []
    for vid in ids:
        evs = records[vid].get("evidence") or []
        if not evs:
            raise ValueError(f"{vid} 没有证据")
        ev = evs[0]
        if not (ROOT / ev["path"]).exists():
            raise ValueError(f"{vid} 证据路径不存在: {ev['path']}")
        item = {k: ev.get(k) for k in ("id", "fact_status", "path", "symbol")}
        item["evidence_id"] = item.pop("id")
        evidence.append(item)
        refs.append(f"knowledge/variables/{record_file[vid]}#id={vid}")
    if behavior == "refuse":
        evidence = [{"evidence_id": "scope-v0.1-manifest", "fact_status": "design_intent", "path": "knowledge/manifests/scope.yaml", "symbol": "scope.in_scope_rule"}]
    rows.append({
        "benchmark_version": VERSION,
        "category": "generalization_challenge",
        "clarification_required": behavior == "clarify",
        "difficulty": "hard" if index <= 54 else "medium",
        "expected_behavior": behavior,
        "expected_status": status,
        "expected_variable_ids": ids,
        "forbidden_claims": ["声称执行了本题未记录的 SC2 运行时或外部模型测试", "使用知识库外常识补齐缺失变量"],
        "generated_at": TODAY,
        "id": f"challenge.v0.6.{index:03d}.{slug}",
        "intents": ["sixth_frozen_challenge", "single_first_blind_generalization"],
        "language": "zh",
        "notes": "v0.6 在完整题集首次运行前冻结；冻结后禁止检索预览、局部试跑、修改受锁文件或按结果调参。",
        "question": question,
        "question_type": qtype,
        "required_evidence": evidence,
        "required_facts": [],
        "source_record_refs": refs,
        "split": SPLIT,
        "variable_categories": sorted({records[vid]["category"] for vid in ids}),
    })
question_file.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")
question_hash = hashlib.sha256(question_file.read_bytes()).hexdigest()
lock_hash = hashlib.sha256(LOCK_FILE.read_bytes()).hexdigest()
manifest = {
    "case_count": len(rows),
    "challenge_version": VERSION,
    "created_at": TODAY,
    "difficulty": dict(sorted(collections.Counter(r["difficulty"] for r in rows).items())),
    "expected_behavior": dict(sorted(collections.Counter(r["expected_behavior"] for r in rows).items())),
    "external_model_test": "未执行",
    "first_evaluation_status": "not_run_at_freeze_time",
    "frozen_at": TODAY,
    "frozen_before_first_evaluation": True,
    "normalized_overlap_with_all_prior_sets": 0,
    "prior_sets": [p.relative_to(ROOT).as_posix() for p in prior_files],
    "question_file": question_file.relative_to(ROOT).as_posix(),
    "question_type": dict(sorted(collections.Counter(r["question_type"] for r in rows).items())),
    "rag_lock_file": LOCK_FILE.relative_to(ROOT).as_posix(),
    "rag_lock_sha256": lock_hash,
    "question_generation_sources": ["knowledge/variables/*.yaml", "source evidence paths referenced by variable cards", "prior question text for exact-overlap rejection"],
    "retrieval_files_read_during_generation": False,
    "retrieval_imported_or_called_during_generation": False,
    "sc2_runtime": "未执行",
    "sha256": question_hash,
    "tuning_policy": "v0.6 冻结后不得运行预检索、不得修改受锁文件、不得按题调参；只允许一次完整首次盲测。",
}
manifest_file.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({"question_file": str(question_file), "manifest_file": str(manifest_file), "case_count": len(rows), "sha256": question_hash, "rag_lock_sha256": lock_hash, "behavior": manifest["expected_behavior"], "types": manifest["question_type"]}, ensure_ascii=False, indent=2))
