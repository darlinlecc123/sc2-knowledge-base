"""创建并冻结 challenge v0.5。构题过程不得导入或调用知识库问答/检索实现。"""
from __future__ import annotations

import collections
import hashlib
import json
import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
EVALS = KB / "evals"
VERSION = "0.5.0"
SPLIT = "challenge_v0.5"
TODAY = "2026-09-06"
LOCK_FILE = EVALS / "rag_v0.5_preblind_lock.json"

# 题目由正式变量卡片及源码证据人工设计；这里只保存规格并做结构、证据和重复性校验。
SPECS = json.loads(r'''[
  [
    "raw-spatial-identity-side",
    "我想在 Raw 单位表中同时确定对象是谁、属于哪一方以及位于哪里，需要联合取出类型号、唯一标识、阵营和两个坐标，请给出变量。",
    [
      "raw_unit.unit_type",
      "raw_unit.tag",
      "raw_unit.alliance",
      "raw_unit.x",
      "raw_unit.y"
    ],
    "multi_variable_comparison"
  ],
  [
    "raw-durability-dual-scale",
    "一次读取单位生命与护盾的绝对剩余量和归一化比例，Raw 接口中的四个字段是什么？",
    [
      "raw_unit.health",
      "raw_unit.health_ratio",
      "raw_unit.shield",
      "raw_unit.shield_ratio"
    ],
    "interface"
  ],
  [
    "raw-combat-snapshot",
    "若一条即时战斗快照要包含当前生命、开火冷却和二维位置，应绑定哪四个 Raw 字段？",
    [
      "raw_unit.health",
      "raw_unit.weapon_cooldown",
      "raw_unit.x",
      "raw_unit.y"
    ],
    "multi_variable_comparison"
  ],
  [
    "player-economy-headroom",
    "判断当前经济资源与还能使用多少补给时，需要矿物、瓦斯、已用补给、上限和剩余补给这五个量。",
    [
      "player.minerals",
      "player.vespene",
      "player.food_used",
      "player.food_cap",
      "player.supply_remaining"
    ],
    "formula"
  ],
  [
    "environment-raw-cadence",
    "确认环境确实启用 Raw 单位与 Raw 动作，并记录空间分辨率、SC2 每次推进量和智能体决策间隔，要查哪些配置？",
    [
      "environment.use_raw_units",
      "environment.use_raw_actions",
      "environment.raw_resolution",
      "environment.step_mul",
      "environment.decision_interval"
    ],
    "interface"
  ],
  [
    "environment-run-mode",
    "复现实验运行方式时，地图名、实时模式、可视化开关分别对应什么变量？",
    [
      "environment.map_name",
      "environment.realtime",
      "environment.visualize"
    ],
    "interface"
  ],
  [
    "timestep-terminal-return",
    "每一步既要知道是否终局，又要记录本步奖励变化和累计分数，应读取哪三个量？",
    [
      "timestep.is_last",
      "timestep.reward_delta",
      "timestep.score_cumulative_0"
    ],
    "interface"
  ],
  [
    "lineage-defense-mismatch",
    "请沿当前实现列出 Raw 生命、护盾及二者比例写入 ABox 生存/防护字段的完整八变量链路，尤其不要把实现中的 armor 映射说成理论设计。",
    [
      "raw_unit.health",
      "raw_unit.health_ratio",
      "raw_unit.shield",
      "raw_unit.shield_ratio",
      "abox.unit.hp",
      "abox.unit.hp_ratio",
      "abox.unit.armor",
      "abox.unit.armor_ratio"
    ],
    "known_issue_trap"
  ],
  [
    "lineage-address-position",
    "一个 Raw 对象的 tag、类型号、横纵坐标进入实例图后分别形成实例 tag、类型编号和 position；请给出全部七个变量。",
    [
      "raw_unit.tag",
      "raw_unit.unit_type",
      "raw_unit.x",
      "raw_unit.y",
      "abox.unit.tag",
      "abox.unit.unit_type_id",
      "abox.unit.position"
    ],
    "lineage"
  ],
  [
    "lineage-cooldown",
    "从 Raw 观测到 ABox 节点，武器冷却量前后分别叫什么？",
    [
      "raw_unit.weapon_cooldown",
      "abox.unit.weapon_cooldown"
    ],
    "lineage"
  ],
  [
    "abox-identity-profile",
    "动态实例节点的阵营、tag、类型编号、类别和种族由哪些属性组成？",
    [
      "abox.unit.alliance",
      "abox.unit.tag",
      "abox.unit.unit_type_id",
      "abox.unit.category",
      "abox.unit.race"
    ],
    "multi_variable_comparison"
  ],
  [
    "abox-dynamic-combat",
    "只看 ABox 动态节点时，生命比例、武器冷却、攻击伤害和攻击距离分别是哪四个属性？",
    [
      "abox.unit.hp_ratio",
      "abox.unit.weapon_cooldown",
      "abox.unit.attack_damage",
      "abox.unit.attack_range"
    ],
    "multi_variable_comparison"
  ],
  [
    "abox-edge-full-record",
    "审计一条实例关系时，需要起点、终点、关系类型、边类别、效果、理由和时间戳，请列出七个字段。",
    [
      "abox.relation.source_node",
      "abox.relation.target_node",
      "abox.relation.edge_type",
      "abox.relation.edge_class",
      "abox.relation.effectiveness",
      "abox.relation.reason",
      "abox.relation.timestamp"
    ],
    "interface"
  ],
  [
    "abox-graph-live-summary",
    "实例图更新到了第几步以及当前缓存了多少敌方节点，分别由什么图级变量表示？",
    [
      "abox.graph.step_count",
      "abox.graph.enemy_count"
    ],
    "interface"
  ],
  [
    "abox-unknown-semantics",
    "遇到本体表中未识别的单位时，实例节点上用于标明未知、保存类别和文字描述的三个字段是什么？",
    [
      "abox.unit.is_unknown",
      "abox.unit.category",
      "abox.unit.description"
    ],
    "known_issue_trap"
  ],
  [
    "tbox-offense-profile",
    "静态单位类型的攻击伤害、攻击速度、DPS 和射程应联合查询哪四个 TBox 属性？",
    [
      "tbox.entity.attack_damage",
      "tbox.entity.attack_speed",
      "tbox.entity.dps",
      "tbox.entity.attack_range"
    ],
    "multi_variable_comparison"
  ],
  [
    "tbox-survival-mobility-sight",
    "比较兵种的基础生命、护甲、移动速度和视野时，应使用哪些静态属性？",
    [
      "tbox.entity.hp",
      "tbox.entity.armor",
      "tbox.entity.movement_speed",
      "tbox.entity.sight"
    ],
    "multi_variable_comparison"
  ],
  [
    "tbox-production-budget",
    "估算某静态单位的矿气成本、补给占用和生产耗时，需要哪四个变量？",
    [
      "tbox.entity.mineral_cost",
      "tbox.entity.gas_cost",
      "tbox.entity.supply_cost",
      "tbox.entity.build_time"
    ],
    "multi_variable_comparison"
  ],
  [
    "tbox-taxonomic-identity",
    "TBox 节点的类型编号、节点类型、类别与种族分别记录在哪些字段？",
    [
      "tbox.entity.unit_type_id",
      "tbox.entity.node_type",
      "tbox.entity.category",
      "tbox.entity.race"
    ],
    "interface"
  ],
  [
    "tbox-resource-description-edge",
    "对于静态本体中的资源/实体说明及其关系，资源类型、描述文本和关系边分别是哪三个量？",
    [
      "tbox.entity.resource_type",
      "tbox.entity.description",
      "tbox.relation.edge"
    ],
    "multi_variable_comparison"
  ],
  [
    "tactical-army-vitals",
    "一条战术摘要要同时报告我方/敌方数量及双方平均生命，应返回哪四个派生量？",
    [
      "derived.tactical.friendly_count",
      "derived.tactical.enemy_count",
      "derived.tactical.friendly_avg_hp",
      "derived.tactical.enemy_avg_hp"
    ],
    "multi_variable_comparison"
  ],
  [
    "tactical-geometry",
    "若要用双方质心与编队间距描述空间态势，需要哪三个派生变量？",
    [
      "derived.tactical.friendly_centroid",
      "derived.tactical.enemy_centroid",
      "derived.tactical.formation_distance"
    ],
    "multi_variable_comparison"
  ],
  [
    "tactical-fire-state",
    "区分整体开火准备度并统计已经可开火的单位数，对应哪两个战术量？",
    [
      "derived.tactical.fire_readiness",
      "derived.tactical.ready_to_fire_count"
    ],
    "interface"
  ],
  [
    "tactical-balance-health",
    "判断兵力数量对比与整体健康状态，要联合使用什么派生变量？",
    [
      "derived.tactical.force_ratio",
      "derived.tactical.health_status"
    ],
    "multi_variable_comparison"
  ],
  [
    "tactical-engagement-priority",
    "战斗接触类型和需要重点处理的单位列表分别由哪些摘要变量承载？",
    [
      "derived.tactical.engagement_type",
      "derived.tactical.critical_units"
    ],
    "interface"
  ],
  [
    "action-command-shape",
    "一项计划动作的主类型、子类型、目标内容和目标种类，对应哪四个动作字段？",
    [
      "action.type",
      "action.subtype",
      "action.target",
      "action.target_type"
    ],
    "interface"
  ],
  [
    "action-scheduling-rationale",
    "让动作明确执行单位、优先级、延迟步数和决策理由，需要哪四个字段？",
    [
      "action.units",
      "action.priority",
      "action.delay_steps",
      "action.reasoning"
    ],
    "interface"
  ],
  [
    "action-plan-validation",
    "读取完整计划、计划动作集合、非法动作集合和非法原因计数，应查询哪四项？",
    [
      "action.plan",
      "action.planned_actions",
      "action.invalid_actions",
      "action.invalid_reason_counts"
    ],
    "multi_variable_comparison"
  ],
  [
    "pysc2-move-call",
    "把 MOVE 计划落到 PySC2 Raw FunctionCall 时，移动函数编号、排队参数、目标坐标、单位 tags 和 raw 标志分别对应哪些量？",
    [
      "pysc2.move.function_id",
      "pysc2.function.queued",
      "pysc2.function.target",
      "pysc2.function.unit_tags",
      "pysc2.function.raw_flag"
    ],
    "interface"
  ],
  [
    "pysc2-attack-call",
    "执行 ATTACK 时，除攻击函数编号外还需要哪四个通用 FunctionCall 参数？",
    [
      "pysc2.attack.function_id",
      "pysc2.function.queued",
      "pysc2.function.target",
      "pysc2.function.unit_tags",
      "pysc2.function.raw_flag"
    ],
    "interface"
  ],
  [
    "pysc2-build-train-ids",
    "代码中 BUILD、TRAIN 和无操作三类 Raw 调用的函数编号变量分别是什么？",
    [
      "pysc2.build.function_id",
      "pysc2.train.function_id",
      "pysc2.no_op.function_id"
    ],
    "multi_variable_comparison"
  ],
  [
    "swm-input-contract",
    "世界模型预测请求中，当前 ABox 状态、计划动作、预测步数和候选编号分别用什么字段？",
    [
      "swm.input.abox_state",
      "swm.input.planned_actions",
      "swm.prediction_steps",
      "swm.candidate_index"
    ],
    "interface"
  ],
  [
    "swm-output-contract",
    "世界模型返回的总预测列表、预测单位状态和预测关系分别是哪三个字段？",
    [
      "swm.predictions",
      "swm.predicted_unit_states",
      "swm.predicted_relations"
    ],
    "interface"
  ],
  [
    "swm-per-step-change",
    "某个未来步的步号、置信度、位置增量和生命增量分别由哪些 SWM 变量表达？",
    [
      "swm.prediction.step",
      "swm.confidence",
      "swm.unit.position_delta",
      "swm.unit.health_delta"
    ],
    "multi_variable_comparison"
  ],
  [
    "swm-response-audit",
    "审计世界模型调用时，需要原始回复和 token 用量，两个字段是什么？",
    [
      "swm.raw_response",
      "swm.token_usage"
    ],
    "interface"
  ],
  [
    "metric-token-accounting",
    "分别统计提示、补全和总 token 数，应使用哪三个 LLM 指标？",
    [
      "metric.llm.prompt_tokens",
      "metric.llm.completion_tokens",
      "metric.llm.total_tokens"
    ],
    "multi_variable_comparison"
  ],
  [
    "metric-decision-cost",
    "衡量决策调用次数、平均耗时和每次平均 token，需要哪三个指标？",
    [
      "metric.llm.decision_calls",
      "metric.llm.avg_decision_time",
      "metric.llm.avg_tokens_per_decision"
    ],
    "multi_variable_comparison"
  ],
  [
    "metric-action-failure-split",
    "总动作失败率、决策阶段失败率和延迟执行失败率分别是什么指标？",
    [
      "metric.action.failure_rate",
      "metric.action.decision_failure_rate",
      "metric.action.delayed_failure_rate"
    ],
    "multi_variable_comparison"
  ],
  [
    "metric-score-aggregation",
    "单回合最终分数与跨实验平均分数分别记录在哪两个指标？",
    [
      "metric.episode.final_score",
      "metric.experiment.avg_score"
    ],
    "multi_variable_comparison"
  ],
  [
    "metric-swm-four-way",
    "世界模型的位置误差、生命误差、关系正确率和总体误差分别由什么指标度量？",
    [
      "metric.swm.position_rmse",
      "metric.swm.health_rmse",
      "metric.swm.relation_accuracy",
      "metric.swm.overall_error"
    ],
    "multi_variable_comparison"
  ],
  [
    "formula-supply-remaining",
    "“补给上限减去已用补给”在知识库中对应哪个派生结果，并需要哪两个输入变量？",
    [
      "player.food_cap",
      "player.food_used",
      "player.supply_remaining"
    ],
    "formula"
  ],
  [
    "formula-raw-ratios",
    "RawUnit 中生命比例和护盾比例的接口值如何对应两个比例变量？请同时返回绝对量与比例量，避免只答其中一组。",
    [
      "raw_unit.health",
      "raw_unit.health_ratio",
      "raw_unit.shield",
      "raw_unit.shield_ratio"
    ],
    "formula"
  ],
  [
    "formula-force-ratio",
    "战术摘要里用于表达双方数量比的量是什么？同时给出构成它的我方和敌方计数变量。",
    [
      "derived.tactical.friendly_count",
      "derived.tactical.enemy_count",
      "derived.tactical.force_ratio"
    ],
    "formula"
  ],
  [
    "formula-token-average",
    "若要解释“每次决策平均 token”，需要总 token、决策调用次数和平均量本身哪三个指标？",
    [
      "metric.llm.total_tokens",
      "metric.llm.decision_calls",
      "metric.llm.avg_tokens_per_decision"
    ],
    "formula"
  ],
  [
    "cross-layer-attack-range",
    "同名的攻击距离在静态类型画像与动态实例节点两层分别是什么变量？",
    [
      "tbox.entity.attack_range",
      "abox.unit.attack_range"
    ],
    "lineage"
  ],
  [
    "cross-layer-type-id",
    "比较 Raw 观测、ABox 实例与 TBox 静态类型中的单位类型编号，需要哪三个变量？",
    [
      "raw_unit.unit_type",
      "abox.unit.unit_type_id",
      "tbox.entity.unit_type_id"
    ],
    "lineage"
  ],
  [
    "ambiguous-hp",
    "用户只说“hp”，没有说明是 Raw 当前生命、ABox 实例生命还是 TBox 静态基础生命；应返回哪些候选并要求补充层级？",
    [
      "raw_unit.health",
      "abox.unit.hp",
      "tbox.entity.hp"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "ambiguous-attack-range",
    "只问 attack range 而未指明静态类型还是动态实例，应列出哪两个候选变量？",
    [
      "tbox.entity.attack_range",
      "abox.unit.attack_range"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "ambiguous-unit-description",
    "问题只有“单位 description”，没有说明 TBox 或 ABox，知识库应提示哪两个候选？",
    [
      "tbox.entity.description",
      "abox.unit.description"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "ambiguous-token-usage",
    "只说 token usage，既可能指世界模型调用记录，也可能指 LLM 的总 token 指标；应给出哪两个候选？",
    [
      "swm.token_usage",
      "metric.llm.total_tokens"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "ambiguous-reason",
    "只问“reason”，既可能是动作决策理由，也可能是 ABox 关系成立理由；应返回哪两个候选？",
    [
      "action.reasoning",
      "abox.relation.reason"
    ],
    "ambiguous",
    "clarify"
  ],
  [
    "out-feature-screen-hp",
    "请给出 feature_screen.unit_hit_points 的通道接口；当前仅收录 STORM Raw API 主路径时应如何处理？",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-minimap-visibility",
    "查询 feature_minimap.visibility_map 的像素语义，但 V0.1 没有对应变量卡片，应拒绝越界补全。",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-camera-position",
    "我需要 feature-layer camera 位置掩码变量；若知识库仅覆盖 Raw 主路径，不要凭 PySC2 常识作答。",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-rgb-observation",
    "请查 RGB 屏幕观测数组的 shape 和通道；这不在当前 Raw 变量范围内时应明确找不到。",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-replay-apm",
    "查询 SC2 replay 解析器中的玩家 APM 字段；当前 STORM Raw 主路径没有证据时不要猜。",
    [],
    "out_of_scope",
    "refuse"
  ],
  [
    "out-ui-control-group",
    "请返回 UI feature layer 的 control_groups 数组定义；如果未被当前知识库收录，应按范围外处理。",
    [],
    "out_of_scope",
    "refuse"
  ]
]''')
FORMAL_FILES = ("abox.yaml", "actions.yaml", "derived.yaml", "metrics.yaml", "raw_api.yaml", "swm.yaml", "tbox.yaml")

if not LOCK_FILE.exists():
    raise FileNotFoundError("必须先创建 v0.5 pre-blind RAG 锁")

records = {}
record_file = {}
for name in FORMAL_FILES:
    payload = yaml.safe_load((KB / "variables" / name).read_text(encoding="utf-8"))
    for record in payload["records"]:
        if record["id"] in records:
            raise ValueError(f"正式变量 ID 重复: {record['id']}")
        records[record["id"]] = record
        record_file[record["id"]] = name

def normalize(text: str) -> str:
    return re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+", "", text).casefold()

question_file = EVALS / "questions_challenge_v0.5.jsonl"
prior_files = sorted(p for p in EVALS.glob("questions*.jsonl") if p != question_file)
prior_questions = {}
for p in prior_files:
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            row = json.loads(line)
            prior_questions[normalize(row["question"])] = f"{p.name}:{row.get('id')}"

rows = []
seen_questions = set()
for index, spec in enumerate(SPECS, 1):
    slug, question, ids, qtype, *behavior_override = spec
    missing = [vid for vid in ids if vid not in records]
    if missing:
        raise ValueError(f"{slug} 引用非法变量: {missing}")
    norm = normalize(question)
    if norm in prior_questions:
        raise ValueError(f"{slug} 与旧题完全重复: {prior_questions[norm]}")
    if norm in seen_questions:
        raise ValueError(f"v0.5 内部题目重复: {slug}")
    seen_questions.add(norm)
    behavior = behavior_override[0] if behavior_override else "answer"
    status = {"answer": "found", "clarify": "ambiguous", "refuse": "not_found"}[behavior]
    evidence = []
    refs = []
    for vid in ids:
        evs = records[vid].get("evidence") or []
        if not evs:
            raise ValueError(f"{vid} 没有证据")
        ev = evs[0]
        if not (ROOT / ev["path"]).exists():
            raise ValueError(f"{vid} 证据路径不存在: {ev['path']}")
        item = {k: ev.get(k) for k in ("id", "fact_status", "path", "symbol")}
        item["evidence_id"] = item.pop("id")
        evidence.append(item)
        refs.append(f"knowledge/variables/{record_file[vid]}#id={vid}")
    if behavior == "refuse":
        evidence = [{"evidence_id": "scope-v0.1-manifest", "fact_status": "design_intent", "path": "knowledge/manifests/scope.yaml", "symbol": "scope.in_scope_rule"}]
    rows.append({
        "benchmark_version": VERSION,
        "category": "generalization_challenge",
        "clarification_required": behavior == "clarify",
        "difficulty": "hard" if index <= 50 else "medium",
        "expected_behavior": behavior,
        "expected_status": status,
        "expected_variable_ids": ids,
        "forbidden_claims": ["声称执行了本题未记录的 SC2 运行时或外部模型测试", "使用知识库外常识补齐缺失变量"],
        "generated_at": TODAY,
        "id": f"challenge.v0.5.{index:03d}.{slug}",
        "intents": ["fifth_frozen_challenge", "single_first_blind_generalization"],
        "language": "zh",
        "notes": "v0.5 在完整题集首次运行前冻结；冻结后禁止逐题预检、修改受锁文件或按结果调参。",
        "question": question,
        "question_type": qtype,
        "required_evidence": evidence,
        "required_facts": [],
        "source_record_refs": refs,
        "split": SPLIT,
        "variable_categories": sorted({records[vid]["category"] for vid in ids}),
    })

question_file.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")
question_hash = hashlib.sha256(question_file.read_bytes()).hexdigest()
lock_hash = hashlib.sha256(LOCK_FILE.read_bytes()).hexdigest()
manifest = {
    "case_count": len(rows),
    "challenge_version": VERSION,
    "created_at": TODAY,
    "difficulty": dict(sorted(collections.Counter(r["difficulty"] for r in rows).items())),
    "expected_behavior": dict(sorted(collections.Counter(r["expected_behavior"] for r in rows).items())),
    "external_model_test": "未执行",
    "first_evaluation_status": "not_run_at_freeze_time",
    "frozen_at": TODAY,
    "frozen_before_first_evaluation": True,
    "normalized_overlap_with_all_prior_sets": 0,
    "prior_sets": [str(p.relative_to(ROOT)).replace("\\", "/") for p in prior_files],
    "question_file": str(question_file.relative_to(ROOT)).replace("\\", "/"),
    "question_type": dict(sorted(collections.Counter(r["question_type"] for r in rows).items())),
    "rag_lock_file": str(LOCK_FILE.relative_to(ROOT)).replace("\\", "/"),
    "rag_lock_sha256": lock_hash,
    "question_generation_sources": ["knowledge/variables/*.yaml", "source evidence paths referenced by variable cards", "prior question text for exact-overlap rejection"],
    "retrieval_files_read_during_generation": False,
    "retrieval_imported_or_called_during_generation": False,
    "sc2_runtime": "未执行",
    "sha256": question_hash,
    "tuning_policy": "v0.5 冻结后不得运行预检索、不得修改受锁文件、不得按题调参；只允许一次不带 limit 的完整首次盲测。",
}
manifest_file = EVALS / "challenge_v0.5_manifest.json"
manifest_file.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({"question_file": str(question_file), "manifest_file": str(manifest_file), "case_count": len(rows), "sha256": question_hash, "rag_lock_sha256": lock_hash, "behavior": manifest["expected_behavior"], "types": manifest["question_type"]}, ensure_ascii=False, indent=2))
