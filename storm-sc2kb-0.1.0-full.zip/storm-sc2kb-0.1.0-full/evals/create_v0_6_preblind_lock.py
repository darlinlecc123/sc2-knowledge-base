"""在 challenge v0.6 生成前封存当前 RAG、知识库、评测器和 STORM 源码。"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
EVALS = KB / "evals"
OUTPUT = EVALS / "rag_v0.6_preblind_lock.json"
REGRESSION = EVALS / "results" / "20260906_deepseek_challenge_v0.5_post_regression_rag_v2"

TREE_ROOTS = (
    KB / "src" / "sc2kb",
    KB / "retrieval",
    KB / "context",
    KB / "variables",
    KB / "schemas",
    KB / "lineage",
    KB / "relations",
    KB / "manifests",
    KB / "tests",
    ROOT / "agents",
    ROOT / "ontology",
    ROOT / "examples",
)
FIXED_FILES = (
    KB / "known_issues.yaml",
    EVALS / "run_evaluation.py",
    EVALS / "scorers.py",
    EVALS / "report.py",
    EVALS / "configs" / "deepseek_v4_flash_rag_optimized.yaml",
    EVALS / "questions_rag_generalization_dev_v0.3.jsonl",
    EVALS / "rag_generalization_dev_v0.3_manifest.json",
    EVALS / "challenge_v0.5_first_blind_result_seal.json",
    REGRESSION / "summary.json",
    REGRESSION / "run_manifest.json",
    REGRESSION / "report.md",
    REGRESSION / "results.jsonl",
    Path(__file__).resolve(),
    ROOT / "pyproject.toml",
    ROOT / "uv.lock",
)

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

files: set[Path] = set(FIXED_FILES)
for tree in TREE_ROOTS:
    files.update(
        path for path in tree.rglob("*")
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"
    )
files.discard(OUTPUT)
missing = [str(path) for path in files if not path.exists()]
if missing:
    raise FileNotFoundError("锁定文件不存在: " + ", ".join(missing))
summary = json.loads((REGRESSION / "summary.json").read_text(encoding="utf-8"))
metrics = summary["models"]["deepseek-v4-flash"]
thresholds = {
    "behavior_accuracy": 0.85,
    "variable_hit_rate": 0.85,
    "variable_precision": 0.90,
    "evidence_hit_rate": 0.90,
    "refusal_accuracy": 0.90,
    "native_json_compliance_rate": 0.99,
}
passed = all(float(metrics[name]) >= threshold for name, threshold in thresholds.items())
if not passed:
    raise RuntimeError("v0.5 post-regression 未达到创建 v0.6 的门槛")
entries = []
for path in sorted(files, key=lambda item: item.relative_to(ROOT).as_posix()):
    entries.append({
        "path": path.relative_to(ROOT).as_posix(),
        "sha256": digest(path),
        "bytes": path.stat().st_size,
    })
payload = {
    "schema_version": "1.0.0",
    "lock_id": "rag-v0.6-preblind",
    "created_at": "2026-09-06T18:00:00+08:00",
    "purpose": "Freeze post-v0.5 RAG implementation and evidence before challenge v0.6 is generated or inspected.",
    "parent_first_blind_result": {
        "path": "knowledge/evals/challenge_v0.5_first_blind_result_seal.json",
        "status": "exposed_regression_only",
    },
    "readiness_gate": {
        "result_dir": REGRESSION.relative_to(ROOT).as_posix(),
        "metrics": {name: metrics[name] for name in thresholds},
        "thresholds": thresholds,
        "threshold_passed": passed,
    },
    "blind_protocol": {
        "retrieval_pre_run_before_challenge_freeze": False,
        "model_pre_run_before_challenge_freeze": False,
        "modify_locked_files_after_freeze": False,
        "tune_on_challenge_v0_6": False,
        "overwrite_first_result": False,
        "partial_or_limit_run": False,
        "full_dataset_single_first_run": True,
    },
    "evaluation_semantics": {
        "challenge_v0_5_status": "exposed_regression_only",
        "challenge_v0_6_status_at_lock": "not_created",
        "may_claim_v0_6_first_blind_only_after_freeze_and_single_full_run": True,
    },
    "file_count": len(entries),
    "files": entries,
}
OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({"output": str(OUTPUT), "file_count": len(entries), "sha256": digest(OUTPUT), "gate": passed}, ensure_ascii=False, indent=2))
