"""创建并冻结 challenge v0.4。禁止导入或调用 QAAgent/检索器。"""
from __future__ import annotations

import collections
import hashlib
import json
import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
KB = ROOT / "knowledge"
EVALS = KB / "evals"
VERSION = "0.4.0"
SPLIT = "challenge_v0.4"
TODAY = "2026-09-06"
LOCK_FILE = EVALS / "rag_v0.4_preblind_lock.json"

# 题目只依据正式变量卡片与源码证据构造；本脚本不读取 retrieval/，不导入 sc2kb。
SPECS = [
("raw-survival-clock", "把单位承伤后的当前血量、护盾余量和再次开火等待量放进同一条 Raw 记录，应联合读取哪些字段？", ["raw_unit.health","raw_unit.shield","raw_unit.weapon_cooldown"], "interface"),
("raw-track-key", "若要用兵种编号和唯一对象标识追踪一个单位，同时保留其二维落点，需要哪四个 Raw 量？", ["raw_unit.unit_type","raw_unit.tag","raw_unit.x","raw_unit.y"], "multi_variable_comparison"),
("raw-normalized-side", "只保留生命比例、护盾比例以及所属方编码时，Raw 观测对应哪三项？", ["raw_unit.health_ratio","raw_unit.shield_ratio","raw_unit.alliance"], "interface"),
("lineage-motion-fire", "从 Raw 输入建立 ABox 节点时，横纵坐标合成为位置，而武器等待量原样进入节点；这条链路涉及哪些五个变量？", ["raw_unit.x","raw_unit.y","raw_unit.weapon_cooldown","abox.unit.position","abox.unit.weapon_cooldown"], "lineage"),
("lineage-health-identity", "单位由原始观测进入实例图时，要同时追踪生命值及其比例、唯一 tag；请列出前后两层的六个量。", ["raw_unit.health","raw_unit.health_ratio","raw_unit.tag","abox.unit.hp","abox.unit.hp_ratio","abox.unit.tag"], "lineage"),
("abox-combat-mobility", "ABox 节点要描述单次攻击强度、攻击节奏、射程和移动速度，应查询哪四个实例属性？", ["abox.unit.attack_damage","abox.unit.attack_speed","abox.unit.attack_range","abox.unit.movement_speed"], "multi_variable_comparison"),
("abox-classification-five", "要完整区分 ABox 单位的类别、节点类型、种族、类名和类型编号，需要哪五项？", ["abox.unit.category","abox.unit.node_type","abox.unit.race","abox.unit.unit_class","abox.unit.unit_type_id"], "multi_variable_comparison"),
("abox-edge-address", "一条动态 ABox 关系边由起点、终点、关系类型和写入步号共同定位，四个字段分别是什么？", ["abox.relation.source_node","abox.relation.target_node","abox.relation.edge_type","abox.relation.timestamp"], "interface"),
("abox-edge-semantics", "若要解释一条实例关系属于哪类边、效果有多强以及为何成立，应返回哪三个关系属性？", ["abox.relation.edge_class","abox.relation.effectiveness","abox.relation.reason"], "multi_variable_comparison"),
("abox-graph-progress", "观察图随 Raw 帧更新的进度并读取当前敌方节点缓存，需要哪两个图级量？", ["abox.graph.step_count","abox.graph.enemy_count"], "multi_variable_comparison"),
("abox-unknown-description", "实例节点若要同时表达未知类型标记、文本说明和静态类别映射，应使用哪三个属性？", ["abox.unit.is_unknown","abox.unit.description","abox.unit.category"], "known_issue_trap"),
("abox-defense-binding", "当前实现中实例节点的 armor 与 armor_ratio 是从 Raw 的哪两个护盾字段写入的？请给出源端和目标端四个变量。", ["raw_unit.shield","raw_unit.shield_ratio","abox.unit.armor","abox.unit.armor_ratio"], "known_issue_trap"),
("tbox-survival-perception", "静态类型画像若要描述基础耐久、防护、移动能力和视野，需要哪四个 TBox 属性？", ["tbox.entity.hp","tbox.entity.armor","tbox.entity.movement_speed","tbox.entity.sight"], "multi_variable_comparison"),
("tbox-economy-identity", "查询一个静态类型的矿物、气体、建造时长以及类型编号，应联合返回哪些属性？", ["tbox.entity.mineral_cost","tbox.entity.gas_cost","tbox.entity.build_time","tbox.entity.unit_type_id"], "multi_variable_comparison"),
("tbox-taxonomy-text", "静态本体节点的节点类型、类别、种族、资源种类和说明文字分别由哪些变量承载？", ["tbox.entity.node_type","tbox.entity.category","tbox.entity.race","tbox.entity.resource_type","tbox.entity.description"], "multi_variable_comparison"),
("tbox-offense-edge", "要把静态 DPS、攻击距离与本体关系边一起提供给分析器，应查询哪三个量？", ["tbox.entity.dps","tbox.entity.attack_range","tbox.relation.edge"], "multi_variable_comparison"),
("tbox-production-supply", "一个单位类型的补给占用、生产时间和矿气成本分别由哪四个静态变量给出？", ["tbox.entity.supply_cost","tbox.entity.build_time","tbox.entity.mineral_cost","tbox.entity.gas_cost"], "interface"),
("tactical-centroid-spacing", "战术摘要要同时给出我方中心、敌方中心和两阵型中心间距，应读取哪三个派生量？", ["derived.tactical.friendly_centroid","derived.tactical.enemy_centroid","derived.tactical.formation_distance"], "formula"),
("tactical-count-balance", "若报告双方数量以及兵力数量比，三个派生统计项分别是什么？", ["derived.tactical.friendly_count","derived.tactical.enemy_count","derived.tactical.force_ratio"], "formula"),
("tactical-health-summary", "比较双方平均生命并给出整体健康态势，需要哪三个战术派生字段？", ["derived.tactical.friendly_avg_hp","derived.tactical.enemy_avg_hp","derived.tactical.health_status"], "multi_variable_comparison"),
("tactical-fire-risk", "同时描述可开火程度、已就绪单位数和危险单位集合，应查询哪些派生量？", ["derived.tactical.fire_readiness","derived.tactical.ready_to_fire_count","derived.tactical.critical_units"], "multi_variable_comparison"),
("tactical-engagement-geometry", "判断交战类型时若还要附带敌我中心位置，应该组合哪三个摘要变量？", ["derived.tactical.engagement_type","derived.tactical.friendly_centroid","derived.tactical.enemy_centroid"], "multi_variable_comparison"),
("action-semantic-envelope", "一条计划动作的主类型、子类型、优先级和理由说明分别存在哪些字段？", ["action.type","action.subtype","action.priority","action.reasoning"], "interface"),
("action-target-contract", "动作落到谁或哪里，需要目标值、目标种类以及执行单位集合；对应哪三个 Schema 字段？", ["action.target","action.target_type","action.units"], "interface"),
("action-plan-schedule", "从完整计划拆出动作列表后，还要表达每项延迟和优先级，应涉及哪四个字段？", ["action.plan","action.planned_actions","action.delay_steps","action.priority"], "lineage"),
("action-invalid-diagnostics", "统计无效动作时，既要保留无效条目，又要按原因聚合，并知道原动作类型，应组合哪些量？", ["action.invalid_actions","action.invalid_reason_counts","action.type"], "multi_variable_comparison"),
("function-call-payload", "不讨论具体技能编号，只看 Raw FunctionCall 的排队标志、raw 标志、单位标签和目标参数，四项接口变量是什么？", ["pysc2.function.queued","pysc2.function.raw_flag","pysc2.function.unit_tags","pysc2.function.target"], "interface"),
("function-combat-ids", "执行无操作、移动和攻击分支时使用的三个函数编号变量分别是什么？", ["pysc2.no_op.function_id","pysc2.move.function_id","pysc2.attack.function_id"], "interface"),
("function-production-ids", "生产路径中建造与训练分支分别由哪个 Function ID 变量选择？", ["pysc2.build.function_id","pysc2.train.function_id"], "interface"),
("environment-raw-contract", "要确保环境走 Raw 单位和 Raw 动作接口，并固定原始坐标分辨率，应检查哪三个配置？", ["environment.use_raw_units","environment.use_raw_actions","environment.raw_resolution"], "interface"),
("environment-time-controls", "环境步长倍数、Agent 决策间隔和是否实时运行，分别对应哪些配置变量？", ["environment.step_mul","environment.decision_interval","environment.realtime"], "multi_variable_comparison"),
("environment-scene-display", "运行入口若要确定地图、是否可视化以及实时模式，需要哪三个环境配置？", ["environment.map_name","environment.visualize","environment.realtime"], "interface"),
("player-economy-supply", "一次决策同时读取矿物、气体、已用补给、补给上限和剩余补给，应查询哪五个玩家量？", ["player.minerals","player.vespene","player.food_used","player.food_cap","player.supply_remaining"], "multi_variable_comparison"),
("timestep-outcome-score", "判断回合是否结束、获得本步奖励变化并读取累计分数第零项，需要哪三个 TimeStep/分数量？", ["timestep.is_last","timestep.reward_delta","timestep.score_cumulative_0"], "formula"),
("metric-token-decomposition", "LLM 开销报告若拆成提示 token、补全 token 和总 token，对应哪三个指标？", ["metric.llm.prompt_tokens","metric.llm.completion_tokens","metric.llm.total_tokens"], "multi_variable_comparison"),
("metric-decision-efficiency", "评估 LLM 决策次数、平均决策耗时与每次平均 token，应使用哪三个实验指标？", ["metric.llm.decision_calls","metric.llm.avg_decision_time","metric.llm.avg_tokens_per_decision"], "multi_variable_comparison"),
("metric-action-failures", "要区分全部动作失败、决策阶段失败和延迟执行失败，应联合查看哪三个失败率？", ["metric.action.failure_rate","metric.action.decision_failure_rate","metric.action.delayed_failure_rate"], "multi_variable_comparison"),
("metric-score-levels", "单局最终得分与跨局平均得分分别由哪个指标记录？", ["metric.episode.final_score","metric.experiment.avg_score"], "multi_variable_comparison"),
("metric-swm-quality", "评价世界模型的位置、生命、关系预测和总体误差，需要哪四个质量指标？", ["metric.swm.position_rmse","metric.swm.health_rmse","metric.swm.relation_accuracy","metric.swm.overall_error"], "multi_variable_comparison"),
("swm-step-deltas", "世界模型某个预测步若要返回置信度、单位位置变化和生命变化，应组合哪四项？", ["swm.prediction.step","swm.confidence","swm.unit.position_delta","swm.unit.health_delta"], "interface"),
("swm-structured-output", "预测结果既包含总预测列表，也包含单步单位状态和单步关系，应查询哪三个 SWM 字段？", ["swm.predictions","swm.predicted_unit_states","swm.predicted_relations"], "multi_variable_comparison"),
("swm-request-envelope", "发起候选世界模型预测时，输入状态、候选动作、未来步数和候选序号分别是什么？", ["swm.input.abox_state","swm.input.planned_actions","swm.prediction_steps","swm.candidate_index"], "interface"),
("swm-audit-envelope", "若要审计世界模型的原始回复、token 用量与置信程度，应返回哪三项？", ["swm.raw_response","swm.token_usage","swm.confidence"], "multi_variable_comparison"),
("ambiguous-armor", "只说 armor 而没有指出是静态类型防护还是运行时实例属性时，知识库应保留哪两个候选变量？", ["tbox.entity.armor","abox.unit.armor"], "ambiguous", "clarify"),
("ambiguous-type-number", "用户只问兵种编号，却没说要 Raw 字段、ABox 实例编号还是 TBox 静态编号，应该列出哪些候选？", ["raw_unit.unit_type","abox.unit.unit_type_id","tbox.entity.unit_type_id"], "ambiguous", "clarify"),
("ambiguous-description", "只要求 description，未说明来自静态本体还是动态实例节点，应返回哪两个可能变量并请求澄清？", ["tbox.entity.description","abox.unit.description"], "ambiguous", "clarify"),
("ambiguous-enemy-count", "别人只说 enemy_count，没有说明要图对象缓存还是战术摘要派生值，应该保留哪两个候选？", ["abox.graph.enemy_count","derived.tactical.enemy_count"], "ambiguous", "clarify"),
("out-feature-selection", "请读取 feature screen 中当前框选单位面板的技能图标数组；若 Raw 主路径未收录就明确拒答。", [], "out_of_scope", "refuse"),
("out-camera-offset", "我要 feature-layer 摄像机在小地图上的平移偏移量，当前 V0.1 没有正式变量时不要猜测。", [], "out_of_scope", "refuse"),
("out-minimap-creep", "请给出 feature minimap 的 creep 像素掩码；如果不属于当前 STORM Raw API 变量范围就说明找不到。", [], "out_of_scope", "refuse"),
("out-network-ping", "查询 SC2 客户端到服务器的实时网络 ping；知识库没有源码卡片时不得用常识补齐。", [], "out_of_scope", "refuse"),
]

FORMAL_FILES = ("abox.yaml","actions.yaml","derived.yaml","metrics.yaml","raw_api.yaml","swm.yaml","tbox.yaml")
records = {}
record_file = {}
for name in FORMAL_FILES:
    payload = yaml.safe_load((KB / "variables" / name).read_text(encoding="utf-8"))
    for record in payload["records"]:
        records[record["id"]] = record
        record_file[record["id"]] = name

def normalize(text: str) -> str:
    return re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+", "", text).casefold()

prior_files = sorted(p for p in EVALS.glob("questions*.jsonl") if p.name != "questions_challenge_v0.4.jsonl")
prior_questions = {}
for p in prior_files:
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            row = json.loads(line)
            prior_questions[normalize(row["question"])] = f"{p.name}:{row.get('id')}"

rows = []
seen_questions = set()
for index, spec in enumerate(SPECS, 1):
    slug, question, ids, qtype, *behavior_override = spec
    missing = [vid for vid in ids if vid not in records]
    if missing:
        raise ValueError(f"{slug} 引用非法变量: {missing}")
    norm = normalize(question)
    if norm in prior_questions:
        raise ValueError(f"{slug} 与旧题完全重复: {prior_questions[norm]}")
    if norm in seen_questions:
        raise ValueError(f"v0.4 内部题目重复: {slug}")
    seen_questions.add(norm)
    behavior = behavior_override[0] if behavior_override else "answer"
    status = {"answer":"found","clarify":"ambiguous","refuse":"not_found"}[behavior]
    evidence = []
    refs = []
    for vid in ids:
        evs = records[vid].get("evidence") or []
        if not evs:
            raise ValueError(f"{vid} 没有证据")
        ev = evs[0]
        if not (ROOT / ev["path"]).exists():
            raise ValueError(f"{vid} 证据路径不存在: {ev['path']}")
        evidence.append({k: ev.get(k) for k in ("id","fact_status","path","symbol")})
        evidence[-1]["evidence_id"] = evidence[-1].pop("id")
        refs.append(f"knowledge/variables/{record_file[vid]}#id={vid}")
    if behavior == "refuse":
        evidence = [{"evidence_id":"scope-v0.1-manifest","fact_status":"design_intent","path":"knowledge/manifests/scope.yaml","symbol":"scope.in_scope_rule"}]
    rows.append({
        "benchmark_version": VERSION,
        "category": "generalization_challenge",
        "clarification_required": behavior == "clarify",
        "difficulty": "hard" if index <= 44 else "medium",
        "expected_behavior": behavior,
        "expected_status": status,
        "expected_variable_ids": ids,
        "forbidden_claims": ["声称执行了本题未记录的 SC2 运行时或外部模型测试","使用知识库外常识补齐缺失变量"],
        "generated_at": TODAY,
        "id": f"challenge.v0.4.{index:03d}.{slug}",
        "intents": ["fourth_frozen_challenge","post_optimization_blind_generalization"],
        "language": "zh",
        "notes": "v0.4 在任何检索或模型预跑前冻结；首次评测后禁止改写题集、清单或根据结果调参。",
        "question": question,
        "question_type": qtype,
        "required_evidence": evidence,
        "required_facts": [],
        "source_record_refs": refs,
        "split": SPLIT,
        "variable_categories": sorted({records[vid]["category"] for vid in ids}),
    })

question_file = EVALS / "questions_challenge_v0.4.jsonl"
question_file.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")
question_hash = hashlib.sha256(question_file.read_bytes()).hexdigest()
lock_hash = hashlib.sha256(LOCK_FILE.read_bytes()).hexdigest()
manifest = {
    "case_count": len(rows),
    "challenge_version": VERSION,
    "created_at": TODAY,
    "difficulty": dict(sorted(collections.Counter(r["difficulty"] for r in rows).items())),
    "expected_behavior": dict(sorted(collections.Counter(r["expected_behavior"] for r in rows).items())),
    "external_model_test": "未执行",
    "first_evaluation_status": "not_run_at_freeze_time",
    "frozen_at": TODAY,
    "frozen_before_first_evaluation": True,
    "normalized_overlap_with_all_prior_sets": 0,
    "prior_sets": [str(p.relative_to(ROOT)).replace("\\","/") for p in prior_files],
    "question_file": str(question_file.relative_to(ROOT)).replace("\\","/"),
    "question_type": dict(sorted(collections.Counter(r["question_type"] for r in rows).items())),
    "rag_lock_file": str(LOCK_FILE.relative_to(ROOT)).replace("\\","/"),
    "rag_lock_sha256": lock_hash,
    "retrieval_files_read_during_generation": False,
    "retrieval_imported_or_called_during_generation": False,
    "sc2_runtime": "未执行",
    "sha256": question_hash,
    "tuning_policy": "v0.4 冻结后禁止预跑、修改题集或根据首次结果调整检索器；首次结果无论成败均原样保留。",
}
manifest_file = EVALS / "challenge_v0.4_manifest.json"
manifest_file.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({"question_file":str(question_file),"manifest_file":str(manifest_file),"case_count":len(rows),"sha256":question_hash,"rag_lock_sha256":lock_hash,"behavior":manifest["expected_behavior"],"types":manifest["question_type"]}, ensure_ascii=False, indent=2))
