"""批量运行步骤 12 QAAgent，并用步骤 13 benchmark 做自动评测。"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[2]
KNOWLEDGE = ROOT / "knowledge"
sys.path.insert(0, str(KNOWLEDGE / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from sc2kb.model_clients import DisabledModelClient, build_model_client, load_model_config
from sc2kb.qa_agent import QAAgent
from sc2kb.evaluation_conditions import DirectKnowledgeConditionAgent
from report import write_report
from scorers import aggregate, score_case


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def sanitize_config(config: dict[str, Any]) -> dict[str, Any]:
    blocked = {"api_key", "key", "secret", "token", "password"}
    result: dict[str, Any] = {}
    for key, value in config.items():
        if key.lower() in blocked or key.lower().endswith("_key"):
            result[key] = "<redacted>"
        elif isinstance(value, dict):
            result[key] = sanitize_config(value)
        else:
            result[key] = value
    return result


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def code_version() -> dict[str, str]:
    paths = [
        KNOWLEDGE / "src/sc2kb/qa_agent.py",
        KNOWLEDGE / "retrieval/facet_registry.json",
        KNOWLEDGE / "retrieval/semantic_concepts.json",
        KNOWLEDGE / "src/sc2kb/model_clients.py",
        KNOWLEDGE / "evals/run_evaluation.py",
        KNOWLEDGE / "evals/scorers.py",
        KNOWLEDGE / "evals/report.py",
    ]
    return {str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path) for path in paths}


def extract_usage(result: dict[str, Any]) -> tuple[float | None, float | None]:
    usage = result.get("usage")
    metadata = result.get("model_metadata")
    answer = result.get("answer")
    if not isinstance(usage, dict) and isinstance(metadata, dict):
        usage = metadata.get("usage")
    if not isinstance(usage, dict) and isinstance(answer, dict):
        usage = answer.get("usage")
    if not isinstance(usage, dict):
        return None, None
    total = usage.get("total_tokens")
    cost = usage.get("estimated_cost_usd")
    return (float(total) if isinstance(total, (int, float)) else None,
            float(cost) if isinstance(cost, (int, float)) else None)


def perfect_mock(question: dict[str, Any]) -> dict[str, Any]:
    ids = question["expected_variable_ids"]
    grounding = {
        "variable_ids": ids,
        "evidence_ids": [e["evidence_id"] for e in question["required_evidence"]],
        "source_locations": [{k: e.get(k) for k in ("path", "symbol")} for e in question["required_evidence"]],
        "truth_boundary": {},
    }
    if question["expected_behavior"] == "refuse":
        return {"status": "not_found", "candidate_variable_ids": [], "answer": {"refusal": "当前 V0.1 知识库没有依据，拒绝编造。", "facts": question["required_facts"], "evidence": question["required_evidence"]}, "grounding": grounding, "model_called": False}
    if question["expected_behavior"] == "clarify":
        return {"status": "ambiguous", "candidate_variable_ids": ids, "answer": {"candidate_variable_ids": ids, "candidate_explanations": [{"variable_id": x} for x in ids], "clarification_question": "请明确变量层级。", "facts": question["required_facts"], "evidence": question["required_evidence"]}, "grounding": grounding, "model_called": False}
    return {"status": "answered", "candidate_variable_ids": ids, "answer": {"corresponding_variables": ids, "plain_language_meaning": "见结构化事实。", "physical_or_business_meaning": "见结构化事实。", "interface_form": {}, "storm_code_locations": question["required_evidence"], "transformations_or_formulas": [], "limitations_and_evidence": question["required_evidence"], "facts": question["required_facts"]}, "grounding": grounding, "model_called": False}


def imperfect_mock(question: dict[str, Any], index: int) -> dict[str, Any]:
    result = perfect_mock(question)
    if index % 2 == 0:
        result["candidate_variable_ids"] = []
        result["grounding"]["variable_ids"] = []
        if isinstance(result.get("answer"), dict):
            result["answer"]["corresponding_variables"] = []
            result["answer"]["candidate_variable_ids"] = []
    if index % 3 == 0 and isinstance(result.get("answer"), dict):
        result["answer"]["facts"] = []
        result["answer"]["evidence"] = []
        result["grounding"]["evidence_ids"] = []
        result["grounding"]["source_locations"] = []
    if index % 4 == 0 and question["forbidden_claims"] and isinstance(result.get("answer"), dict):
        result["answer"]["bad_claim"] = question["forbidden_claims"][0]
    if index % 5 == 0 and question["expected_behavior"] == "refuse":
        result["status"] = "answered"
        result["answer"] = {"corresponding_variables": [], "plain_language_meaning": "无依据但仍回答。"}
    return result


def normalize_live_config(path: Path) -> tuple[str, dict[str, Any], dict[str, Any]]:
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    model_section = raw.get("model", raw)
    provider = model_section.get("provider", "disabled")
    mapped = {
        "provider": provider,
        "model": model_section.get("name") or model_section.get("model"),
        "base_url": os.getenv(model_section.get("base_url_env", "SC2KB_MODEL_BASE_URL")) or model_section.get("base_url"),
        "api_key_env": model_section.get("api_key_env", "SC2KB_MODEL_API_KEY"),
        "timeout_seconds": model_section.get("timeout_seconds", 60),
        "sdk_max_retries": model_section.get("sdk_max_retries", 0),
        "temperature": model_section.get("temperature", 0),
        "max_output_tokens": model_section.get("max_output_tokens", 1500),
        "thinking": model_section.get("thinking"),
        "json_mode": model_section.get("json_mode", True),
    }
    label = str(model_section.get("name") or path.stem)
    return label, mapped, sanitize_config(raw)


def model_specs(args: argparse.Namespace) -> list[tuple[str, dict[str, Any] | None, dict[str, Any]]]:
    if args.mode != "live":
        labels = args.model_label or [args.mode]
        return [(label, None, {"provider": "disabled", "mode": args.mode, "temperature": 0}) for label in labels]
    if not args.model_config:
        raise ValueError("live 模式必须至少提供一个 --model-config。")
    result = []
    for value in args.model_config:
        label, mapped, public = normalize_live_config(Path(value))
        result.append((label, mapped, public))
    return result


def run_one(question: dict[str, Any], mode: str, agent: Any | None, index: int) -> dict[str, Any]:
    if mode == "mock-perfect":
        return perfect_mock(question)
    if mode == "mock-imperfect":
        return imperfect_mock(question, index)
    if agent is None:
        raise RuntimeError("Agent 未初始化。")
    return agent.ask(question["question"], dry_run=(mode == "dry-run"), limit=8)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="STORM Raw API 知识库自动评测")
    parser.add_argument("--questions", default="knowledge/evals/questions_dev.jsonl")
    parser.add_argument("--mode", choices=("dry-run", "mock-perfect", "mock-imperfect", "live"), default="dry-run")
    parser.add_argument("--model-config", action="append", help="live 模式可重复指定，实现多模型运行")
    parser.add_argument("--model-label", action="append", help="dry-run/mock 的运行标签，可重复指定以离线验证多模型隔离")
    parser.add_argument("--output-dir", help="运行目录；默认在 knowledge/evals/results 下按时间创建")
    parser.add_argument("--resume", action="store_true", help="跳过 results.jsonl 已存在的模型-题目组合")
    parser.add_argument("--max-retries", type=int, default=1)
    parser.add_argument("--question-id", action="append", help="只运行指定题目，可重复使用")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--context-tier", choices=("short", "standard", "full", "rag_compact"), default="standard")
    parser.add_argument("--knowledge-condition", choices=("no_knowledge_base", "full_context", "retrieval_augmented"), default="retrieval_augmented")
    parser.add_argument("--full-context-file", default="knowledge/context/sc2_raw_api_context_full.md")
    args = parser.parse_args(argv)

    question_path = (ROOT / args.questions).resolve() if not Path(args.questions).is_absolute() else Path(args.questions)
    questions = load_jsonl(question_path)
    if args.question_id:
        wanted = set(args.question_id)
        questions = [q for q in questions if q["id"] in wanted]
        missing = wanted - {q["id"] for q in questions}
        if missing:
            raise ValueError("问题 ID 不存在：" + ", ".join(sorted(missing)))
    if args.limit is not None:
        questions = questions[:args.limit]
    if not questions:
        raise ValueError("没有待运行问题。")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(args.output_dir) if args.output_dir else KNOWLEDGE / "evals" / "results" / f"{timestamp}_{args.mode}"
    if not output_dir.is_absolute():
        output_dir = ROOT / output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    results_path = output_dir / "results.jsonl"
    if results_path.exists() and not args.resume:
        raise FileExistsError("结果文件已存在；请更换 --output-dir，或显式使用 --resume。")
    existing = load_jsonl(results_path) if args.resume and results_path.exists() else []
    completed = {(x["model_label"], x["question_id"]) for x in existing}
    all_results = list(existing)

    specs = model_specs(args)
    benchmark_version = questions[0].get("benchmark_version", "unknown")
    manifest = {
        "schema_version": "1.0.0", "run_id": output_dir.name, "started_at": now_iso(),
        "finished_at": None, "mode": args.mode,
        "question_file": str(question_path.relative_to(ROOT)).replace("\\", "/") if ROOT in question_path.parents else str(question_path),
        "question_count": len(questions), "benchmark_version": benchmark_version,
        "knowledge_version": "0.1.0", "context_tier": args.context_tier,
        "knowledge_condition": args.knowledge_condition,
        "max_retries": args.max_retries, "resume": args.resume,
        "code_version": code_version(),
        "models": [{"label": label, "config": public} for label, _, public in specs],
        "randomness": [{"label": label, "temperature": public.get("model", public).get("temperature", 0) if isinstance(public.get("model", public), dict) else 0} for label, _, public in specs],
        "external_model_test": "已执行" if args.mode == "live" else "未执行",
        "sc2_runtime": "未执行",
        "llm_judge": {"enabled": False, "status": "未执行"},
    }
    (output_dir / "run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    for label, config, _public in specs:
        agent = None
        if args.mode in {"dry-run", "live"}:
            client = DisabledModelClient() if args.mode == "dry-run" else build_model_client(config)
            if args.knowledge_condition == "retrieval_augmented":
                agent = QAAgent(model_client=client, context_profile=args.context_tier)
            else:
                full_context_path = None
                if args.knowledge_condition == "full_context":
                    candidate = Path(args.full_context_file)
                    full_context_path = candidate if candidate.is_absolute() else ROOT / candidate
                agent = DirectKnowledgeConditionAgent(
                    model_client=client,
                    condition=args.knowledge_condition,
                    full_context_path=full_context_path,
                )
                manifest["condition_context"] = agent.context_metadata
        for index, question in enumerate(questions, 1):
            key = (label, question["id"])
            if key in completed:
                continue
            started = time.perf_counter()
            error = None
            agent_result: dict[str, Any] = {}
            attempts = 0
            for attempt in range(args.max_retries + 1):
                attempts = attempt + 1
                try:
                    agent_result = run_one(question, args.mode, agent, index)
                    error = None
                    if agent_result.get("status") == "model_error" and attempt < args.max_retries:
                        continue
                    break
                except Exception as exc:
                    error = {"type": type(exc).__name__, "message": str(exc)}
                    if attempt >= args.max_retries:
                        agent_result = {"status": "runner_error", "answer": None, "candidate_variable_ids": [], "grounding": {}}
            latency_ms = (time.perf_counter() - started) * 1000
            total_tokens, estimated_cost = extract_usage(agent_result)
            scores = score_case(question, agent_result)
            record = {
                "schema_version": "1.0.0", "run_id": manifest["run_id"], "model_label": label,
                "question_id": question["id"],
                "question_meta": {k: question[k] for k in ("split", "category", "difficulty", "question_type", "expected_behavior")},
                "question": question["question"], "agent_result": agent_result, "scores": scores,
                "runtime": {"latency_ms": round(latency_ms, 3), "attempts": attempts,
                            "api_call_attempts": attempts if agent_result.get("model_called") else 0,
                            "total_tokens": total_tokens, "estimated_cost_usd": estimated_cost},
                "error": error,
                "reproduce_command": f'{sys.executable} knowledge/evals/run_evaluation.py --questions {args.questions} --mode {args.mode} --knowledge-condition {args.knowledge_condition} --question-id {question["id"]} --output-dir knowledge/evals/results/reproduce_{question["id"]}',
            }
            with results_path.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
            all_results.append(record)

    summaries = {label: aggregate([x for x in all_results if x["model_label"] == label]) for label, _, _ in specs}
    manifest["finished_at"] = now_iso()
    manifest["result_count"] = len(all_results)
    (output_dir / "run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (output_dir / "summary.json").write_text(json.dumps({"run_id": manifest["run_id"], "models": summaries}, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_report(output_dir / "report.md", manifest, summaries, all_results)
    print(json.dumps({"run_id": manifest["run_id"], "output_dir": str(output_dir), "summaries": summaries}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


