"""离线生成 GPT-5.4 Mini 三条件分析及与 DeepSeek 的并列比较。不会调用外部 API。"""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
QUESTIONS = ROOT / "knowledge/evals/questions_challenge_v0.3.jsonl"
GPT_OUT = ROOT / "knowledge/evals/analysis/20260906_gpt54mini_three_conditions"
CMP_OUT = ROOT / "knowledge/evals/analysis/20260906_gpt54mini_vs_deepseek"

RUNS = {
    "gpt": {
        "no_knowledge_base": ROOT / "knowledge/evals/results/20260906_gpt54mini_challenge_v0.3_no_kb_formal",
        "full_compact_context": ROOT / "knowledge/evals/results/20260906_gpt54mini_challenge_v0.3_full_compact_formal",
        "retrieval_augmented": ROOT / "knowledge/evals/results/20260906_gpt54mini_challenge_v0.3_rag_formal",
    },
    "deepseek": {
        "no_knowledge_base": ROOT / "knowledge/evals/results/20260905_deepseek_challenge_v0.3_no_kb_three_conditions",
        "full_compact_context": ROOT / "knowledge/evals/results/20260905_deepseek_challenge_v0.3_full_compact_three_conditions",
        "retrieval_augmented": ROOT / "knowledge/evals/results/20260905_deepseek_challenge_v0.3_rag_three_conditions",
    },
}
NAMES = {"no_knowledge_base": "no-KB", "full_compact_context": "full-context", "retrieval_augmented": "RAG"}


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def classify_error(row: dict[str, Any]) -> str | None:
    if row["agent_result"].get("status") != "model_error":
        return None
    answer = row["agent_result"].get("answer") or {}
    kind = str(answer.get("error_type") or "unknown")
    message = str(answer.get("message") or "").lower()
    if kind == "APITimeoutError" or "timed out" in message:
        return "timeout"
    if kind == "APIConnectionError" or "connection error" in message:
        return "connection"
    if kind in {"InternalServerError", "BadGatewayError"} or any(x in message for x in ("500", "502", "522", "bad gateway")):
        return "upstream_http"
    if kind == "ModelClientError":
        return "post_response_validation_or_format"
    return kind


def actual_response_received(row: dict[str, Any]) -> bool:
    """正式旧结果有失败调用残留元数据；按异常阶段判断是否真实拿到响应。"""
    if not row["agent_result"].get("model_called"):
        return False
    category = classify_error(row)
    return category not in {"timeout", "connection", "upstream_http"}


def grouped(rows: list[dict[str, Any]], field: str) -> dict[str, Any]:
    buckets: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        buckets[str(row["question_meta"].get(field))].append(row)
    output = {}
    for key, items in sorted(buckets.items()):
        output[key] = {
            "count": len(items),
            "behavior_accuracy": sum(bool(x["scores"].get("behavior_correct")) for x in items) / len(items),
            "variable_exact_match_rate": sum(bool(x["scores"].get("variable_exact_match")) for x in items) / len(items),
            "model_error_count": sum(x["agent_result"].get("status") == "model_error" for x in items),
        }
    return output


def analyze_condition(run: Path, model_key: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rows = load_jsonl(run / "results.jsonl")
    summary_obj = load_json(run / "summary.json")["models"]
    summary = next(iter(summary_obj.values()))
    errors = [row for row in rows if row["agent_result"].get("status") == "model_error"]
    error_types = Counter(classify_error(row) for row in errors)
    response_rows = [row for row in rows if actual_response_received(row)] if model_key == "gpt" else [row for row in rows if row["agent_result"].get("model_called") and classify_error(row) not in {"timeout", "connection", "upstream_http"}]
    model_values = Counter((row["agent_result"].get("model_metadata") or {}).get("response_model") for row in response_rows)
    request_id_count = sum(bool((row["agent_result"].get("model_metadata") or {}).get("response_request_id")) for row in response_rows)
    sdk_retry_values = Counter((row["agent_result"].get("model_metadata") or {}).get("sdk_max_retries") for row in rows if row["agent_result"].get("model_called"))
    return {
        "run_dir": str(run.relative_to(ROOT)).replace("\\", "/"),
        "summary": summary,
        "status_distribution": dict(Counter(row["agent_result"].get("status") for row in rows)),
        "error_type_distribution": {str(k): v for k, v in error_types.items()},
        "error_questions": [{"question_id": row["question_id"], "type": classify_error(row), "latency_ms": row["runtime"].get("latency_ms")} for row in errors],
        "by_expected_behavior": grouped(rows, "expected_behavior"),
        "by_question_type": grouped(rows, "question_type"),
        "behavior_wrong_question_ids": [row["question_id"] for row in rows if not row["scores"].get("behavior_correct")],
        "variable_not_exact_question_ids": [row["question_id"] for row in rows if not row["scores"].get("variable_exact_match")],
        "actual_response_count": len(response_rows),
        "response_model_distribution_confirmed": {str(k): v for k, v in model_values.items()},
        "response_request_id_coverage_confirmed": request_id_count / len(response_rows) if response_rows else None,
        "sdk_max_retries_recorded_distribution": {str(k): v for k, v in sdk_retry_values.items()},
        "metadata_caveat": "GPT 正式结果生成时存在失败调用沿用上一次 last_call_metadata 的问题；仅 actual_response_count 范围内的响应侧元数据视为确认。" if model_key == "gpt" else None,
    }, rows


def pct(value: float) -> str:
    return f"{value:.2%}"


def main() -> int:
    GPT_OUT.mkdir(parents=True, exist_ok=True)
    CMP_OUT.mkdir(parents=True, exist_ok=True)
    question_map = {q["id"]: q for q in load_jsonl(QUESTIONS)}
    analyses: dict[str, dict[str, Any]] = {"gpt": {}, "deepseek": {}}
    all_rows: dict[str, dict[str, list[dict[str, Any]]]] = {"gpt": {}, "deepseek": {}}
    for model_key, conditions in RUNS.items():
        for condition, run in conditions.items():
            analyses[model_key][condition], all_rows[model_key][condition] = analyze_condition(run, model_key)

    gpt_payload = {
        "analysis_date": "2026-09-06",
        "model_label": "gpt-5.4-mini via third-party OpenAI-compatible relay",
        "benchmark": "challenge_v0.3",
        "question_count": len(question_map),
        "conditions": analyses["gpt"],
        "comparability_notes": [
            "模型身份由第三方中转站及 response.model 声明，无法独立证明真实后端。",
            "GPT 使用 json_mode=true；DeepSeek 对照使用 json_mode=false，结构化输出能力并非完全同条件。",
            "正式结果中的传输失败题曾残留上一成功调用的响应元数据；本分析只统计确认拿到响应对象的题。",
            "RAG 指标包含检索候选、local short-circuit 和 grounding 贡献，不能全部归因于生成模型。",
            "接口没有返回价格，estimated_cost_usd=null 不代表费用为零。",
        ],
    }
    (GPT_OUT / "analysis.json").write_text(json.dumps(gpt_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    with (GPT_OUT / "per_question.csv").open("w", encoding="utf-8-sig", newline="") as f:
        fields = ["condition", "question_id", "question_type", "expected_behavior", "actual_status", "model_called", "behavior_correct", "variable_exact_match", "variable_hit_rate", "evidence_hit_rate", "error_type", "latency_ms", "tokens", "response_received", "response_model_confirmed"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for condition, rows in all_rows["gpt"].items():
            for row in rows:
                received = actual_response_received(row)
                metadata = row["agent_result"].get("model_metadata") or {}
                writer.writerow({
                    "condition": condition, "question_id": row["question_id"], "question_type": row["question_meta"].get("question_type"),
                    "expected_behavior": row["question_meta"].get("expected_behavior"), "actual_status": row["agent_result"].get("status"),
                    "model_called": bool(row["agent_result"].get("model_called")), "behavior_correct": bool(row["scores"].get("behavior_correct")),
                    "variable_exact_match": bool(row["scores"].get("variable_exact_match")), "variable_hit_rate": row["scores"].get("variable_hit_rate"),
                    "evidence_hit_rate": row["scores"].get("evidence_hit_rate"), "error_type": classify_error(row), "latency_ms": row["runtime"].get("latency_ms"),
                    "tokens": row["runtime"].get("total_tokens"), "response_received": received,
                    "response_model_confirmed": metadata.get("response_model") if received else None,
                })

    # 跨模型逐题胜负：以冻结评分器的 behavior_correct 为主。
    comparisons: dict[str, Any] = {}
    comparison_rows = []
    for condition in NAMES:
        gpt_rows = {r["question_id"]: r for r in all_rows["gpt"][condition]}
        ds_rows = {r["question_id"]: r for r in all_rows["deepseek"][condition]}
        outcomes = Counter()
        for qid in question_map:
            g = gpt_rows[qid]
            d = ds_rows[qid]
            gb, db = bool(g["scores"].get("behavior_correct")), bool(d["scores"].get("behavior_correct"))
            outcome = "gpt_win" if gb and not db else "deepseek_win" if db and not gb else "both_correct" if gb and db else "both_wrong"
            outcomes[outcome] += 1
            comparison_rows.append({
                "condition": condition, "question_id": qid, "question": question_map[qid]["question"], "expected_behavior": question_map[qid]["expected_behavior"],
                "gpt_status": g["agent_result"].get("status"), "deepseek_status": d["agent_result"].get("status"),
                "gpt_behavior_correct": gb, "deepseek_behavior_correct": db, "outcome": outcome,
                "gpt_error_type": classify_error(g), "deepseek_error_type": classify_error(d),
                "gpt_variable_exact": bool(g["scores"].get("variable_exact_match")), "deepseek_variable_exact": bool(d["scores"].get("variable_exact_match")),
            })
        gs = analyses["gpt"][condition]["summary"]
        ds = analyses["deepseek"][condition]["summary"]
        comparisons[condition] = {
            "gpt_summary": gs, "deepseek_summary": ds, "per_question_outcomes": dict(outcomes),
            "behavior_accuracy_difference_gpt_minus_deepseek": gs["behavior_accuracy"] - ds["behavior_accuracy"],
            "token_multiple_gpt_over_deepseek": gs["tokens"]["total"] / ds["tokens"]["total"],
            "latency_multiple_gpt_over_deepseek": gs["latency_ms"]["mean"] / ds["latency_ms"]["mean"],
        }
    comparison_payload = {
        "analysis_date": "2026-09-06", "benchmark": "challenge_v0.3", "question_count": len(question_map),
        "models": {"gpt": "gpt-5.4-mini (third-party relay claim)", "deepseek": "deepseek-v4-flash"},
        "conditions": comparisons,
        "limitations": gpt_payload["comparability_notes"] + ["两轮评测日期和服务状态不同，延迟及错误率包含服务端/中转站状态影响。"],
    }
    (CMP_OUT / "comparison.json").write_text(json.dumps(comparison_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (CMP_OUT / "per_question_comparison.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(comparison_rows[0]))
        writer.writeheader(); writer.writerows(comparison_rows)

    # GPT 人类可读报告
    glines = ["# GPT-5.4 Mini 三条件 challenge v0.3 评测分析", "", "- 日期：2026-09-06", "- 题集：冻结的 `challenge v0.3`，41 题", "- 接口：第三方 OpenAI-compatible 中转站", "- 参数：temperature=0、json_mode=true、max_output_tokens=2000、outer retries=0、SDK retries=0", "", "## 1. 总体结果", "", "| 条件 | 有效响应/调用 | 模型错误 | 行为准确率 | 变量完全匹配 | 证据命中 | 原生 JSON | 总 tokens | 平均延迟 |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for c in NAMES:
        s = analyses["gpt"][c]["summary"]
        glines.append(f"| {NAMES[c]} | {s['model_valid_response_count']}/{s['model_called_count']} | {s['model_error_count']} | {pct(s['behavior_accuracy'])} | {pct(s['variable_exact_match_rate'])} | {pct(s['evidence_hit_rate'])} | {pct(s['native_json_compliance_rate'])} | {int(s['tokens']['total']):,} | {s['latency_ms']['mean']/1000:.2f} s |")
    glines += ["", "## 2. 错误与响应元数据审计", ""]
    for c in NAMES:
        a = analyses["gpt"][c]
        glines += [f"### {NAMES[c]}", "", f"- 错误类型：`{json.dumps(a['error_type_distribution'], ensure_ascii=False)}`", f"- 确认拿到响应对象：{a['actual_response_count']} 题；其中 `response.model` 分布：`{json.dumps(a['response_model_distribution_confirmed'], ensure_ascii=False)}`。", f"- 确认响应的 request id 覆盖率：{pct(a['response_request_id_coverage_confirmed'] or 0)}。", f"- 调用记录中的 `sdk_max_retries`：`{json.dumps(a['sdk_max_retries_recorded_distribution'], ensure_ascii=False)}`。", ""]
    glines += ["## 3. 结论", "", "1. **full-context 是本轮准确率上界。** 行为准确率 95.12%，比 no-KB 高 85.37 个百分点，也比 RAG 高 51.22 个百分点。", "2. **RAG 的主要损失不只是检索。** 26 次模型调用中有 9 次模型错误：7 次属于拿到响应后的候选约束/格式验证失败，另有 1 次 502 和 1 次 120 秒超时；15 题由本地短路处理。", "3. **第三方链路是显著不稳定因素。** no-KB 有超时、连接错误和 5xx/522；full-context 两次均为约 120 秒超时。", "4. **成功响应的元数据记录有效。** 确认响应均声明 `response.model=gpt-5.4-mini` 且 request id 覆盖完整；但这仍只是中转站声明，不能独立证明后端身份。", "5. **旧正式结果的失败响应元数据不可直接使用。** 已修复客户端缓存清理；本报告已按异常阶段排除失败调用的残留值。", "", "## 4. 工程建议", "", "1. 保留 SDK retries=0，以确保一次评测题对应一次透明的 SDK 请求；如生产环境需要重试，应在评测协议中单独记录。", "2. RAG 优先修复候选集约束与检索漏召回的边界：允许模型补充正确变量时应标记为‘检索漏召回’，而非统一转成 model_error。", "3. 将链路超时/5xx 与知识问答错误分开报告；当前行为准确率同时反映模型、检索器和中转站可靠性。", "4. 后续新实验使用已修复的调用元数据逻辑；不要覆盖本轮正式结果。", ""]
    (GPT_OUT / "report.md").write_text("\n".join(glines), encoding="utf-8")

    clines = ["# GPT-5.4 Mini 与 DeepSeek 三条件并列分析", "", "- GPT：`gpt-5.4-mini`，模型名由第三方中转站声明", "- DeepSeek：`deepseek-v4-flash`", "- 题集：同一冻结 `challenge v0.3`，41 题", "", "## 1. 核心指标", "", "| 条件 | GPT 行为准确率 | DeepSeek 行为准确率 | 差值 GPT-DS | GPT/DS tokens | GPT/DS 平均延迟 | GPT 错误 | DS 错误 |", "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for c in NAMES:
        x=comparisons[c]; gs=x["gpt_summary"]; ds=x["deepseek_summary"]
        clines.append(f"| {NAMES[c]} | {pct(gs['behavior_accuracy'])} | {pct(ds['behavior_accuracy'])} | {x['behavior_accuracy_difference_gpt_minus_deepseek']*100:+.2f} pp | {x['token_multiple_gpt_over_deepseek']:.2f}× | {x['latency_multiple_gpt_over_deepseek']:.2f}× | {gs['model_error_count']} | {ds['model_error_count']} |")
    clines += ["", "## 2. 逐题胜负", "", "| 条件 | GPT 独胜 | DeepSeek 独胜 | 都正确 | 都错误 |", "|---|---:|---:|---:|---:|"]
    for c in NAMES:
        o=comparisons[c]["per_question_outcomes"]
        clines.append(f"| {NAMES[c]} | {o.get('gpt_win',0)} | {o.get('deepseek_win',0)} | {o.get('both_correct',0)} | {o.get('both_wrong',0)} |")
    clines += ["", "## 3. 并列解读", "", "1. **no-KB：DeepSeek 略高，但二者都不能可靠完成项目特定变量映射。** DeepSeek 14.63%，GPT 9.76%；二者变量完全匹配同为 7.32%，证据命中均为 0。", "2. **full-context：GPT 准确率更高。** GPT 95.12%，比 DeepSeek 高 4.88 个百分点；变量完全匹配也高 2.44 个百分点。代价是 GPT 平均延迟约为 DeepSeek 的 8.58 倍，总 token 多约 8%。", "3. **RAG：DeepSeek 的端到端结果更好。** DeepSeek 58.54%，GPT 43.90%，差 14.63 个百分点。两者原始证据命中同为 63.90%，说明差距主要来自 GPT 链路/候选约束阶段的 9 个错误，而不能简单归结为检索器召回。", "4. **结构化输出机制不同。** GPT 开启 json_mode，原生 JSON 合规率显著高；DeepSeek 关闭 json_mode，full-context 的有效答案主要依赖确定性 YAML 修复。因此原生格式合规不能作为完全公平的模型能力对比。", "5. **成本无法按美元比较。** 两个接口均未返回价格；只能比较 token 和延迟，不能把 `null` 解释为零费用。", "", "## 4. 效果—成本选择", "", "- 若当前目标是最高准确率与知识库完整性验证：优先 full-context；GPT 本轮上界最高。", "- 若目标是低 token 的在线 Agent：RAG 仍是正确方向，但当前应先修复检索候选约束、组合题召回和错误分层。", "- no-KB 只适合作为必要性基线，不能用于需要源码依据的变量问答。", "", "## 5. 威胁与边界", "", "- GPT 身份只能由中转站的配置与 `response.model` 声明，无法独立核验。", "- 两模型评测日期、网络链路和服务状态不同；延迟与错误率不是纯模型属性。", "- GPT `json_mode=true`、DeepSeek `json_mode=false`，格式合规不完全同条件。", "- RAG 的候选变量、证据 grounding 和本地短路包含检索器/规则贡献，不能把全部变量与证据指标归因给 LLM。", "- challenge v0.3 的 `required_facts` 为空，因此事实覆盖率不具区分度。", ""]
    (CMP_OUT / "report.md").write_text("\n".join(clines), encoding="utf-8")
    print(json.dumps({"gpt_output": str(GPT_OUT), "comparison_output": str(CMP_OUT), "question_count": len(question_map)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
