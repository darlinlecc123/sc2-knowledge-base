"""脱敏诊断 OpenAI-compatible 返回结构；不保存提示词、回答正文或密钥。"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[2]
KNOWLEDGE = ROOT / "knowledge"
sys.path.insert(0, str(KNOWLEDGE / "src"))

from sc2kb.model_clients import DisabledModelClient  # noqa: E402
from sc2kb.qa_agent import QAAgent  # noqa: E402


def _field_metadata(message: Any) -> dict[str, Any]:
    """只记录字段结构和长度，不记录文本内容。"""
    if hasattr(message, "model_dump"):
        data = message.model_dump()
    elif isinstance(message, dict):
        data = dict(message)
    else:
        data = {name: getattr(message, name) for name in dir(message) if not name.startswith("_")}

    metadata: dict[str, Any] = {}
    for key, value in data.items():
        if isinstance(value, str):
            metadata[key] = {"type": "str", "length": len(value), "nonempty": bool(value)}
        elif value is None:
            metadata[key] = {"type": "null", "nonempty": False}
        elif isinstance(value, (list, dict)):
            metadata[key] = {"type": type(value).__name__, "length": len(value), "nonempty": bool(value)}
        else:
            metadata[key] = {"type": type(value).__name__, "nonempty": True}
    return metadata


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--question-id", default="test.002.oral-health-shield")
    parser.add_argument("--questions", default="knowledge/evals/questions_test.jsonl")
    parser.add_argument("--model-config", default="knowledge/evals/configs/deepseek_v4_flash_smoke.yaml")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    output = ROOT / args.output
    if output.exists():
        raise FileExistsError(f"拒绝覆盖已有诊断文件：{output}")

    questions = [json.loads(line) for line in (ROOT / args.questions).read_text(encoding="utf-8").splitlines() if line.strip()]
    question = next(item for item in questions if item["id"] == args.question_id)

    agent = QAAgent(model_client=DisabledModelClient(), context_profile="standard")
    dry = agent.ask(question["question"], dry_run=True, limit=8)
    messages = dry.get("messages")
    if not messages:
        raise RuntimeError("该测试题被本地规则短路，未生成模型消息。")

    raw_config = yaml.safe_load((ROOT / args.model_config).read_text(encoding="utf-8")) or {}
    config = raw_config.get("model", raw_config)
    key_env = str(config.get("api_key_env") or "SC2KB_MODEL_API_KEY")
    api_key = os.getenv(key_env)
    if not api_key:
        raise RuntimeError(f"环境变量 {key_env} 未设置。")

    from openai import OpenAI

    client = OpenAI(api_key=api_key, base_url=config.get("base_url"), timeout=float(config.get("timeout_seconds", 90)))
    started = time.perf_counter()
    response = client.chat.completions.create(
        model=config.get("name") or config.get("model"),
        messages=messages,
        temperature=float(config.get("temperature", 0)),
        max_tokens=int(config.get("max_output_tokens", 800)),
        response_format={"type": "json_object"},
    )
    latency_ms = round((time.perf_counter() - started) * 1000, 3)

    choices = []
    for choice in response.choices:
        choices.append({
            "index": getattr(choice, "index", None),
            "finish_reason": getattr(choice, "finish_reason", None),
            "message_fields": _field_metadata(choice.message),
        })
    usage = response.usage.model_dump() if getattr(response, "usage", None) is not None else None
    result = {
        "schema_version": "1.0.0",
        "date": "2026-09-04",
        "question_id": args.question_id,
        "model": config.get("name") or config.get("model"),
        "base_url": config.get("base_url"),
        "request": {
            "temperature": float(config.get("temperature", 0)),
            "max_output_tokens": int(config.get("max_output_tokens", 800)),
            "response_format": "json_object",
            "message_count": len(messages),
            "prompt_text_saved": False,
        },
        "response": {
            "choice_count": len(response.choices),
            "choices": choices,
            "usage": usage,
            "response_text_saved": False,
            "latency_ms": latency_ms,
        },
        "secrets_saved": False,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
