"""步骤 14 Markdown 报告生成器。"""
from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


def _pct(value: Any) -> str:
    return "未记录" if value is None else f"{float(value) * 100:.2f}%"


def build_markdown(manifest: dict[str, Any], summaries: dict[str, dict[str, Any]],
                   case_results: list[dict[str, Any]]) -> str:
    lines = [
        "# STORM Raw API 知识库自动评测报告",
        "",
        "## 1. 运行信息",
        "",
        f"- 运行 ID：`{manifest['run_id']}`",
        f"- 开始时间：`{manifest['started_at']}`",
        f"- 完成时间：`{manifest.get('finished_at', '未完成')}`",
        f"- 模式：`{manifest['mode']}`",
        f"- benchmark：`{manifest['benchmark_version']}`",
        f"- 知识库版本：`{manifest['knowledge_version']}`",
        f"- 问题文件：`{manifest['question_file']}`",
        f"- 外部模型调用：`{manifest['external_model_test']}`",
        f"- SC2 运行时：`{manifest['sc2_runtime']}`",
        "",
        "## 2. 总体指标",
        "",
        "| 模型/运行标签 | 样本数 | 模型调用 | 可用回答 | 模型错误 | 调用成功率 | 变量命中率 | 事实覆盖率 | 证据命中率 | 禁止断言率 | 拒答正确率 | 行为正确率 | 平均延迟(ms) | Token | 估算费用(USD) |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for label, summary in summaries.items():
        lines.append(
            f"| `{label}` | {summary.get('case_count', 0)} | {summary.get('model_called_count', 0)} | "
            f"{summary.get('model_answered_count', 0)} | {summary.get('model_error_count', 0)} | "
            f"{_pct(summary.get('model_call_success_rate')) if summary.get('model_call_success_rate') is not None else '不适用'} | "
            f"{_pct(summary.get('variable_hit_rate'))} | {_pct(summary.get('required_fact_coverage'))} | "
            f"{_pct(summary.get('evidence_hit_rate'))} | {_pct(summary.get('forbidden_assertion_rate'))} | "
            f"{_pct(summary.get('refusal_accuracy'))} | {_pct(summary.get('behavior_accuracy'))} | "
            f"{summary.get('latency_ms', {}).get('mean', '未记录')} | "
            f"{summary.get('tokens', {}).get('total', '未记录')} | {summary.get('estimated_cost_usd', '未记录')} |"
        )

    lines += ["", "## 3. 分类别结果", ""]
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for item in case_results:
        grouped[(item["model_label"], item["question_meta"]["category"])].append(item)
    lines += ["| 模型/运行标签 | 类别 | 样本数 | 变量命中率 | 事实覆盖率 | 证据命中率 |", "|---|---|---:|---:|---:|---:|"]
    for (label, category), items in sorted(grouped.items()):
        def avg(key: str) -> float:
            return sum(float(x["scores"][key]) for x in items) / len(items)
        lines.append(f"| `{label}` | `{category}` | {len(items)} | {_pct(avg('variable_hit_rate'))} | {_pct(avg('required_fact_coverage'))} | {_pct(avg('evidence_hit_rate'))} |")

    failures = [item for item in case_results if item.get("error") or not item["scores"]["behavior_correct"] or item["scores"]["variable_hit_rate"] < 1 or item["scores"]["forbidden_assertion_rate"] > 0]
    lines += ["", "## 4. 失败或需复核样本", ""]
    if not failures:
        lines.append("没有满足确定性失败条件的样本。")
    else:
        lines += ["| 模型 | 题目 ID | 状态 | 变量命中率 | 禁止断言率 | 单独复现命令 |", "|---|---|---|---:|---:|---|"]
        for item in failures[:50]:
            command = item.get("reproduce_command", "未记录").replace("|", "\\|")
            lines.append(f"| `{item['model_label']}` | `{item['question_id']}` | `{item['agent_result'].get('status')}` | {_pct(item['scores']['variable_hit_rate'])} | {_pct(item['scores']['forbidden_assertion_rate'])} | `{command}` |")

    lines += [
        "", "## 5. 评分边界", "",
        "- 变量、证据、结构化事实、拒答和状态优先采用确定性规则。",
        "- 必需事实的自由文本改写可能被保守规则漏判；结构化 `facts` 可获得更稳定评分。",
        "- 禁止断言率当前只检测明确出现的禁用描述，不能代替语义级人工审计或可选 LLM judge。",
        "- 模型调用、可用回答与模型错误单独统计；runner failure_count=0 不代表 Agent 内部没有 model_error。",
        "- 变量与证据指标可能主要来自检索候选和 grounding，不应直接归因于模型生成。",
        "- 报告中的外部模型、SC2 和费用状态以本次 manifest 为准，不得据此推断未执行实验。",
    ]
    return "\n".join(lines) + "\n"


def write_report(path: str | Path, manifest: dict[str, Any], summaries: dict[str, dict[str, Any]],
                 case_results: list[dict[str, Any]]) -> None:
    Path(path).write_text(build_markdown(manifest, summaries, case_results), encoding="utf-8", newline="\n")
