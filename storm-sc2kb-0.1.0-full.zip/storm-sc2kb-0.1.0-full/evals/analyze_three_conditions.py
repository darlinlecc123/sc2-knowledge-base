from __future__ import annotations
import csv, json
from collections import Counter, defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'knowledge/evals/analysis/20260905_deepseek_three_conditions'
OUT.mkdir(parents=True,exist_ok=True)
RUNS={
 'no_knowledge_base': ROOT/'knowledge/evals/results/20260905_deepseek_challenge_v0.3_no_kb_three_conditions',
 'full_compact_context': ROOT/'knowledge/evals/results/20260905_deepseek_challenge_v0.3_full_compact_three_conditions',
 'retrieval_augmented': ROOT/'knowledge/evals/results/20260905_deepseek_challenge_v0.3_rag_three_conditions',
}

def load_json(p): return json.loads(p.read_text(encoding='utf-8'))
def load_jsonl(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def rate(items,key): return sum(bool(x['scores'].get(key)) for x in items)/len(items) if items else None

def grouped(rows,field):
 d=defaultdict(list)
 for r in rows: d[r['question_meta'][field]].append(r)
 out={}
 for k,v in sorted(d.items()):
  out[k]={
   'count':len(v),'behavior_accuracy':rate(v,'behavior_correct'),'status_accuracy':rate(v,'status_correct'),
   'variable_exact_match_rate':rate(v,'variable_exact_match'),
   'model_error_count':sum(r['agent_result'].get('status')=='model_error' for r in v),
   'model_called_count':sum(bool(r['agent_result'].get('model_called')) for r in v),
   'mean_variable_hit_rate':sum(float(r['scores'].get('variable_hit_rate') or 0) for r in v)/len(v),
   'mean_evidence_hit_rate':sum(float(r['scores'].get('evidence_hit_rate') or 0) for r in v)/len(v),
  }
 return out

payload={'analysis_date':'2026-09-05','model':'deepseek-v4-flash','benchmark':'challenge_v0.3','conditions':{},'comparability_notes':[
 'full_context 实际使用 full_compact_context_v2：包含全部 135 个变量，无检索、无按题裁剪、无截断，但不是原始 Markdown 的逐字副本。',
 'no-KB 与 full-context 的 predicted variables 来自模型 corresponding_variables；RAG 指标包含检索候选和 grounding 贡献，检索指标不可完全等价解释。',
 'challenge v0.3 的 required_facts 为空，因此 required_fact_coverage=1.0 缺乏区分度。',
 'API 未返回价格，estimated_cost_usd 为 null；不得据此推断真实费用为 0。',
]}
all_detail=[]
for cond,run in RUNS.items():
 rows=load_jsonl(run/'results.jsonl'); summary=load_json(run/'summary.json')['models']['deepseek-v4-flash']
 ids=[r['question_id'] for r in rows]
 errors=[r['question_id'] for r in rows if r['agent_result'].get('status')=='model_error']
 behavior_wrong=[r['question_id'] for r in rows if not r['scores'].get('behavior_correct')]
 var_wrong=[r['question_id'] for r in rows if not r['scores'].get('variable_exact_match')]
 evidence_miss=[r['question_id'] for r in rows if float(r['scores'].get('evidence_hit_rate') or 0)<1]
 statuses=Counter(r['agent_result'].get('status') for r in rows)
 payload['conditions'][cond]={
  'run_dir':str(run.relative_to(ROOT)).replace('\\','/'),'summary':summary,'status_distribution':dict(statuses),
  'by_expected_behavior':grouped(rows,'expected_behavior'),'by_category':grouped(rows,'category'),
  'model_error_question_ids':errors,'behavior_wrong_question_ids':behavior_wrong,
  'variable_not_exact_question_ids':var_wrong,'evidence_not_full_question_ids':evidence_miss,
 }
 for r in rows:
  all_detail.append({
   'condition':cond,'question_id':r['question_id'],'category':r['question_meta']['category'],
   'expected_behavior':r['question_meta']['expected_behavior'],'actual_status':r['agent_result'].get('status'),
   'model_called':bool(r['agent_result'].get('model_called')),'behavior_correct':bool(r['scores'].get('behavior_correct')),
   'status_correct':bool(r['scores'].get('status_correct')),'variable_exact_match':bool(r['scores'].get('variable_exact_match')),
   'variable_hit_rate':r['scores'].get('variable_hit_rate'),'variable_precision':r['scores'].get('variable_precision'),
   'evidence_hit_rate':r['scores'].get('evidence_hit_rate'),'tokens':r['runtime'].get('total_tokens'),
   'format_repaired':bool((r['agent_result'].get('model_metadata') or {}).get('format_repaired')),
   'expected_ids':'|'.join(r['question_meta'].get('expected_variable_ids',[]) or []),
   'predicted_ids':'|'.join(r['agent_result'].get('candidate_variable_ids',[]) or []),
   'error_message':(r['agent_result'].get('answer') or {}).get('message') if isinstance(r['agent_result'].get('answer'),dict) else None,
  })

# Pairwise efficiency
base=payload['conditions']['full_compact_context']['summary']['tokens']['total']
rag=payload['conditions']['retrieval_augmented']['summary']['tokens']['total']
no=payload['conditions']['no_knowledge_base']['summary']['tokens']['total']
payload['comparisons']={
 'rag_token_reduction_vs_full':1-rag/base,
 'rag_total_tokens_as_fraction_of_full':rag/base,
 'full_total_tokens_vs_rag_multiple':base/rag,
 'no_kb_total_tokens_as_fraction_of_full':no/base,
 'behavior_accuracy_ranking':sorted(((c,d['summary']['behavior_accuracy']) for c,d in payload['conditions'].items()),key=lambda x:x[1],reverse=True),
 'variable_exact_match_ranking':sorted(((c,d['summary']['variable_exact_match_rate']) for c,d in payload['conditions'].items()),key=lambda x:x[1],reverse=True),
}
(OUT/'analysis.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with (OUT/'per_question.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(all_detail[0])); w.writeheader(); w.writerows(all_detail)

# Markdown
names={'no_knowledge_base':'无知识库','full_compact_context':'全量紧凑上下文','retrieval_augmented':'RAG'}
lines=['# DeepSeek 三条件 challenge v0.3 评测分析','','- 日期：2026-09-05','- 模型：`deepseek-v4-flash`','- 题集：冻结的 `challenge v0.3`，41 题','- 统一参数：temperature=0、thinking=disabled、json_mode=false、max_output_tokens=2000、max_retries=0','','## 1. 总体结果','','| 条件 | 有效响应 | 模型错误 | 行为准确率 | 变量命中率 | 变量精确率 | 变量完全匹配 | 证据命中率 | 总 tokens | 平均延迟 |','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
for c in ('no_knowledge_base','full_compact_context','retrieval_augmented'):
 s=payload['conditions'][c]['summary']; lines.append(f"| {names[c]} | {s['model_valid_response_count']}/{s['model_called_count']} | {s['model_error_count']} | {s['behavior_accuracy']:.2%} | {s['variable_hit_rate']:.2%} | {s['variable_precision']:.2%} | {s['variable_exact_match_rate']:.2%} | {s['evidence_hit_rate']:.2%} | {int(s['tokens']['total']):,} | {s['latency_ms']['mean']:.0f} ms |")
lines += ['','## 2. 核心结论','',
 f"1. **全量紧凑上下文准确率最高**：行为准确率 {payload['conditions']['full_compact_context']['summary']['behavior_accuracy']:.2%}，变量完全匹配率 {payload['conditions']['full_compact_context']['summary']['variable_exact_match_rate']:.2%}。",
 f"2. **RAG 显著节省 token，但当前检索泛化仍是主要瓶颈**：RAG 总 token 比 full-context 少 {payload['comparisons']['rag_token_reduction_vs_full']:.2%}，但行为准确率下降到 {payload['conditions']['retrieval_augmented']['summary']['behavior_accuracy']:.2%}，变量完全匹配率仅 {payload['conditions']['retrieval_augmented']['summary']['variable_exact_match_rate']:.2%}。",
 f"3. **无知识库基线符合预期地弱**：行为准确率仅 {payload['conditions']['no_knowledge_base']['summary']['behavior_accuracy']:.2%}，证据命中率为 0；说明当前任务确实需要项目知识上下文。",
 '4. **DeepSeek 输出格式稳定性存在明显差异**：full-context 的 40 个有效响应全部经过确定性 YAML 恢复；RAG 的有效模型响应均为原生 JSON；no-KB 有 31 个 YAML 恢复和 10 个格式错误。',
 '5. **不能用 required_fact_coverage 判断三者优劣**：challenge v0.3 的 required_facts 为空，三组该指标均为 1.0。','',
 '## 3. 按期望行为分组','','| 条件 | 分组 | 题数 | 行为准确率 | 变量完全匹配 | 模型错误 |','|---|---|---:|---:|---:|---:|']
for c in ('no_knowledge_base','full_compact_context','retrieval_augmented'):
 for k,v in payload['conditions'][c]['by_expected_behavior'].items(): lines.append(f"| {names[c]} | {k} | {v['count']} | {v['behavior_accuracy']:.2%} | {v['variable_exact_match_rate']:.2%} | {v['model_error_count']} |")
lines += ['','## 4. 失败题目','','### 全量紧凑上下文','',f"- 模型错误：`{', '.join(payload['conditions']['full_compact_context']['model_error_question_ids']) or '无'}`",f"- 行为判断错误：`{', '.join(payload['conditions']['full_compact_context']['behavior_wrong_question_ids']) or '无'}`",f"- 变量未完全匹配：`{', '.join(payload['conditions']['full_compact_context']['variable_not_exact_question_ids']) or '无'}`",'','### RAG','',f"- 模型错误：`{', '.join(payload['conditions']['retrieval_augmented']['model_error_question_ids']) or '无'}`",f"- 行为判断错误：`{', '.join(payload['conditions']['retrieval_augmented']['behavior_wrong_question_ids']) or '无'}`",f"- 变量未完全匹配：`{', '.join(payload['conditions']['retrieval_augmented']['variable_not_exact_question_ids']) or '无'}`",'','## 5. 解释边界','',
 '- full-context 使用 `full_compact_context_v2`：135/135 变量全覆盖，无检索、无按题裁剪、无截断；但不是原始 Markdown 的逐字全文。',
 '- no-KB/full-context 的变量 ID 来自模型回答；RAG 的候选变量和 grounding 含检索器贡献，所以变量/证据指标应结合行为准确率一起看。',
 '- `estimated_cost_usd` 为 null 只表示接口未回传价格，不能解释为零费用。',
 '- 本轮关闭 thinking，与 2026-09-04 默认 thinking 的旧 RAG 复测不是完全同参数复现。','',
 '## 6. 建议','',
 '1. 下一轮优先修复 RAG 的查询归一化、别名召回、多变量组合题和歧义判定，不要针对 challenge v0.3 逐题写规则。',
 '2. 建立独立开发集做检索器调参；challenge v0.3 保持冻结，只用于阶段性回归。',
 '3. 为 full-context 单独保留 YAML 恢复审计指标；若用于生产 Agent，应要求原生结构化输出或增加独立 schema validator。',
 '4. 给题集补充非空 `required_facts`，否则事实覆盖率指标无法发挥作用。','']
(OUT/'report.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({'output_dir':str(OUT),'comparisons':payload['comparisons'],'failures':{c:{'model_error':d['model_error_question_ids'],'behavior_wrong':d['behavior_wrong_question_ids']} for c,d in payload['conditions'].items()}},ensure_ascii=False,indent=2))
