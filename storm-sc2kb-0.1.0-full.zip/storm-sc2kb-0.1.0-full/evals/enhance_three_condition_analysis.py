from __future__ import annotations
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'knowledge/evals/analysis/20260905_deepseek_three_conditions'
analysis=json.loads((OUT/'analysis.json').read_text(encoding='utf-8'))
questions={x['id']:x for x in [json.loads(l) for l in (ROOT/'knowledge/evals/questions_challenge_v0.3.jsonl').read_text(encoding='utf-8').splitlines() if l.strip()]}
runs={
 'no_knowledge_base':ROOT/'knowledge/evals/results/20260905_deepseek_challenge_v0.3_no_kb_three_conditions/results.jsonl',
 'full_compact_context':ROOT/'knowledge/evals/results/20260905_deepseek_challenge_v0.3_full_compact_three_conditions/results.jsonl',
 'retrieval_augmented':ROOT/'knowledge/evals/results/20260905_deepseek_challenge_v0.3_rag_three_conditions/results.jsonl'}
for cond,path in runs.items():
 rows=[json.loads(l) for l in path.read_text(encoding='utf-8').splitlines() if l.strip()]
 exact=hit=precision=0.0
 for r in rows:
  expected=set(questions[r['question_id']].get('expected_variable_ids') or [])
  ans=r['agent_result'].get('answer') or {}; predicted=set(ans.get('corresponding_variables') or []) if isinstance(ans,dict) else set()
  if not predicted and isinstance(ans,dict) and isinstance(ans.get('candidate_explanations'),list): predicted={x.get('variable_id') for x in ans['candidate_explanations'] if isinstance(x,dict) and x.get('variable_id')}
  exact += predicted == expected
  hit += len(predicted & expected)/len(expected) if expected else float(not predicted)
  precision += len(predicted & expected)/len(predicted) if predicted else float(not expected)
 analysis['conditions'][cond]['answer_variable_id_metrics']={'exact_match_rate':exact/len(rows),'hit_rate':hit/len(rows),'precision':precision/len(rows)}
 analysis['conditions'][cond]['model_called_latency_mean_ms']=sum(r['runtime']['latency_ms'] for r in rows if r['agent_result'].get('model_called'))/sum(bool(r['agent_result'].get('model_called')) for r in rows)
(OUT/'analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

n={'no_knowledge_base':'无知识库','full_compact_context':'全量紧凑上下文','retrieval_augmented':'RAG'}
lines=['# DeepSeek 三条件 challenge v0.3 评测分析','','- 日期：2026-09-05','- 模型：`deepseek-v4-flash`','- 题集：冻结的 `challenge v0.3`，41 题','- 统一参数：`temperature=0`、`thinking=disabled`、`json_mode=false`、`max_output_tokens=2000`、`max_retries=0`','','## 1. 总体结果','','| 条件 | 有效响应 | 模型错误 | 行为准确率 | 变量命中率* | 变量精确率* | 变量完全匹配* | 证据命中率* | 总 tokens | 模型调用平均延迟 |','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
for c in n:
 s=analysis['conditions'][c]['summary']; lines.append(f"| {n[c]} | {s['model_valid_response_count']}/{s['model_called_count']} | {s['model_error_count']} | {s['behavior_accuracy']:.2%} | {s['variable_hit_rate']:.2%} | {s['variable_precision']:.2%} | {s['variable_exact_match_rate']:.2%} | {s['evidence_hit_rate']:.2%} | {int(s['tokens']['total']):,} | {analysis['conditions'][c]['model_called_latency_mean_ms']:.0f} ms |")
lines += ['','* 原始 RAG 变量/证据指标包含检索候选与 grounding 贡献，不能直接等同于模型最终引用。','','## 2. 模型最终变量 ID 的统一口径','','| 条件 | 命中率 | 精确率 | 完全匹配率 |','|---|---:|---:|---:|']
for c in n:
 m=analysis['conditions'][c]['answer_variable_id_metrics']; lines.append(f"| {n[c]} | {m['hit_rate']:.2%} | {m['precision']:.2%} | {m['exact_match_rate']:.2%} |")
lines += ['','该口径读取最终答案的 `corresponding_variables`；歧义本地短路题读取 `candidate_explanations`。RAG 的最终变量完全匹配率为 21.95%，比检索候选口径的 14.63% 略高，但仍远低于 full-context 的 90.24%。','','## 3. 核心结论','',
 '1. **知识库有效性得到验证。** 无知识库条件行为准确率只有 14.63%，加入全量知识上下文后升至 90.24%，提升 75.61 个百分点。',
 '2. **当前最准确方案是全量紧凑上下文。** 35 道应回答题中答对 34 道；3 道应拒答题全部正确。主要短板不是知识缺失，而是歧义题不会主动澄清。',
 f"3. **RAG 具有明显效率优势。** 总 token 为 82,502，仅为 full-context 的 {analysis['comparisons']['rag_total_tokens_as_fraction_of_full']:.2%}，节省 {analysis['comparisons']['rag_token_reduction_vs_full']:.2%}，但行为准确率只有 58.54%。",
 '4. **RAG 的主要瓶颈在检索而不是生成。** 12 道范围内题因检索为空直接 `not_found`；另有 2 道模型引用检索候选之外的正确或相关变量，被验证器拒绝。',
 '5. **DeepSeek 的格式稳定性依赖上下文形态。** full-context 的 40 个有效响应全部经过确定性 YAML 恢复，原生 JSON 合规率为 0%；RAG 的 24 个有效模型响应均为原生 JSON；no-KB 有 31 个可恢复响应和 10 个格式错误。',
 '6. **`required_fact_coverage=1.0` 本轮没有解释力。** challenge v0.3 的 `required_facts` 为空，应在未来题集版本补充事实级金标准。','','## 4. 按期望行为分组','','| 条件 | 类型 | 题数 | 行为准确率 | 变量完全匹配率（原评分） | 模型错误 |','|---|---|---:|---:|---:|---:|']
for c in n:
 for k,v in analysis['conditions'][c]['by_expected_behavior'].items(): lines.append(f"| {n[c]} | {k} | {v['count']} | {v['behavior_accuracy']:.2%} | {v['variable_exact_match_rate']:.2%} | {v['model_error_count']} |")
lines += ['','## 5. 失败机理','','### 5.1 全量紧凑上下文','','- `challenge.v0.3.034.llm-usage-bundle`：唯一格式解析失败题。','- 3 道歧义题（HP、alliance、range）均找全候选变量，却直接回答为 `answered`，未返回 `ambiguous` 和澄清问题。','- 3 道应回答题出现相邻变量过召回：health 题额外加入 ratio，shield/armor 题额外加入 shield_ratio，action queue 题额外加入 action.units。','','### 5.2 RAG','','- **检索空结果导致错误拒答（12 题）**：跨 Raw→ABox 链、TBox 组合字段、ABox 边、图计数、战术计数、非法动作、玩家 supply、SWM 结果封装等组合题。','- **候选约束冲突（2 题）**：FunctionCall 通用 payload 与 function-id family 中，模型引用了候选集外变量，被验证器拒绝。','- **歧义处理失败（2 题）**：alliance 和 range 找到多个层级后仍直接回答。','- **范围外误召回（1 题）**：camera zoom 被错误关联到 `pysc2.function.raw_flag` 后回答。','','### 5.3 无知识库','','- 35 道应回答题全部失败，符合“不能凭模型常识证明当前仓库接口和源码”的预期。','- 3 道应澄清题和 3 道应拒答题全部行为正确，因此 14.63% 的准确率主要来自保守拒答策略。','','## 6. 成本与延迟','','- full-context：1,214,822 tokens，41 次调用，平均每题约 29,630 tokens。','- RAG：82,502 tokens，26 次调用、15 次本地短路；按真实模型调用计算平均延迟约 4,203 ms。','- no-KB：20,301 tokens，41 次调用，平均每题约 495 tokens。','- 接口没有返回费用，`estimated_cost_usd=null` 不代表费用为 0。','','## 7. 结论与下一步','','**结论：第一版知识库本体已经能够支持 DeepSeek 高准确回答；当前工程瓶颈是 RAG 检索召回和歧义控制，而不是变量记录覆盖不足。**','','建议按以下优先级继续：','','1. 在独立开发集上改进组合问题的查询拆分、别名归一化和多变量召回；不得针对冻结 challenge v0.3 逐题写规则。','2. 将“候选集外变量”分成真正幻觉与检索漏召回两类，避免验证器把正确补充一律判错。','3. 增加显式歧义策略：多个层级同名量同时命中时，优先返回 `ambiguous` 和澄清问题。','4. 新建 challenge v0.4 前补充非空 `required_facts`，并继续冻结后只做阶段性回归。','5. full-context 可作为准确率上界和知识库完整性验证，不适合作为默认生产方案；生产目标应是把 RAG 准确率逼近该上界。','','## 8. 可复现文件','','- 无知识库结果：`knowledge/evals/results/20260905_deepseek_challenge_v0.3_no_kb_three_conditions/`','- 全量上下文结果：`knowledge/evals/results/20260905_deepseek_challenge_v0.3_full_compact_three_conditions/`','- RAG 结果：`knowledge/evals/results/20260905_deepseek_challenge_v0.3_rag_three_conditions/`','- 机器可读分析：`knowledge/evals/analysis/20260905_deepseek_three_conditions/analysis.json`','- 逐题表：`knowledge/evals/analysis/20260905_deepseek_three_conditions/per_question.csv`','']
(OUT/'report.md').write_text('\n'.join(lines),encoding='utf-8')
print('ENHANCED_ANALYSIS_OK')

