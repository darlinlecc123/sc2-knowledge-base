"""步骤 14 确定性评分器。

不调用 LLM judge。文本匹配是保守基线，结构化字段优先。
"""
from __future__ import annotations

import json
import re
from typing import Any


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _norm(value: Any) -> str:
    text = value if isinstance(value, str) else _json(value)
    return re.sub(r"[\s`*_'\"，。；：、,.():（）\[\]{}]+", "", text).lower()


def _walk(value: Any):
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from _walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk(child)


def _answer_payload(agent_result: dict[str, Any]) -> Any:
    return agent_result.get("answer")


def predicted_variable_ids(agent_result: dict[str, Any]) -> set[str]:
    ids: set[str] = set(agent_result.get("candidate_variable_ids") or [])
    answer = agent_result.get("answer")
    if isinstance(answer, dict):
        ids.update(x for x in answer.get("corresponding_variables", []) if isinstance(x, str))
        ids.update(x for x in answer.get("candidate_variable_ids", []) if isinstance(x, str))
        for item in answer.get("candidate_explanations", []):
            if isinstance(item, dict) and isinstance(item.get("variable_id"), str):
                ids.add(item["variable_id"])
    grounding = agent_result.get("grounding") or {}
    ids.update(x for x in grounding.get("variable_ids", []) if isinstance(x, str))
    return ids


def _leaf_atoms(value: Any) -> list[str]:
    """抽取适合保守文本匹配的非空叶子；忽略过短通用状态词。"""
    atoms: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"description", "notes"}:
                continue
            atoms.extend(_leaf_atoms(child))
    elif isinstance(value, list):
        for child in value:
            atoms.extend(_leaf_atoms(child))
    elif value is not None and value != "":
        text = str(value)
        if len(_norm(text)) >= 2 or isinstance(value, (int, float, bool)):
            atoms.append(text)
    return atoms


def fact_coverage(required_fact: dict[str, Any], answer: Any) -> float:
    if answer is None:
        return 0.0
    # 模型或模拟器若返回结构化 facts，优先精确匹配。
    for node in _walk(answer):
        if isinstance(node, dict) and node == required_fact:
            return 1.0
    answer_norm = _norm(answer)
    value = required_fact.get("value")
    if isinstance(value, str):
        return float(bool(_norm(value)) and _norm(value) in answer_norm)
    atoms = _leaf_atoms(value)
    if not atoms:
        return 0.0
    matched = sum(_norm(atom) in answer_norm for atom in atoms)
    return matched / len(atoms)


def evidence_coverage(required: dict[str, Any], agent_result: dict[str, Any]) -> float:
    searchable = {
        "answer": agent_result.get("answer"),
        "grounding": agent_result.get("grounding"),
    }
    text = _norm(searchable)
    needles = [required.get("evidence_id"), required.get("path"), required.get("symbol")]
    needles = [needle for needle in needles if needle]
    if not needles:
        return 0.0
    # evidence id 或源码 path 命中即可；symbol 作为补充。
    primary = [required.get("evidence_id"), required.get("path")]
    primary = [x for x in primary if x]
    if any(_norm(x) in text for x in primary):
        return 1.0
    return float(any(_norm(x) in text for x in needles))


def forbidden_claim_hits(forbidden_claims: list[str], answer: Any) -> list[str]:
    """只报告答案中明确出现的禁用描述；语义等价误述留给人工/可选 judge。"""
    text = _norm(answer)
    return [claim for claim in forbidden_claims if _norm(claim) and _norm(claim) in text]


def _is_refusal(agent_result: dict[str, Any]) -> bool:
    if agent_result.get("status") == "not_found":
        return True
    answer = agent_result.get("answer")
    if isinstance(answer, dict) and ("refusal" in answer or answer.get("refused") is True):
        return True
    text = _norm(answer)
    return any(_norm(marker) in text for marker in ("拒绝编造", "知识库没有依据", "outofscope"))


def score_case(question: dict[str, Any], agent_result: dict[str, Any]) -> dict[str, Any]:
    expected = set(question.get("expected_variable_ids") or [])
    predicted = predicted_variable_ids(agent_result)
    if expected:
        variable_hit_rate = len(expected & predicted) / len(expected)
        variable_precision = len(expected & predicted) / len(predicted) if predicted else 0.0
    else:
        variable_hit_rate = 1.0 if not predicted else 0.0
        variable_precision = 1.0 if not predicted else 0.0

    facts = question.get("required_facts") or []
    fact_scores = [fact_coverage(item, _answer_payload(agent_result)) for item in facts]
    evidences = question.get("required_evidence") or []
    evidence_scores = [evidence_coverage(item, agent_result) for item in evidences]
    forbidden = question.get("forbidden_claims") or []
    hits = forbidden_claim_hits(forbidden, _answer_payload(agent_result))

    expected_behavior = question.get("expected_behavior")
    refused = _is_refusal(agent_result)
    refusal_correct = (refused if expected_behavior == "refuse" else not refused)
    if expected_behavior == "clarify":
        behavior_correct = agent_result.get("status") == "ambiguous"
    elif expected_behavior == "refuse":
        behavior_correct = refused
    else:
        behavior_correct = agent_result.get("status") in {"answered", "ready", "found"} and not refused

    expected_status = question.get("expected_status")
    actual_status = agent_result.get("status")
    normalized_actual = "found" if actual_status in {"ready", "answered"} else actual_status
    status_correct = normalized_actual == expected_status

    return {
        "expected_variable_ids": sorted(expected),
        "predicted_variable_ids": sorted(predicted),
        "variable_hit_rate": round(variable_hit_rate, 6),
        "variable_precision": round(variable_precision, 6),
        "variable_exact_match": expected == predicted,
        "required_fact_coverage": round(sum(fact_scores) / len(fact_scores), 6) if fact_scores else 1.0,
        "fact_item_scores": [round(x, 6) for x in fact_scores],
        "evidence_hit_rate": round(sum(evidence_scores) / len(evidence_scores), 6) if evidence_scores else 1.0,
        "evidence_item_scores": [round(x, 6) for x in evidence_scores],
        "forbidden_assertion_rate": round(len(hits) / len(forbidden), 6) if forbidden else 0.0,
        "forbidden_claim_hits": hits,
        "refusal_correct": bool(refusal_correct),
        "behavior_correct": bool(behavior_correct),
        "status_correct": bool(status_correct),
        "expected_behavior": expected_behavior,
        "expected_status": expected_status,
        "actual_status": actual_status,
    }


def aggregate(case_results: list[dict[str, Any]]) -> dict[str, Any]:
    if not case_results:
        return {"case_count": 0}
    scores = [item["scores"] for item in case_results]
    def mean(key: str) -> float:
        return round(sum(float(score[key]) for score in scores) / len(scores), 6)
    latencies = [float(item["runtime"]["latency_ms"]) for item in case_results]
    token_values = [item["runtime"].get("total_tokens") for item in case_results]
    known_tokens = [float(x) for x in token_values if isinstance(x, (int, float))]
    costs = [item["runtime"].get("estimated_cost_usd") for item in case_results]
    known_costs = [float(x) for x in costs if isinstance(x, (int, float))]
    model_called_count = sum(bool(item.get("agent_result", {}).get("model_called")) for item in case_results)
    model_answered_count = sum(
        item.get("agent_result", {}).get("status") == "answered" and bool(item.get("agent_result", {}).get("model_called"))
        for item in case_results
    )
    model_error_count = sum(item.get("agent_result", {}).get("status") == "model_error" for item in case_results)
    local_short_circuit_count = len(case_results) - model_called_count
    model_valid_response_count = sum(
        bool(item.get("agent_result", {}).get("model_called"))
        and item.get("agent_result", {}).get("status") != "model_error"
        for item in case_results
    )
    format_repaired_count = sum(
        bool((item.get("agent_result", {}).get("model_metadata") or {}).get("format_repaired"))
        for item in case_results
    )
    truncated_output_count = sum(
        (item.get("agent_result", {}).get("model_metadata") or {}).get("failure_reason")
        == "output_truncated_before_final_content"
        for item in case_results
    )
    empty_final_content_count = sum(
        (item.get("agent_result", {}).get("model_metadata") or {}).get("failure_reason")
        in {"empty_model_content", "reasoning_present_but_final_content_empty", "output_truncated_before_final_content"}
        for item in case_results
    )
    return {
        "case_count": len(case_results),
        "model_called_count": model_called_count,
        "local_short_circuit_count": local_short_circuit_count,
        "model_answered_count": model_answered_count,
        "model_error_count": model_error_count,
        "model_call_success_rate": round(model_answered_count / model_called_count, 6) if model_called_count else None,
        "model_valid_response_count": model_valid_response_count,
        "model_response_success_rate": round(model_valid_response_count / model_called_count, 6) if model_called_count else None,
        "format_repaired_count": format_repaired_count,
        "native_json_compliance_rate": round((model_called_count - format_repaired_count - model_error_count) / model_called_count, 6) if model_called_count else None,
        "empty_final_content_count": empty_final_content_count,
        "truncated_output_count": truncated_output_count,
        "variable_hit_rate": mean("variable_hit_rate"),
        "variable_precision": mean("variable_precision"),
        "variable_exact_match_rate": round(sum(s["variable_exact_match"] for s in scores) / len(scores), 6),
        "required_fact_coverage": mean("required_fact_coverage"),
        "evidence_hit_rate": mean("evidence_hit_rate"),
        "forbidden_assertion_rate": mean("forbidden_assertion_rate"),
        "refusal_accuracy": round(sum(s["refusal_correct"] for s in scores) / len(scores), 6),
        "behavior_accuracy": round(sum(s["behavior_correct"] for s in scores) / len(scores), 6),
        "status_accuracy": round(sum(s["status_correct"] for s in scores) / len(scores), 6),
        "latency_ms": {
            "mean": round(sum(latencies) / len(latencies), 3),
            "min": round(min(latencies), 3),
            "max": round(max(latencies), 3),
        },
        "tokens": {
            "available_cases": len(known_tokens),
            "total": round(sum(known_tokens), 3) if known_tokens else None,
            "mean": round(sum(known_tokens) / len(known_tokens), 3) if known_tokens else None,
        },
        "estimated_cost_usd": round(sum(known_costs), 8) if known_costs else None,
        "failure_count": sum(item.get("error") is not None for item in case_results),
        "runner_failure_count": sum(item.get("error") is not None for item in case_results),
    }
